export { createConsoleHttpClient, ConsoleTransportError } from './client/api.js';
export { mountTeamsConsole, TeamsConsoleController } from './client/index.js';
export type { ConsoleHttpClientOptions } from './client/api.js';
export type { ConsoleClientV1, ConsoleCommandResultV1, ConsoleCommandV1, ConsoleProjectionV1, ConsoleProviderView, JsonValue, ServiceError } from './client/protocol.js';
export type { MountTeamsConsoleOptions, MountedTeamsConsole } from './client/index.js';
