export declare const teamsStyles: string;
