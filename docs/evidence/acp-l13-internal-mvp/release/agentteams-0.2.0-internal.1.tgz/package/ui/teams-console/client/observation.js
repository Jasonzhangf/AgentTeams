import { parseConsoleProjectionSnapshot } from "./protocol.js";
export class ProjectionObservationController {
    options;
    expectedSeq = null;
    health = { state: 'live' };
    projection = null;
    unsubscribe = null;
    constructor(options) {
        this.options = options;
    }
    start() {
        if (this.unsubscribe !== null)
            return;
        this.unsubscribe = this.options.subscribe();
        this.emit('live');
    }
    stop() {
        if (this.unsubscribe === null)
            return;
        this.unsubscribe();
        this.unsubscribe = null;
    }
    onSnapshot(snapshot) {
        const parsed = parseConsoleProjectionSnapshot(snapshot);
        if (this.expectedSeq === null || parsed.seq >= this.expectedSeq) {
            this.expectedSeq = parsed.seq + 1;
            this.projection = parsed.projection;
            this.health = { state: 'live' };
            this.options.onSnapshot(parsed.projection);
            this.emit('live');
            return;
        }
        this.health = { state: 'degraded', reason: 'projection-loss', detail: `Missing projection sequence ${this.expectedSeq}`, droppedEvents: this.expectedSeq - parsed.seq };
        this.emit('stale');
    }
    onHealth(state) {
        this.health = state;
        this.emit(state.state === 'live' ? 'live' : 'stale');
    }
    getSnapshot() {
        return { projection: this.projection, observation: this.health.state === 'live' ? 'live' : 'stale', health: this.health };
    }
    emit(observation) {
        this.options.onObservation({ projection: this.projection, observation, health: this.health });
    }
}
