import { createFixtureClient } from "./fixture.js";
import { mountTeamsConsole } from "./client/index.js";
const root = document.querySelector('#app');
if (root === null)
    throw new Error('Teams fixture requires #app');
mountTeamsConsole(root, createFixtureClient(), {
    initialOpen: true,
    locale: 'en',
    fixtureLabel: 'Browser fixture — host projection only; not live daemon/device E2E',
});
