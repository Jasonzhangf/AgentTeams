export declare function containDrawerTab(root: HTMLElement, event: KeyboardEvent): boolean;
