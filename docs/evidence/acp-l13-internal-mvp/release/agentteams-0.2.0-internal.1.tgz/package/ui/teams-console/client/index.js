import { TeamsConsoleController } from "./controller.js";
import { containDrawerTab } from "./focus.js";
import { renderConsole } from "./render.js";
import { teamsStyles } from "./styles.js";
function installStyles() {
    if (document.getElementById('teams-console-styles') !== null)
        return;
    const style = document.createElement('style');
    style.id = 'teams-console-styles';
    style.textContent = teamsStyles;
    document.head.append(style);
}
export function mountTeamsConsole(root, client, options = {}) {
    installStyles();
    const controller = new TeamsConsoleController(client, { ...options });
    if (options.locale !== undefined)
        controller.setLocale(options.locale);
    let renderedState = controller.getSnapshot();
    let consoleFocusKey;
    const drawerFocusKeys = [];
    const activeFocusKey = () => document.activeElement instanceof HTMLElement ? document.activeElement.dataset.focusKey : undefined;
    const restoreFocus = (focusKey) => {
        if (focusKey === undefined)
            return;
        const target = [...root.querySelectorAll('[data-focus-key]')].find(candidate => candidate.dataset.focusKey === focusKey);
        target?.focus();
    };
    const render = () => {
        const nextState = controller.getSnapshot();
        if (!renderedState.open && nextState.open)
            consoleFocusKey = activeFocusKey();
        const drawerOpened = nextState.drawerStack.length > renderedState.drawerStack.length;
        if (drawerOpened)
            drawerFocusKeys.push(activeFocusKey());
        let drawerFocusKey;
        while (drawerFocusKeys.length > nextState.drawerStack.length)
            drawerFocusKey = drawerFocusKeys.pop();
        const restoreConsole = renderedState.open && !nextState.open;
        const restoreDrawer = nextState.open && nextState.drawerStack.length < renderedState.drawerStack.length;
        renderConsole(root, controller, options);
        if (drawerOpened)
            root.querySelector('.teams-drawer-header')?.focus();
        else if (restoreConsole)
            restoreFocus(consoleFocusKey);
        else if (restoreDrawer)
            restoreFocus(drawerFocusKey);
        renderedState = nextState;
    };
    const unsubscribe = controller.subscribe(render);
    const onKeyDown = (event) => {
        if (event.key === 'Tab' && controller.getSnapshot().drawer !== null) {
            containDrawerTab(root, event);
            return;
        }
        if (event.key !== 'Escape' || !controller.getSnapshot().open)
            return;
        event.preventDefault();
        if (controller.getSnapshot().drawer !== null)
            controller.closeDrawer();
        else
            controller.closeConsole();
    };
    document.addEventListener('keydown', onKeyDown);
    render();
    if (options.initialOpen === true)
        controller.openConsole();
    // The mount owns the observation lifecycle: the controller builds the observation
    // controller for a live client in its constructor but never starts it, and nothing else in
    // the product called startObservation(), so the page opened no /api/v1/events stream and
    // received no live snapshot. start() and destroy() are both no-ops for a fixture client.
    controller.startObservation();
    return {
        controller,
        destroy: () => {
            unsubscribe();
            document.removeEventListener('keydown', onKeyDown);
            controller.destroy();
            root.replaceChildren();
        },
    };
}
export { TeamsConsoleController };
