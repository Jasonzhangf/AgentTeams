import type { ConsoleClientV1, ConsoleProviderView, HistoryPage, HistoryQuery, JsonValue } from './protocol.js';
import { type DraftPersistence } from './drafts.js';
import { type ObservationSession } from './observation.js';
import { type NetworkMemberDraft } from './page-networking.js';
import type { ConsoleEntry, TeamPage } from './model.js';
export type DrawerState = {
    readonly kind: 'agent';
    readonly agentId: string;
} | {
    readonly kind: 'session';
    readonly agentId: string;
    readonly sessionId: string;
} | {
    readonly kind: 'settings';
    readonly agentId?: string;
};
export interface ProviderDraft {
    readonly id: string;
    readonly label: string;
    readonly protocol: 'openai-chat' | 'openai-responses';
    readonly apiBaseUrl: string;
    readonly enabled: boolean;
    readonly authKind: 'none' | 'bearer';
    readonly credentialRef: string;
}
export interface ConsoleState {
    readonly open: boolean;
    readonly entry: ConsoleEntry;
    readonly drawer: DrawerState | null;
    readonly drawerStack: readonly DrawerState[];
    readonly drawerExpanded: boolean;
    readonly projection: import('./protocol.js').ConsoleProjectionV1 | null;
    readonly status: 'idle' | 'loading' | 'ready' | 'error';
    readonly error: string | null;
    readonly notice: string | null;
    readonly busy: string | null;
    readonly query: string;
    readonly locale: 'en' | 'zh';
    readonly selectedAgentId: string | undefined;
    readonly providerFormOpen: boolean;
    readonly editingProviderId: string | undefined;
    readonly providerDraft: ProviderDraft;
    readonly live: boolean;
    readonly page: TeamPage;
    readonly observation: ObservationSession;
    readonly messageDraft: string;
    readonly selectedSessionId: string | undefined;
    readonly cancelState: 'idle' | 'requested' | 'confirmed' | 'unknown';
    readonly membershipDraft: readonly NetworkMemberDraft[];
    readonly historyStatus: 'idle' | 'loading' | 'ready' | 'refused' | 'error';
    readonly history: HistoryPage | null;
    readonly historyError: {
        readonly code: string;
        readonly message: string;
    } | null;
    readonly historyNextBeforeSequence: number | undefined;
    readonly refusedError: {
        readonly code: string;
        readonly message: string;
    } | null;
    readonly lastFocusKey: string | undefined;
}
export declare const emptyProviderDraft: ProviderDraft;
export declare const initialConsoleState: ConsoleState;
export declare class TeamsConsoleController {
    private state;
    private readonly listeners;
    private readonly client;
    private readonly liveClient?;
    private readonly persistence?;
    private observationController?;
    private readonly timers;
    constructor(client: ConsoleClientV1, options?: {
        readonly persistence?: DraftPersistence;
        readonly initialPage?: TeamPage;
    });
    getSnapshot: () => ConsoleState;
    subscribe: (listener: () => void) => (() => void);
    startObservation(): void;
    destroy(): void;
    setFocusKey(focusKey: string | undefined): void;
    private observeLiveProjection;
    private update;
    private isTeamsLiveClient;
    private scheduleTimer;
    private loadProjection;
    refresh(): Promise<void>;
    openConsole(): void;
    closeConsole(): void;
    selectEntry(entry: ConsoleEntry): void;
    selectPage(page: TeamPage): void;
    /**
     * The history view owns no initial read. Its only other trigger is the "previous" control,
     * which is disabled until a page has already been read, so without this the view is a dead
     * end that can never show a record. The first read happens when the view is opened.
     */
    private ensureHistoryLoaded;
    setMessageDraft(message: string): void;
    selectSessionSessionId(sessionId: string | undefined): void;
    setMembershipDraft(draft: readonly NetworkMemberDraft[]): void;
    connectAgent(agentId: string): Promise<boolean>;
    applyMembership(expectedRevision: number, members: readonly NetworkMemberDraft[]): Promise<boolean>;
    selectNetworkMember(agentId: string, role: 'master' | 'peer'): void;
    loadHistory(query?: Partial<HistoryQuery>): Promise<boolean>;
    loadRequestHistory(query?: Partial<HistoryQuery>): Promise<boolean>;
    private runRefusedAction;
    setLocale(locale: 'en' | 'zh'): void;
    setQuery(query: string): void;
    openAgent(agentId: string): void;
    openSession(agentId: string, sessionId: string): void;
    openSettings(agentId?: string): void;
    closeDrawer(): void;
    toggleDrawerExpanded(): void;
    selectAgent(agentId: string): void;
    private pushDrawer;
    beginAddProvider(): void;
    closeProviderForm(): void;
    editProvider(provider: ConsoleProviderView): void;
    setProviderDraft<K extends keyof ProviderDraft>(key: K, value: ProviderDraft[K]): void;
    setProviderAuthKind(authKind: ProviderDraft['authKind']): void;
    private refreshAfterAction;
    private runAction;
    openSessionCommand(agentId: string, sessionId: string): Promise<boolean>;
    createSession(agentId: string, title?: string): Promise<boolean>;
    cancelSession(agentId: string, sessionId: string): Promise<boolean>;
    acknowledge(notificationId: string, agentId: string): Promise<boolean>;
    replyPermission(agentId: string, sessionId: string, permissionId: string, decision: 'once' | 'always' | 'reject', optionId?: string): Promise<boolean>;
    sendSession(agentId: string, sessionId: string, payload: JsonValue): Promise<boolean>;
    refreshModels(agentId: string, providerId: string): Promise<boolean>;
    bindModel(agentId: string, providerId: string, modelId: string): Promise<boolean>;
    putProvider(agentId: string): Promise<boolean>;
    applyConfig(agentId: string): Promise<boolean>;
    dismissNotice(): void;
    getLastErrorCode(): string | undefined;
}
