/**
 * The networking page selects participating agents and assigns master/peer roles. It only
 * needs each owner row's identity to decide membership, so it accepts the minimal shape the
 * owner projection provides rather than requiring the mapped `AgentRow`.
 */
export function selectNetworkMembers(agents, draft, agentId, role) {
    const existing = draft.filter(member => member.agentId !== agentId);
    if (!agents.some(agent => agent.agentId === agentId))
        return existing;
    return [...existing, { agentId, role }];
}
export function removeNetworkMember(draft, agentId) {
    return draft.filter(member => member.agentId !== agentId);
}
/** Exactly one master and zero or more peers; control is never a default master. */
export function canSubmitMembership(draft, controlAgentId) {
    const masters = draft.filter(member => member.role === 'master');
    if (masters.length !== 1)
        return false;
    if (controlAgentId !== undefined && masters.some(member => member.agentId === controlAgentId))
        return false;
    return draft.length > 0;
}
export function projectMembershipDraft(projection, draft) {
    const known = new Set(projection.agents.map(agent => agent.agentId));
    return draft.filter(member => known.has(member.agentId));
}
