import { type AgentMessage } from './agent-message.js';
import { type RelationReport } from './relation-report.js';
import type { AuthenticatedAgent } from './agent-services.js';
export type AgentKind = 'opencode' | 'acp' | 'custom';
export type HealthState = 'starting' | 'ready' | 'error';
export type RouteKind = 'lan' | 'tailscale' | 'ipv6' | 'ipv4' | 'gateway' | 'relay-ws' | 'relay-webrtc';
export type PermissionAction = 'once' | 'always' | 'reject';
export type NotificationPriority = 'low' | 'normal' | 'high' | 'critical';
export type NotificationStatus = 'pending' | 'processed';
export type SessionRole = 'user' | 'assistant' | 'system' | 'tool';
export interface HostIdentity {
    hostId: string;
    machineId: string;
    agentId: string;
    accountId: string;
    agentKind: AgentKind;
    label: string;
}
export interface RouteCandidate {
    candidateId: string;
    kind: RouteKind;
    endpoint?: string;
    port?: number;
    authRequired: boolean;
    lastSeenAt: string;
}
export interface SessionRef {
    hostId: string;
    agentId: string;
    sessionId: string;
}
export interface SessionSummary {
    sessionId: string;
    title?: string;
    status: string;
    updatedAt: string;
    unreadNotifications: number;
}
export interface PermissionRequestRef {
    hostId: string;
    agentId: string;
    sessionId: string;
    permissionId: string;
}
export interface NotificationModel {
    notificationId: string;
    hostId: string;
    agentId: string;
    sessionId?: string;
    permissionId?: string;
    priority: NotificationPriority;
    status: NotificationStatus;
    occurredAt: string;
}
export interface HostDiscoveryRoute {
    kind: 'manual' | 'auto';
    candidates: readonly RouteCandidate[];
    generation: number;
    confirmedAt: string;
}
export interface TargetControlFrameMap {
    'transport.hello': {
        kind: 'transport.hello';
        targetGeneration: number;
        protocolVersion: number;
        hostId: string;
        agentId: string;
        capabilitiesRevision: string;
        source: AuthenticatedAgent;
        admissionRef: string;
    };
    'transport.hello_ack': {
        kind: 'transport.hello_ack';
        targetGeneration: number;
    };
    'transport.ping': {
        kind: 'transport.ping';
        targetGeneration: number;
        nonce: string;
    };
    'transport.pong': {
        kind: 'transport.pong';
        targetGeneration: number;
        nonce: string;
    };
    'transport.health': {
        kind: 'transport.health';
        targetGeneration: number;
        health: HealthState;
    };
    'transport.generation': {
        kind: 'transport.generation';
        targetGeneration: number;
    };
    'transport.capability': {
        kind: 'transport.capability';
        targetGeneration: number;
        capabilitiesRevision: string;
        capabilities: readonly string[];
    };
    'transport.route_info': {
        kind: 'transport.route_info';
        targetGeneration: number;
        route: HostDiscoveryRoute;
    };
    'transport.error': {
        kind: 'transport.error';
        targetGeneration: number;
        code: string;
        message: string;
    };
    'channel.open': {
        kind: 'channel.open';
        targetGeneration: number;
        channelId: string;
        sessionRef: SessionRef;
    };
    'channel.open_ack': {
        kind: 'channel.open_ack';
        targetGeneration: number;
        channelId: string;
    };
    'channel.close': {
        kind: 'channel.close';
        targetGeneration: number;
        channelId: string;
        reason: string;
    };
    'channel.close_ack': {
        kind: 'channel.close_ack';
        targetGeneration: number;
        channelId: string;
    };
    'channel.error': {
        kind: 'channel.error';
        targetGeneration: number;
        channelId: string;
        code: string;
        message: string;
    };
}
export type TargetControlFrame = TargetControlFrameMap[keyof TargetControlFrameMap];
export interface SessionChannelFrameMap {
    'session.list': {
        kind: 'session.list';
        targetGeneration: number;
        channelId: string;
        requestId: string;
    };
    'session.list_result': {
        kind: 'session.list_result';
        targetGeneration: number;
        channelId: string;
        requestId: string;
        sessions: readonly SessionSummary[];
    };
    'session.current': {
        kind: 'session.current';
        targetGeneration: number;
        channelId: string;
        requestId: string;
    };
    'session.open': {
        kind: 'session.open';
        targetGeneration: number;
        channelId: string;
        requestId: string;
        sessionId: string;
    };
    'session.message': {
        kind: 'session.message';
        targetGeneration: number;
        channelId: string;
        sessionId: string;
        correlationId: string;
        role: SessionRole;
        body: Record<string, unknown>;
        metadata?: Record<string, unknown>;
    };
    'session.message_delta': {
        kind: 'session.message_delta';
        targetGeneration: number;
        channelId: string;
        sessionId: string;
        correlationId: string;
        delta: unknown;
    };
    'permission.ask': {
        kind: 'permission.ask';
        targetGeneration: number;
        channelId: string;
        requestId: string;
        permissionRequest: PermissionRequestRef;
    };
    'permission.reply': {
        kind: 'permission.reply';
        targetGeneration: number;
        channelId: string;
        requestId: string;
        permissionId: string;
        action: PermissionAction;
    };
    'notification.upsert': {
        kind: 'notification.upsert';
        targetGeneration: number;
        channelId: string;
        notification: NotificationModel;
    };
    'notification.ack': {
        kind: 'notification.ack';
        targetGeneration: number;
        channelId: string;
        requestId: string;
        notificationId: string;
    };
    'agent.message': {
        kind: 'agent.message';
        targetGeneration: number;
        channelId: string;
        message: AgentMessage;
    };
    'relation.report': {
        kind: 'relation.report';
        targetGeneration: number;
        channelId: string;
        report: RelationReport;
    };
}
export type SessionChannelFrame = SessionChannelFrameMap[keyof SessionChannelFrameMap];
export declare function parseTargetControlFrame(value: unknown): TargetControlFrame;
export declare function parseSessionChannelFrame(value: unknown): SessionChannelFrame;
