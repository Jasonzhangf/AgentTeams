import type { ConsoleClientV1 } from './protocol.js';
import { TeamsConsoleController } from './controller.js';
import type { DraftPersistence } from './drafts.js';
export interface MountTeamsConsoleOptions {
    readonly initialOpen?: boolean;
    readonly locale?: 'en' | 'zh';
    readonly fixtureLabel?: string;
    readonly persistence?: DraftPersistence;
}
export interface MountedTeamsConsole {
    readonly controller: TeamsConsoleController;
    readonly destroy: () => void;
}
export declare function mountTeamsConsole(root: HTMLElement, client: ConsoleClientV1, options?: MountTeamsConsoleOptions): MountedTeamsConsole;
export type { ConsoleClientV1 };
export { TeamsConsoleController };
