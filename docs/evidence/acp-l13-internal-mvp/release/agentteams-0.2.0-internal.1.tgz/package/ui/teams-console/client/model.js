export const teamPages = ['discovery', 'networking', 'interaction', 'history'];
/** UI enablement: owner runtime row, real managed Session capability, current readiness, online presence. */
export function canOperateSession(agent) {
    return agent.kind === 'runtime' && agent.sessionCapable === true
        && agent.sessionAvailability === 'current' && agent.presence === 'online';
}
export function projectAgents(projection) {
    const sessions = new Map();
    for (const session of projection.sessions)
        sessions.set(session.agentId, (sessions.get(session.agentId) ?? 0) + 1);
    const notifications = new Map();
    for (const notification of projection.notifications) {
        if (notification.state === 'pending') {
            notifications.set(notification.agentId, (notifications.get(notification.agentId) ?? 0) + 1);
        }
    }
    return projection.agents.map(agent => ({
        ...agent,
        sessionCount: sessions.get(agent.agentId) ?? 0,
        notificationCount: notifications.get(agent.agentId) ?? 0,
    }));
}
export function projectSessions(projection) {
    return projection.sessions;
}
export function projectNotifications(projection) {
    return projection.notifications;
}
export function projectSessionFlow(projection, agentId, sessionId) {
    const notificationByPermission = new Map(projection.notifications
        .filter(notification => notification.agentId === agentId && notification.sessionId === sessionId && notification.permissionId !== undefined)
        .map(notification => [notification.permissionId, notification.notificationId]));
    return (projection.sessionEvents ?? [])
        .filter(event => event.agentId === agentId && event.sessionId === sessionId)
        .map(event => ({
        ...event,
        ...(event.kind !== 'permission' ? {} : { notificationId: notificationByPermission.get(event.permissionId) }),
    }));
}
export function projectConfig(projection, agentId) {
    return projection.configs.find(config => config.agentId === agentId);
}
export function providerById(config, providerId) {
    return config?.providers.find(provider => provider.id === providerId);
}
export function providerLabel(provider) {
    return provider.label.trim() || provider.id;
}
export function modelLabel(provider, modelId) {
    if (modelId === undefined)
        return 'Model not selected';
    const model = provider.models.find(candidate => candidate.id === modelId);
    return model === undefined ? `Unknown model: ${modelId}` : model.label ?? model.id;
}
export function projectionHasAgent(projection, agentId) {
    return projection?.agents.some(agent => agent.agentId === agentId) ?? false;
}
