import type { ConsoleProjectionSnapshot, ConsoleProjectionUnsubscribe, SessionObservationState } from './protocol.js';
export type ObservationState = 'unknown' | 'stale' | 'live';
export interface ObservationSession {
    readonly projection: ConsoleProjectionSnapshot['projection'] | null;
    readonly observation: ObservationState;
    readonly health: SessionObservationState;
}
export interface ObservationControllerOptions {
    readonly subscribe: () => ConsoleProjectionUnsubscribe;
    readonly onSnapshot: (projection: ConsoleProjectionSnapshot['projection']) => void;
    readonly onObservation: (state: ObservationSession) => void;
    readonly onError: (error: unknown) => void;
}
export declare class ProjectionObservationController {
    private readonly options;
    private expectedSeq;
    private health;
    private projection;
    private unsubscribe;
    constructor(options: ObservationControllerOptions);
    start(): void;
    stop(): void;
    onSnapshot(snapshot: unknown): void;
    onHealth(state: SessionObservationState): void;
    getSnapshot(): ObservationSession;
    private emit;
}
