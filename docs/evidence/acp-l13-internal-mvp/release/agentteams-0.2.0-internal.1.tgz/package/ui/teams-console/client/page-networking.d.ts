import type { ConsoleProjectionV1 } from './protocol.js';
/** One agent the operator places in the membership draft, with its assigned role. */
export interface NetworkMemberDraft {
    readonly agentId: string;
    readonly role: 'master' | 'peer';
}
/**
 * The networking page selects participating agents and assigns master/peer roles. It only
 * needs each owner row's identity to decide membership, so it accepts the minimal shape the
 * owner projection provides rather than requiring the mapped `AgentRow`.
 */
export declare function selectNetworkMembers(agents: readonly {
    readonly agentId: string;
}[], draft: readonly NetworkMemberDraft[], agentId: string, role: 'master' | 'peer'): readonly NetworkMemberDraft[];
export declare function removeNetworkMember(draft: readonly NetworkMemberDraft[], agentId: string): readonly NetworkMemberDraft[];
/** Exactly one master and zero or more peers; control is never a default master. */
export declare function canSubmitMembership(draft: readonly NetworkMemberDraft[], controlAgentId: string | undefined): boolean;
export declare function projectMembershipDraft(projection: ConsoleProjectionV1, draft: readonly NetworkMemberDraft[]): readonly NetworkMemberDraft[];
