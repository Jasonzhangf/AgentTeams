import type { ConsoleClientV1, ConsoleCommandResultV1, ConsoleServiceError, JsonValue } from '../canonical/console-api.js';
import type { ConsoleProjectionSink, ConsoleProjectionUnsubscribe, HistoryPage, HistoryQuery } from '../canonical/teams-state.js';
export type { ConsoleAgentObservationV1, ConsoleCapabilityDetail, ConsoleClientV1, ConsoleCommandResultV1, ConsoleCommandV1, ConsoleConnectionView, ConsolePermissionOption, ConsolePermissionOptionKind, ConsoleProjectionV1, ConsoleProviderView, ConsoleSessionEventView, JsonValue, PermissionReplyResult, SessionCancelUnknownDetail, SessionCreateResult, SessionObservationState, } from '../canonical/console-api.js';
export type { ConsoleProjectionSnapshot, ConsoleProjectionSink, ConsoleProjectionUnsubscribe, HistoryPage, HistoryQuery, TeamsConnectionState, TeamsConnectionStatus, } from '../canonical/teams-state.js';
export { parseConsoleAgentObservation, parseConsoleSessionEvent, parsePermissionReplyResult, parseSessionCancelConfirmed, parseSessionCancelUnknownDetail, parseSessionCreateResult, } from '../canonical/console-api.js';
export { parseConsoleProjectionSnapshot, parseTeamsConnectionState, parseTeamsConnectionStatus, } from '../canonical/teams-state.js';
export type ServiceError = ConsoleServiceError;
/** UI-owned ADDITIVE capability extending the frozen canonical `ConsoleClientV1`. */
export type TeamsConsoleClientV1 = ConsoleClientV1 & {
    readonly readHistory: (query: HistoryQuery) => Promise<HistoryPage>;
    readonly subscribeProjection: (sink: ConsoleProjectionSink) => ConsoleProjectionUnsubscribe;
};
/** The D07 live client is the canonical client plus UI-owned read/event capabilities. */
export type TeamsConsoleLiveClientV1 = ConsoleClientV1 & TeamsConsoleClientV1;
export declare function isServiceError(value: unknown): value is ServiceError;
export declare function formatServiceError(error: ServiceError): string;
export declare function isCommandFailure(result: ConsoleCommandResultV1): result is {
    readonly ok: false;
    readonly error: ServiceError;
};
export declare function commandFailureMessage(result: ConsoleCommandResultV1): string | undefined;
export declare function asJsonValue(value: string): JsonValue;
