export { parseConsoleAgentObservation, parseConsoleSessionEvent, parsePermissionReplyResult, parseSessionCancelConfirmed, parseSessionCancelUnknownDetail, parseSessionCreateResult, } from "../canonical/console-api.js";
export { parseConsoleProjectionSnapshot, parseTeamsConnectionState, parseTeamsConnectionStatus, } from "../canonical/teams-state.js";
export function isServiceError(value) {
    if (typeof value !== 'object' || value === null)
        return false;
    const error = value;
    return typeof error.code === 'string' && typeof error.message === 'string';
}
export function formatServiceError(error) {
    const base = `${error.code}: ${error.message}`;
    if (error.detail === undefined)
        return base;
    const detail = error.detail;
    const fields = [
        `sessionId=${detail.sessionId}`,
        `reason=${detail.reason}`,
        `reconciliation=${detail.reconciliation}`,
        `finalState=${detail.finalState}`,
        `baseAccepted=${detail.baseAccepted === undefined ? 'absent' : String(detail.baseAccepted)}`,
        ...(detail.operationId === undefined ? [] : [`operationId=${detail.operationId}`]),
        ...(detail.abortOperationId === undefined ? [] : [`abortOperationId=${detail.abortOperationId}`]),
    ];
    return `${base} (${fields.join(', ')})`;
}
export function isCommandFailure(result) {
    return result.ok === false;
}
export function commandFailureMessage(result) {
    return isCommandFailure(result) ? formatServiceError(result.error) : undefined;
}
export function asJsonValue(value) {
    return value;
}
