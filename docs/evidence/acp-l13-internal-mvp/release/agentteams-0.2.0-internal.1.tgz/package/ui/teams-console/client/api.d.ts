import type { ConsoleClientV1 } from './protocol.js';
export interface ConsoleHttpClientOptions {
    readonly baseUrl?: string;
    readonly fetchImpl?: typeof fetch;
    readonly projectionPath?: string;
    readonly commandPath?: string;
    readonly sessionMessagePath?: string;
}
export declare class ConsoleTransportError extends Error {
    readonly status?: number | undefined;
    constructor(message: string, status?: number | undefined);
}
export declare function createConsoleHttpClient(options?: ConsoleHttpClientOptions): ConsoleClientV1;
