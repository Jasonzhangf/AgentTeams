import type { ConsoleClientV1, ConsoleProjectionV1, JsonValue } from './client/protocol.js';
export declare const fixtureProjection: ConsoleProjectionV1;
export declare function createFixtureClient(): ConsoleClientV1 & {
    readonly sentPayloads: readonly JsonValue[];
};
