import type { ConsoleCapabilityDetail, ConsoleProjectionV1, ConsoleProviderView, ConsoleSessionEventView } from './protocol.js';
export type ConsoleEntry = 'topology' | 'conversations' | 'notifications' | 'search' | 'memory';
export type TeamPage = 'discovery' | 'networking' | 'interaction' | 'history';
export declare const teamPages: readonly TeamPage[];
export type UiStatus = 'online' | 'offline' | 'unknown';
export interface AgentRow {
    readonly agentId: string;
    readonly label: string;
    readonly machineId: string;
    readonly generation?: number;
    readonly presence: UiStatus;
    readonly capabilities: readonly string[];
    readonly capabilityDetails?: readonly ConsoleCapabilityDetail[];
    /** Engine kind declared by the owning daemon; mirrors the frozen config EngineKind. */
    readonly engine?: 'opencode' | 'dsh';
    /** Directory observation time of the owning peer; never a UI-side heartbeat. */
    readonly lastSeenAt?: string;
    readonly kind: 'runtime' | 'directory';
    readonly sessionCapable?: boolean;
    readonly sessionAvailability?: 'changing' | 'stopped' | 'no-current' | 'uncertain' | 'current' | 'not-applicable';
    readonly sessionObservation?: import('./protocol.js').SessionObservationState;
    readonly sessionEffectiveRevision?: number;
    readonly currentSessionId?: string;
    readonly providerId?: string;
    readonly modelId?: string;
    readonly sessionCount: number;
    readonly notificationCount: number;
}
/** Structural subset shared by the owner observation union and the UI AgentRow. */
export interface SessionOperableAgent {
    readonly kind: 'runtime' | 'directory';
    readonly sessionCapable?: boolean;
    readonly sessionAvailability?: string;
    readonly presence: UiStatus;
}
/** UI enablement: owner runtime row, real managed Session capability, current readiness, online presence. */
export declare function canOperateSession(agent: SessionOperableAgent): boolean;
export interface SessionRow {
    readonly agentId: string;
    readonly sessionId: string;
    readonly title?: string;
}
export interface NotificationRow {
    readonly agentId: string;
    readonly notificationId: string;
    readonly sessionId?: string;
    readonly kind: 'notice' | 'permission';
    readonly state: 'pending' | 'resolved';
    readonly title: string;
    readonly permissionId?: string;
    readonly priority?: 'low' | 'normal' | 'high' | 'critical';
    readonly occurredAt?: string;
    readonly detail?: string;
}
export type SessionFlowRow = ConsoleSessionEventView & {
    readonly notificationId?: string;
};
export interface AgentConfigView {
    readonly agentId: string;
    readonly acceptedRevision: number;
    readonly effectiveRevision?: number;
    readonly providers: readonly ConsoleProviderView[];
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
}
export declare function projectAgents(projection: ConsoleProjectionV1): readonly AgentRow[];
export declare function projectSessions(projection: ConsoleProjectionV1): readonly SessionRow[];
export declare function projectNotifications(projection: ConsoleProjectionV1): readonly NotificationRow[];
export declare function projectSessionFlow(projection: ConsoleProjectionV1, agentId: string, sessionId: string): readonly SessionFlowRow[];
export declare function projectConfig(projection: ConsoleProjectionV1, agentId: string): AgentConfigView | undefined;
export declare function providerById(config: AgentConfigView | undefined, providerId: string): ConsoleProviderView | undefined;
export declare function providerLabel(provider: ConsoleProviderView): string;
export declare function modelLabel(provider: ConsoleProviderView, modelId: string | undefined): string;
export declare function projectionHasAgent(projection: ConsoleProjectionV1 | null, agentId: string): boolean;
