import { assertJsonValue } from "../canonical/json-value.js";
import { parseTeamsConnectionStatus } from "../canonical/teams-state.js";
import { isServiceError, parseConsoleAgentObservation, parseConsoleSessionEvent, parsePermissionReplyResult, parseSessionCancelConfirmed, parseSessionCancelUnknownDetail, parseSessionCreateResult } from "./protocol.js";
export class ConsoleTransportError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.status = status;
        this.name = 'ConsoleTransportError';
    }
}
function isRecord(value) {
    return typeof value === 'object' && value !== null;
}
function hasOnlyKeys(value, keys) {
    const allowed = new Set(keys);
    return Object.keys(value).every(key => allowed.has(key));
}
const PROJECTION_KEYS = ['version', 'agents', 'sessions', 'notifications', 'configs', 'sessionEvents', 'works', 'relations', 'connections'];
const WORK_KEYS = ['agentId', 'workId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion', 'policyRevision', 'state'];
const RELATION_KEYS = ['agentId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion', 'relationPermission', 'workId'];
function isKeyClosedArray(value, keys) {
    return Array.isArray(value) && value.every(item => isRecord(item) && hasOnlyKeys(item, keys));
}
function parses(validate, value) {
    try {
        validate(value);
        return true;
    }
    catch {
        return false;
    }
}
const CONNECTION_KEYS = ['status', 'halfOpen', 'localRole'];
/** Additive connection rows stay closed: the frozen status parser owns the nested shape. */
function isConnectionRow(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, CONNECTION_KEYS))
        return false;
    if (typeof value.halfOpen !== 'boolean')
        return false;
    if (value.localRole !== undefined && value.localRole !== 'master' && value.localRole !== 'peer')
        return false;
    return parses(parseTeamsConnectionStatus, value.status);
}
function isProjection(value) {
    return isRecord(value)
        && hasOnlyKeys(value, PROJECTION_KEYS)
        && value.version === 1
        && Array.isArray(value.agents)
        && value.agents.every(item => parses(parseConsoleAgentObservation, item))
        && Array.isArray(value.sessions)
        && Array.isArray(value.notifications)
        && Array.isArray(value.configs)
        && (value.sessionEvents === undefined || (Array.isArray(value.sessionEvents) && value.sessionEvents.every(item => parses(parseConsoleSessionEvent, item))))
        && (value.works === undefined || isKeyClosedArray(value.works, WORK_KEYS))
        && (value.relations === undefined || isKeyClosedArray(value.relations, RELATION_KEYS))
        && (value.connections === undefined || (Array.isArray(value.connections) && value.connections.every(isConnectionRow)));
}
function isValidCommandSuccess(kind, result) {
    // Every accepted Session command has a closed, kind-specific result shape. Any other
    // accepted command carries no structured result at the HTTP boundary.
    if (kind === 'session.create')
        return parses(parseSessionCreateResult, result);
    if (kind === 'session.cancel')
        return parses(parseSessionCancelConfirmed, result) || parses(parseSessionCancelUnknownDetail, result);
    if (kind === 'permission.reply')
        return parses(parsePermissionReplyResult, result);
    if (result === undefined)
        return true;
    try {
        assertJsonValue(result, 'console command result');
        return true;
    }
    catch {
        return false;
    }
}
function isCommandResult(kind, value) {
    if (!isRecord(value) || typeof value.ok !== 'boolean')
        return false;
    if (value.ok === false)
        return isServiceError(value.error);
    return isValidCommandSuccess(kind, value.result);
}
function resolveUrl(path, baseUrl) {
    if (baseUrl === undefined)
        return path;
    return new URL(path, baseUrl).toString();
}
function withTarget(path, target) {
    const separator = path.includes('?') ? '&' : '?';
    return `${path}${separator}agentId=${encodeURIComponent(target.agentId)}&sessionId=${encodeURIComponent(target.sessionId)}`;
}
async function readJson(response) {
    const text = await response.text();
    if (text.length === 0)
        throw new ConsoleTransportError('Host returned an empty response', response.status);
    try {
        return JSON.parse(text);
    }
    catch {
        throw new ConsoleTransportError('Host returned invalid JSON', response.status);
    }
}
export function createConsoleHttpClient(options = {}) {
    const fetchImpl = options.fetchImpl ?? fetch;
    const projectionPath = options.projectionPath ?? '/api/v1/projection';
    const commandPath = options.commandPath ?? '/api/v1/command';
    const sessionMessagePath = options.sessionMessagePath ?? '/api/v1/session-message';
    async function request(path, init) {
        let response;
        try {
            response = await fetchImpl(resolveUrl(path, options.baseUrl), init);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Network request failed';
            throw new ConsoleTransportError(`Host request failed: ${message}`);
        }
        if (!response.ok) {
            let detail = `HTTP ${response.status}`;
            try {
                const body = await readJson(response);
                if (isRecord(body) && typeof body.message === 'string')
                    detail = `${detail}: ${body.message}`;
            }
            catch {
                // Keep the status as the stable transport evidence when the error body is not JSON.
            }
            throw new ConsoleTransportError(detail, response.status);
        }
        return readJson(response);
    }
    return {
        async readProjection() {
            const value = await request(projectionPath, { method: 'GET', headers: { Accept: 'application/json' } });
            if (!isProjection(value))
                throw new ConsoleTransportError('Host returned an invalid v1 projection');
            return value;
        },
        async command(command) {
            const value = await request(commandPath, {
                method: 'POST',
                headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
                body: JSON.stringify(command),
            });
            if (!isCommandResult(command.kind, value))
                throw new ConsoleTransportError('Host returned an invalid v1 command result');
            return value;
        },
        async sendSession(target, payload) {
            const value = await request(withTarget(sessionMessagePath, target), {
                method: 'POST',
                headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            if (!isCommandResult('session.send', value))
                throw new ConsoleTransportError('Host returned an invalid v1 Session result');
            return value;
        },
    };
}
