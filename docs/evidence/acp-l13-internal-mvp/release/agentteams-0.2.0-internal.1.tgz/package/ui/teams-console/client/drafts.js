const PREFIX = 'teams-console-draft:';
export const DRAFT_STORAGE_KEYS = {
    message: 'message',
    networking: 'networking',
    focus: 'teams-console-focus',
    page: 'teams-console-page',
};
export function createSessionStorageDrafts(storage) {
    return storage;
}
export function readDraft(persistence, key) {
    if (persistence === undefined)
        return undefined;
    const raw = persistence.getItem(PREFIX + key);
    if (raw === null)
        return undefined;
    try {
        return JSON.parse(raw);
    }
    catch {
        return undefined;
    }
}
export function writeDraft(persistence, key, value) {
    persistence?.setItem(PREFIX + key, JSON.stringify(value));
}
export function readFocus(persistence) {
    const value = readDraft(persistence, DRAFT_STORAGE_KEYS.focus);
    return typeof value === 'string' && value.length > 0 ? value : undefined;
}
export function writeFocus(persistence, focusKey) {
    if (focusKey === undefined || focusKey.length === 0)
        return;
    writeDraft(persistence, DRAFT_STORAGE_KEYS.focus, focusKey);
}
export function readPage(persistence, allowed) {
    const value = readDraft(persistence, DRAFT_STORAGE_KEYS.page);
    return allowed.includes(value ?? '') ? value : undefined;
}
export function writePage(persistence, page) {
    writeDraft(persistence, DRAFT_STORAGE_KEYS.page, page);
}
