import type { TeamsConsoleLiveClientV1 } from './protocol.js';
import { type ConsoleHttpClientOptions } from './api.js';
export interface LiveClientOptions extends ConsoleHttpClientOptions {
    readonly historyPath?: string;
    readonly eventsPath?: string;
    readonly eventSourceImpl?: new (url: string) => EventSource;
}
/**
 * Real fetch+EventSource client for the ADDITIVE D07 capability. It builds on the
 * canonical `createConsoleHttpClient` (unchanged and backwards compatible) and adds
 * the two UI-owned ports: `GET /api/v1/history` and `GET /api/v1/events`.
 */
export declare function createLiveConsoleHttpClient(options?: LiveClientOptions): TeamsConsoleLiveClientV1;
