import type { TeamsConsoleController } from './controller.js';
type RenderOptions = {
    readonly fixtureLabel?: string;
};
export declare function renderConsole(root: HTMLElement, controller: TeamsConsoleController, options?: RenderOptions): void;
export {};
