export interface DraftPersistence {
    readonly getItem: (key: string) => string | null;
    readonly setItem: (key: string, value: string) => void;
}
export declare const DRAFT_STORAGE_KEYS: {
    readonly message: "message";
    readonly networking: "networking";
    readonly focus: "teams-console-focus";
    readonly page: "teams-console-page";
};
export declare function createSessionStorageDrafts(storage: Storage): DraftPersistence;
export declare function readDraft<T>(persistence: DraftPersistence | undefined, key: string): T | undefined;
export declare function writeDraft(persistence: DraftPersistence | undefined, key: string, value: unknown): void;
export declare function readFocus(persistence: DraftPersistence | undefined): string | undefined;
export declare function writeFocus(persistence: DraftPersistence | undefined, focusKey: string | undefined): void;
export declare function readPage(persistence: DraftPersistence | undefined, allowed: readonly string[]): string | undefined;
export declare function writePage(persistence: DraftPersistence | undefined, page: string): void;
