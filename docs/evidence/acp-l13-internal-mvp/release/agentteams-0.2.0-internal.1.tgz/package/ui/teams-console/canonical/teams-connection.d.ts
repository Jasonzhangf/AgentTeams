import type { AuthenticatedAgent } from './agent-services.js';
import type { AcpChannelRef, AcpFrame, AcpFault } from './acp.js';
/**
 * D00 amendment A1 (effective 2026-10-11): the two negotiation frames that carry
 * this side's own facts also carry the integer accepted config policy revision
 * (`TeamsConnectionContext.policyRevision` and
 * `TeamsConnectionPropose.sourcePolicyRevision`), so the responder no longer
 * needs an unauthenticated caller-supplied `peerPolicyRevision`.
 *
 * The frame `version` stays 1. The key set is wire-visible, so a pre-A1 peer
 * that omits the key is refused `INVALID_ACP_FRAME` by the positive-integer
 * check below. A version bump would be required only if a v1 peer had shipped,
 * and none has: D05 was unclosed and no LAN peer was deployed.
 */
/** A relation is bilateral: master/peer or peer/peer. No subordinate alias exists. */
export type RelationRole = 'master' | 'peer';
export interface TeamsAgreement {
    readonly connectionId: string;
    /** A new connection starts this value at 1. */
    readonly relationRevision: number;
    readonly source: AuthenticatedAgent;
    readonly target: AuthenticatedAgent;
    readonly sourceRole: RelationRole;
    readonly targetRole: RelationRole;
    readonly sourceGeneration: number;
    readonly targetGeneration: number;
    readonly sourceCapabilitiesRevision: string;
    readonly targetCapabilitiesRevision: string;
    readonly sourcePolicyRevision: number;
    readonly targetPolicyRevision: number;
    /** Capabilities explicitly admitted for this connection. */
    readonly capabilities: readonly string[];
}
export interface TeamsConnectionPropose {
    readonly version: 1;
    readonly kind: 'teams.connection.propose';
    readonly requestId: string;
    readonly connectionId: string;
    readonly sourceGeneration: number;
    readonly targetGeneration: number;
    readonly sourceCapabilitiesRevision: string;
    readonly targetCapabilitiesRevision: string;
    /**
     * D00 amendment A1: the proposer's own integer accepted config policy
     * revision. Never defaulted and never coerced.
     */
    readonly sourcePolicyRevision: number;
    /** The proposer's own role for the relation. */
    readonly requestedRole: RelationRole;
    /** The role the proposer intends the responder to take; peer is not a guess. */
    readonly requestedPeerRole: RelationRole;
    readonly requestedCapabilities: readonly string[];
}
/**
 * Transport-owner context the responder sends after the existing auth/hello
 * exchange. `connectionId` is the responder's real transport owner ID, which
 * `hello_ack` does not carry, so the initiator can name it before proposing.
 */
export interface TeamsConnectionContext {
    readonly version: 1;
    readonly kind: 'teams.connection.context';
    readonly connectionId: string;
    readonly targetGeneration: number;
    readonly capabilitiesRevision: string;
    /**
     * D00 amendment A1: the responder's own integer accepted config policy
     * revision, authenticated by this frame. Never defaulted and never coerced.
     */
    readonly policyRevision: number;
    /**
     * D00 amendment A3: the responder's own live engine instance, so the initiator
     * can name it on `acp.open`. `AcpChannelRef.engineInstanceId` is required and
     * non-empty, and `createTeamsSession` refuses an `acp.open` that names a
     * different engine instance with `STALE_GENERATION`. This is the only frame
     * that carries the value before `acp.open`: the engine instance is generated
     * per engine process (`<kind>-<daemonId>-<uuid>`), so it is a connection-time
     * fact, and neither the replicated `AgentDeclaration` nor any directory or
     * route surface publishes it. Never defaulted and never coerced.
     */
    readonly engineInstanceId: string;
}
export interface TeamsConnectionAccept {
    readonly version: 1;
    readonly kind: 'teams.connection.accept';
    readonly requestId: string;
    readonly agreement: TeamsAgreement;
}
export interface TeamsConnectionReject {
    readonly version: 1;
    readonly kind: 'teams.connection.reject';
    readonly requestId: string;
    readonly connectionId: string;
    readonly error: AcpFault;
}
export interface TeamsConnectionConfirm {
    readonly version: 1;
    readonly kind: 'teams.connection.confirm';
    readonly requestId: string;
    readonly agreement: TeamsAgreement;
}
export interface TeamsConnectionReady {
    readonly version: 1;
    readonly kind: 'teams.connection.ready';
    readonly requestId: string;
    readonly agreement: TeamsAgreement;
}
export interface TeamsAcpOpen {
    readonly version: 1;
    readonly kind: 'acp.open';
    readonly ref: AcpChannelRef;
}
export interface TeamsAcpOpenAck {
    readonly version: 1;
    readonly kind: 'acp.open_ack';
    readonly ref: AcpChannelRef;
}
export interface TeamsAcpFrame {
    readonly version: 1;
    readonly kind: 'acp.frame';
    readonly ref: AcpChannelRef;
    readonly frame: AcpFrame;
}
export interface TeamsAcpClose {
    readonly version: 1;
    readonly kind: 'acp.close';
    readonly ref: AcpChannelRef;
}
export interface TeamsAcpError {
    readonly version: 1;
    readonly kind: 'acp.error';
    readonly ref: AcpChannelRef;
    readonly error: AcpFault;
}
export type TeamsConnectionFrame = TeamsConnectionContext | TeamsConnectionPropose | TeamsConnectionAccept | TeamsConnectionReject | TeamsConnectionConfirm | TeamsConnectionReady | TeamsAcpOpen | TeamsAcpOpenAck | TeamsAcpFrame | TeamsAcpClose | TeamsAcpError;
export declare function parseTeamsConnectionFrame(value: unknown): TeamsConnectionFrame;
