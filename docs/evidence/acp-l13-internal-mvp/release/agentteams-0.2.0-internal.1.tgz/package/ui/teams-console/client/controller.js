import { commandFailureMessage, formatServiceError } from "./protocol.js";
import { readDraft, readFocus, readPage, writeDraft, writeFocus, writePage } from "./drafts.js";
import { ProjectionObservationController } from "./observation.js";
import { canSubmitMembership, projectMembershipDraft, selectNetworkMembers } from "./page-networking.js";
import { teamPages } from "./model.js";
export const emptyProviderDraft = {
    id: '',
    label: '',
    protocol: 'openai-chat',
    apiBaseUrl: '',
    enabled: true,
    authKind: 'none',
    credentialRef: '',
};
export const initialConsoleState = {
    open: false,
    entry: 'topology',
    drawer: null,
    drawerStack: [],
    drawerExpanded: false,
    projection: null,
    status: 'idle',
    error: null,
    notice: null,
    busy: null,
    query: '',
    locale: 'en',
    selectedAgentId: undefined,
    providerFormOpen: false,
    editingProviderId: undefined,
    providerDraft: emptyProviderDraft,
    live: false,
    page: 'discovery',
    observation: { projection: null, observation: 'unknown', health: { state: 'live' } },
    messageDraft: '',
    selectedSessionId: undefined,
    cancelState: 'idle',
    membershipDraft: [],
    historyStatus: 'idle',
    history: null,
    historyError: null,
    historyNextBeforeSequence: undefined,
    refusedError: null,
    lastFocusKey: undefined,
};
const liveDefaults = {
    live: false,
    page: 'discovery',
    observation: { projection: null, observation: 'unknown', health: { state: 'live' } },
    messageDraft: '',
    selectedSessionId: undefined,
    cancelState: 'idle',
    membershipDraft: [],
    historyStatus: 'idle',
    history: null,
    historyError: null,
    historyNextBeforeSequence: undefined,
    refusedError: null,
    lastFocusKey: undefined,
};
function errorText(error) {
    return error instanceof Error ? error.message : 'Unknown host error';
}
function cloneDraft(draft) {
    return { ...draft };
}
function typedError(error) {
    if (error instanceof Error) {
        const code = error.code;
        return { code: typeof code === "string" ? code : "HISTORY_REFUSED", message: error.message };
    }
    return { code: "HISTORY_REFUSED", message: "Unknown history refusal" };
}
function actionResult(label, result) {
    return result.result === undefined ? `${label}: accepted by Agent` : `${label}: ${JSON.stringify(result.result)}`;
}
export class TeamsConsoleController {
    state = initialConsoleState;
    listeners = new Set();
    client;
    liveClient;
    persistence;
    observationController;
    timers = new Set();
    constructor(client, options = {}) {
        this.client = client;
        if (this.isTeamsLiveClient(client))
            this.liveClient = client;
        this.persistence = options.persistence;
        this.state = {
            ...initialConsoleState,
            ...liveDefaults,
            live: this.liveClient !== undefined,
            page: options.initialPage ?? readPage(options.persistence, teamPages) ?? 'discovery',
            messageDraft: readDraft(options.persistence, 'message') ?? '',
            membershipDraft: readDraft(options.persistence, 'networking') ?? [],
            lastFocusKey: readFocus(options.persistence),
        };
        if (this.liveClient !== undefined) {
            this.observeLiveProjection();
            // A page restored from persistence is never routed through selectPage, so the first
            // history read has to be started here as well.
            this.ensureHistoryLoaded(this.state.page);
        }
    }
    getSnapshot = () => this.state;
    subscribe = (listener) => {
        this.listeners.add(listener);
        return () => { this.listeners.delete(listener); };
    };
    startObservation() {
        this.observationController?.start();
    }
    destroy() {
        this.observationController?.stop();
        for (const timer of this.timers)
            clearTimeout(timer);
        this.timers.clear();
        this.observationController = undefined;
    }
    setFocusKey(focusKey) {
        this.update({ lastFocusKey: focusKey });
        writeFocus(this.persistence, focusKey);
    }
    observeLiveProjection() {
        if (this.liveClient === undefined)
            return;
        const liveClient = this.liveClient;
        this.observationController = new ProjectionObservationController({
            subscribe: () => liveClient.subscribeProjection({
                onSnapshot: snapshot => { this.observationController?.onSnapshot(snapshot); },
                onHealth: health => { this.observationController?.onHealth(health); },
            }),
            onSnapshot: projection => this.update({ projection, status: 'ready' }),
            onObservation: observation => this.update({ observation }),
            onError: error => this.update({ status: 'error', error: errorText(error) }),
        });
    }
    update(patch) {
        this.state = { ...this.state, ...patch };
        for (const listener of this.listeners)
            listener();
    }
    isTeamsLiveClient(client) {
        return typeof client.readHistory === 'function'
            && typeof client.subscribeProjection === 'function';
    }
    scheduleTimer(timer) {
        this.timers.add(timer);
        void timer;
    }
    async loadProjection(showLoading) {
        if (showLoading)
            this.update({ status: 'loading', error: null });
        try {
            const projection = await this.client.readProjection();
            this.update({ projection, status: 'ready', error: null });
            return true;
        }
        catch (error) {
            this.update({ status: 'error', error: errorText(error) });
            return false;
        }
    }
    async refresh() {
        await this.loadProjection(true);
    }
    openConsole() {
        this.update({ open: true, notice: null });
        if (this.state.projection === null && this.state.status !== 'loading')
            void this.refresh();
    }
    closeConsole() {
        this.update({ open: false, drawer: null, drawerStack: [], drawerExpanded: false, notice: null, error: null });
    }
    selectEntry(entry) {
        this.update({ entry, drawer: null, drawerStack: [], drawerExpanded: false, notice: null });
    }
    selectPage(page) {
        this.update({ page, notice: null, refusedError: null });
        writePage(this.persistence, page);
        this.ensureHistoryLoaded(page);
    }
    /**
     * The history view owns no initial read. Its only other trigger is the "previous" control,
     * which is disabled until a page has already been read, so without this the view is a dead
     * end that can never show a record. The first read happens when the view is opened.
     */
    ensureHistoryLoaded(page) {
        if (page !== 'history')
            return;
        // Only a live client has a history owner. A fixture client keeps its previous rendering
        // instead of flipping to a HISTORY_UNAVAILABLE refusal, matching the constructor path.
        if (this.liveClient === undefined)
            return;
        if (this.state.history !== null || this.state.historyStatus === 'loading')
            return;
        void this.loadHistory();
    }
    setMessageDraft(message) {
        this.update({ messageDraft: message });
        writeDraft(this.persistence, 'message', message);
    }
    selectSessionSessionId(sessionId) {
        this.update({ selectedSessionId: sessionId });
    }
    setMembershipDraft(draft) {
        this.update({ membershipDraft: draft });
        writeDraft(this.persistence, 'networking', draft);
    }
    async connectAgent(agentId) {
        return this.runRefusedAction('Connect', () => this.client.command({ kind: 'connection.connect', agentId }));
    }
    async applyMembership(expectedRevision, members) {
        const projection = this.state.projection;
        const known = projection === null ? [] : projectMembershipDraft(projection, members);
        if (known.length === 0) {
            this.update({ refusedError: { code: 'INVALID_NETWORK_DRAFT', message: 'Select at least one participating Agent.' } });
            return false;
        }
        if (!canSubmitMembership(known, projection?.agents.find(agent => agent.agentId === 'control')?.agentId)) {
            this.update({ refusedError: { code: 'INVALID_NETWORK_DRAFT', message: 'Assign exactly one non-control master before submit.' } });
            return false;
        }
        return this.runRefusedAction('Submit network draft', () => this.client.command({
            kind: 'network.membership.apply',
            agentId: known[0]?.agentId ?? '',
            expectedRevision,
            members: known,
        }));
    }
    selectNetworkMember(agentId, role) {
        this.setMembershipDraft(selectNetworkMembers(this.state.projection?.agents ?? [], this.state.membershipDraft, agentId, role));
    }
    async loadHistory(query) {
        if (this.liveClient === undefined) {
            this.update({ historyStatus: 'refused', historyError: { code: 'HISTORY_UNAVAILABLE', message: 'History owner is not bound to this UI client.' } });
            return false;
        }
        const beforeSequence = query?.beforeSequence ?? this.state.historyNextBeforeSequence;
        const historyQuery = { version: 1, kind: 'connection', limit: 20, ...(beforeSequence === undefined ? {} : { beforeSequence }) };
        this.update({ historyStatus: 'loading', historyError: null });
        try {
            const page = await this.liveClient.readHistory(historyQuery);
            this.update({ historyStatus: 'ready', history: page, historyNextBeforeSequence: page.nextBeforeSequence });
            return true;
        }
        catch (error) {
            this.update({ historyStatus: 'refused', historyError: typedError(error) });
            return false;
        }
    }
    async loadRequestHistory(query) {
        if (this.liveClient === undefined) {
            this.update({ historyStatus: 'refused', historyError: { code: 'HISTORY_UNAVAILABLE', message: 'History owner is not bound to this UI client.' } });
            return false;
        }
        const beforeSequence = query?.beforeSequence;
        const historyQuery = { version: 1, kind: 'request', limit: 20, ...(beforeSequence === undefined ? {} : { beforeSequence }) };
        this.update({ historyStatus: 'loading', historyError: null });
        try {
            const page = await this.liveClient.readHistory(historyQuery);
            this.update({ historyStatus: 'ready', history: page, historyNextBeforeSequence: page.nextBeforeSequence });
            return true;
        }
        catch (error) {
            this.update({ historyStatus: 'refused', historyError: typedError(error) });
            return false;
        }
    }
    async runRefusedAction(label, action) {
        this.update({ busy: label, error: null, notice: null, refusedError: null });
        try {
            const result = await action();
            if (result.ok === false) {
                this.update({ busy: null, refusedError: { code: result.error.code, message: result.error.message }, error: null });
                return false;
            }
            const refreshed = await this.refreshAfterAction();
            this.update({ busy: null, notice: actionResult(label, result) });
            return refreshed;
        }
        catch (error) {
            this.update({ busy: null, error: `${label}: ${errorText(error)}` });
            return false;
        }
    }
    setLocale(locale) {
        this.update({ locale });
    }
    setQuery(query) {
        this.update({ query });
    }
    openAgent(agentId) {
        this.pushDrawer({ kind: 'agent', agentId });
    }
    openSession(agentId, sessionId) {
        this.pushDrawer({ kind: 'session', agentId, sessionId });
    }
    openSettings(agentId) {
        const drawer = { kind: 'settings', ...(agentId === undefined ? {} : { agentId }) };
        const stack = [...this.state.drawerStack, drawer];
        this.update({
            drawer,
            drawerStack: stack,
            drawerExpanded: false,
            selectedAgentId: agentId ?? this.state.selectedAgentId,
            providerFormOpen: false,
            editingProviderId: undefined,
            providerDraft: emptyProviderDraft,
            error: null,
        });
    }
    closeDrawer() {
        const stack = this.state.drawerStack.slice(0, -1);
        this.update({
            drawer: stack.at(-1) ?? null,
            drawerStack: stack,
            drawerExpanded: false,
            providerFormOpen: false,
            editingProviderId: undefined,
            providerDraft: emptyProviderDraft,
        });
    }
    toggleDrawerExpanded() {
        if (this.state.drawer !== null)
            this.update({ drawerExpanded: !this.state.drawerExpanded });
    }
    selectAgent(agentId) {
        this.update({ selectedAgentId: agentId, providerFormOpen: false, editingProviderId: undefined, providerDraft: emptyProviderDraft, error: null });
    }
    pushDrawer(drawer) {
        this.update({
            drawer,
            drawerStack: [...this.state.drawerStack, drawer],
            drawerExpanded: false,
            error: null,
        });
    }
    beginAddProvider() {
        this.update({ providerFormOpen: true, editingProviderId: undefined, providerDraft: cloneDraft(emptyProviderDraft), error: null });
    }
    closeProviderForm() {
        this.update({ providerFormOpen: false, editingProviderId: undefined, providerDraft: emptyProviderDraft, error: null });
    }
    editProvider(provider) {
        this.update({
            editingProviderId: provider.id,
            providerFormOpen: true,
            providerDraft: {
                id: provider.id,
                label: provider.label,
                protocol: provider.protocol,
                apiBaseUrl: provider.apiBaseUrl,
                enabled: provider.enabled,
                authKind: provider.authKind,
                credentialRef: '',
            },
            error: null,
        });
    }
    setProviderDraft(key, value) {
        this.state = { ...this.state, providerDraft: { ...this.state.providerDraft, [key]: value } };
    }
    setProviderAuthKind(authKind) {
        this.update({ providerDraft: { ...this.state.providerDraft, authKind } });
    }
    async refreshAfterAction() {
        return this.loadProjection(false);
    }
    async runAction(label, action) {
        this.update({ busy: label, error: null, notice: null });
        try {
            const result = await action();
            const failure = commandFailureMessage(result);
            if (result.ok === false) {
                this.update({ busy: null, error: `${label}: ${failure ?? formatServiceError(result.error)}` });
                return false;
            }
            const refreshed = await this.refreshAfterAction();
            if (!refreshed) {
                this.update({ busy: null, error: `${label} succeeded, but the host projection could not be refreshed.` });
                return false;
            }
            this.update({ busy: null, notice: actionResult(label, result) });
            return true;
        }
        catch (error) {
            this.update({ busy: null, error: `${label}: ${errorText(error)}` });
            return false;
        }
    }
    async openSessionCommand(agentId, sessionId) {
        return this.runAction('Open session', () => this.client.command({ kind: 'session.open', agentId, sessionId }));
    }
    async createSession(agentId, title) {
        return this.runAction('Create session', () => this.client.command({ kind: 'session.create', agentId, ...(title === undefined ? {} : { title }) }));
    }
    async cancelSession(agentId, sessionId) {
        this.update({ cancelState: 'requested' });
        const ok = await this.runAction('Cancel session', () => this.client.command({ kind: 'session.cancel', agentId, sessionId }));
        this.update({ cancelState: ok ? 'confirmed' : 'unknown' });
        return ok;
    }
    async acknowledge(notificationId, agentId) {
        return this.runAction('Acknowledge notification', () => this.client.command({ kind: 'notification.ack', agentId, notificationId }));
    }
    async replyPermission(agentId, sessionId, permissionId, decision, optionId) {
        return this.runAction('Permission reply', () => this.client.command({ kind: 'permission.reply', agentId, sessionId, permissionId, decision, ...(optionId === undefined ? {} : { optionId }) }));
    }
    async sendSession(agentId, sessionId, payload) {
        this.update({ busy: 'Send message', error: null, notice: null });
        try {
            const result = await this.client.sendSession({ agentId, sessionId }, payload);
            const failure = commandFailureMessage(result);
            if (result.ok === false) {
                this.update({ busy: null, error: `Send message: ${failure ?? formatServiceError(result.error)}` });
                return false;
            }
            const refreshed = await this.refreshAfterAction();
            if (!refreshed) {
                this.update({ busy: null, error: 'Send message succeeded, but the host projection could not be refreshed.' });
                return false;
            }
            this.update({ busy: null, notice: actionResult('Send message', result) });
            return true;
        }
        catch (error) {
            this.update({ busy: null, error: `Send message: ${errorText(error)}` });
            return false;
        }
    }
    async refreshModels(agentId, providerId) {
        const config = this.state.projection?.configs.find(candidate => candidate.agentId === agentId);
        if (config === undefined) {
            this.update({ error: 'Refresh models: Agent config is not projected.' });
            return false;
        }
        return this.runAction('Refresh models', () => this.client.command({
            kind: 'config.refreshModels',
            agentId,
            expectedRevision: config.acceptedRevision,
            providerId,
        }));
    }
    async bindModel(agentId, providerId, modelId) {
        if (modelId.length === 0) {
            this.update({ error: 'Bind model: select a model returned by the host catalog.' });
            return false;
        }
        const config = this.state.projection?.configs.find(candidate => candidate.agentId === agentId);
        const provider = config?.providers.find(candidate => candidate.id === providerId);
        if (config === undefined || provider === undefined) {
            this.update({ error: 'Bind model: provider config is not projected.' });
            return false;
        }
        if (!provider.models.some(model => model.id === modelId)) {
            this.update({ error: `Bind model: unknown model "${modelId}"; refresh the catalog first.` });
            return false;
        }
        return this.runAction('Bind model', () => this.client.command({
            kind: 'config.bindModel',
            agentId,
            expectedRevision: config.acceptedRevision,
            providerId,
            modelId,
        }));
    }
    async putProvider(agentId) {
        const draft = this.state.providerDraft;
        if (draft.id.trim().length === 0 || draft.label.trim().length === 0 || draft.apiBaseUrl.trim().length === 0) {
            this.update({ error: 'Save provider: ID, label, and API base URL are required.' });
            return false;
        }
        try {
            const parsed = new URL(draft.apiBaseUrl);
            if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:')
                throw new Error('API base URL must use http or https.');
        }
        catch (error) {
            this.update({ error: `Save provider: ${errorText(error)}` });
            return false;
        }
        if (draft.authKind === 'bearer' && draft.credentialRef.trim().length === 0) {
            this.update({ error: 'Save provider: a credential reference is required for bearer auth; values never belong in Teams UI.' });
            return false;
        }
        const config = this.state.projection?.configs.find(candidate => candidate.agentId === agentId);
        if (config === undefined) {
            this.update({ error: 'Save provider: Agent config is not projected.' });
            return false;
        }
        return this.runAction('Save provider', () => this.client.command({
            kind: 'config.putProvider',
            agentId,
            expectedRevision: config.acceptedRevision,
            provider: {
                id: draft.id.trim(),
                label: draft.label.trim(),
                protocol: draft.protocol,
                apiBaseUrl: draft.apiBaseUrl.trim(),
                enabled: draft.enabled,
                auth: draft.authKind === 'none'
                    ? { kind: 'none' }
                    : { kind: 'bearer', credentialRef: draft.credentialRef.trim() },
            },
        }));
    }
    async applyConfig(agentId) {
        return this.runAction('Apply configuration', () => this.client.command({ kind: 'config.apply', agentId }));
    }
    dismissNotice() {
        this.update({ notice: null });
    }
    getLastErrorCode() {
        const error = this.state.projection?.configs.find(config => config.error !== undefined)?.error;
        return error === undefined ? undefined : formatServiceError(error);
    }
}
