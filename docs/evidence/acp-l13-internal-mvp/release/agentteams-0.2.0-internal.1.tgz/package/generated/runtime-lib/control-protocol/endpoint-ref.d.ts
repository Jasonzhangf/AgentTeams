declare const ENDPOINT_KINDS: readonly ["browser", "shell", "filesystem", "llm", "device", "service"];
declare const ENDPOINT_LIFECYCLES: readonly ["active", "draining", "disabled"];
export type EndpointKind = (typeof ENDPOINT_KINDS)[number];
export type EndpointLifecycle = (typeof ENDPOINT_LIFECYCLES)[number];
export interface EndpointCapabilitySummary {
    readonly capabilityId: string;
    readonly version: string;
    readonly operations: readonly string[];
}
export interface EndpointResourceSummary {
    readonly resourceId: string;
    readonly capacity: number;
    readonly unit: 'slot' | 'context';
}
export interface EndpointDiscoveryView {
    readonly endpointId: string;
    readonly ownerAgentId: string;
    readonly scopeId: string;
    readonly kind: EndpointKind;
    readonly revision: number;
    readonly lifecycle: EndpointLifecycle;
    readonly capabilities: readonly EndpointCapabilitySummary[];
    readonly resources: readonly EndpointResourceSummary[];
}
export interface EndpointReference {
    readonly providerAgentId: string;
    readonly endpointId: string;
    readonly revision: number;
}
export interface WorkEndpointReference extends EndpointReference {
    readonly workId: string;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
}
export interface EndpointViewer {
    readonly agentId: string;
    readonly scopeId: string;
}
/** Endpoint identity is not a URL, route candidate, or target transport. */
export declare function assertEndpointIdentity(value: string, label: string): string;
export declare function parseEndpointDiscoveryView(value: unknown): EndpointDiscoveryView;
export declare function parseEndpointReference(value: unknown): EndpointReference;
export declare function parseWorkEndpointReference(value: unknown): WorkEndpointReference;
export declare function filterVisibleEndpoints(catalog: readonly EndpointDiscoveryView[], viewer: EndpointViewer): EndpointDiscoveryView[];
export declare function admitEndpointReference(catalog: readonly EndpointDiscoveryView[], viewer: EndpointViewer, ref: EndpointReference): EndpointDiscoveryView;
export declare function admitWorkEndpointReference(catalog: readonly EndpointDiscoveryView[], viewer: EndpointViewer, ref: WorkEndpointReference): EndpointDiscoveryView;
export {};
