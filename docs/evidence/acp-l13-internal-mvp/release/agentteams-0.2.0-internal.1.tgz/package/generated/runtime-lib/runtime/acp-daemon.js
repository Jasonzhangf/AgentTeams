import { spawn } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, isAbsolute } from 'node:path';
import { AcpError, parseAcpFrame } from "../control-protocol/acp.js";
import { assertAcpAllowed, extractAcpCapabilities, resolveAcpPolicy } from "../config/acp-policy.js";
import { createAcpHost, rpcIdKey } from "../agent-host/acp-host.js";
import { createStdioAcpDuplex } from "../acp-adapter/stdio.js";
function faultFrom(cause, fallback) {
    if (cause instanceof AcpError)
        return cause.toFault();
    return { code: fallback, message: cause instanceof Error ? cause.message : 'ACP operation failed' };
}
function assertPositiveInteger(value, label) {
    if (!Number.isSafeInteger(value) || value < 1) {
        throw new AcpError('UNSUPPORTED_CONFIGURATION', `${label} must be a positive safe integer`);
    }
}
async function withDeadline(work, deadline, message) {
    const remaining = deadline - Date.now();
    if (remaining <= 0)
        throw new AcpError('ENGINE_UNAVAILABLE', message);
    let timer;
    try {
        return await Promise.race([
            work,
            new Promise((_, reject) => {
                timer = setTimeout(() => reject(new AcpError('ENGINE_UNAVAILABLE', message)), remaining);
            }),
        ]);
    }
    finally {
        clearTimeout(timer);
    }
}
/**
 * Write the adapter's compiled files and resolve its credential env refs, then
 * spawn exactly one child over the stdio ACP duplex.
 */
export async function startAcpEngineHandle(input) {
    let launch;
    let env;
    try {
        if (input === null || typeof input !== 'object')
            throw new AcpError('UNSUPPORTED_CONFIGURATION', 'engine start input is required');
        launch = input.launch;
        if (launch === null || typeof launch !== 'object')
            throw new AcpError('UNSUPPORTED_CONFIGURATION', 'engine launch spec is required');
        if (!isAbsolute(launch.executable))
            throw new AcpError('UNSUPPORTED_CONFIGURATION', 'engine executable must be an absolute path');
        if (!isAbsolute(launch.cwd))
            throw new AcpError('UNSUPPORTED_CONFIGURATION', 'engine cwd must be an absolute path');
        assertPositiveInteger(input.stopTimeoutMs, 'stopTimeoutMs');
        if (typeof input.engineInstanceId !== 'string' || input.engineInstanceId.length === 0) {
            throw new AcpError('UNSUPPORTED_CONFIGURATION', 'engineInstanceId is required');
        }
        assertPositiveInteger(input.targetGeneration, 'targetGeneration');
        env = { ...launch.env };
        for (const [key, reference] of Object.entries(launch.credentialEnvRefs)) {
            if (input.resolveCredential === undefined) {
                throw new AcpError('UNSUPPORTED_CONFIGURATION', `engine launch needs credential ${reference} but no resolver is configured`);
            }
            const value = await input.resolveCredential(reference);
            if (typeof value !== 'string' || value.length === 0) {
                throw new AcpError('UNSUPPORTED_CONFIGURATION', `engine credential ${reference} is unavailable`);
            }
            env[key] = value;
        }
        for (const file of launch.files) {
            if (!isAbsolute(file.path))
                throw new AcpError('UNSUPPORTED_CONFIGURATION', 'engine launch file path must be absolute');
            await mkdir(dirname(file.path), { recursive: true, mode: 0o700 });
            await writeFile(file.path, file.content, { encoding: 'utf8', mode: file.mode });
        }
    }
    catch (cause) {
        // Nothing has been spawned yet, so there is no child to clean up.
        return { kind: 'failed', fault: faultFrom(cause, 'ENGINE_UNAVAILABLE'), cleanup: null };
    }
    let child;
    try {
        child = spawn(launch.executable, [...launch.args], {
            cwd: launch.cwd,
            env,
            stdio: ['pipe', 'pipe', 'pipe'],
        });
    }
    catch (cause) {
        return { kind: 'failed', fault: faultFrom(cause, 'ENGINE_UNAVAILABLE'), cleanup: null };
    }
    let ended = false;
    const exited = new Promise(resolve => {
        child.once('error', () => { ended = true; resolve({ code: null, signal: null }); });
        child.once('exit', (code, signal) => { ended = true; resolve({ code, signal }); });
    });
    const spawnFailure = await new Promise(resolve => {
        child.once('spawn', () => resolve(null));
        child.once('error', error => resolve(error));
    });
    if (spawnFailure !== null) {
        // The spawn failed before exec, so no OS process exists to reap.
        return { kind: 'failed', fault: { code: 'ENGINE_UNAVAILABLE', message: `engine failed to start: ${spawnFailure.message}` }, cleanup: null };
    }
    const pid = child.pid;
    if (pid === undefined) {
        child.kill('SIGKILL');
        return { kind: 'failed', fault: { code: 'ENGINE_UNAVAILABLE', message: 'engine started without a pid' }, cleanup: null };
    }
    let stopping;
    const confirmExit = async (deadlineMs) => {
        let timer;
        try {
            await Promise.race([
                exited,
                new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('exit window elapsed')), deadlineMs); }),
            ]);
            return true;
        }
        catch {
            return false;
        }
        finally {
            clearTimeout(timer);
        }
    };
    const stop = () => {
        if (stopping !== undefined)
            return stopping;
        stopping = (async () => {
            if (ended)
                return { kind: 'exited', code: child.exitCode, signal: child.signalCode };
            const deadline = Date.now() + input.stopTimeoutMs;
            child.kill('SIGTERM');
            if (await confirmExit(Math.max(1, Math.floor(input.stopTimeoutMs / 2)))) {
                return { kind: 'exited', code: child.exitCode, signal: child.signalCode };
            }
            child.kill('SIGKILL');
            if (await confirmExit(Math.max(1, deadline - Date.now()))) {
                return { kind: 'exited', code: child.exitCode, signal: child.signalCode };
            }
            return {
                kind: 'retained',
                pid,
                error: { code: 'ENGINE_UNAVAILABLE', message: 'engine exit remains unconfirmed after SIGKILL' },
            };
        })();
        return stopping;
    };
    if (child.stdout === null || child.stdin === null) {
        return {
            kind: 'failed',
            fault: { code: 'ENGINE_UNAVAILABLE', message: 'engine child did not expose stdio pipes' },
            cleanup: await stop(),
        };
    }
    let acp;
    try {
        acp = createStdioAcpDuplex({
            readable: child.stdout,
            writable: child.stdin,
            ...(input.maxFrameBytes === undefined ? {} : { maxFrameBytes: input.maxFrameBytes }),
            ...(input.readTimeoutMs === undefined ? {} : { readTimeoutMs: input.readTimeoutMs }),
        });
    }
    catch (cause) {
        // The child is already running: reap it before reporting the failure.
        return { kind: 'failed', fault: faultFrom(cause, 'UNSUPPORTED_CONFIGURATION'), cleanup: await stop() };
    }
    return {
        kind: 'started',
        handle: {
            engineInstanceId: input.engineInstanceId,
            pid,
            targetGeneration: input.targetGeneration,
            acp,
            exited,
            stop,
        },
    };
}
/**
 * Perform the single real `initialize` exchange as the sole reader of the
 * duplex. The captured response is the only initialize result the agent-host
 * will ever serve; no per-client re-initialization exists.
 */
export async function bootstrapAcpInitialize(handle, input) {
    try {
        assertPositiveInteger(input?.timeoutMs, 'initialize timeoutMs');
        const id = input.requestId ?? `acp-initialize-${handle.engineInstanceId}`;
        const deadline = Date.now() + input.timeoutMs;
        const frame = {
            jsonrpc: '2.0',
            id,
            method: 'initialize',
            params: input.params ?? {},
        };
        await withDeadline(handle.acp.send(frame), deadline, `ACP initialize write timed out after ${input.timeoutMs}ms`);
        for (;;) {
            const received = await withDeadline(handle.acp.read(), deadline, `ACP initialize timed out after ${input.timeoutMs}ms`);
            const parsed = parseAcpFrame(received);
            if (typeof parsed.method === 'string') {
                return { kind: 'failed', fault: { code: 'ENGINE_UNAVAILABLE', message: 'engine sent ACP traffic before initialize completed' } };
            }
            if (rpcIdKey(parsed.id) !== rpcIdKey(id)) {
                return { kind: 'failed', fault: { code: 'ENGINE_UNAVAILABLE', message: 'engine answered an unknown request during initialize' } };
            }
            if (Object.hasOwn(parsed, 'error')) {
                return {
                    kind: 'failed',
                    fault: { code: 'ENGINE_UNAVAILABLE', message: `engine initialize failed: ${JSON.stringify(parsed.error)}`, detail: parsed.error },
                };
            }
            return { kind: 'initialized', result: parsed };
        }
    }
    catch (cause) {
        return { kind: 'failed', fault: faultFrom(cause, 'ENGINE_UNAVAILABLE') };
    }
}
/** Start one ACP agent daemon: child, stdio duplex, bootstrap initialize, host. */
export async function startAcpAgentDaemon(input) {
    const started = await startAcpEngineHandle(input);
    if (started.kind === 'failed')
        return { kind: 'failed', fault: started.fault, cleanup: started.cleanup };
    const handle = started.handle;
    const initialized = await bootstrapAcpInitialize(handle, input.initialize);
    if (initialized.kind === 'failed') {
        return { kind: 'failed', fault: initialized.fault, cleanup: await handle.stop() };
    }
    try {
        const supported = extractAcpCapabilities(initialized.result, input.policy.adapterMethods ?? []);
        const policy = resolveAcpPolicy({
            intent: input.policy.intent,
            engineInstanceId: input.engineInstanceId,
            supported,
            enforceablePolicies: input.policy.enforceablePolicies ?? supported,
        });
        const host = createAcpHost({
            handle,
            initializeResult: initialized.result,
            policy,
            history: input.history,
            assertAllowed: input.assertAllowed ?? assertAcpAllowed,
            ...(input.agentId === undefined ? {} : { agentId: input.agentId }),
            ...(input.maxDeliveryBacklog === undefined ? {} : { maxDeliveryBacklog: input.maxDeliveryBacklog }),
            ...(input.onHistoryFault === undefined ? {} : { onHistoryFault: input.onHistoryFault }),
        });
        return {
            kind: 'started',
            daemon: { handle, host, initializeResult: initialized.result, policy, stop: () => handle.stop() },
        };
    }
    catch (cause) {
        return { kind: 'failed', fault: faultFrom(cause, 'ENGINE_UNAVAILABLE'), cleanup: await handle.stop() };
    }
}
