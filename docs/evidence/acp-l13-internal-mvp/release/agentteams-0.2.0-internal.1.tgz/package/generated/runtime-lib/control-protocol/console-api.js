import { assertEnvelopeKeys, assertJsonValue } from "./json-value.js";
const WORK_STATES = ['accepted', 'closing', 'closed', 'rejected'];
const RELATION_PERMISSIONS = ['requested', 'granted', 'revoked'];
function object(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Console control must be an object');
    return value;
}
function text(value) {
    if (typeof value !== 'string' || value.length === 0)
        throw new Error('Console control requires a non-empty string');
}
function revision(value) {
    if (!Number.isSafeInteger(value) || value < 0)
        throw new Error('Invalid config revision');
}
function workView(value) {
    const work = object(value);
    assertEnvelopeKeys(work, ['agentId', 'workId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion', 'policyRevision', 'state'], 'Console work');
    for (const key of ['agentId', 'workId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion'])
        text(work[key]);
    revision(work.policyRevision);
    if (!WORK_STATES.includes(work.state))
        throw new Error('Invalid Console work state');
    return work;
}
function relationView(value) {
    const relation = object(value);
    assertEnvelopeKeys(relation, ['agentId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion', 'relationPermission', 'workId'], 'Console relation');
    for (const key of ['agentId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion'])
        text(relation[key]);
    if (!RELATION_PERMISSIONS.includes(relation.relationPermission))
        throw new Error('Invalid Console relation permission');
    if (relation.workId !== undefined)
        text(relation.workId);
    return relation;
}
/** Observe-only projection rows; request/Session payloads are rejected as undeclared fields. */
export function parseConsoleWorkRelationProjection(value) {
    const input = object(value);
    if (!Array.isArray(input.works) || !Array.isArray(input.relations))
        throw new Error('Console projection requires work and relation observations');
    return { works: input.works.map(workView), relations: input.relations.map(relationView) };
}
/** Validate the closed control envelope before dispatch; authorization stays at the daemon. */
export function parseConsoleCommand(value) {
    assertJsonValue(value, 'Console command');
    const command = object(value);
    text(command.agentId);
    let fields;
    switch (command.kind) {
        case 'session.open':
            fields = ['sessionId'];
            text(command.sessionId);
            break;
        case 'session.create':
            fields = ['title'];
            if (command.title !== undefined)
                text(command.title);
            break;
        case 'session.cancel':
            fields = ['sessionId'];
            text(command.sessionId);
            break;
        case 'permission.reply':
            fields = ['sessionId', 'permissionId', 'decision', 'optionId'];
            text(command.sessionId);
            text(command.permissionId);
            if (!['once', 'always', 'reject'].includes(command.decision))
                throw new Error('Invalid permission decision');
            // The chosen engine option is optional, but when present it must name one real option.
            if (command.optionId !== undefined)
                text(command.optionId);
            break;
        case 'notification.ack':
            fields = ['notificationId'];
            text(command.notificationId);
            break;
        case 'connection.connect':
            fields = [];
            break;
        case 'connection.disconnect':
            fields = [];
            break;
        case 'network.membership.apply': {
            fields = ['expectedRevision', 'members'];
            revision(command.expectedRevision);
            if (!Array.isArray(command.members))
                throw new Error('Console network membership must be an array');
            const seen = new Set();
            for (const member of command.members) {
                const entry = object(member);
                assertEnvelopeKeys(entry, ['agentId', 'role'], 'Console network member');
                text(entry.agentId);
                if (entry.role !== 'master' && entry.role !== 'peer')
                    throw new Error('Invalid Console network member role');
                if (seen.has(entry.agentId))
                    throw new Error('Console network membership requires unique Agent identities');
                seen.add(entry.agentId);
            }
            break;
        }
        case 'config.refreshModels':
            fields = ['expectedRevision', 'providerId'];
            revision(command.expectedRevision);
            text(command.providerId);
            break;
        case 'config.bindModel':
            fields = ['expectedRevision', 'providerId', 'modelId'];
            revision(command.expectedRevision);
            text(command.providerId);
            text(command.modelId);
            break;
        case 'config.model.put': {
            fields = ['expectedRevision', 'entry'];
            revision(command.expectedRevision);
            const entry = object(command.entry);
            assertEnvelopeKeys(entry, ['ref', 'origin', 'base', 'overrides', 'availability'], 'Console model entry');
            if (entry.origin !== 'manual')
                throw new Error('Console model entry must be manual');
            const ref = object(entry.ref);
            assertEnvelopeKeys(ref, ['providerInstanceId', 'modelId'], 'Console model reference');
            text(ref.providerInstanceId);
            text(ref.modelId);
            const parseMetadata = (value, label) => {
                const metadata = object(value);
                assertEnvelopeKeys(metadata, ['label', 'contextWindow', 'maxOutputTokens', 'tools', 'streaming', 'reasoning', 'inputModalities', 'outputModalities'], label);
                if (metadata.label !== undefined)
                    text(metadata.label);
                for (const key of ['contextWindow', 'maxOutputTokens'])
                    if (metadata[key] !== undefined) {
                        if (!Number.isSafeInteger(metadata[key]) || metadata[key] < 1)
                            throw new Error(`Invalid ${label} numeric metadata`);
                    }
                for (const key of ['tools', 'streaming', 'reasoning'])
                    if (metadata[key] !== undefined && typeof metadata[key] !== 'boolean')
                        throw new Error(`Invalid ${label} boolean metadata`);
                for (const key of ['inputModalities', 'outputModalities'])
                    if (metadata[key] !== undefined && (!Array.isArray(metadata[key]) || metadata[key].some(item => typeof item !== 'string' || item.length === 0)))
                        throw new Error(`Invalid ${label} modalities`);
            };
            parseMetadata(entry.base, 'Console model base');
            parseMetadata(entry.overrides, 'Console model overrides');
            if (entry.availability !== undefined && entry.availability !== 'available' && entry.availability !== 'unavailable')
                throw new Error('Invalid Console model availability');
            break;
        }
        case 'config.apply':
            fields = [];
            break;
        case 'config.agent.select-backup': {
            fields = ['expectedRevision', 'backup'];
            revision(command.expectedRevision);
            const backup = object(command.backup);
            assertEnvelopeKeys(backup, ['providerInstanceId', 'modelId'], 'Backup model reference');
            text(backup.providerInstanceId);
            text(backup.modelId);
            break;
        }
        case 'config.putProvider': {
            fields = ['expectedRevision', 'provider'];
            revision(command.expectedRevision);
            const provider = object(command.provider);
            assertEnvelopeKeys(provider, ['id', 'label', 'protocol', 'apiBaseUrl', 'enabled', 'auth'], 'Console provider');
            text(provider.id);
            text(provider.label);
            text(provider.apiBaseUrl);
            if (!['openai-chat', 'openai-responses'].includes(provider.protocol) || typeof provider.enabled !== 'boolean')
                throw new Error('Invalid provider declaration');
            const auth = object(provider.auth);
            if (auth.kind === 'none')
                assertEnvelopeKeys(auth, ['kind'], 'Provider auth');
            else if (auth.kind === 'bearer') {
                assertEnvelopeKeys(auth, ['kind', 'credentialRef'], 'Provider auth');
                text(auth.credentialRef);
            }
            else
                throw new Error('Invalid provider authentication kind');
            break;
        }
        default: throw new Error('Unknown Console command');
    }
    assertEnvelopeKeys(command, ['kind', 'agentId', ...fields], 'Console command');
    return command;
}
const PRESENCE = ['online', 'offline', 'unknown'];
const SESSION_AVAILABILITY = ['changing', 'stopped', 'no-current', 'uncertain', 'current'];
const OBSERVED_PART_TYPES = ['file', 'step-start', 'step-finish', 'snapshot', 'patch', 'agent', 'retry', 'compaction', 'subtask'];
const CANCEL_UNKNOWN_REASONS = ['abort-rejected', 'no-final', 'link-lost', 'uncorrelated-idle', 'ambiguous-owner', 'stale-generation', 'superseded'];
const STRUCTURED_ERROR_NAMES = ['ProviderAuthError', 'UnknownError', 'MessageOutputLengthError', 'MessageAbortedError', 'APIError'];
const ENGINE_KINDS = ['opencode', 'dsh'];
const SERVICE_ERROR_CODES = ['INVALID_INPUT', 'UNAUTHENTICATED', 'FORBIDDEN', 'NOT_FOUND',
    'UNSUPPORTED_VERSION', 'UNSUPPORTED_OPERATION', 'STALE_GENERATION', 'REVISION_CONFLICT',
    'RESOURCE_EXHAUSTED', 'CONFLICT', 'RESULT_UNKNOWN', 'UNAVAILABLE', 'UPSTREAM_ERROR',
    'CREDENTIAL_UNAVAILABLE', 'SOURCE_CHANGED', 'MIGRATION_CONFLICT', 'APPLY_TARGET_MISMATCH'];
const SERVICE_ERROR_FIELDS = ['code', 'message', 'execution', 'status', 'providerInstanceId', 'detail'];
const PROVIDER_FIELDS = ['id', 'label', 'protocol', 'apiBaseUrl', 'enabled', 'authKind', 'catalogState', 'models', 'error'];
const PROJECTION_FIELDS = ['version', 'agents', 'sessions', 'notifications', 'configs', 'sessionEvents', 'works', 'relations', 'connections'];
const CONNECTION_FIELDS = ['status', 'halfOpen', 'localRole'];
const CONNECTION_STATUS_FIELDS = ['version', 'remoteAgentId', 'state', 'targetGeneration', 'observedAt', 'connectionId', 'role', 'error'];
const CONNECTION_STATES = ['disconnected', 'connecting', 'authenticating', 'negotiating', 'ready', 'closed', 'failed'];
function optionalText(value, label) {
    if (value !== undefined && (typeof value !== 'string' || value.length === 0))
        throw new Error(`${label} must be a non-empty string`);
}
function boolean(value, label) {
    if (typeof value !== 'boolean')
        throw new Error(`${label} must be a boolean`);
}
function counter(value, label) {
    if (!Number.isSafeInteger(value) || value < 0)
        throw new Error(`${label} must be a non-negative integer`);
}
function json(value, label) {
    assertJsonValue(value, label);
}
function timestamp(value, label) {
    if (typeof value !== 'string' || value.length === 0 || Number.isNaN(Date.parse(value)))
        throw new Error(`${label} must be an ISO timestamp`);
}
function choiceOf(value, allowed, label) {
    if (!allowed.includes(value))
        throw new Error(`Invalid ${label}`);
}
function parseStructuredError(value) {
    const error = object(value);
    assertEnvelopeKeys(error, ['name', 'data'], 'OpenCode structured error');
    choiceOf(error.name, STRUCTURED_ERROR_NAMES, 'OpenCode structured error name');
    json(error.data, 'OpenCode structured error data');
}
/** Closed validation of the engine-provided permission option set; no option is invented here. */
export function parsePermissionOptions(value) {
    if (!Array.isArray(value) || value.length === 0)
        throw new Error('Console permission options must be a non-empty array');
    const seen = new Set();
    for (const item of value) {
        const option = object(item);
        assertEnvelopeKeys(option, ['optionId', 'name', 'kind'], 'Console permission option');
        text(option.optionId);
        text(option.name);
        choiceOf(option.kind, ['once', 'always', 'reject'], 'Console permission option kind');
        if (seen.has(option.optionId))
            throw new Error('Console permission options require unique option IDs');
        seen.add(option.optionId);
    }
    return value;
}
export function parseSessionObservationState(value) {
    const observation = object(value);
    switch (observation.state) {
        case 'live':
            assertEnvelopeKeys(observation, ['state'], 'Session observation');
            break;
        case 'degraded':
            assertEnvelopeKeys(observation, ['state', 'reason', 'detail', 'droppedEvents'], 'Session observation');
            choiceOf(observation.reason, ['projection-loss', 'stream-retry'], 'Session observation reason');
            text(observation.detail);
            counter(observation.droppedEvents, 'Session observation droppedEvents');
            break;
        case 'lost':
            assertEnvelopeKeys(observation, ['state', 'reason', 'detail'], 'Session observation');
            choiceOf(observation.reason, ['stream-ended', 'retry-exhausted'], 'Session observation reason');
            text(observation.detail);
            break;
        default:
            throw new Error('Invalid Session observation state');
    }
    return observation;
}
const CAPABILITY_DETAIL_FIELDS = ['capabilityId', 'version', 'operations', 'resources'];
const CAPABILITY_RESOURCE_FIELDS = ['resourceId', 'capacity', 'unit'];
/** Closed validation of the declared capability detail; nested objects close explicitly. */
function parseCapabilityDetails(value) {
    if (!Array.isArray(value))
        throw new Error('Console agent capabilityDetails must be an array');
    for (const entry of value) {
        const detail = object(entry);
        assertEnvelopeKeys(detail, CAPABILITY_DETAIL_FIELDS, 'Console capability detail');
        text(detail.capabilityId);
        text(detail.version);
        if (!Array.isArray(detail.operations))
            throw new Error('Console capability detail operations must be an array');
        for (const operation of detail.operations)
            text(operation);
        if (!Array.isArray(detail.resources))
            throw new Error('Console capability detail resources must be an array');
        for (const resource of detail.resources) {
            const declared = object(resource);
            assertEnvelopeKeys(declared, CAPABILITY_RESOURCE_FIELDS, 'Console capability resource');
            text(declared.resourceId);
            if (!Number.isSafeInteger(declared.capacity) || declared.capacity < 1) {
                throw new Error('Console capability resource capacity must be a positive safe integer');
            }
            choiceOf(declared.unit, ['slot', 'context'], 'Console capability resource unit');
        }
    }
}
/**
 * The one published-declaration → Console detail summary mapping. Both the Agent runtime row
 * and the Console directory row project through this helper; no second state store exists.
 */
export function projectCapabilityDetails(capabilities) {
    return capabilities.map(capability => ({
        capabilityId: capability.capabilityId,
        version: capability.version,
        operations: capability.operations.map(operation => operation.operation),
        resources: capability.resources.map(resource => ({ resourceId: resource.resourceId, capacity: resource.capacity, unit: resource.unit })),
    }));
}
/** Closed validation of one Agent management row; rejects session/model fields on directory/false rows. */
export function parseConsoleAgentObservation(value) {
    const agent = object(value);
    const common = ['kind', 'agentId', 'label', 'machineId', 'generation', 'presence', 'capabilities', 'capabilityDetails', 'engine', 'lastSeenAt'];
    text(agent.agentId);
    text(agent.label);
    text(agent.machineId);
    if (agent.generation !== undefined) {
        if (!Number.isSafeInteger(agent.generation) || agent.generation < 1)
            throw new Error('Console agent generation invalid');
    }
    choiceOf(agent.presence, PRESENCE, 'Console agent presence');
    if (!Array.isArray(agent.capabilities))
        throw new Error('Console agent capabilities must be an array');
    for (const capability of agent.capabilities)
        text(capability);
    if (agent.capabilityDetails !== undefined)
        parseCapabilityDetails(agent.capabilityDetails);
    if (agent.engine !== undefined)
        choiceOf(agent.engine, ENGINE_KINDS, 'Console agent engine');
    if (agent.lastSeenAt !== undefined)
        timestamp(agent.lastSeenAt, 'Console agent lastSeenAt');
    if (agent.kind === 'directory') {
        assertEnvelopeKeys(agent, common, 'Console directory agent');
        return agent;
    }
    if (agent.kind !== 'runtime')
        throw new Error('Console agent kind is invalid');
    boolean(agent.sessionCapable, 'Console agent sessionCapable');
    if (agent.sessionCapable === false) {
        assertEnvelopeKeys(agent, [...common, 'sessionCapable', 'sessionAvailability'], 'Console passive runtime agent');
        if (agent.sessionAvailability !== 'not-applicable')
            throw new Error('Console passive runtime availability must be not-applicable');
        return agent;
    }
    assertEnvelopeKeys(agent, [...common, 'sessionCapable', 'sessionAvailability', 'sessionObservation', 'sessionEffectiveRevision', 'currentSessionId', 'providerId', 'modelId'], 'Console runtime agent');
    choiceOf(agent.sessionAvailability, SESSION_AVAILABILITY, 'Console runtime availability');
    if (agent.sessionAvailability === 'current' && agent.sessionEffectiveRevision === undefined) {
        throw new Error('Console current runtime availability requires an effective revision');
    }
    if (agent.sessionEffectiveRevision !== undefined)
        revision(agent.sessionEffectiveRevision);
    optionalText(agent.currentSessionId, 'Console agent currentSessionId');
    optionalText(agent.providerId, 'Console agent providerId');
    optionalText(agent.modelId, 'Console agent modelId');
    if (agent.sessionObservation !== undefined)
        parseSessionObservationState(agent.sessionObservation);
    return agent;
}
/** Closed validation of one owner-projected Session event; identity must match the variant. */
export function parseConsoleSessionEvent(value) {
    const event = object(value);
    const base = ['eventId', 'agentId', 'sessionId', 'occurredAt'];
    text(event.eventId);
    text(event.agentId);
    text(event.sessionId);
    optionalText(event.occurredAt, 'Console Session event occurredAt');
    const withState = (fields) => {
        assertEnvelopeKeys(event, [...base, 'kind', 'state', ...fields], 'Console Session event');
        return event;
    };
    switch (event.kind) {
        case 'message':
            if (event.state === 'failed') {
                withState(['messageId', 'role', 'error']);
                text(event.messageId);
                choiceOf(event.role, ['user', 'assistant'], 'message role');
                parseStructuredError(event.error);
            }
            else {
                withState(['messageId', 'role']);
                choiceOf(event.state, ['pending', 'completed'], 'message state');
                text(event.messageId);
                choiceOf(event.role, ['user', 'assistant'], 'message role');
            }
            break;
        case 'part':
            if (event.state === 'observed') {
                withState(['messageId', 'partId', 'partType', 'sourcePart']);
                text(event.messageId);
                text(event.partId);
                choiceOf(event.partType, OBSERVED_PART_TYPES, 'observed part type');
                json(event.sourcePart, 'Console observed part sourcePart');
            }
            else {
                withState(['messageId', 'partId', 'partType', 'text']);
                choiceOf(event.state, ['pending', 'completed'], 'part state');
                text(event.messageId);
                text(event.partId);
                choiceOf(event.partType, ['text', 'reasoning'], 'part type');
                if (typeof event.text !== 'string')
                    throw new Error('Console part text must be a string');
            }
            break;
        case 'tool': {
            const identity = ['messageId', 'partId', 'callId', 'tool', 'input'];
            if (event.state === 'pending') {
                withState([...identity, 'raw']);
                text(event.messageId);
                text(event.partId);
                text(event.callId);
                text(event.tool);
                json(event.input, 'tool input');
                if (typeof event.raw !== 'string')
                    throw new Error('Console tool raw must be a string');
            }
            else if (event.state === 'running') {
                withState([...identity, 'title', 'metadata']);
                text(event.messageId);
                text(event.partId);
                text(event.callId);
                text(event.tool);
                json(event.input, 'tool input');
                optionalText(event.title, 'tool title');
                if (event.metadata !== undefined)
                    json(event.metadata, 'tool metadata');
            }
            else if (event.state === 'completed') {
                withState([...identity, 'output', 'title', 'metadata', 'attachments']);
                text(event.messageId);
                text(event.partId);
                text(event.callId);
                text(event.tool);
                json(event.input, 'tool input');
                if (typeof event.output !== 'string')
                    throw new Error('Console tool output must be a string');
                text(event.title);
                json(event.metadata, 'tool metadata');
                if (event.attachments !== undefined) {
                    if (!Array.isArray(event.attachments))
                        throw new Error('Console tool attachments must be an array');
                    for (const attachment of event.attachments)
                        json(attachment, 'tool attachment');
                }
            }
            else if (event.state === 'error') {
                withState([...identity, 'error', 'metadata']);
                text(event.messageId);
                text(event.partId);
                text(event.callId);
                text(event.tool);
                json(event.input, 'tool input');
                if (typeof event.error !== 'string')
                    throw new Error('Console tool error must be a string');
                if (event.metadata !== undefined)
                    json(event.metadata, 'tool metadata');
            }
            else
                throw new Error('Invalid Console tool state');
            break;
        }
        case 'permission':
            if (event.state === 'pending') {
                withState(['permissionId', 'messageId', 'callId', 'title', 'metadata', 'options']);
                text(event.permissionId);
                text(event.messageId);
                optionalText(event.callId, 'permission callId');
                text(event.title);
                json(event.metadata, 'permission metadata');
                if (event.options !== undefined)
                    parsePermissionOptions(event.options);
            }
            else if (event.state === 'resolved') {
                withState(['permissionId', 'decision', 'rawResponse']);
                text(event.permissionId);
                choiceOf(event.decision, ['once', 'always', 'reject', 'unknown'], 'permission decision');
                optionalText(event.rawResponse, 'permission rawResponse');
            }
            else
                throw new Error('Invalid Console permission state');
            break;
        case 'final':
            if (event.state === 'completed') {
                withState(['messageId', 'finish']);
                text(event.messageId);
                optionalText(event.finish, 'final finish');
            }
            else if (event.state === 'failed') {
                withState(['messageId', 'error']);
                text(event.messageId);
                parseStructuredError(event.error);
            }
            else
                throw new Error('Invalid Console final state');
            break;
        case 'error': {
            withState(['error', 'correlation']);
            parseStructuredError(event.error);
            const correlation = object(event.correlation);
            if (correlation.kind === 'session') {
                assertEnvelopeKeys(correlation, ['kind', 'sessionId'], 'Console error correlation');
                text(correlation.sessionId);
            }
            else if (correlation.kind === 'message') {
                assertEnvelopeKeys(correlation, ['kind', 'messageId'], 'Console error correlation');
                text(correlation.messageId);
            }
            else
                throw new Error('Invalid Console error correlation');
            break;
        }
        case 'cancel': {
            const identity = ['operationId', 'runtimeGeneration', 'effectiveRevision', 'promptMessageId'];
            if (event.state === 'accepted' || event.state === 'rejected') {
                withState(['abortOperationId', ...identity, 'baseAccepted']);
                text(event.abortOperationId);
                text(event.operationId);
                revision(event.runtimeGeneration);
                revision(event.effectiveRevision);
                text(event.promptMessageId);
                boolean(event.baseAccepted, 'cancel baseAccepted');
                if (event.state === 'accepted' && event.baseAccepted !== true)
                    throw new Error('Cancel accepted requires baseAccepted true');
                if (event.state === 'rejected' && event.baseAccepted !== false)
                    throw new Error('Cancel rejected requires baseAccepted false');
            }
            else if (event.state === 'reconciled') {
                withState(['abortOperationId', ...identity, 'baseAccepted', 'finalState', 'messageId', 'errorName', 'causalEvidence']);
                text(event.abortOperationId);
                text(event.operationId);
                revision(event.runtimeGeneration);
                revision(event.effectiveRevision);
                text(event.promptMessageId);
                if (event.baseAccepted !== true)
                    throw new Error('Cancel reconciled requires baseAccepted true');
                if (event.finalState !== 'cancelled')
                    throw new Error('Cancel reconciled requires finalState cancelled');
                text(event.messageId);
                if (event.errorName !== 'MessageAbortedError')
                    throw new Error('Cancel reconciled requires MessageAbortedError');
                if (event.causalEvidence !== 'unique-owned-message')
                    throw new Error('Cancel reconciled requires unique-owned-message evidence');
            }
            else if (event.state === 'unknown') {
                withState(['abortOperationId', ...identity, 'baseAccepted', 'reason']);
                optionalText(event.abortOperationId, 'cancel abortOperationId');
                optionalText(event.operationId, 'cancel operationId');
                if (event.runtimeGeneration !== undefined)
                    revision(event.runtimeGeneration);
                if (event.effectiveRevision !== undefined)
                    revision(event.effectiveRevision);
                optionalText(event.promptMessageId, 'cancel promptMessageId');
                if (event.baseAccepted !== undefined)
                    boolean(event.baseAccepted, 'cancel baseAccepted');
                choiceOf(event.reason, CANCEL_UNKNOWN_REASONS, 'cancel unknown reason');
            }
            else
                throw new Error('Invalid Console cancel state');
            break;
        }
        default: throw new Error('Invalid Console Session event kind');
    }
    return event;
}
/** Closed validation of a create success result; rejects model/config/provider fields. */
export function parseSessionCreateResult(value) {
    const result = object(value);
    assertEnvelopeKeys(result, ['kind', 'agentId', 'sessionId', 'title', 'directory', 'time'], 'Session create result');
    if (result.kind !== 'session.create')
        throw new Error('Session create result kind is invalid');
    text(result.agentId);
    text(result.sessionId);
    optionalText(result.title, 'Session create title');
    optionalText(result.directory, 'Session create directory');
    if (result.time !== undefined) {
        const time = object(result.time);
        for (const key of Object.keys(time))
            json(time[key], `Session create time.${key}`);
    }
    return result;
}
/** Closed validation of a confirmed permission reply; the engine option is never invented. */
export function parsePermissionReplyResult(value) {
    const result = object(value);
    assertEnvelopeKeys(result, ['kind', 'agentId', 'sessionId', 'permissionId', 'decision', 'optionId'], 'Permission reply result');
    if (result.kind !== 'permission.reply')
        throw new Error('Permission reply result kind is invalid');
    text(result.agentId);
    text(result.sessionId);
    text(result.permissionId);
    choiceOf(result.decision, ['once', 'always', 'reject'], 'permission reply decision');
    if (result.optionId !== undefined)
        text(result.optionId);
    return result;
}
/** Closed validation of a typed cancel unknown detail; baseAccepted stays three-state. */
export function parseSessionCancelUnknownDetail(value) {
    const detail = object(value);
    assertEnvelopeKeys(detail, ['kind', 'sessionId', 'operationId', 'promptMessageId', 'runtimeGeneration', 'effectiveRevision', 'baseAccepted', 'reconciliation', 'finalState', 'reason', 'abortOperationId'], 'Session cancel detail');
    if (detail.kind !== 'session.cancel')
        throw new Error('Session cancel detail kind is invalid');
    text(detail.sessionId);
    optionalText(detail.operationId, 'cancel detail operationId');
    optionalText(detail.promptMessageId, 'cancel detail promptMessageId');
    if (detail.runtimeGeneration !== undefined)
        revision(detail.runtimeGeneration);
    if (detail.effectiveRevision !== undefined)
        revision(detail.effectiveRevision);
    if (detail.baseAccepted !== undefined)
        boolean(detail.baseAccepted, 'cancel detail baseAccepted');
    if (detail.reconciliation !== 'unknown' || detail.finalState !== 'unknown')
        throw new Error('Session cancel detail must stay unknown');
    choiceOf(detail.reason, CANCEL_UNKNOWN_REASONS, 'cancel detail reason');
    optionalText(detail.abortOperationId, 'cancel detail abortOperationId');
    return detail;
}
/** Closed validation of a confirmed cancel result; only the unique-owned abort shape passes. */
export function parseSessionCancelConfirmed(value) {
    const result = object(value);
    assertEnvelopeKeys(result, ['kind', 'sessionId', 'operationId', 'promptMessageId', 'runtimeGeneration', 'effectiveRevision', 'baseAccepted', 'reconciliation', 'finalState', 'messageId', 'errorName', 'abortOperationId', 'causalEvidence'], 'Session cancel result');
    if (result.kind !== 'session.cancel')
        throw new Error('Session cancel result kind is invalid');
    text(result.sessionId);
    text(result.operationId);
    text(result.promptMessageId);
    revision(result.runtimeGeneration);
    revision(result.effectiveRevision);
    if (result.baseAccepted !== true)
        throw new Error('Session cancel result must record an accepted abort');
    if (result.reconciliation !== 'confirmed' || result.finalState !== 'cancelled')
        throw new Error('Session cancel result must be confirmed and cancelled');
    text(result.messageId);
    text(result.abortOperationId);
    if (result.errorName !== 'MessageAbortedError')
        throw new Error('Session cancel result error name is invalid');
    if (result.causalEvidence !== 'unique-owned-message')
        throw new Error('Session cancel result causal evidence is invalid');
    return result;
}
function parseServiceErrorValue(value, label) {
    const error = object(value);
    assertEnvelopeKeys(error, SERVICE_ERROR_FIELDS, label);
    choiceOf(error.code, SERVICE_ERROR_CODES, `${label} code`);
    text(error.message);
    if (error.status !== undefined && (!Number.isSafeInteger(error.status) || error.status < 100 || error.status > 599)) {
        throw new Error(`${label} status is invalid`);
    }
    optionalText(error.providerInstanceId, `${label} providerInstanceId`);
    if (error.detail !== undefined)
        parseSessionCancelUnknownDetail(error.detail);
}
function parseProviderView(value) {
    const provider = object(value);
    assertEnvelopeKeys(provider, PROVIDER_FIELDS, 'Console provider');
    text(provider.id);
    text(provider.label);
    text(provider.apiBaseUrl);
    choiceOf(provider.protocol, ['openai-chat', 'openai-responses'], 'Console provider protocol');
    boolean(provider.enabled, 'Console provider enabled');
    choiceOf(provider.authKind, ['none', 'bearer'], 'Console provider authKind');
    choiceOf(provider.catalogState, ['ready', 'empty', 'stale', 'error'], 'Console provider catalogState');
    if (provider.error !== undefined)
        parseServiceErrorValue(provider.error, 'Console provider error');
    if (!Array.isArray(provider.models))
        throw new Error('Console provider models must be an array');
    for (const item of provider.models) {
        const model = object(item);
        assertEnvelopeKeys(model, ['id', 'label'], 'Console provider model');
        text(model.id);
        optionalText(model.label, 'Console provider model label');
    }
}
function parseConnectionView(value) {
    const connection = object(value);
    assertEnvelopeKeys(connection, CONNECTION_FIELDS, 'Console connection');
    boolean(connection.halfOpen, 'Console connection halfOpen');
    if (connection.localRole !== undefined)
        choiceOf(connection.localRole, ['master', 'peer'], 'Console connection localRole');
    const status = object(connection.status);
    assertEnvelopeKeys(status, CONNECTION_STATUS_FIELDS, 'Console connection status');
    if (status.version !== 1)
        throw new Error('Console connection status version must be 1');
    text(status.remoteAgentId);
    choiceOf(status.state, CONNECTION_STATES, 'Console connection state');
    if (!Number.isSafeInteger(status.targetGeneration) || status.targetGeneration < 1) {
        throw new Error('Console connection status targetGeneration must be a positive integer');
    }
    timestamp(status.observedAt, 'Console connection observedAt');
    optionalText(status.connectionId, 'Console connection connectionId');
    if (status.role !== undefined)
        choiceOf(status.role, ['master', 'peer'], 'Console connection role');
    if (status.state === 'failed') {
        if (status.error === undefined)
            throw new Error('Console failed connection requires an error');
        const fault = object(status.error);
        assertEnvelopeKeys(fault, ['code', 'message', 'detail'], 'Console connection fault');
        text(fault.code);
        text(fault.message);
        if (fault.detail !== undefined)
            json(fault.detail, 'Console connection fault detail');
    }
    else if (status.error !== undefined)
        throw new Error('Console connection carries an error only when failed');
}
/** Closed validation of the full owner projection, including the additive rows. */
export function parseConsoleProjection(value) {
    const projection = object(value);
    assertEnvelopeKeys(projection, PROJECTION_FIELDS, 'Console projection');
    if (projection.version !== 1)
        throw new Error('Console projection version must be 1');
    if (!Array.isArray(projection.agents))
        throw new Error('Console projection agents must be an array');
    for (const agent of projection.agents)
        parseConsoleAgentObservation(agent);
    if (!Array.isArray(projection.sessions))
        throw new Error('Console projection sessions must be an array');
    for (const item of projection.sessions) {
        const session = object(item);
        assertEnvelopeKeys(session, ['agentId', 'sessionId', 'title'], 'Console session row');
        text(session.agentId);
        text(session.sessionId);
        optionalText(session.title, 'Console session title');
    }
    if (!Array.isArray(projection.notifications))
        throw new Error('Console projection notifications must be an array');
    for (const item of projection.notifications) {
        const notice = object(item);
        assertEnvelopeKeys(notice, ['agentId', 'notificationId', 'sessionId', 'kind', 'state', 'title', 'permissionId', 'priority', 'occurredAt', 'detail'], 'Console notification row');
        text(notice.agentId);
        text(notice.notificationId);
        text(notice.title);
        choiceOf(notice.kind, ['notice', 'permission'], 'Console notification kind');
        choiceOf(notice.state, ['pending', 'resolved'], 'Console notification state');
        optionalText(notice.sessionId, 'Console notification sessionId');
        optionalText(notice.permissionId, 'Console notification permissionId');
        if (notice.priority !== undefined)
            choiceOf(notice.priority, ['low', 'normal', 'high', 'critical'], 'Console notification priority');
        if (notice.occurredAt !== undefined)
            timestamp(notice.occurredAt, 'Console notification occurredAt');
        optionalText(notice.detail, 'Console notification detail');
    }
    if (!Array.isArray(projection.configs))
        throw new Error('Console projection configs must be an array');
    for (const item of projection.configs) {
        const config = object(item);
        assertEnvelopeKeys(config, ['agentId', 'acceptedRevision', 'effectiveRevision', 'applyState', 'acceptedBinding', 'providers', 'error'], 'Console config row');
        text(config.agentId);
        revision(config.acceptedRevision);
        if (config.effectiveRevision !== undefined)
            revision(config.effectiveRevision);
        if (config.applyState !== undefined)
            choiceOf(config.applyState, ['clean', 'uncertain'], 'Console config applyState');
        if (config.acceptedBinding !== undefined && config.acceptedBinding !== null) {
            const binding = object(config.acceptedBinding);
            assertEnvelopeKeys(binding, ['primary', 'backup'], 'Console accepted binding');
            const bindingRef = (value) => {
                const ref = object(value);
                assertEnvelopeKeys(ref, ['providerInstanceId', 'modelId'], 'Console binding reference');
                text(ref.providerInstanceId);
                text(ref.modelId);
            };
            bindingRef(binding.primary);
            if (binding.backup !== undefined)
                bindingRef(binding.backup);
        }
        if (config.error !== undefined)
            parseServiceErrorValue(config.error, 'Console config error');
        if (!Array.isArray(config.providers))
            throw new Error('Console config providers must be an array');
        for (const provider of config.providers)
            parseProviderView(provider);
    }
    if (projection.sessionEvents !== undefined) {
        if (!Array.isArray(projection.sessionEvents))
            throw new Error('Console projection sessionEvents must be an array');
        for (const event of projection.sessionEvents)
            parseConsoleSessionEvent(event);
    }
    if (projection.connections !== undefined) {
        if (!Array.isArray(projection.connections))
            throw new Error('Console projection connections must be an array');
        for (const connection of projection.connections)
            parseConnectionView(connection);
    }
    if (projection.works !== undefined || projection.relations !== undefined)
        parseConsoleWorkRelationProjection(projection);
    return projection;
}
