import { assertEnvelopeKeys, assertJsonValue } from "./json-value.js";
/** Typed local failure carrier for protocol, transport, and policy boundaries. */
export class AcpError extends Error {
    code;
    detail;
    constructor(code, message, detail) {
        super(message);
        this.name = 'AcpError';
        this.code = code;
        if (detail !== undefined)
            this.detail = detail;
    }
    toFault() {
        return {
            code: this.code,
            message: this.message,
            ...(this.detail === undefined ? {} : { detail: this.detail }),
        };
    }
}
const FAULT_CODES = [
    'INVALID_ACP_FRAME',
    'UNSUPPORTED_METHOD',
    'UNSUPPORTED_CAPABILITY',
    'UNSUPPORTED_POLICY',
    'UNSUPPORTED_CONFIGURATION',
    'CAPABILITY_DENIED',
    'AUTHENTICATION_REQUIRED',
    'STALE_GENERATION',
    'SESSION_OWNERSHIP_CONFLICT',
    'CALLBACK_UNAVAILABLE',
    'ENGINE_UNAVAILABLE',
    'RESULT_UNKNOWN',
    'HISTORY_UNAVAILABLE',
    'CONFLICT',
    'FORBIDDEN',
];
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function isJsonContainer(value) {
    return typeof value === 'object' && value !== null;
}
function isRpcId(value) {
    return typeof value === 'string' || (typeof value === 'number' && Number.isSafeInteger(value));
}
function fail(message) {
    throw new AcpError('INVALID_ACP_FRAME', message);
}
function assertRpcId(value, path) {
    if (!isRpcId(value))
        fail(`${path} must be a string or finite safe integer`);
}
function assertMethod(value, path) {
    if (typeof value !== 'string' || value.length === 0)
        fail(`${path} must be a non-empty string`);
}
function assertErrorObject(value) {
    if (!isRecord(value))
        fail('ACP error must be an object');
    if (!Number.isSafeInteger(value.code))
        fail('ACP error.code must be a finite safe integer');
    if (typeof value.message !== 'string' || value.message.length === 0) {
        fail('ACP error.message must be a non-empty string');
    }
    if (Object.hasOwn(value, 'data'))
        assertJsonValue(value.data, 'ACP error.data');
}
/**
 * Validate a complete JSON-RPC envelope without cloning or coercing it.
 * Legal extension members, `_meta`, params, and results remain untouched.
 */
export function parseAcpFrame(value) {
    try {
        assertJsonValue(value, 'ACP frame');
    }
    catch (error) {
        fail(error instanceof Error ? error.message : 'ACP frame must contain only JSON values');
    }
    if (!isRecord(value))
        fail('ACP frame must be an object');
    if (value.jsonrpc !== '2.0')
        fail('ACP frame.jsonrpc must equal "2.0"');
    const hasMethod = Object.hasOwn(value, 'method');
    const hasId = Object.hasOwn(value, 'id');
    const hasResult = Object.hasOwn(value, 'result');
    const hasError = Object.hasOwn(value, 'error');
    if (hasMethod) {
        assertMethod(value.method, 'ACP frame.method');
        if (hasResult || hasError)
            fail('ACP request or notification cannot contain result or error');
        if (Object.hasOwn(value, 'params') && !isJsonContainer(value.params)) {
            fail('ACP frame.params must be an object or array');
        }
        if (hasId)
            assertRpcId(value.id, 'ACP frame.id');
        return value;
    }
    if (!hasId)
        fail('ACP response requires an id');
    assertRpcId(value.id, 'ACP frame.id');
    if (hasResult === hasError)
        fail('ACP response must contain exactly one of result or error');
    if (hasError)
        assertErrorObject(value.error);
    return value;
}
export function parseAcpFault(value) {
    try {
        assertJsonValue(value, 'ACP fault');
        if (!isRecord(value))
            throw new AcpError('INVALID_ACP_FRAME', 'ACP fault must be an object');
        assertEnvelopeKeys(value, ['code', 'message', 'detail'], 'ACP fault');
        if (typeof value.code !== 'string' || !FAULT_CODES.includes(value.code)) {
            throw new AcpError('INVALID_ACP_FRAME', 'ACP fault.code is unsupported');
        }
        if (typeof value.message !== 'string' || value.message.length === 0) {
            throw new AcpError('INVALID_ACP_FRAME', 'ACP fault.message must be a non-empty string');
        }
        if (value.detail !== undefined)
            assertJsonValue(value.detail, 'ACP fault.detail');
        return value;
    }
    catch (error) {
        if (error instanceof AcpError)
            throw error;
        throw new AcpError('INVALID_ACP_FRAME', error instanceof Error ? error.message : 'ACP fault is invalid');
    }
}
