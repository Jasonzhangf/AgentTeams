import type { CapabilityDeclaration } from '../control-protocol/agent-services.ts';
import type { LocalServiceIntent } from '../runtime/local-config.ts';
import type { WorkExecutor } from './work-host.ts';
export interface CliWorkExecutorOptions {
    readonly services: readonly LocalServiceIntent[];
    readonly camoExecutable?: string;
    readonly searchExecutable?: string;
    readonly searchRoot?: string;
    readonly profilePrefix?: string;
}
export interface CliWorkExecutor extends WorkExecutor {
    readonly capabilities: readonly CapabilityDeclaration[];
}
export declare class CliWorkExecutorConfigError extends Error {
    readonly code: 'INVALID_INPUT' | 'UNSUPPORTED_OPERATION';
    constructor(code: 'INVALID_INPUT' | 'UNSUPPORTED_OPERATION', message: string);
}
/** Adapter ownership is per Work; capacity and permission remain in the provider ledger. */
export declare function createCliWorkExecutor(input: CliWorkExecutorOptions): CliWorkExecutor;
