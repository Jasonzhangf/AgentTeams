export declare function processAlive(pid: number): boolean;
export declare function processCommand(pid: number): Promise<string | undefined>;
export declare function processOwnsConfigCommand(command: string, configPath: string, entryPath: string, startToken: string | undefined, tokenFlag?: '--launcher-start-token' | '--start-token'): boolean;
