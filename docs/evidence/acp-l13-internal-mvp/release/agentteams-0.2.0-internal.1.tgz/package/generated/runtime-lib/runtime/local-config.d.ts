import type { RuntimeConfigPersistence, RuntimeConfigStoreSections } from '../config/runtime-config.ts';
export interface LocalRelaySpec {
    readonly enabled: boolean;
    readonly configPath: string;
}
export interface LocalDaemonSpec {
    readonly id: string;
    readonly enabled: boolean;
    readonly configPath: string;
    readonly role?: 'provider' | 'receiver' | 'hybrid';
    readonly connection?: LocalConnectionIntent;
    readonly services?: readonly LocalServiceIntent[];
}
/** Simplified v3 user service intent; U3 owns adapter schemas and execution. */
export interface LocalServiceIntent {
    readonly capabilityId: string;
    readonly version: string;
    readonly operations: readonly string[];
    readonly resources: readonly {
        readonly resourceId: string;
        readonly capacity: number;
        readonly unit: 'slot' | 'context';
    }[];
}
export interface LocalConnectionIntent {
    readonly targetAgentId: string;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly demands: readonly {
        readonly resourceId: string;
        readonly amount: number;
    }[];
}
export interface LocalConfig {
    readonly version: 1 | 2 | 3;
    readonly configPath: string;
    readonly relay: LocalRelaySpec;
    readonly daemons: readonly LocalDaemonSpec[];
    /** U2 projection ref for the optional Console child; absent when console is disabled. */
    readonly console?: LocalConsoleSpec;
    readonly internalPath?: string;
    readonly bridge?: {
        readonly enabled: boolean;
    };
    readonly v3Input?: {
        readonly agents: Readonly<Record<string, unknown>>;
        readonly console?: Readonly<Record<string, unknown>>;
    };
}
export interface LocalConsoleSpec {
    readonly enabled: true;
    readonly configPath: string;
}
export interface LocalInternalConfig {
    readonly version: 1 | 2;
    readonly sourceRevision?: number;
    readonly sourceHash?: string;
    readonly configRevision?: string;
    readonly sourcePath?: string;
    readonly generatedAt?: string;
    readonly updatedAt?: string;
    readonly launcher?: LocalInternalLauncherConfig;
    readonly workControl?: LocalInternalWorkControl;
    readonly relay?: {
        readonly projectionPath?: string;
        readonly config?: string;
    };
    readonly console?: {
        readonly projectionPath?: string;
        readonly config?: string;
    };
    readonly consoleRuntime?: LocalInternalConsoleRuntime;
    readonly configRuntime?: LocalInternalConfigRuntime;
    readonly migration?: LocalInternalMigration;
    readonly daemons?: Readonly<Record<string, LocalInternalDaemonConfig>>;
}
/** Per-daemon accepted user-intent slice; `snapshot` is the JSON serialized VersionedRuntimeConfig subset. */
export interface LocalInternalConfigRuntimeAccepted {
    readonly acceptedRevision: number;
    readonly acceptedSourceRevision: number;
    readonly acceptedSourceHash: string;
    readonly snapshot?: string;
}
/** Per-daemon effective/apply fact slice; `uncertain` is the JSON serialized uncertainty fence record set. */
export interface LocalInternalConfigRuntimeEffective {
    readonly effectiveRevision?: number;
    readonly applyState?: 'clean' | 'uncertain';
    readonly lastApplyError?: string;
    readonly uncertain?: string;
}
/** Per-daemon discovered catalog observation; `entries` is the JSON serialized discovered-only model list. */
export interface LocalInternalConfigRuntimeCatalog {
    readonly state: 'ready' | 'empty' | 'stale' | 'error';
    readonly refreshedAt?: string;
    readonly error?: string;
    readonly providerFingerprint?: string;
    readonly observedAcceptedRevision?: number;
    readonly observedAcceptedSourceRevision?: number;
    readonly observedAcceptedSourceHash?: string;
    readonly observedEndpoint?: string;
    readonly observedCredentialRef?: string;
    readonly entries?: string;
}
export interface LocalInternalConfigRuntime {
    readonly accepted: Readonly<Record<string, LocalInternalConfigRuntimeAccepted>>;
    readonly effective: Readonly<Record<string, LocalInternalConfigRuntimeEffective>>;
    readonly catalogs: Readonly<Record<string, Readonly<Record<string, LocalInternalConfigRuntimeCatalog>>>>;
}
export type ConsoleRuntimeState = 'disabled' | 'stopped' | 'starting' | 'online' | 'stopping' | 'failed' | 'retained';
export interface ConsoleRuntimeError {
    readonly code: string;
    readonly message: string;
}
/** U5-owned lifecycle fields; U2 only reloads, merges and atomically rewrites this closed table. */
export interface LocalInternalConsoleRuntime {
    readonly enabled?: boolean;
    readonly pid?: number;
    readonly generation?: number;
    readonly startToken?: string;
    readonly entryPath?: string;
    readonly state?: ConsoleRuntimeState;
    readonly url?: string;
    readonly origin?: string;
    readonly identityRef?: string;
    readonly error?: ConsoleRuntimeError;
}
export interface LocalInternalMigrationInput {
    readonly kind: string;
    readonly path: string;
    readonly sha256: string;
}
export interface LocalInternalMigration {
    readonly formatVersion: number;
    readonly phase: 'prepared' | 'config-committed' | 'verified';
    readonly preparedAt: string;
    readonly committedAt?: string;
    readonly verifiedAt?: string;
    readonly fromConfigVersion: number;
    readonly fromInternalVersion: number;
    readonly sourcePath: string;
    readonly sourceBeforeHash: string;
    readonly intendedSourceHash: string;
    readonly candidateConfigText: string;
    readonly legacyInputs: readonly LocalInternalMigrationInput[];
    readonly consoleMigrationInput?: {
        readonly path: string;
        readonly sha256: string;
    };
    readonly recovery: string;
}
export interface LocalInternalLauncherConfig {
    readonly pid: number;
    readonly generation: number;
    readonly startToken?: string;
    readonly state: 'starting' | 'running' | 'stopped' | 'failed';
    readonly error?: string;
}
export interface LocalInternalWorkControl {
    readonly socketPath: string;
    readonly launcherGeneration: number;
    readonly launcherStartToken: string;
}
export interface LocalLauncherControl {
    readonly generation: number;
    readonly startToken: string;
}
export interface LocalLauncherOwnerRecord {
    readonly version: 1;
    readonly pid: number;
    readonly startToken: string;
}
export interface LocalInternalDaemonConfig {
    readonly projectionPath?: string;
    readonly enabled?: boolean;
    readonly orphaned?: boolean;
    readonly entryPath?: string;
    readonly startToken?: string;
    readonly role?: 'provider' | 'receiver' | 'hybrid';
    readonly config?: string;
    readonly pid?: number;
    readonly generation?: number;
    readonly state?: 'online' | 'stopped' | 'failed';
}
export declare class LocalConfigError extends Error {
    constructor(message: string, cause?: unknown);
}
type TomlRecord = Record<string, unknown>;
/** Deterministic TOML serializer used by the internal state and store-owned config rewrite. */
export declare function serializeTomlDocument(root: TomlRecord): string;
export declare function configSourceHash(text: string): string;
/**
 * Unique machine-source revision allocator. Caller must already hold
 * `withLocalInternalConfigLock`; this never acquires the lock itself.
 */
export declare function admitMachineSourceUnlocked(internalPath: string, configText: string, existing?: LocalInternalConfig): Promise<{
    readonly sourceRevision: number;
    readonly sourceHash: string;
}>;
/** Public machine-source admission used by `loadLocalConfig`; acquires the internal lock. */
export declare function admitMachineSource(internalPath: string, configText: string): Promise<{
    readonly sourceRevision: number;
    readonly sourceHash: string;
}>;
export interface ConsoleRuntimePatch {
    readonly enabled?: boolean;
    readonly pid?: number | null;
    readonly generation?: number;
    readonly startToken?: string | null;
    readonly entryPath?: string | null;
    readonly state?: ConsoleRuntimeState;
    readonly url?: string | null;
    readonly origin?: string | null;
    readonly identityRef?: string | null;
    readonly error?: ConsoleRuntimeError | null;
}
/**
 * U5 Console lifecycle typed patch port. Same internal short lock as every other
 * internal writer; U5 is the only caller and owns the lifecycle field semantics.
 */
export declare function writeLocalInternalConsoleRuntime(path: string, patch: Readonly<ConsoleRuntimePatch>): Promise<string>;
export declare function readLocalLauncherOwnership(path: string): Promise<LocalLauncherOwnerRecord | undefined>;
export declare function writeLocalLauncherOwnership(path: string, owner: LocalLauncherOwnerRecord): Promise<string>;
/** Serialize internal.toml read-modify-write transactions across launcher and daemon writers. */
export declare function withLocalInternalConfigLock<T>(path: string, task: () => Promise<T>): Promise<T>;
export declare function readLocalInternalConfig(path: string): Promise<LocalInternalConfig>;
export declare function projectLocalChildConfigs(internalPath: string): Promise<void>;
export declare function parseLocalConsoleProjectionConfig(config: string | undefined): Record<string, unknown> | undefined;
export declare function defaultLocalConfigPath(home?: string): string;
/**
 * Unique pending-migration recovery entry point. Caller must already hold the
 * internal lock. Uses only the durable `[migration]` snapshot; never re-scans or
 * rewrites legacy inputs. Returns after `[migration].phase` reaches `verified`.
 */
export declare function resumePendingMigration(internalPath: string): Promise<void>;
export declare function loadLocalConfig(path?: string): Promise<LocalConfig>;
export interface WriteLocalConfigOptions {
    /** Create the config only when it does not already exist; never replace an existing file. */
    readonly exclusive?: boolean;
}
/** Persist operator-authored TOML atomically; validation remains the startup gate. */
export declare function writeLocalConfig(path: string, text: string, options?: WriteLocalConfigOptions): Promise<string>;
export interface InitializeLocalConfigResult {
    readonly configPath: string;
    readonly internalPath: string;
}
/**
 * Unique v3 init/bootstrap caller. Creates user intent and runtime-owned TLS
 * under the same internal short lock, then compiles internal.toml v2 through
 * the same v3 producer used by loadLocalConfig.
 */
export declare function initializeLocalConfig(path: string, text: string): Promise<InitializeLocalConfigResult>;
export interface LocalInternalDaemonState {
    readonly pid: number;
    readonly generation?: number;
    readonly entryPath?: string;
    readonly startToken?: string;
    readonly state: 'online' | 'stopped' | 'failed';
}
export declare function writeLocalInternalState(path: string, daemons: Readonly<Record<string, LocalInternalDaemonState>>): Promise<string>;
export interface LocalInternalRecoveryOptions {
    /** Console classification to persist with the recovered launcher. */
    readonly consoleRuntime?: Readonly<ConsoleRuntimePatch>;
    /**
     * Drop the previous launcher's `[workControl]` refs. Dead-launcher recovery
     * replaces the launcher that published them, so keeping them would contradict
     * the recovered generation and make every later internal read fail the exact
     * work-control refs check.
     */
    readonly clearWorkControl?: boolean;
}
export declare function writeLocalInternalRecoveryState(path: string, daemons: Readonly<Record<string, LocalInternalDaemonState>>, launcher: LocalInternalLauncherConfig, options?: Readonly<LocalInternalRecoveryOptions>): Promise<string>;
export declare function writeLocalInternalLauncherState(path: string, launcher: LocalInternalLauncherConfig): Promise<string>;
/** Read the U4-owned socket lifecycle reference without adding another lock or store. */
export declare function readLocalInternalWorkControl(path: string): Promise<LocalInternalWorkControl | undefined>;
/**
 * U4-owned socket lifecycle primitive. The caller supplies the exact launcher
 * refs; `undefined` deletes only `[workControl]` under the existing internal lock.
 */
export declare function writeLocalInternalWorkControl(path: string, value: LocalInternalWorkControl | undefined): Promise<string>;
/** Parse the store-owned provider/model/binding user intent from a v3 config root. */
export declare function parseConfigUserSections(root: Record<string, unknown>): RuntimeConfigStoreSections;
/**
 * Replace only store-owned provider/model/binding user sections, preserving
 * bridge/agents identity/services/connect/console and unknown-but-declared tables.
 */
export declare function writeConfigUserSections(root: Record<string, unknown>, sections: RuntimeConfigStoreSections): TomlRecord;
/** Production daemon persistence bound to one Agent; the only writable TOML config owner. */
export declare function createTomlRuntimeConfigPersistence(options: {
    readonly configPath: string;
    readonly internalPath: string;
    readonly agentId: string;
}): RuntimeConfigPersistence;
export {};
