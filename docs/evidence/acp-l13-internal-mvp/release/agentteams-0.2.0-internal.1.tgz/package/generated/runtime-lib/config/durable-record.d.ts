import type { ConfigApplyResult, ManagedConfigUncertainty } from './runtime-config.ts';
/**
 * The one durable record write every record store in `config/` uses.
 *
 * `config/session-intent-store.ts` (the control daemon writing pending Session writes),
 * `config/session-observation-store.ts` (the agent daemon publishing its own Session and
 * permission observations) and `config/relations-intent-store.ts` (the control daemon writing
 * desired peer relations) carry three different facts with three different owners, but the
 * durability discipline is one decision: a mode-`0o600` temporary file in the target
 * directory followed by an atomic rename, so a reader never observes a half-written record.
 *
 * The three outcomes are the store owner's honest boundary:
 *  - the temporary write failed: the target is untouched and the result is `failed`
 *    `UNAVAILABLE`;
 *  - the rename failed: never `applied`, because the target may already carry the new bytes,
 *    so the result is `uncertain` with the real substrate fence;
 *  - the rename succeeded: `applied` with the revision that is now durable.
 *
 * `label` is only the human-readable subject inside the two messages. No caller-specific
 * behavior lives here, so a second durable store cannot grow its own copy of this rule.
 */
export interface DurableRecordWrite {
    readonly path: string;
    /** The record's own name, used verbatim in the `failed` and `uncertain` messages. */
    readonly label: string;
    readonly record: unknown;
    readonly acceptedRevision: number;
    readonly effectiveRevision: number;
}
/**
 * The fence records the real substrate facts of an ambiguous write: the durable target (the
 * record path, which is the only identity this store owns), the revision the caller
 * accepted, and the revision the write intended to publish.
 */
export declare function recordWriteUncertainty(path: string, label: string, acceptedRevision: number, effectiveRevision: number, cause: unknown): ManagedConfigUncertainty;
export declare function writeRecordAtomically(input: DurableRecordWrite): Promise<ConfigApplyResult>;
