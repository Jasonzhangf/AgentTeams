import type { JsonValue } from '../../control-protocol/agent-services.ts';
import type { AcpFrame } from '../../control-protocol/acp.ts';
import type { EngineAdapter, EngineHandle, EngineLaunchInput, EngineLaunchSpec } from '../../control-protocol/engine.ts';
import type { AcpPolicyIntent } from '../../config/acp-policy.ts';
import type { ModelRef } from '../../config/runtime-config.ts';
/**
 * Pre-launch native-policy boundary. It runs before any spawn or file write.
 *
 * - A blacklisted `internal-tool:opencode:<tool>` must map to a real OpenCode
 *   permission key; an unknown tool or another engine's kind is rejected as
 *   `UNSUPPORTED_POLICY` instead of being lowered to a no-op.
 * - A `required` native tool is rejected: this adapter can enforce a native
 *   tool denial, but it cannot prove the engine offers a native tool, and a
 *   `required` key must not pass on an unproven claim.
 *
 * Engine-independent `method:`/`capability:`/`callback:` keys stay owned by
 * `config/acp-policy.ts#resolveAcpPolicy`, which the runtime runs against the
 * real `initialize` declaration before the host serves any channel.
 */
export declare function assertOpenCodeNativePolicy(intent: AcpPolicyIntent): void;
export interface OpenCodeEngineAdapter extends EngineAdapter {
    readonly kind: 'opencode';
    /** Feed to `StartAcpDaemonInput.policy.adapterMethods`. */
    readonly declaredMethods: readonly string[];
    /** Feed to `StartAcpDaemonInput.policy.enforceablePolicies`. */
    readonly enforceablePolicies: readonly string[];
    compileLaunch(input: EngineLaunchInput): Promise<EngineLaunchSpec>;
    verifyEffective(input: {
        readonly handle: EngineHandle;
        readonly launch: EngineLaunchInput;
        readonly initializeResult: AcpFrame;
        readonly sessionConfigResult?: AcpFrame;
    }): Promise<{
        readonly effectiveRevision: number;
        readonly modelTarget: ModelRef | null;
        readonly evidence: JsonValue;
    }>;
}
export declare const openCodeAcpAdapter: OpenCodeEngineAdapter;
