import { createServer } from 'node:net';
import { mkdir, open, link, readFile, rename, unlink } from 'node:fs/promises';
import { accessSync, existsSync, statSync } from 'node:fs';
import { delimiter, dirname, resolve } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { object, text, number, loadDirectListenerConfig, loadRelayConfig } from "./process-config.js";
import { parseAgentDeclaration, RelayProtocolError } from "../control-protocol/relay-codec.js";
import { createCliWorkExecutor } from "../agent-host/cli-executor.js";
import { createWorkHost } from "../agent-host/work-host.js";
import { createWorkIngress } from "../agent-host/work-ingress.js";
import { createFileWorkStore, createTrustedWorkAuthority, createWorkLedger, currentWorkProcessStartToken, readFileWorkStoreLockProof, recover, recoverFileWorkStoreLock } from "../agent/work-resource.js";
import { createConsoleIngress } from "../agent-host/console-ingress.js";
import { acceptAgentData } from "./agent-data.js";
import { projectCapabilityDetails } from "../control-protocol/console-api.js";
import { projectConsoleWorkObservations } from "./console-work-projection.js";
import { startAgentDaemon } from "./agent-daemon.js";
import { createRuntimeConfigStore, RuntimeConfigError, targetIdentityFor } from "../config/runtime-config.js";
import { createOpenAIModelCatalogClient } from "../config/provider-model-client.js";
import { createConsoleConfigBinding } from "./console-config.js";
import { createManagedConfigOwner, createManagedConfigOwnerPersistence } from "./managed-config-owner.js";
import { OpenCodeAdapterError, cancelOpenCodeSession, createOpenCodePromptMessageId, createOpenCodeSession, createOpenCodeSessionClient, decodeOpenCodeSessionMessage, getOpenCodeSession, listOpenCodeSessions, promptOpenCodeSession, projectOpenCodeSessionMessages, projectOpenCodeSessionEvent, readOpenCodeSessionMessages, replyOpenCodePermission, subscribeOpenCodeEvents, } from "../opencode-adapter/src/index.js";
import { createTomlRuntimeConfigPersistence, defaultLocalConfigPath } from "./local-config.js";
import { createAgentWorkClient } from "./agent-work-client.js";
import { compileDeclarationEndpoints } from "../server/endpoint-discovery.js";
import { createDirectWssListener } from "../network/direct-listener.js";
import { failedLocalWorkReceipt } from "./local-work-control.js";
import { runWorkExecution } from "./dagpipe/host.js";
/**
 * The single runtime management-row projection. `sessionCapable` is the U2
 * binding fact; the owner supplies only readiness, never a second config truth.
 */
export function projectRuntimeAgentRow(input) {
    const base = {
        kind: 'runtime',
        agentId: input.agentId, machineId: input.machineId, label: input.label,
        presence: input.presence, capabilities: [...input.capabilities],
        ...(input.capabilityDetails === undefined ? {} : { capabilityDetails: input.capabilityDetails }),
        ...(input.generation === undefined ? {} : { generation: input.generation }),
    };
    const readiness = input.readiness;
    if (!input.sessionCapable || readiness === undefined) {
        return { ...base, sessionCapable: false, sessionAvailability: 'not-applicable' };
    }
    const effectiveRevision = readiness.state === 'current' || readiness.state === 'uncertain' ? readiness.effectiveRevision : undefined;
    const modelTarget = readiness.state === 'current' ? readiness.modelTarget : undefined;
    return {
        ...base,
        sessionCapable: true,
        sessionAvailability: readiness.state,
        ...(input.observation === undefined ? {} : { sessionObservation: input.observation }),
        ...(effectiveRevision === undefined ? {} : { sessionEffectiveRevision: effectiveRevision }),
        ...(input.currentSessionId === undefined ? {} : { currentSessionId: input.currentSessionId }),
        ...(modelTarget === undefined ? {} : { providerId: modelTarget.providerID, modelId: modelTarget.modelID }),
    };
}
const SESSION_EVENT_BUFFER_LIMIT = 200;
const ABORT_RECONCILE_TIMEOUT_MS = 5_000;
const MANAGED_OPENCODE_STARTUP_TIMEOUT_MS = 10_000;
const MANAGED_OPENCODE_STOP_TIMEOUT_MS = 3_000;
const EXPECTED_ADAPTER_CODES = ['NOT_FOUND', 'INVALID_INPUT', 'FORBIDDEN', 'UNAUTHENTICATED', 'UNSUPPORTED_OPERATION'];
const effectiveHandleIdentity = (handle) => `${handle.url}\u0000${handle.effectiveRevision}\u0000${handle.pid ?? ''}`;
function sessionFailure(code, message, status) {
    return { ok: false, error: { code, message, ...(status === undefined ? {} : { status }) } };
}
/** Single owner for Session-command readiness admission across typed commands and the message ingress. */
function sessionReadiness(readiness) {
    if (readiness.state === 'current')
        return { ok: true, readiness };
    return { ok: false, result: sessionFailure(readiness.state === 'changing' ? 'CONFLICT' : 'UNAVAILABLE', `Session runtime is ${readiness.state}`) };
}
/** Expected adapter failures stay resultized so the owner keeps `current`; anything else keeps uncertainty. */
function containExpectedAdapterError(error) {
    if (!(error instanceof OpenCodeAdapterError))
        return undefined;
    if (!EXPECTED_ADAPTER_CODES.includes(error.code))
        return undefined;
    return sessionFailure(error.code, error.message, error.status);
}
function sessionEventIdentity(event) {
    if (event.kind === 'part' || event.kind === 'tool')
        return `${event.kind}:${event.sessionId}:${event.partId}`;
    if (event.kind === 'permission')
        return `permission:${event.sessionId}:${event.permissionId}`;
    if (event.kind === 'message' || event.kind === 'final')
        return `${event.kind}:${event.sessionId}:${event.messageId}`;
    return undefined;
}
/**
 * Owns the single per-child OpenCode event stream, the bounded per-session projection buffer, the
 * observation state, and the per-session prompt operation record. It is not a persistent store.
 */
export function createSessionHost(deps) {
    const limit = deps.bufferLimit ?? SESSION_EVENT_BUFFER_LIMIT;
    const createClient = deps.createClient ?? createOpenCodeSessionClient;
    const buffers = new Map();
    const operations = new Map();
    const pendingCancels = new Map();
    let observation = { state: 'live' };
    let dropped = 0;
    let currentSession;
    let stream;
    let replacing;
    let disposed = false;
    const degrade = (detail) => {
        dropped += 1;
        observation = { state: 'degraded', reason: 'projection-loss', detail, droppedEvents: dropped };
    };
    const lose = (reason, detail) => {
        observation = { state: 'lost', reason, detail };
    };
    const buffer = (event) => {
        const list = buffers.get(event.sessionId) ?? [];
        const identity = sessionEventIdentity(event);
        const index = identity === undefined ? -1 : list.findIndex(existing => sessionEventIdentity(existing) === identity);
        if (index >= 0)
            list[index] = event;
        else
            list.push(event);
        while (list.length > limit) {
            list.shift();
            degrade('Session projection buffer reached its bound');
        }
        buffers.set(event.sessionId, list);
    };
    const settlePendingCancel = (sessionId, abortOperationId, messageId) => {
        const pending = pendingCancels.get(sessionId);
        if (pending === undefined || pending.abortOperationId !== abortOperationId)
            return;
        pendingCancels.delete(sessionId);
        pending.resolve(messageId);
    };
    // A replaced child cannot speak for the records or buffers its predecessor owned.
    const fenceReplacedRuntime = (handle) => {
        const generation = deps.generation();
        const handleFingerprint = effectiveHandleIdentity(handle);
        for (const [sessionId, record] of operations) {
            if (record.runtimeGeneration === generation && record.handleFingerprint === handleFingerprint)
                continue;
            operations.delete(sessionId);
            const pending = pendingCancels.get(sessionId);
            if (pending !== undefined) {
                pendingCancels.delete(sessionId);
                pending.resolve(undefined);
            }
        }
        buffers.clear();
    };
    // A second distinct assistant identity for one owned request is a multi-match:
    // the design keeps that binding unresolved and forbids confirming a cancel from it.
    const bindPromptMatch = (record, messageId) => {
        const matches = record.promptMatchIds ?? (record.promptMessageId === undefined ? [] : [record.promptMessageId]);
        if (matches.includes(messageId))
            return record;
        const next = [...matches, messageId];
        return { ...record, promptMatchIds: next, promptMessageId: next.length === 1 ? next[0] : undefined };
    };
    const correlate = (event, parentMessageId) => {
        const record = operations.get(event.sessionId);
        if (record === undefined)
            return;
        if ((event.kind === 'message' || event.kind === 'final')
            && parentMessageId !== undefined && parentMessageId === record.requestMessageId) {
            const bound = bindPromptMatch(record, event.messageId);
            if (bound !== record)
                operations.set(event.sessionId, bound);
        }
        if (event.kind === 'final' && event.state === 'failed' && event.error.name === 'MessageAbortedError') {
            const pending = pendingCancels.get(event.sessionId);
            const current = operations.get(event.sessionId);
            if (pending !== undefined && current !== undefined
                && pending.abortOperationId === current.abortOperationId
                && current.promptMessageId === event.messageId
                && pending.promptMessageId === event.messageId) {
                settlePendingCancel(event.sessionId, pending.abortOperationId, event.messageId);
            }
        }
        const bound = operations.get(event.sessionId);
        if (event.kind === 'final' && bound !== undefined && bound.promptMessageId === event.messageId)
            operations.delete(event.sessionId);
    };
    const consume = async (client, controller) => {
        try {
            for await (const raw of subscribeOpenCodeEvents(client, controller.signal)) {
                const projected = projectOpenCodeSessionEvent(raw);
                // Recognized non-outcome events are intentionally ignored; only a genuinely
                // unparseable/foreign event is projection loss.
                if (projected.kind === 'ignored')
                    continue;
                if (projected.kind !== 'event') {
                    degrade(projected.reason);
                    continue;
                }
                const event = { ...projected.event, agentId: deps.agentId };
                buffer(event);
                correlate(event, projected.parentMessageId);
            }
            if (!controller.signal.aborted)
                lose('stream-ended', 'OpenCode event stream ended');
        }
        catch (error) {
            if (!controller.signal.aborted)
                lose('retry-exhausted', error instanceof Error ? error.message : 'OpenCode event stream failed');
        }
    };
    const startStream = (handle, fingerprint) => {
        if (disposed)
            return;
        const controller = new AbortController();
        const client = createClient({ url: handle.url, authorization: handle.authorization });
        const record = { fingerprint, controller, done: Promise.resolve(), ended: false };
        record.done = consume(client, controller).finally(() => { record.ended = true; });
        stream = record;
        observation = { state: 'live' };
    };
    const ensureStream = () => {
        if (replacing !== undefined)
            return replacing;
        const handle = deps.owner.currentHandle();
        if (handle === undefined)
            return;
        const fingerprint = effectiveHandleIdentity(handle);
        if (stream !== undefined && !stream.ended && stream.fingerprint === fingerprint)
            return;
        const previous = stream;
        if (previous === undefined) {
            startStream(handle, fingerprint);
            return;
        }
        stream = undefined;
        if (!previous.ended)
            previous.controller.abort();
        replacing = (async () => {
            try {
                await previous.done;
                const current = deps.owner.currentHandle();
                if (disposed || current === undefined)
                    return;
                const currentFingerprint = effectiveHandleIdentity(current);
                if (currentFingerprint !== previous.fingerprint)
                    fenceReplacedRuntime(current);
                if (stream?.fingerprint === currentFingerprint)
                    return;
                startStream(current, currentFingerprint);
            }
            finally {
                replacing = undefined;
            }
        })();
        return replacing;
    };
    const useAdapter = async (operation, precondition) => {
        const readiness = sessionReadiness(deps.owner.readiness());
        if (!readiness.ok)
            return { ok: false, result: readiness.result, preDispatch: true };
        try {
            return await deps.owner.use(async (handle) => {
                const rejected = precondition?.(handle);
                if (rejected !== undefined)
                    return { ok: false, result: rejected, preDispatch: true };
                const client = createClient({ url: handle.url, authorization: handle.authorization });
                let dispatched = false;
                try {
                    return { ok: true, value: await operation(client, handle, () => { dispatched = true; }) };
                }
                catch (error) {
                    const contained = containExpectedAdapterError(error);
                    if (contained !== undefined)
                        return { ok: false, result: contained, preDispatch: !dispatched };
                    throw error;
                }
            });
        }
        catch (error) {
            if (error instanceof RuntimeConfigError) {
                return { ok: false, result: sessionFailure(error.code === 'CONFLICT' ? 'CONFLICT' : 'UNAVAILABLE', error.message), preDispatch: true };
            }
            throw error;
        }
    };
    const emitCancelEvent = (event) => { buffer(event); };
    const cancelUnknown = (record, abortOperationId, reason, baseAccepted) => ({
        ok: false,
        error: { code: 'RESULT_UNKNOWN', message: 'Session cancel is not confirmed', detail: {
                kind: 'session.cancel', sessionId: record.sessionId, operationId: record.operationId,
                ...(record.promptMessageId === undefined ? {} : { promptMessageId: record.promptMessageId }),
                runtimeGeneration: record.runtimeGeneration, effectiveRevision: record.effectiveRevision,
                ...(baseAccepted === undefined ? {} : { baseAccepted }), reconciliation: 'unknown', finalState: 'unknown', reason,
                ...(abortOperationId === undefined ? {} : { abortOperationId }),
            } },
    });
    const awaitAbort = async (sessionId, record, abortOperationId) => {
        if (record.promptMessageId === undefined)
            return undefined;
        return await new Promise(resolve => {
            const timer = setTimeout(() => { settlePendingCancel(sessionId, abortOperationId, undefined); }, ABORT_RECONCILE_TIMEOUT_MS);
            pendingCancels.set(sessionId, { abortOperationId, promptMessageId: record.promptMessageId, resolve: messageId => { clearTimeout(timer); resolve(messageId); } });
        });
    };
    const bufferedAbortMessageId = (sessionId, promptMessageId) => (buffers.get(sessionId) ?? []).flatMap(event => event.kind === 'final' && event.state === 'failed' &&
        event.error.name === 'MessageAbortedError' && event.messageId === promptMessageId ? [event.messageId] : [])[0];
    const cancelEvent = (record, abortOperationId, event) => {
        const base = {
            eventId: randomUUID(), agentId: deps.agentId, sessionId: record.sessionId,
            operationId: record.operationId, runtimeGeneration: record.runtimeGeneration, effectiveRevision: record.effectiveRevision,
            ...(record.promptMessageId === undefined ? {} : { promptMessageId: record.promptMessageId }),
            ...(abortOperationId === undefined ? {} : { abortOperationId }),
        };
        if (event.state === 'accepted' || event.state === 'rejected') {
            if (abortOperationId === undefined)
                throw new Error('Accepted or rejected cancel event requires abortOperationId');
            const cancel = { ...base, kind: 'cancel', state: event.state, promptMessageId: event.promptMessageId, baseAccepted: event.baseAccepted };
            return event.state === 'accepted'
                ? { ...cancel, abortOperationId, state: 'accepted', baseAccepted: true }
                : { ...cancel, abortOperationId, state: 'rejected', baseAccepted: false };
        }
        if (event.state === 'reconciled') {
            if (abortOperationId === undefined)
                throw new Error('Reconciled cancel event requires abortOperationId');
            return { ...base, kind: 'cancel', state: 'reconciled', abortOperationId, promptMessageId: event.promptMessageId, baseAccepted: true,
                finalState: 'cancelled', messageId: event.messageId, errorName: 'MessageAbortedError', causalEvidence: 'unique-owned-message' };
        }
        return { ...base, kind: 'cancel', state: 'unknown', reason: event.reason,
            ...(event.baseAccepted === undefined ? {} : { baseAccepted: event.baseAccepted }) };
    };
    return {
        openSession: async (sessionId) => {
            const outcome = await useAdapter(async (client) => {
                const summary = await getOpenCodeSession(client, sessionId);
                const messages = await readOpenCodeSessionMessages(client, sessionId);
                return { summary, messages };
            });
            if (!outcome.ok)
                return outcome.result;
            const { summary, messages } = outcome.value;
            currentSession = { sessionId: summary.id, ...(summary.title === undefined ? {} : { title: summary.title }) };
            // The pull transcript is the same closed event projection as SSE: one
            // classifier, one buffer, no second transcript store.
            for (const projection of projectOpenCodeSessionMessages(messages)) {
                if (projection.kind === 'ignored')
                    continue;
                if (projection.kind !== 'event') {
                    degrade(projection.reason);
                    continue;
                }
                buffer({ ...projection.event, agentId: deps.agentId });
            }
            await ensureStream();
            return { ok: true };
        },
        createSession: async (title) => {
            const outcome = await useAdapter(async (client) => await createOpenCodeSession(client, deps.agentId, title));
            if (!outcome.ok)
                return outcome.result;
            const created = outcome.value;
            currentSession = { sessionId: created.sessionId, ...(created.title === undefined ? {} : { title: created.title }) };
            await ensureStream();
            return { ok: true, result: created };
        },
        sendSession: async (sessionId, payload) => {
            const ready = sessionReadiness(deps.owner.readiness());
            if (!ready.ok)
                return ready.result;
            const readiness = ready.readiness;
            const handle = deps.owner.currentHandle();
            if (handle === undefined)
                return sessionFailure('UNAVAILABLE', 'Session runtime has no current handle');
            let decoded;
            try {
                decoded = decodeOpenCodeSessionMessage(payload);
            }
            catch (error) {
                const contained = containExpectedAdapterError(error);
                if (contained !== undefined)
                    return contained;
                throw error;
            }
            if (operations.has(sessionId))
                return sessionFailure('CONFLICT', 'A prompt is already active for this session');
            const record = { operationId: randomUUID(), sessionId, runtimeGeneration: deps.generation(),
                handleFingerprint: effectiveHandleIdentity(handle), effectiveRevision: readiness.effectiveRevision,
                ...(handle.pid === undefined ? {} : { childPid: handle.pid }),
                requestMessageId: createOpenCodePromptMessageId(), acceptedAt: new Date().toISOString() };
            operations.set(sessionId, record);
            const streamChange = ensureStream();
            if (streamChange !== undefined)
                await streamChange;
            const outcome = await useAdapter(async (client, handle, markDispatched) => await promptOpenCodeSession(client, sessionId, decoded.text, handle.modelTarget, record.requestMessageId, markDispatched), handle => effectiveHandleIdentity(handle) === record.handleFingerprint
                ? undefined
                : sessionFailure('CONFLICT', `Session runtime changed from revision ${record.effectiveRevision} to ${handle.effectiveRevision}`));
            const current = operations.get(sessionId);
            const owned = current !== undefined && current.operationId === record.operationId;
            if (!outcome.ok) {
                // A transport return is not proof that the prompt ended, so only an explicit
                // pre-dispatch rejection may release the not-yet-started record. Every other
                // failure keeps it owned, and a later prompt still conflicts.
                if (outcome.preDispatch && owned && current.promptMessageId === undefined)
                    operations.delete(sessionId);
                return outcome.result;
            }
            // The synchronous response binds the assistant identity only when it names this
            // request; an unbound return keeps the record so admission stays closed.
            if (owned && outcome.value !== undefined) {
                const bound = bindPromptMatch(current, outcome.value.messageId);
                if (bound !== current)
                    operations.set(sessionId, bound);
            }
            return { ok: true };
        },
        cancelSession: async (sessionId) => {
            const ready = sessionReadiness(deps.owner.readiness());
            if (!ready.ok)
                return ready.result;
            const record = operations.get(sessionId);
            if (record === undefined)
                return sessionFailure('CONFLICT', 'No active prompt to cancel for this session');
            // The record snapshot must still match the live handle before abort may reach it:
            // a replaced child cannot prove the owned prompt's causality.
            const handle = deps.owner.currentHandle();
            if (handle === undefined || record.runtimeGeneration !== deps.generation() || record.handleFingerprint !== effectiveHandleIdentity(handle)) {
                return cancelUnknown(record, undefined, 'stale-generation', undefined);
            }
            if (record.abortOperationId !== undefined)
                return sessionFailure('CONFLICT', 'A cancel is already in flight for this session');
            if (record.promptMessageId === undefined) {
                emitCancelEvent(cancelEvent(record, undefined, { state: 'unknown', reason: 'ambiguous-owner' }));
                return cancelUnknown(record, undefined, 'ambiguous-owner', undefined);
            }
            const abortOperationId = randomUUID();
            const promptMessageId = record.promptMessageId;
            const snapshot = { ...record, promptMessageId, abortOperationId };
            operations.set(sessionId, snapshot);
            const abort = awaitAbort(sessionId, snapshot, abortOperationId);
            const staleBuffered = bufferedAbortMessageId(sessionId, promptMessageId);
            const streamChange = ensureStream();
            if (streamChange !== undefined)
                await streamChange;
            let outcome;
            try {
                outcome = await useAdapter(client => cancelOpenCodeSession(client, sessionId), handle => effectiveHandleIdentity(handle) === snapshot.handleFingerprint
                    ? undefined
                    : cancelUnknown(snapshot, abortOperationId, 'stale-generation', undefined));
            }
            catch (error) {
                settlePendingCancel(sessionId, abortOperationId, undefined);
                throw error;
            }
            if (!outcome.ok) {
                settlePendingCancel(sessionId, abortOperationId, undefined);
                return outcome.result;
            }
            if (outcome.value === false) {
                settlePendingCancel(sessionId, abortOperationId, undefined);
                emitCancelEvent(cancelEvent(snapshot, abortOperationId, { state: 'rejected', baseAccepted: false, promptMessageId }));
                return cancelUnknown(snapshot, abortOperationId, 'abort-rejected', false);
            }
            if (outcome.value === undefined) {
                settlePendingCancel(sessionId, abortOperationId, undefined);
                emitCancelEvent(cancelEvent(snapshot, abortOperationId, { state: 'unknown', reason: 'link-lost' }));
                return cancelUnknown(snapshot, abortOperationId, 'link-lost', undefined);
            }
            emitCancelEvent(cancelEvent(snapshot, abortOperationId, { state: 'accepted', baseAccepted: true, promptMessageId }));
            if (staleBuffered !== undefined && pendingCancels.has(sessionId)) {
                settlePendingCancel(sessionId, abortOperationId, undefined);
                emitCancelEvent(cancelEvent(snapshot, abortOperationId, { state: 'unknown', reason: 'no-final', baseAccepted: true }));
                return cancelUnknown(snapshot, abortOperationId, 'no-final', true);
            }
            const messageId = await abort;
            if (messageId === undefined) {
                emitCancelEvent(cancelEvent(snapshot, abortOperationId, { state: 'unknown', reason: 'no-final', baseAccepted: true }));
                return cancelUnknown(snapshot, abortOperationId, 'no-final', true);
            }
            emitCancelEvent(cancelEvent(snapshot, abortOperationId, { state: 'reconciled', messageId, promptMessageId }));
            return { ok: true, result: { kind: 'session.cancel', sessionId, operationId: snapshot.operationId,
                    promptMessageId, runtimeGeneration: snapshot.runtimeGeneration,
                    effectiveRevision: snapshot.effectiveRevision, baseAccepted: true, reconciliation: 'confirmed', finalState: 'cancelled',
                    messageId, errorName: 'MessageAbortedError', abortOperationId, causalEvidence: 'unique-owned-message' } };
        },
        replyPermission: async (sessionId, permissionId, decision) => {
            const outcome = await useAdapter(async (client) => await replyOpenCodePermission(client, permissionId, sessionId, decision));
            return outcome.ok ? { ok: true } : outcome.result;
        },
        sessionEvents: () => [...buffers.values()].flat(),
        projectionSessions: async () => {
            // A projection read is observation, not a Session exchange. It uses the current
            // owner handle directly, so a failed list cannot enter the owner `use` fence and
            // move readiness to `uncertain`. The runtime row carries owner readiness itself.
            const handle = deps.owner.readiness().state === 'current' ? deps.owner.currentHandle() : undefined;
            let listedSessions = [];
            if (handle !== undefined) {
                try {
                    const client = createClient({ url: handle.url, authorization: handle.authorization });
                    listedSessions = (await listOpenCodeSessions(client)).map(session => ({ sessionId: session.id, ...(session.title === undefined ? {} : { title: session.title }) }));
                }
                catch (error) {
                    // A read has no side effect, so only genuinely unknown failures stay explicit.
                    if (containExpectedAdapterError(error) === undefined)
                        throw error;
                }
            }
            const sessions = currentSession === undefined || listedSessions.some(session => session.sessionId === currentSession.sessionId)
                ? listedSessions
                : [...listedSessions, currentSession];
            return sessions.map(session => ({ agentId: deps.agentId, ...session }));
        },
        currentSessionId: () => currentSession?.sessionId,
        observation: () => observation,
        ensureStream,
        dispose: async () => {
            disposed = true;
            if (stream !== undefined) {
                const previous = stream;
                stream = undefined;
                previous.controller.abort();
                await previous.done;
            }
            await replacing;
            for (const pending of pendingCancels.values())
                pending.resolve(undefined);
            pendingCancels.clear();
            operations.clear();
            buffers.clear();
        },
    };
}
function parseRuntimeOwner(value) {
    if (typeof value !== 'object' || value === null || Array.isArray(value))
        throw new RelayProtocolError('INVALID_INPUT', 'runtime owner record must be an object');
    const record = value;
    if (record.version !== 1 || typeof record.pid !== 'number' || !Number.isSafeInteger(record.pid) || record.pid <= 0 ||
        typeof record.startToken !== 'string' || record.startToken.length === 0 || typeof record.leasePort !== 'number' ||
        !Number.isSafeInteger(record.leasePort) || record.leasePort <= 0 || record.leasePort > 65535) {
        throw new RelayProtocolError('INVALID_INPUT', 'runtime owner record is invalid');
    }
    return { version: 1, pid: record.pid, startToken: record.startToken, leasePort: record.leasePort };
}
async function readRuntimeOwner(path) {
    try {
        return parseRuntimeOwner(JSON.parse(await readFile(path, 'utf8')));
    }
    catch (error) {
        if (error.code === 'ENOENT')
            return undefined;
        if (error instanceof RelayProtocolError)
            throw error;
        throw new RelayProtocolError('INVALID_INPUT', `runtime owner record is unreadable: ${error instanceof Error ? error.message : String(error)}`);
    }
}
export async function loadAgentProcessConfig(path, env = process.env) {
    const configPath = resolve(path);
    const input = object(JSON.parse(await readFile(configPath, 'utf8')), ['version', 'identity', 'scopeId', 'dataDirectory', 'leasePort', 'relay', 'presenceIntervalMs', 'policy', 'cli', 'openCode', 'directListener', 'endpoint'], 'Agent config');
    if (input.version !== 1)
        throw new RelayProtocolError('UNSUPPORTED_VERSION', 'Agent config version must be 1');
    const location = (value, label) => resolve(dirname(configPath), text(value, label));
    const cli = object(input.cli, ['camoExecutable', 'searchExecutable', 'searchRoot', 'profilePrefix'], 'cli');
    const policy = object(input.policy, ['revision', 'allowedConsumers', 'allowedManagers'], 'policy');
    if (!Array.isArray(policy.allowedConsumers) || policy.allowedConsumers.some(item => typeof item !== 'string' || !item) ||
        new Set(policy.allowedConsumers).size !== policy.allowedConsumers.length)
        throw new RelayProtocolError('INVALID_INPUT', 'allowedConsumers must be unique Agent IDs');
    const allowedManagers = policy.allowedManagers === undefined ? [] : policy.allowedManagers;
    if (!Array.isArray(allowedManagers) || allowedManagers.some(item => typeof item !== 'string' || !item) || new Set(allowedManagers).size !== allowedManagers.length) {
        throw new RelayProtocolError('INVALID_INPUT', 'allowedManagers must be unique Agent IDs');
    }
    const declaration = parseAgentDeclaration({ identity: input.identity, scopeId: input.scopeId, revision: 1, capabilities: [], routes: [] });
    // Launcher launch parameters (machine-generated projection), never user config authority.
    // The U2 contract removes openCode from user config; legacy v2 projections still carry it.
    let openCode;
    if (input.openCode !== undefined) {
        const value = object(input.openCode, ['executable', 'directory', 'configFile', 'port', 'startupTimeoutMs', 'stopTimeoutMs'], 'openCode');
        openCode = { executable: location(value.executable, 'openCode.executable'), directory: location(value.directory, 'openCode.directory'),
            configFile: location(value.configFile, 'openCode.configFile'), port: number(value.port, 'openCode.port', 65535),
            startupTimeoutMs: number(value.startupTimeoutMs, 'openCode.startupTimeoutMs'), stopTimeoutMs: number(value.stopTimeoutMs, 'openCode.stopTimeoutMs') };
    }
    const directListener = input.directListener === undefined ? undefined : loadDirectListenerConfig(input.directListener, declaration, configPath, env);
    let endpoint;
    if (input.endpoint !== undefined) {
        const endpointInput = object(input.endpoint, ['role', 'connect', 'services'], 'endpoint');
        if (endpointInput.role !== 'provider' && endpointInput.role !== 'receiver' && endpointInput.role !== 'hybrid')
            throw new RelayProtocolError('INVALID_INPUT', 'endpoint.role is invalid');
        let connect;
        if (endpointInput.connect !== undefined) {
            const connection = object(endpointInput.connect, ['targetAgentId', 'capabilityId', 'capabilityVersion', 'operation', 'demands'], 'endpoint.connect');
            const field = (key) => text(connection[key], `endpoint.connect.${key}`);
            if (!Array.isArray(connection.demands) || connection.demands.length === 0)
                throw new RelayProtocolError('INVALID_INPUT', 'endpoint.connect.demands must be non-empty');
            const demands = connection.demands.map((item, index) => {
                const demand = object(item, ['resourceId', 'amount'], `endpoint.connect.demands[${index}]`);
                return { resourceId: text(demand.resourceId, `endpoint.connect.demands[${index}].resourceId`), amount: number(demand.amount, `endpoint.connect.demands[${index}].amount`) };
            });
            connect = {
                targetAgentId: field('targetAgentId'),
                capabilityId: field('capabilityId'),
                capabilityVersion: field('capabilityVersion'),
                operation: field('operation'),
                demands,
            };
        }
        if ((endpointInput.role === 'receiver' || endpointInput.role === 'hybrid') && connect === undefined)
            throw new RelayProtocolError('INVALID_INPUT', 'receiver endpoint requires endpoint.connect');
        const services = endpointInput.services === undefined ? [] : (() => {
            if (!Array.isArray(endpointInput.services))
                throw new RelayProtocolError('INVALID_INPUT', 'endpoint.services must be an array');
            return endpointInput.services.map((value, index) => {
                const service = object(value, ['capabilityId', 'version', 'operations', 'resources'], `endpoint.services[${index}]`);
                const operations = service.operations;
                if (!Array.isArray(operations) || operations.some(operation => typeof operation !== 'string' || operation.length === 0)) {
                    throw new RelayProtocolError('INVALID_INPUT', `endpoint.services[${index}].operations must be a string array`);
                }
                const resources = service.resources;
                if (!Array.isArray(resources) || resources.length === 0)
                    throw new RelayProtocolError('INVALID_INPUT', `endpoint.services[${index}].resources must be a non-empty array`);
                return {
                    capabilityId: text(service.capabilityId, `endpoint.services[${index}].capabilityId`),
                    version: text(service.version, `endpoint.services[${index}].version`),
                    operations: operations.map((operation, operationIndex) => text(operation, `endpoint.services[${index}].operations[${operationIndex}]`)),
                    resources: resources.map((resourceValue, resourceIndex) => {
                        const resource = object(resourceValue, ['resourceId', 'capacity', 'unit'], `endpoint.services[${index}].resources[${resourceIndex}]`);
                        const unit = resource.unit;
                        if (unit !== 'slot' && unit !== 'context')
                            throw new RelayProtocolError('INVALID_INPUT', `endpoint.services[${index}].resources[${resourceIndex}].unit is invalid`);
                        return {
                            resourceId: text(resource.resourceId, `endpoint.services[${index}].resources[${resourceIndex}].resourceId`),
                            capacity: number(resource.capacity, `endpoint.services[${index}].resources[${resourceIndex}].capacity`),
                            unit: unit,
                        };
                    }),
                };
            });
        })();
        endpoint = { role: endpointInput.role, ...(connect === undefined ? {} : { connect }), services };
    }
    return {
        declaration, dataDirectory: location(input.dataDirectory, 'dataDirectory'), leasePort: number(input.leasePort, 'leasePort', 65535),
        presenceIntervalMs: number(input.presenceIntervalMs, 'presenceIntervalMs'), policyRevision: number(policy.revision, 'policy.revision'),
        allowedConsumers: [...policy.allowedConsumers],
        allowedManagers: [...allowedManagers],
        cli: { camoExecutable: location(cli.camoExecutable, 'camoExecutable'), searchExecutable: location(cli.searchExecutable, 'searchExecutable'),
            searchRoot: location(cli.searchRoot, 'searchRoot'), profilePrefix: text(cli.profilePrefix, 'profilePrefix') },
        ...(openCode === undefined ? {} : { openCode }),
        ...(directListener === undefined ? {} : { directListener }),
        ...(endpoint === undefined ? {} : { endpoint }),
        relay: await loadRelayConfig(input.relay, declaration, configPath, env),
    };
}
async function closeLease(server) {
    if (server.listening)
        await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
}
async function availableLoopbackPort() {
    const listener = createServer();
    listener.listen(0, '127.0.0.1');
    await new Promise((resolveListening, reject) => {
        const failed = (error) => { listener.off('listening', resolveListening); reject(error); };
        const ready = () => { listener.off('error', failed); resolveListening(); };
        listener.once('error', failed);
        listener.once('listening', ready);
    });
    const address = listener.address();
    await new Promise(resolveClosing => listener.close(() => resolveClosing()));
    if (address === null || typeof address === 'string')
        throw new Error('managed OpenCode port unavailable');
    return address.port;
}
function executableLaunchPath(candidate, searchPath) {
    if (candidate.length === 0)
        return undefined;
    if (candidate.includes(delimiter) || existsSync(candidate)) {
        try {
            accessSync(candidate, 0o1);
            return resolve(candidate);
        }
        catch {
            return undefined;
        }
    }
    for (const directory of (searchPath ?? '').split(delimiter)) {
        if (directory.length === 0)
            continue;
        const candidatePath = resolve(directory, candidate);
        try {
            accessSync(candidatePath, 0o1);
            if (statSync(candidatePath).isFile())
                return candidatePath;
        }
        catch { /* continue searching */ }
    }
    return undefined;
}
function resolveOpenCodeExecutable(env) {
    const override = env.AGENTTEAMS_OPENCODE_EXECUTABLE;
    if (override !== undefined)
        return executableLaunchPath(override, env.PATH);
    return executableLaunchPath('opencode', env.PATH);
}
async function ownDataDirectory(config) {
    const lease = createServer(socket => socket.destroy());
    await new Promise((resolve, reject) => {
        const failed = (error) => { lease.off('listening', ready); reject(error); };
        const ready = () => { lease.off('error', failed); resolve(); };
        lease.once('error', failed);
        lease.once('listening', ready);
        lease.listen({ host: '127.0.0.1', port: config.leasePort, exclusive: true });
    });
    try {
        await mkdir(config.dataDirectory, { recursive: true, mode: 0o700 });
        const ownerPath = resolve(config.dataDirectory, 'runtime-owner.json');
        const previousOwner = await readRuntimeOwner(ownerPath);
        const { label: _label, ...stableIdentity } = config.declaration.identity;
        const identity = JSON.stringify({ version: 1, identity: stableIdentity, scopeId: config.declaration.scopeId, leasePort: config.leasePort });
        const target = resolve(config.dataDirectory, 'identity.json');
        const temporary = resolve(config.dataDirectory, `.identity-${randomUUID()}`);
        const file = await open(temporary, 'wx', 0o600);
        try {
            await file.writeFile(identity);
            await file.sync();
        }
        finally {
            await file.close();
        }
        try {
            try {
                await link(temporary, target);
            }
            catch (error) {
                if (error.code !== 'EEXIST')
                    throw error;
            }
            if ((await readFile(target, 'utf8')) !== identity)
                throw new RelayProtocolError('CONFLICT', 'data directory belongs to another identity or lease port');
            const directory = await open(config.dataDirectory, 'r');
            try {
                await directory.sync();
            }
            finally {
                await directory.close();
            }
        }
        finally {
            await unlink(temporary);
        }
        const ownerTemporary = resolve(config.dataDirectory, `.runtime-owner-${randomUUID()}`);
        const ownerFile = await open(ownerTemporary, 'wx', 0o600);
        try {
            await ownerFile.writeFile(`${JSON.stringify({ version: 1, pid: process.pid, startToken: currentWorkProcessStartToken(), leasePort: config.leasePort })}\n`);
            await ownerFile.sync();
        }
        finally {
            await ownerFile.close();
        }
        try {
            await rename(ownerTemporary, ownerPath);
        }
        finally {
            try {
                await unlink(ownerTemporary);
            }
            catch { /* already renamed */ }
        }
        return { server: lease, ...(previousOwner === undefined ? {} : { previousOwner }) };
    }
    catch (error) {
        await closeLease(lease);
        throw error;
    }
}
const WORK_GRAPH = {
    'work.submit': { file: 'agent-work.graph.json', id: 'agent-work' },
    'work.query': { file: 'work-query.graph.json', id: 'work-query' },
    'work.open': { file: 'work-open.graph.json', id: 'work-open' },
    'work.request': { file: 'work-request.graph.json', id: 'work-request' },
    'work.close': { file: 'work-close.graph.json', id: 'work-close' },
};
/** Nearest ancestor directory holding the package.json; the installed pack root in every layout. */
function packageRootOf(start) {
    let directory = resolve(start);
    while (true) {
        if (existsSync(resolve(directory, 'package.json')))
            return directory;
        const parent = resolve(directory, '..');
        if (parent === directory)
            throw new Error('agentteams package root cannot be resolved from the runtime module');
        directory = parent;
    }
}
function dagpipeRoot() {
    return resolve(packageRootOf(dirname(fileURLToPath(import.meta.url))), 'runtime', 'dagpipe');
}
function sha256(content) {
    return createHash('sha256').update(content).digest('hex');
}
/**
 * Resolve the installed runner and graph from the pack root and verify their
 * manifest hashes before any provider side effect.
 */
async function resolveDagpipeArtifacts(kind) {
    if (process.platform !== 'darwin' || process.arch !== 'arm64') {
        return { code: 'UNSUPPORTED_PLATFORM', message: `local Work requires darwin-arm64, received ${process.platform}-${process.arch}` };
    }
    const root = dagpipeRoot();
    const manifestPath = resolve(root, 'manifest.json');
    let manifest;
    try {
        manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
    }
    catch (cause) {
        return { code: 'DAGPIPE_RUNNER_MISSING', message: `dagpipe manifest is unavailable: ${manifestPath}: ${cause instanceof Error ? cause.message : String(cause)}` };
    }
    const graph = WORK_GRAPH[kind];
    const runnerPath = resolve(root, manifest.runner.path);
    let runnerBytes;
    try {
        runnerBytes = await readFile(runnerPath);
    }
    catch (cause) {
        return { code: 'DAGPIPE_RUNNER_MISSING', message: `dagpipe runner is unavailable: ${runnerPath}: ${cause instanceof Error ? cause.message : String(cause)}` };
    }
    if (sha256(runnerBytes) !== manifest.runner.sha256)
        return { code: 'RUNNER_HASH_MISMATCH', message: `dagpipe runner hash does not match the manifest: ${runnerPath}` };
    const graphEntry = manifest.graphs.find(entry => entry.id === graph.id || entry.path === `graphs/${graph.file}`);
    if (graphEntry === undefined)
        return { code: 'DAGPIPE_RUNNER_MISSING', message: `dagpipe manifest does not declare graph ${graph.id}` };
    const graphPath = resolve(root, graphEntry.path);
    let graphBytes;
    try {
        graphBytes = await readFile(graphPath);
    }
    catch (cause) {
        return { code: 'DAGPIPE_RUNNER_MISSING', message: `dagpipe graph is unavailable: ${graphPath}: ${cause instanceof Error ? cause.message : String(cause)}` };
    }
    if (sha256(graphBytes) !== graphEntry.sha256)
        return { code: 'GRAPH_HASH_MISMATCH', message: `dagpipe graph hash does not match the manifest: ${graphPath}` };
    return { runnerPath, graphPath };
}
function workIntent(frame, receiverAgentId, connect, policyRevision) {
    const base = { receiverAgentId, workId: frame.control.workId, requestId: frame.control.requestId };
    if (frame.kind === 'work.submit') {
        if (connect === undefined)
            return { code: 'INVALID_INPUT', message: 'receiver has no endpoint.connect service intent for submit' };
        return {
            control: {
                ...base,
                targetAgentId: connect.targetAgentId,
                capabilityId: connect.capabilityId,
                capabilityVersion: connect.capabilityVersion,
                operation: connect.operation,
                policyRevision,
                demands: connect.demands,
            },
            business: frame.business,
        };
    }
    if (frame.kind === 'work.query') {
        if (frame.control.serviceSelection === 'capability') {
            return {
                control: {
                    ...base,
                    targetAgentId: frame.control.targetAgentId,
                    targetGeneration: frame.control.targetGeneration,
                    ...(frame.control.linkGeneration === undefined ? {} : { linkGeneration: frame.control.linkGeneration }),
                    serviceSelection: 'capability',
                    capabilityId: frame.control.capabilityId,
                    capabilityVersion: frame.control.capabilityVersion,
                    operation: frame.control.operation,
                },
            };
        }
        if (connect === undefined)
            return { code: 'INVALID_INPUT', message: 'receiver has no endpoint.connect service intent for endpoint query' };
        return {
            control: {
                ...base,
                targetAgentId: connect.targetAgentId,
                serviceSelection: 'endpoint',
                capabilityId: connect.capabilityId,
                capabilityVersion: connect.capabilityVersion,
                operation: connect.operation,
            },
        };
    }
    const control = {
        ...base,
        targetAgentId: frame.control.targetAgentId,
        targetGeneration: frame.control.targetGeneration,
        serviceSelection: 'capability',
        capabilityId: frame.control.capabilityId,
        capabilityVersion: frame.control.capabilityVersion,
        operation: frame.control.operation,
    };
    if (frame.kind === 'work.close')
        return { control };
    const persistent = { ...control, demands: frame.control.demands };
    if (frame.kind === 'work.open') {
        return { control: { ...persistent, policyRevision: frame.control.policyRevision ?? policyRevision }, business: frame.business };
    }
    return { control: persistent, business: frame.business };
}
async function executeProjectWork(input) {
    const artifacts = await resolveDagpipeArtifacts(input.frame.kind);
    if ('code' in artifacts)
        return failedLocalWorkReceipt(input.frame, artifacts);
    const intent = workIntent(input.frame, input.receiverAgentId, input.connect, input.policyRevision);
    if ('code' in intent)
        return failedLocalWorkReceipt(input.frame, intent);
    return await runWorkExecution(input.client, {
        runnerPath: artifacts.runnerPath,
        graphPath: artifacts.graphPath,
        projectId: 'agentteams-local-work',
        executionId: input.frame.control.executionId,
        attemptId: input.frame.control.attemptId,
        intent,
    });
}
export async function startAgentProcess(configPath, env = process.env) {
    const config = await loadAgentProcessConfig(configPath, env);
    const services = config.endpoint?.role === 'receiver' ? [] : config.endpoint?.services ?? [];
    const executor = createCliWorkExecutor({ services, ...config.cli });
    const advertisedCapabilities = config.endpoint?.role === 'receiver' ? [] : executor.capabilities;
    const ownership = await ownDataDirectory(config);
    const lease = ownership.server;
    let daemon;
    let directListener;
    let consumerWork;
    let configBinding;
    let sessionHost;
    let sessionFailureReason;
    let readyResolve;
    let readyReject;
    const ready = new Promise((resolve, reject) => { readyResolve = resolve; readyReject = reject; });
    void ready.catch(() => undefined); // Startup failure is also returned to the caller.
    try {
        let host;
        let ledger;
        const resolveCredentialValue = async (reference) => {
            const value = env[reference];
            if (typeof value !== 'string' || value.length === 0)
                throw new RuntimeConfigError({ code: 'CREDENTIAL_UNAVAILABLE', message: `credential ${reference} is unavailable` });
            return value;
        };
        const agentId = config.declaration.identity.agentId;
        // U2 owns accepted/effective binding truth; U6 owns managed launch derivation.
        // No user config supplies openCode: the launch block is a launcher-generated
        // projection parameter, and v3 user config retired it entirely.
        const localConfigPath = env.TEAMS_LOCAL_CONFIG_PATH ?? (config.endpoint?.role === undefined ? undefined : defaultLocalConfigPath(env.HOME));
        const localStore = localConfigPath === undefined ? undefined : (() => {
            const internalPath = env.TEAMS_LOCAL_INTERNAL_PATH ?? resolve(localConfigPath, '..', 'internal.toml');
            const persistence = createTomlRuntimeConfigPersistence({ configPath: localConfigPath, internalPath, agentId });
            return { internalPath, persistence, store: createRuntimeConfigStore(persistence, { agentId }) };
        })();
        const configStore = localStore?.store;
        if (localStore !== undefined) {
            const effective = await localStore.store.read();
            const binding = effective.agents[agentId];
            const provider = binding === undefined ? undefined : effective.providers[binding.primary.providerInstanceId];
            const modelEntry = binding === undefined ? undefined : provider === undefined ? undefined
                : effective.catalogs[binding.primary.providerInstanceId]?.entries.find(entry => entry.ref.providerInstanceId === binding.primary.providerInstanceId && entry.ref.modelId === binding.primary.modelId);
            if (binding !== undefined && provider !== undefined && modelEntry !== undefined) {
                const executable = resolveOpenCodeExecutable(env);
                if (executable === undefined) {
                    // A binding whose launch-owned executable is unresolvable constructs no owner,
                    // so this Agent is passive: it has no Session execution path. The refusal is the
                    // contract's typed capability refusal, not a Config-owner credential error.
                    sessionFailureReason = { code: 'UNSUPPORTED_OPERATION', message: 'managed OpenCode executable is unavailable' };
                }
                else {
                    const owner = createManagedConfigOwner({ agentId, executable,
                        directory: config.dataDirectory, port: await availableLoopbackPort(),
                        startupTimeoutMs: MANAGED_OPENCODE_STARTUP_TIMEOUT_MS,
                        stopTimeoutMs: MANAGED_OPENCODE_STOP_TIMEOUT_MS, resolveCredential: resolveCredentialValue,
                        persistence: createManagedConfigOwnerPersistence({ agentId, internalPath: localStore.internalPath, persistence: localStore.persistence }) });
                    const configBindingPort = createConsoleConfigBinding({ agentId, store: localStore.store,
                        models: createOpenAIModelCatalogClient(), credentials: { resolve: async (reference) => ({ kind: 'bearer', value: await resolveCredentialValue(reference) }) }, applier: owner });
                    configBinding = { binding: configBindingPort, owner, store: localStore.store };
                    // Reconcile the exact current target before Session/command ingress opens.
                    await owner.recover(async () => {
                        const current = await localStore.store.read();
                        const modelBinding = current.agents[agentId];
                        const currentProvider = modelBinding === undefined ? undefined : current.providers[modelBinding.primary.providerInstanceId];
                        return currentProvider === undefined ? undefined : { target: targetIdentityFor(current, currentProvider), config: current };
                    });
                    // One Session owner per managed child: the same owner port, no second config or child.
                    sessionHost = createSessionHost({
                        agentId,
                        generation: () => daemon?.network.generation ?? 0,
                        owner: {
                            readiness: () => owner.readiness(),
                            currentHandle: () => owner.currentHandle(),
                            use: operation => owner.use(operation),
                        },
                    });
                    await sessionHost.ensureStream();
                }
            }
        }
        const allowed = (consumer) => config.allowedConsumers.includes(consumer.agentId);
        const policy = { revision: config.policyRevision, authorizeWork: allowed, authorizeRequest: allowed };
        // One runtime management row per Agent. A passive Agent never calls an owner.
        const runtimeRow = async () => {
            const generation = daemon?.network.generation;
            const base = {
                agentId: config.declaration.identity.agentId,
                machineId: config.declaration.identity.machineId,
                label: config.declaration.identity.label,
                presence: daemon?.status().state === 'online' ? 'online' : 'offline',
                capabilities: advertisedCapabilities.map(item => item.capabilityId),
                // Same-package producers always emit the complete declared summary beside the IDs.
                capabilityDetails: projectCapabilityDetails(advertisedCapabilities),
                ...(generation === undefined ? {} : { generation }),
            };
            // The advertised capability and the dispatch path are the same fact:
            // without the owner the Agent is passive, regardless of a stored binding.
            if (configBinding === undefined || sessionHost === undefined || configStore === undefined) {
                return projectRuntimeAgentRow({ ...base, sessionCapable: false });
            }
            const current = await configStore.read();
            if (current.agents[config.declaration.identity.agentId] === undefined) {
                return projectRuntimeAgentRow({ ...base, sessionCapable: false });
            }
            return projectRuntimeAgentRow({
                ...base,
                sessionCapable: true,
                readiness: configBinding?.owner.readiness() ?? { state: 'no-current' },
                observation: sessionHost?.observation(),
                currentSessionId: sessionHost?.currentSessionId(),
            });
        };
        const consoleClient = {
            readProjection: async () => {
                const sessionEvents = sessionHost?.sessionEvents() ?? [];
                const sessions = sessionHost === undefined ? [] : await sessionHost.projectionSessions();
                return {
                    version: 1,
                    agents: [await runtimeRow()],
                    sessions, notifications: [],
                    configs: configBinding === undefined ? [] : [await configBinding.binding.readProjection()],
                    ...(sessionEvents.length === 0 ? {} : { sessionEvents }),
                    ...projectConsoleWorkObservations(config.declaration.identity.agentId, ledger?.snapshot.works ?? []),
                };
            },
            command: async (command) => {
                if (command.kind.startsWith('config.')) {
                    if (configBinding === undefined)
                        return { ok: false, error: { code: 'UNSUPPORTED_OPERATION', message: 'Agent has no model configuration owner' } };
                    const result = await configBinding.binding.command(command);
                    // An applied revision replaces the child; re-point the single event stream at it.
                    await sessionHost?.ensureStream();
                    return result;
                }
                if (sessionHost === undefined)
                    return { ok: false, error: sessionFailureReason ?? { code: 'UNSUPPORTED_OPERATION', message: 'Passive CLI Agent has no Session execution capability' } };
                switch (command.kind) {
                    case 'session.create': return await sessionHost.createSession(command.title);
                    case 'session.open': return await sessionHost.openSession(command.sessionId);
                    case 'session.cancel': return await sessionHost.cancelSession(command.sessionId);
                    case 'permission.reply': return await sessionHost.replyPermission(command.sessionId, command.permissionId, command.decision);
                    default: return { ok: false, error: { code: 'UNSUPPORTED_OPERATION', message: 'Command is not supported by this Agent' } };
                }
            },
            sendSession: async (target, payload) => sessionHost === undefined
                ? ({ ok: false, error: sessionFailureReason ?? { code: 'UNSUPPORTED_OPERATION', message: 'Passive CLI Agent has no Session execution capability' } })
                : await sessionHost.sendSession(target.sessionId, payload),
        };
        daemon = await startAgentDaemon({ presenceIntervalMs: config.presenceIntervalMs, relay: { ...config.relay,
                declaration: config.declaration,
                onEvent: async (event) => {
                    if (event.kind !== 'relay.offer')
                        return;
                    await ready;
                    if (event.grant.targetAgentId !== config.declaration.identity.agentId)
                        throw new RelayProtocolError('FORBIDDEN', 'offer is not directed to this provider');
                    void (async () => {
                        const socket = await daemon.network.openData(event.grant);
                        const peer = { accountId: event.grant.accountId, scopeId: event.grant.scopeId, agentId: event.grant.sourceAgentId };
                        await acceptAgentData(socket, {
                            work: { timeoutMs: config.relay.requestTimeoutMs, maxPending: config.relay.maxPendingRequests,
                                maxIncoming: config.relay.maxPendingRequests, onRequest: createWorkIngress(host, peer) },
                            console: createConsoleIngress({ agentId: config.declaration.identity.agentId, generation: () => daemon.network.generation,
                                client: consoleClient, authorize: principal => principal.accountId === config.declaration.identity.accountId &&
                                    principal.scopeId === config.declaration.scopeId && config.allowedManagers.includes(principal.agentId) }, peer),
                        });
                    })().catch(error => {
                        // A scoped data failure must not kill registration or imply an owning operation completed.
                        console.error('Agent data connection closed:', error instanceof RelayProtocolError ? error.code : 'UNAVAILABLE');
                    });
                },
            } });
        if (config.directListener !== undefined) {
            const admissions = config.directListener.admissions.length > 0
                ? config.directListener.admissions
                : config.allowedConsumers.length === 1
                    ? [{ admissionRef: `direct:${config.allowedConsumers[0]}`, agentId: config.allowedConsumers[0], credential: config.directListener.credential }]
                    : (() => { throw new RelayProtocolError('INVALID_INPUT', 'directListener requires peer-specific admissions when multiple consumers are allowed'); })();
            if (admissions.some(admission => !config.allowedConsumers.includes(admission.agentId))) {
                throw new RelayProtocolError('FORBIDDEN', 'directListener admission is not present in allowedConsumers');
            }
            directListener = await createDirectWssListener({
                host: config.directListener.host,
                port: config.directListener.port,
                key: await readFile(config.directListener.keyFile),
                cert: await readFile(config.directListener.certFile),
                admissions: admissions.map(admission => ({
                    admissionRef: admission.admissionRef,
                    peer: { accountId: config.declaration.identity.accountId, scopeId: config.declaration.scopeId, agentId: admission.agentId },
                    credential: admission.credential,
                })),
                target: { ...config.directListener.target, targetGeneration: daemon.network.generation },
                maxPayload: config.directListener.maxPayload,
                maxConnections: config.directListener.maxConnections,
                maxMessageBytes: config.directListener.maxMessageBytes,
                maxBufferedBytes: config.directListener.maxBufferedBytes,
                maxPendingFrames: config.directListener.maxPendingFrames,
                helloTimeoutMs: config.directListener.helloTimeoutMs,
            });
        }
        const workFile = resolve(config.dataDirectory, 'work.json');
        const workLock = readFileWorkStoreLockProof(workFile);
        if (workLock !== undefined) {
            const previousOwner = ownership.previousOwner;
            if (previousOwner === undefined || previousOwner.pid !== workLock.ownerPid || previousOwner.startToken !== workLock.ownerStartToken || previousOwner.leasePort !== config.leasePort) {
                throw new RelayProtocolError('UNAVAILABLE', 'stale work store lock has no matching previous daemon owner');
            }
            recoverFileWorkStoreLock(workFile, createTrustedWorkAuthority(), workLock, owner => owner.pid === previousOwner.pid && owner.startToken === previousOwner.startToken);
        }
        const directRoute = directListener === undefined ? undefined : {
            candidateId: 'direct',
            kind: 'lan',
            endpoint: directListener.url,
            port: directListener.port,
            authRequired: true,
            lastSeenAt: new Date().toISOString(),
        };
        const publishedDeclaration = {
            ...config.declaration,
            revision: 2,
            capabilities: advertisedCapabilities,
            ...(directRoute === undefined ? {} : { routes: [directRoute] }),
        };
        ledger = createWorkLedger({ provider: { accountId: config.declaration.identity.accountId, scopeId: config.declaration.scopeId,
                agentId: config.declaration.identity.agentId }, generation: daemon.network.generation, capabilities: advertisedCapabilities,
            endpointCatalog: compileDeclarationEndpoints(publishedDeclaration), store: createFileWorkStore(workFile) });
        const hasUnreconciledState = ledger.snapshot.allocations.some(allocation => allocation.state !== 'released') ||
            ledger.snapshot.requests.some(request => ['running', 'cancel_requested', 'unknown'].includes(request.state));
        if (hasUnreconciledState) {
            // A restarted daemon has no trusted external completion observation. Persist
            // RESULT_UNKNOWN through the ledger owner before refusing new Work; never
            // replay an operation or release a resource on process absence alone.
            recover(ledger, createTrustedWorkAuthority(), []);
            throw new RelayProtocolError('RESULT_UNKNOWN', 'persisted resources require trusted reconciliation before serving Work');
        }
        host = createWorkHost({ ledger, policy: () => policy, executor });
        await daemon.network.publish(publishedDeclaration);
        consumerWork = createAgentWorkClient(daemon.network, {
            accountId: config.declaration.identity.accountId,
            scopeId: config.declaration.scopeId,
            agentId: config.declaration.identity.agentId,
        }, { timeoutMs: config.relay.requestTimeoutMs, maxPending: config.relay.maxPendingRequests });
        readyResolve();
        const live = daemon;
        let stopping;
        const stop = () => {
            if (stopping)
                return stopping;
            stopping = (async () => {
                try {
                    await consumerWork?.dispose();
                    await directListener?.close();
                    await live.stop();
                    await sessionHost?.dispose();
                    await configBinding?.owner.stop();
                    const results = await Promise.allSettled(ledger.snapshot.works.filter(work => work.state !== 'closed' && work.state !== 'rejected').map(work => host.close({ accountId: ledger.provider.accountId, scopeId: ledger.provider.scopeId, agentId: work.consumerAgentId }, work.workId)));
                    const failures = results.filter((result) => result.status === 'rejected');
                    if (failures.length)
                        throw new AggregateError(failures.map(result => result.reason), 'Agent resource cleanup remains unconfirmed');
                }
                finally {
                    try {
                        await unlink(resolve(config.dataDirectory, 'runtime-owner.json'));
                    }
                    catch { /* owner record may already be absent */ }
                    await closeLease(lease);
                }
            })();
            return stopping;
        };
        const closed = live.closed.then(async (state) => { await stop(); if (state.state === 'failed')
            throw state.error ?? new Error('Agent network failed'); });
        const statusProjection = () => ({
            agentId: publishedDeclaration.identity.agentId,
            identity: publishedDeclaration.identity,
            role: config.endpoint?.role ?? 'provider',
            presence: 'online',
            state: 'online',
            generation: live.network.generation,
            capabilities: publishedDeclaration.capabilities.map(capability => ({
                capabilityId: capability.capabilityId,
                version: capability.version,
                operations: capability.operations.map(operation => operation.operation),
                resources: capability.resources.map(resource => ({ resourceId: resource.resourceId, capacity: resource.capacity, unit: resource.unit })),
            })),
        });
        const connect = config.endpoint?.connect;
        const executeWork = (frame) => executeProjectWork({ frame, client: consumerWork, connect, policyRevision: config.policyRevision, receiverAgentId: config.declaration.identity.agentId });
        return { daemon: live, consumerWork: consumerWork, executeWork, statusProjection, stop, closed };
    }
    catch (error) {
        readyReject(error);
        try {
            await directListener?.close();
            await daemon?.stop();
            await sessionHost?.dispose();
            await configBinding?.owner.stop();
        }
        finally {
            await closeLease(lease);
        }
        throw error;
    }
}
/**
 * Build the typed reply for one launcher Work frame. Exported so the failure
 * contract — identity, fixed binding and unconfirmed delivery — is verifiable
 * without spawning a daemon.
 */
export async function resolveWorkChildReply(handle, request) {
    const frame = request.frame;
    if (request.receiverAgentId !== handle.daemon.status().agentId) {
        return { kind: 'work.error', requestId: frame.requestId, error: { code: 'RECEIVER_NOT_FOUND', message: 'Work request reached a different receiver identity' } };
    }
    if (request.expectedAgentGeneration !== handle.daemon.network.generation) {
        return { kind: 'work.error', requestId: frame.requestId, error: { code: 'STALE_GENERATION', message: 'Work request targets a stale receiver generation' } };
    }
    try {
        return { kind: 'work.result', requestId: frame.requestId, receipt: await handle.executeWork(frame) };
    }
    catch (error) {
        // A throw here means the execution did not reach a terminal receipt. The
        // provider may already have accepted or executed the Work, so report the
        // typed failed receipt with the original identity and binding and mark the
        // local delivery unconfirmed instead of collapsing to a bare error.
        const code = error.code;
        return {
            kind: 'work.result',
            requestId: frame.requestId,
            receipt: failedLocalWorkReceipt(frame, {
                code: typeof code === 'string' && code.length > 0 ? code : 'EXECUTION_FAILED',
                message: error instanceof Error ? error.message : 'receiver Work execution failed',
            }, 'unconfirmed'),
        };
    }
}
export async function runAgentProcess(argv = process.argv.slice(2)) {
    if (!((argv.length === 2 || argv.length === 4) && argv[0] === '--config' && (argv.length === 2 || (argv[2] === '--launcher-start-token' && argv[3].trim() !== ''))))
        throw new RelayProtocolError('INVALID_INPUT', 'usage: agent-process --config <file>');
    const handle = await startAgentProcess(argv[1]);
    const stop = () => { void handle.stop().catch(error => { process.exitCode = 1; console.error(error.message); }); };
    process.once('SIGINT', stop);
    process.once('SIGTERM', stop);
    // The launcher forwards typed Work frames over this child's IPC channel. The
    // receiver binds its own registered identity and executes through the sole
    // AgentWorkClient + runWorkExecution path; it never rebuilds control state.
    const onMessage = (message) => {
        if (typeof message !== 'object' || message === null)
            return;
        const request = message;
        if (request.kind !== 'work.control' || typeof request.localCorrelation !== 'string' || request.frame === undefined)
            return;
        const localCorrelation = request.localCorrelation;
        void (async () => {
            const reply = {
                kind: 'work.reply',
                localCorrelation,
                reply: await resolveWorkChildReply(handle, request),
            };
            process.send?.(reply);
        })();
    };
    process.on('message', onMessage);
    const status = handle.daemon.status();
    // Preserve the established first readiness frame for external child readers;
    // the typed status projection follows on the same IPC channel.
    process.send?.({ kind: 'daemon.registered', agentId: status.agentId, generation: status.generation });
    process.send?.({ kind: 'daemon.status', agentId: status.agentId, generation: status.generation, endpoint: handle.statusProjection() });
    try {
        await handle.closed;
    }
    finally {
        process.off('SIGINT', stop);
        process.off('SIGTERM', stop);
        process.off('message', onMessage);
    }
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
    void runAgentProcess().catch(error => { console.error(error instanceof Error ? error.message : 'Agent startup failed'); process.exitCode = 1; });
}
