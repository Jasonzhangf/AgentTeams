const BUSINESS_PAYLOAD_KEYS = ['sessionId', 'permissionId', 'notificationId', 'requestId'];
function requiredString(value, label) {
    if (typeof value !== 'string' || value.length === 0)
        throw new Error(`directory: ${label} is required`);
    return value;
}
function assertNoBusinessPayload(input) {
    for (const key of BUSINESS_PAYLOAD_KEYS) {
        if (key in input)
            throw new Error(`directory: business payload field ${key} is forbidden`);
    }
    for (const candidate of input.routeCandidates ?? []) {
        for (const key of BUSINESS_PAYLOAD_KEYS) {
            if (key in candidate)
                throw new Error(`directory: route candidate business field ${key} is forbidden`);
        }
    }
}
function normalizeRouteCandidates(candidates) {
    return candidates.map((candidate) => {
        requiredString(candidate.candidateId, 'candidateId');
        if (candidate.endpoint !== undefined) {
            let endpoint;
            try {
                endpoint = new URL(candidate.endpoint);
            }
            catch {
                throw new Error('directory: route endpoint must be a valid URL');
            }
            if (!['http:', 'https:', 'wss:'].includes(endpoint.protocol) || !endpoint.hostname || endpoint.username || endpoint.password || endpoint.hash) {
                throw new Error('directory: route endpoint must use http://, https://, or wss:// without credentials or fragment');
            }
        }
        if (candidate.port !== undefined && (!Number.isInteger(candidate.port) || candidate.port < 1 || candidate.port > 65535)) {
            throw new Error('directory: route port must be between 1 and 65535');
        }
        return {
            candidateId: candidate.candidateId,
            kind: candidate.kind,
            ...(candidate.endpoint === undefined ? {} : { endpoint: candidate.endpoint }),
            ...(candidate.port === undefined ? {} : { port: candidate.port }),
            authRequired: candidate.authRequired,
            lastSeenAt: candidate.lastSeenAt,
        };
    });
}
export function createHostDirectory() {
    return { generation: 0, hosts: new Map() };
}
export function upsertDirectoryHost(directory, input, now = new Date().toISOString()) {
    assertNoBusinessPayload(input);
    const entry = {
        hostId: requiredString(input.hostId, 'hostId'),
        machineId: requiredString(input.machineId, 'machineId'),
        agentId: requiredString(input.agentId, 'agentId'),
        agentKind: input.agentKind,
        accountId: requiredString(input.accountId, 'accountId'),
        capabilitiesRevision: requiredString(input.capabilitiesRevision, 'capabilitiesRevision'),
        health: input.health ?? 'starting',
        routeCandidates: normalizeRouteCandidates(input.routeCandidates),
        updatedAt: now,
        lastSeenAt: input.lastSeenAt ?? now,
    };
    const hosts = new Map(directory.hosts);
    hosts.set(entry.hostId, entry);
    return { generation: directory.generation + 1, hosts };
}
export function touchHostPresence(directory, hostId, now = new Date().toISOString()) {
    const previous = directory.hosts.get(hostId);
    if (!previous)
        throw new Error(`directory: unknown host ${hostId}`);
    const hosts = new Map(directory.hosts);
    hosts.set(hostId, {
        ...previous,
        health: 'ready',
        updatedAt: now,
        lastSeenAt: now,
    });
    return { generation: directory.generation + 1, hosts };
}
export function removeDirectoryHost(directory, hostId) {
    if (!directory.hosts.has(hostId))
        throw new Error(`directory: unknown host ${hostId}`);
    const hosts = new Map(directory.hosts);
    hosts.delete(hostId);
    return { generation: directory.generation + 1, hosts };
}
export function removeStaleHosts(directory, now = new Date().toISOString(), staleAfterMs = 90_000) {
    const cutoff = Date.parse(now) - staleAfterMs;
    const hosts = new Map(directory.hosts);
    for (const [hostId, entry] of hosts) {
        const seen = Date.parse(entry.lastSeenAt);
        if (!Number.isFinite(seen) || seen < cutoff) {
            hosts.set(hostId, { ...entry, health: 'stale' });
        }
    }
    if (hosts.size === directory.hosts.size && [...hosts.entries()].every(([hostId, entry]) => {
        const previous = directory.hosts.get(hostId);
        return previous && previous.health === entry.health && previous.lastSeenAt === entry.lastSeenAt;
    })) {
        return directory;
    }
    return { generation: directory.generation + 1, hosts };
}
export function listDirectoryHosts(directory, accountId) {
    return [...directory.hosts.values()]
        .filter((entry) => accountId === undefined || entry.accountId === accountId)
        .sort((left, right) => right.lastSeenAt.localeCompare(left.lastSeenAt));
}
