import { readFile } from 'node:fs/promises';
import { isAbsolute } from 'node:path';
import { REGISTRY_IMPLEMENTATION } from "../config/daemon-intent.js";
import { DEFAULT_PEER_TTL_MS } from "./relay.js";
/**
 * The single owner that maps the frozen `RegistryDaemonIntent` onto the
 * existing `server/Relay` server options. `RelayProcessConfig` v1 JSON stays an
 * internal projection of the local launcher and is never a second editable
 * source for the registry; this module is the only registry mapping site.
 */
/**
 * A registry `listen` always needs an explicit certificate and key, including a
 * loopback listener. The runtime never generates a certificate and never
 * downgrades to plaintext `ws`.
 */
export const REGISTRY_TLS_OPENSSL_COMMAND = 'openssl req -x509 -newkey rsa:2048 -nodes -days 365 -subj "/CN=<registry-host>" -keyout certs/registry-key.pem -out certs/registry-cert.pem';
/** Reuses the deployed Relay limit policy and adds the server-owned presence lease. */
export const REGISTRY_SERVER_DEFAULTS = {
    maxPayload: 65_536,
    maxConnections: 64,
    maxGrants: 32,
    maxBufferedAmount: 65_536,
    maxPendingMessages: 32,
    maxPendingBytes: 65_536,
    grantTtlMs: 10_000,
    peerTtlMs: DEFAULT_PEER_TTL_MS,
};
export class RegistryIntentFault extends Error {
    code;
    constructor(code, message, cause) {
        super(message, { cause });
        this.code = code;
        this.name = 'RegistryIntentFault';
    }
}
function absoluteFileRef(ref, label) {
    if (!ref.startsWith('file:')) {
        throw new RegistryIntentFault('INVALID_INPUT', `${label} must resolve to a file: reference`);
    }
    const path = ref.slice('file:'.length);
    if (!isAbsolute(path)) {
        throw new RegistryIntentFault('INVALID_INPUT', `${label} must be an absolute path after resolveDaemonIntent`);
    }
    return path;
}
function admissionBinding(admission) {
    return {
        admissionRef: admission.admissionRef,
        identity: { accountId: admission.accountId, scopeId: admission.scopeId, agentId: admission.agentId },
        credentialRef: admission.credentialRef,
    };
}
/**
 * Pure projection of one already-resolved registry intent. It reads no secret
 * and touches no file, so `registry status` can print it without a credential.
 */
export function resolveRegistryServerPlan(intent) {
    if (intent?.daemon?.kind !== 'registry') {
        throw new RegistryIntentFault('UNSUPPORTED_CONFIGURATION', 'registry server options require a registry daemon config');
    }
    const { tlsCertRef, tlsKeyRef } = intent.listen;
    if (tlsCertRef === undefined || tlsKeyRef === undefined) {
        throw new RegistryIntentFault('TLS_REQUIRED', `registry listen requires explicit tlsCertRef and tlsKeyRef, even on a loopback address; generate a local certificate with: ${REGISTRY_TLS_OPENSSL_COMMAND}`);
    }
    return {
        implementation: REGISTRY_IMPLEMENTATION,
        host: intent.listen.ip,
        port: intent.listen.port,
        tls: {
            certFile: absoluteFileRef(tlsCertRef, 'listen.tlsCertRef'),
            keyFile: absoluteFileRef(tlsKeyRef, 'listen.tlsKeyRef'),
        },
        limits: REGISTRY_SERVER_DEFAULTS,
        credentials: intent.admissions.map(admissionBinding),
    };
}
function credentialValue(ref, options) {
    if (ref.startsWith('env:')) {
        const name = ref.slice('env:'.length);
        if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)) {
            throw new RegistryIntentFault('INVALID_INPUT', `credential reference ${ref} is not a valid environment-variable name`);
        }
        const value = (options.env ?? process.env)[name];
        if (typeof value !== 'string' || value.length === 0) {
            throw new RegistryIntentFault('UNAUTHENTICATED', `credential environment ${name} is missing or empty`);
        }
        return Promise.resolve(value);
    }
    if (!ref.startsWith('file:')) {
        throw new RegistryIntentFault('INVALID_INPUT', `credential reference ${ref} must use env:NAME or file:<path>`);
    }
    const path = ref.slice('file:'.length);
    return (options.readFile ?? (async (candidate) => await readFile(candidate, 'utf8')))(path).catch(cause => {
        throw new RegistryIntentFault('NOT_FOUND', `credential file could not be read: ${path}`, cause);
    });
}
/**
 * Resolves every admitted credential value exactly once. The returned map is
 * keyed by the exact `Authorization` header value; it is never a projection
 * field and never enters a directory entry or control frame.
 */
export async function loadRegistryCredentials(plan, options = {}) {
    const credentials = new Map();
    for (const binding of plan.credentials) {
        const raw = await credentialValue(binding.credentialRef, options);
        const value = raw.replace(/\r?\n$/, '');
        if (value.length === 0 || /[\r\n]/.test(value)) {
            throw new RegistryIntentFault('UNAUTHENTICATED', `credential ${binding.credentialRef} is empty or contains a line break`);
        }
        if (credentials.has(value)) {
            throw new RegistryIntentFault('CONFLICT', `duplicate credential value for admission ${binding.admissionRef}`);
        }
        credentials.set(value, { ...binding.identity });
    }
    return credentials;
}
/**
 * Assembles the exact `RelayServerOptions` for one registry. Identity matching
 * against the declaration stays owned by `createRelayServer`.
 */
export function createRegistryRelayOptions(plan, input) {
    return {
        host: plan.host,
        port: plan.port,
        key: input.tls.key,
        cert: input.tls.cert,
        ...plan.limits,
        authenticate: credential => {
            if (credential === undefined)
                return null;
            const identity = input.credentials.get(credential);
            return identity === undefined ? null : { ...identity };
        },
    };
}
