import type { ConsoleAgentObservationV1, ConsoleClientV1 } from '../control-protocol/console-api.ts';
import type { RelayPeer } from '../control-protocol/agent-services.ts';
export interface ConsoleDirectoryBinding {
    readonly peers: readonly RelayPeer[];
    readonly client: (peer: RelayPeer) => ConsoleClientV1;
}
/**
 * One directory agent row projected from an admitted Relay peer. The peer's published
 * declaration owns the identity, generation, presence and capability facts; this is the
 * single mapper for a directory row, shared by the Console hub and the control daemon's
 * directory projection.
 */
export declare function directoryAgentObservation(peer: RelayPeer): ConsoleAgentObservationV1;
/** Compose bound owners without storing a second copy of their state. Empty static bindings use directory discovery. */
export declare function createConsoleHub(bindings: readonly {
    readonly agentId: string;
    readonly client: ConsoleClientV1;
}[], discovery?: () => Promise<ConsoleDirectoryBinding>): ConsoleClientV1;
