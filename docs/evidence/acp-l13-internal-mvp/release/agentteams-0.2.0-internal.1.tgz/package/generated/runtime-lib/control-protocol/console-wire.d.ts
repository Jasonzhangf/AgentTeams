import type { JsonValue } from './agent-services.ts';
import { type ConsoleCommandV1, type ConsoleCommandResultV1, type ConsoleProjectionV1 } from './console-api.ts';
interface ConsoleRequestControl {
    readonly correlationId: string;
    readonly targetGeneration: number;
}
export type ConsoleWireRequest = ConsoleRequestControl & ({
    readonly kind: 'console.projection';
    readonly agentId: string;
} | {
    readonly kind: 'console.command';
    readonly command: ConsoleCommandV1;
} | {
    readonly kind: 'console.session';
    readonly agentId: string;
    readonly sessionId: string;
    readonly payload: JsonValue;
});
export type ConsoleWireReply = {
    readonly kind: 'console.projection.result';
    readonly correlationId: string;
    readonly projection: ConsoleProjectionV1;
} | {
    readonly kind: 'console.result';
    readonly correlationId: string;
    readonly result: ConsoleCommandResultV1;
};
/** This decoder grants no permission: runtime binds the authenticated peer and checks generation. */
export declare function parseConsoleWireRequest(text: string): ConsoleWireRequest;
export declare function parseConsoleWireReply(text: string): ConsoleWireReply;
export {};
