import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { WorkWireReply, WorkWireRequest } from '../control-protocol/work-wire.ts';
import { type WorkHost } from './work-host.ts';
/** Runtime binds an authenticated grant participant once; requests cannot replace it. */
export declare function createWorkIngress(host: WorkHost, peer: AuthenticatedAgent): (request: WorkWireRequest) => Promise<WorkWireReply>;
