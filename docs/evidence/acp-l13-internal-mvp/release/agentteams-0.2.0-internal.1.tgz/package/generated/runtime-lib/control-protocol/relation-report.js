function stringValue(value, label) {
    if (typeof value !== 'string' || value.length === 0)
        throw new Error(`relation-report: ${label} must be a non-empty string`);
    return value;
}
function positiveInteger(value, label) {
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 1)
        throw new Error(`relation-report: ${label} must be a positive integer`);
    return value;
}
function isoDate(value, label) {
    const parsed = stringValue(value, label);
    if (Number.isNaN(Date.parse(parsed)))
        throw new Error(`relation-report: ${label} must be an ISO date`);
    return parsed;
}
export function validateRelationReport(value) {
    if (typeof value !== 'object' || value === null || Array.isArray(value))
        throw new Error('relation-report: report must be an object');
    const input = value;
    const role = stringValue(input.role, 'role');
    if (role !== 'consumer' && role !== 'provider')
        throw new Error('relation-report: role must be consumer or provider');
    const state = stringValue(input.state, 'state');
    if (!['discovered', 'requested', 'allowed', 'denied', 'using', 'stopped', 'revoked', 'expired'].includes(state)) {
        throw new Error('relation-report: unsupported state');
    }
    const reporterAgentId = stringValue(input.reporterAgentId, 'reporterAgentId');
    const subjectAgentId = stringValue(input.subjectAgentId, 'subjectAgentId');
    if (reporterAgentId === subjectAgentId)
        throw new Error('relation-report: self relation is not allowed');
    return {
        relationId: stringValue(input.relationId, 'relationId'),
        reporterAgentId,
        subjectAgentId,
        capabilityId: stringValue(input.capabilityId, 'capabilityId'),
        role: role,
        state: state,
        reportRevision: positiveInteger(input.reportRevision, 'reportRevision'),
        reportedAt: isoDate(input.reportedAt, 'reportedAt'),
    };
}
