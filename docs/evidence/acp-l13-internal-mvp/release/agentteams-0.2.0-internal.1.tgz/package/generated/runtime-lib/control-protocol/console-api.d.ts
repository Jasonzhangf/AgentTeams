import type { CapabilityDeclaration, JsonValue, ServiceError, ServiceErrorCode, WorkState } from './agent-services.ts';
import type { EndpointCapabilitySummary, EndpointResourceSummary } from './endpoint-ref.ts';
import type { RelationRole } from './teams-connection.ts';
import type { TeamsConnectionStatus } from './teams-state.ts';
export type { JsonValue } from './agent-services.ts';
export type { RelationRole } from './teams-connection.ts';
/** Console config errors retain their owning service's code and provider/status context. */
export interface ConsoleServiceError extends Omit<ServiceError, 'code'> {
    readonly code: ServiceErrorCode | 'CREDENTIAL_UNAVAILABLE' | 'SOURCE_CHANGED' | 'MIGRATION_CONFLICT' | 'APPLY_TARGET_MISMATCH';
    readonly message: string;
    readonly status?: number;
    readonly providerInstanceId?: string;
    /** Typed cancel unknown detail; never a business payload or log mirror. */
    readonly detail?: SessionCancelUnknownDetail;
}
/** Console transport DTOs. Daemons own the source state and command authorization. */
export interface ConsoleProviderView {
    readonly id: string;
    readonly label: string;
    readonly protocol: 'openai-chat' | 'openai-responses';
    readonly apiBaseUrl: string;
    readonly enabled: boolean;
    readonly authKind: 'none' | 'bearer';
    readonly catalogState: 'ready' | 'empty' | 'stale' | 'error';
    readonly models: readonly {
        readonly id: string;
        readonly label?: string;
    }[];
    readonly error?: ConsoleServiceError;
}
export interface ConsoleBindingRef {
    readonly providerInstanceId: string;
    readonly modelId: string;
}
export interface ConsoleAcceptedBinding {
    readonly primary: ConsoleBindingRef;
    readonly backup?: ConsoleBindingRef;
}
export interface ConsoleModelMetadata {
    readonly label?: string;
    readonly contextWindow?: number;
    readonly maxOutputTokens?: number;
    readonly tools?: boolean;
    readonly streaming?: boolean;
    readonly reasoning?: boolean;
    readonly inputModalities?: readonly string[];
    readonly outputModalities?: readonly string[];
}
export interface ConsoleManualModelEntry {
    readonly ref: {
        readonly providerInstanceId: string;
        readonly modelId: string;
    };
    readonly origin: 'manual';
    readonly base: ConsoleModelMetadata;
    readonly overrides: ConsoleModelMetadata;
    readonly availability?: 'available' | 'unavailable';
}
/** Independent event-observation health; never a ManagedRuntimeReadiness branch. */
export type SessionObservationState = {
    readonly state: 'live';
} | {
    readonly state: 'degraded';
    readonly reason: 'projection-loss' | 'stream-retry';
    readonly detail: string;
    readonly droppedEvents: number;
} | {
    readonly state: 'lost';
    readonly reason: 'stream-ended' | 'retry-exhausted';
    readonly detail: string;
};
/**
 * One engine-provided permission choice. `kind` reuses the decision vocabulary the
 * permission reply already carries; a daemon projects the option set verbatim from the
 * engine callback and never mints an option the engine did not offer.
 */
export type ConsolePermissionOptionKind = 'once' | 'always' | 'reject';
export interface ConsolePermissionOption {
    readonly optionId: string;
    readonly name: string;
    readonly kind: ConsolePermissionOptionKind;
}
/** The exact OpenCode structured error union retained on failed message/final/error events. */
export interface OpenCodeStructuredError {
    readonly name: 'ProviderAuthError' | 'UnknownError' | 'MessageOutputLengthError' | 'MessageAbortedError' | 'APIError';
    readonly data: JsonValue;
}
interface ConsoleSessionEventBase {
    readonly eventId: string;
    readonly agentId: string;
    readonly sessionId: string;
    readonly occurredAt?: string;
}
/** Closed owner-projected Session event union. Every required identity comes from a real SDK event/part. */
export type ConsoleSessionEventView = ConsoleSessionEventBase & {
    readonly kind: 'message';
    readonly state: 'pending' | 'completed';
    readonly messageId: string;
    readonly role: 'user' | 'assistant';
} | ConsoleSessionEventBase & {
    readonly kind: 'message';
    readonly state: 'failed';
    readonly messageId: string;
    readonly role: 'user' | 'assistant';
    readonly error: OpenCodeStructuredError;
} | ConsoleSessionEventBase & {
    readonly kind: 'part';
    readonly state: 'pending' | 'completed';
    readonly messageId: string;
    readonly partId: string;
    readonly partType: 'text' | 'reasoning';
    readonly text: string;
} | ConsoleSessionEventBase & {
    readonly kind: 'part';
    readonly state: 'observed';
    readonly messageId: string;
    readonly partId: string;
    readonly partType: 'file' | 'step-start' | 'step-finish' | 'snapshot' | 'patch' | 'agent' | 'retry' | 'compaction' | 'subtask';
    readonly sourcePart: JsonValue;
} | ConsoleSessionEventBase & {
    readonly kind: 'tool';
    readonly state: 'pending';
    readonly messageId: string;
    readonly partId: string;
    readonly callId: string;
    readonly tool: string;
    readonly input: JsonValue;
    readonly raw: string;
} | ConsoleSessionEventBase & {
    readonly kind: 'tool';
    readonly state: 'running';
    readonly messageId: string;
    readonly partId: string;
    readonly callId: string;
    readonly tool: string;
    readonly input: JsonValue;
    readonly title?: string;
    readonly metadata?: JsonValue;
} | ConsoleSessionEventBase & {
    readonly kind: 'tool';
    readonly state: 'completed';
    readonly messageId: string;
    readonly partId: string;
    readonly callId: string;
    readonly tool: string;
    readonly input: JsonValue;
    readonly output: string;
    readonly title: string;
    readonly metadata: JsonValue;
    readonly attachments?: readonly JsonValue[];
} | ConsoleSessionEventBase & {
    readonly kind: 'tool';
    readonly state: 'error';
    readonly messageId: string;
    readonly partId: string;
    readonly callId: string;
    readonly tool: string;
    readonly input: JsonValue;
    readonly error: string;
    readonly metadata?: JsonValue;
} | ConsoleSessionEventBase & {
    readonly kind: 'permission';
    readonly state: 'pending';
    readonly permissionId: string;
    readonly messageId: string;
    readonly callId?: string;
    readonly title: string;
    readonly metadata: JsonValue;
    /** Engine-provided choice set; absent when the engine callback offered none. */
    readonly options?: readonly ConsolePermissionOption[];
} | ConsoleSessionEventBase & {
    readonly kind: 'permission';
    readonly state: 'resolved';
    readonly permissionId: string;
    readonly decision: 'once' | 'always' | 'reject' | 'unknown';
    readonly rawResponse?: string;
} | ConsoleSessionEventBase & {
    readonly kind: 'final';
    readonly state: 'completed';
    readonly messageId: string;
    readonly finish?: string;
} | ConsoleSessionEventBase & {
    readonly kind: 'final';
    readonly state: 'failed';
    readonly messageId: string;
    readonly error: OpenCodeStructuredError;
} | ConsoleSessionEventBase & {
    readonly kind: 'error';
    readonly state: 'failed';
    readonly error: OpenCodeStructuredError;
    readonly correlation: {
        readonly kind: 'session';
        readonly sessionId: string;
    } | {
        readonly kind: 'message';
        readonly messageId: string;
    };
} | ConsoleSessionEventBase & {
    readonly kind: 'cancel';
    readonly state: 'accepted';
    readonly abortOperationId: string;
    readonly operationId: string;
    readonly sessionId: string;
    readonly runtimeGeneration: number;
    readonly effectiveRevision: number;
    readonly promptMessageId: string;
    readonly baseAccepted: true;
} | ConsoleSessionEventBase & {
    readonly kind: 'cancel';
    readonly state: 'rejected';
    readonly abortOperationId: string;
    readonly operationId: string;
    readonly sessionId: string;
    readonly runtimeGeneration: number;
    readonly effectiveRevision: number;
    readonly promptMessageId: string;
    readonly baseAccepted: false;
} | ConsoleSessionEventBase & {
    readonly kind: 'cancel';
    readonly state: 'reconciled';
    readonly abortOperationId: string;
    readonly operationId: string;
    readonly sessionId: string;
    readonly runtimeGeneration: number;
    readonly effectiveRevision: number;
    readonly promptMessageId: string;
    readonly baseAccepted: true;
    readonly finalState: 'cancelled';
    readonly messageId: string;
    readonly errorName: 'MessageAbortedError';
    readonly causalEvidence: 'unique-owned-message';
} | ConsoleSessionEventBase & {
    readonly kind: 'cancel';
    readonly state: 'unknown';
    readonly abortOperationId?: string;
    readonly operationId?: string;
    readonly sessionId: string;
    readonly runtimeGeneration?: number;
    readonly effectiveRevision?: number;
    readonly promptMessageId?: string;
    readonly baseAccepted?: boolean;
    readonly reason: 'abort-rejected' | 'no-final' | 'link-lost' | 'uncorrelated-idle' | 'ambiguous-owner' | 'stale-generation' | 'superseded';
};
/** Precise create result; carries only real OpenCode Session identity and never model/config truth. */
export interface SessionCreateResult {
    readonly kind: 'session.create';
    readonly agentId: string;
    readonly sessionId: string;
    readonly title?: string;
    readonly directory?: string;
    readonly time?: Readonly<Record<string, JsonValue>>;
}
/**
 * Confirmed permission reply. The engine choice is carried only when the engine callback
 * offered options; the daemon never invents an optionId for a missing or expired callback.
 */
export interface PermissionReplyResult {
    readonly kind: 'permission.reply';
    readonly agentId: string;
    readonly sessionId: string;
    readonly permissionId: string;
    readonly decision: 'once' | 'always' | 'reject';
    readonly optionId?: string;
}
/** Typed cancel unknown detail retained by the owning Session runtime. */
export interface SessionCancelUnknownDetail {
    readonly kind: 'session.cancel';
    readonly sessionId: string;
    readonly operationId?: string;
    readonly promptMessageId?: string;
    readonly runtimeGeneration?: number;
    readonly effectiveRevision?: number;
    readonly baseAccepted?: boolean;
    readonly reconciliation: 'unknown';
    readonly finalState: 'unknown';
    readonly reason: 'abort-rejected' | 'no-final' | 'link-lost' | 'uncorrelated-idle' | 'ambiguous-owner' | 'stale-generation' | 'superseded';
    readonly abortOperationId?: string;
}
/** Confirmed cancel result; only a uniquely owned MessageAbortedError produces this shape. */
export interface SessionCancelConfirmed {
    readonly kind: 'session.cancel';
    readonly sessionId: string;
    readonly operationId: string;
    readonly promptMessageId: string;
    readonly runtimeGeneration: number;
    readonly effectiveRevision: number;
    readonly baseAccepted: true;
    readonly reconciliation: 'confirmed';
    readonly finalState: 'cancelled';
    readonly messageId: string;
    readonly errorName: 'MessageAbortedError';
    readonly abortOperationId: string;
    readonly causalEvidence: 'unique-owned-message';
}
/**
 * Canonical Console summary of one published capability declaration. It reuses the
 * Endpoint summary field types and carries declared capacity only: never remaining
 * capacity, live usage, or an allocation ledger.
 */
export interface ConsoleCapabilityDetail extends EndpointCapabilitySummary {
    readonly resources: readonly EndpointResourceSummary[];
}
/**
 * Agent management row. The runtime/directory discriminated union is not a Work capability and
 * is not a second source of config or runtime truth.
 *
 * `engine` and `lastSeenAt` are additive optional projections of existing owner sources: the
 * engine kind the agent daemon published and the directory observation time. A row that has no
 * owner value omits the field; a daemon never derives either from history or from UI state.
 */
export interface ConsoleAgentObservationBaseV1 {
    readonly kind: 'runtime' | 'directory';
    readonly agentId: string;
    readonly label: string;
    readonly machineId: string;
    readonly generation?: number;
    readonly presence: 'online' | 'offline' | 'unknown';
    readonly capabilities: readonly string[];
    readonly capabilityDetails?: readonly ConsoleCapabilityDetail[];
    /** Engine kind declared by the owning agent daemon; mirrors the frozen config EngineKind. */
    readonly engine?: 'opencode' | 'dsh';
    /** Directory observation time of the owning peer; never a UI-side heartbeat. */
    readonly lastSeenAt?: string;
}
export type ConsoleAgentObservationV1 = (ConsoleAgentObservationBaseV1 & {
    readonly kind: 'runtime';
    readonly sessionCapable: true;
    readonly sessionAvailability: 'changing' | 'stopped' | 'no-current' | 'uncertain' | 'current';
    readonly sessionObservation?: SessionObservationState;
    readonly sessionEffectiveRevision?: number;
    readonly currentSessionId?: string;
    readonly providerId?: string;
    readonly modelId?: string;
}) | (ConsoleAgentObservationBaseV1 & {
    readonly kind: 'runtime';
    readonly sessionCapable: false;
    readonly sessionAvailability: 'not-applicable';
}) | (ConsoleAgentObservationBaseV1 & {
    readonly kind: 'directory';
});
/**
 * One Teams connection row. It reuses the frozen `TeamsConnectionStatus` verbatim and only adds
 * the two facts that status cannot carry: whether the handshake is still half-open, and this
 * daemon's own relation role for the link. No synonym of the connection lifecycle is minted here.
 */
export interface ConsoleConnectionView {
    readonly status: TeamsConnectionStatus;
    readonly halfOpen: boolean;
    readonly localRole?: RelationRole;
}
export interface ConsoleProjectionV1 {
    readonly version: 1;
    readonly agents: readonly ConsoleAgentObservationV1[];
    readonly sessions: readonly {
        readonly agentId: string;
        readonly sessionId: string;
        readonly title?: string;
    }[];
    readonly notifications: readonly {
        readonly agentId: string;
        readonly notificationId: string;
        readonly sessionId?: string;
        readonly kind: 'notice' | 'permission';
        readonly state: 'pending' | 'resolved';
        readonly title: string;
        readonly permissionId?: string;
        readonly priority?: 'low' | 'normal' | 'high' | 'critical';
        readonly occurredAt?: string;
        readonly detail?: string;
    }[];
    readonly configs: readonly {
        readonly agentId: string;
        readonly acceptedRevision: number;
        readonly effectiveRevision?: number;
        /** Durable config-owner fence projection; always emitted by the U2 config binding. */
        readonly applyState?: 'clean' | 'uncertain';
        /** Accepted binding from the same config view; null before the first explicit accept. */
        readonly acceptedBinding?: ConsoleAcceptedBinding | null;
        readonly providers: readonly ConsoleProviderView[];
        readonly error?: ConsoleServiceError;
    }[];
    readonly sessionEvents?: readonly ConsoleSessionEventView[];
    readonly works?: readonly ConsoleWorkView[];
    readonly relations?: readonly ConsoleRelationView[];
    /** Additive Teams connection rows projected from the network status port; absent when unbound. */
    readonly connections?: readonly ConsoleConnectionView[];
}
export interface ConsoleWorkView {
    readonly agentId: string;
    readonly workId: string;
    readonly consumerAgentId: string;
    readonly providerAgentId: string;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly policyRevision: number;
    readonly state: WorkState;
}
export interface ConsoleRelationView {
    readonly agentId: string;
    readonly consumerAgentId: string;
    readonly providerAgentId: string;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly relationPermission: 'requested' | 'granted' | 'revoked';
    readonly workId?: string;
}
export type ConsoleCommandV1 = {
    readonly kind: 'session.open';
    readonly agentId: string;
    readonly sessionId: string;
} | {
    readonly kind: 'session.create';
    readonly agentId: string;
    readonly title?: string;
} | {
    readonly kind: 'session.cancel';
    readonly agentId: string;
    readonly sessionId: string;
} | {
    readonly kind: 'permission.reply';
    readonly agentId: string;
    readonly sessionId: string;
    readonly permissionId: string;
    readonly decision: 'once' | 'always' | 'reject';
    /** Engine option chosen from the pending event's option set; omitted when the engine offered none. */
    readonly optionId?: string;
} | {
    readonly kind: 'notification.ack';
    readonly agentId: string;
    readonly notificationId: string;
} | {
    readonly kind: 'config.refreshModels';
    readonly agentId: string;
    readonly expectedRevision: number;
    readonly providerId: string;
} | {
    readonly kind: 'config.bindModel';
    readonly agentId: string;
    readonly expectedRevision: number;
    readonly providerId: string;
    readonly modelId: string;
} | {
    readonly kind: 'config.model.put';
    readonly agentId: string;
    readonly expectedRevision: number;
    readonly entry: ConsoleManualModelEntry;
} | {
    readonly kind: 'config.apply';
    readonly agentId: string;
} | {
    readonly kind: 'config.agent.select-backup';
    readonly agentId: string;
    readonly expectedRevision: number;
    readonly backup: {
        readonly providerInstanceId: string;
        readonly modelId: string;
    };
} | {
    readonly kind: 'config.putProvider';
    readonly agentId: string;
    readonly expectedRevision: number;
    readonly provider: {
        readonly id: string;
        readonly label: string;
        readonly protocol: ConsoleProviderView['protocol'];
        readonly apiBaseUrl: string;
        readonly enabled: boolean;
        readonly auth: {
            readonly kind: 'none';
        } | {
            readonly kind: 'bearer';
            readonly credentialRef: string;
        };
    };
} | {
    readonly kind: 'connection.connect';
    readonly agentId: string;
} | {
    readonly kind: 'connection.disconnect';
    readonly agentId: string;
} | {
    readonly kind: 'network.membership.apply';
    readonly agentId: string;
    readonly expectedRevision: number;
    readonly members: readonly {
        readonly agentId: string;
        readonly role: RelationRole;
    }[];
};
export type ConsoleCommandResultV1 = {
    readonly ok: true;
    readonly result?: JsonValue;
} | {
    readonly ok: false;
    readonly error: ConsoleServiceError;
};
/** Host binding; no success is inferred when the transport or daemon reports failure. */
export interface ConsoleClientV1 {
    readProjection(): Promise<ConsoleProjectionV1>;
    command(command: ConsoleCommandV1): Promise<ConsoleCommandResultV1>;
    /** Dedicated Session data ingress; business content never enters a host command. */
    sendSession(target: {
        readonly agentId: string;
        readonly sessionId: string;
    }, payload: JsonValue): Promise<ConsoleCommandResultV1>;
}
/** Observe-only projection rows; request/Session payloads are rejected as undeclared fields. */
export declare function parseConsoleWorkRelationProjection(value: unknown): {
    readonly works: readonly ConsoleWorkView[];
    readonly relations: readonly ConsoleRelationView[];
};
/** Validate the closed control envelope before dispatch; authorization stays at the daemon. */
export declare function parseConsoleCommand(value: unknown): ConsoleCommandV1;
/** Closed validation of the engine-provided permission option set; no option is invented here. */
export declare function parsePermissionOptions(value: unknown): readonly ConsolePermissionOption[];
export declare function parseSessionObservationState(value: unknown): SessionObservationState;
/**
 * The one published-declaration → Console detail summary mapping. Both the Agent runtime row
 * and the Console directory row project through this helper; no second state store exists.
 */
export declare function projectCapabilityDetails(capabilities: readonly CapabilityDeclaration[]): readonly ConsoleCapabilityDetail[];
/** Closed validation of one Agent management row; rejects session/model fields on directory/false rows. */
export declare function parseConsoleAgentObservation(value: unknown): ConsoleAgentObservationV1;
/** Closed validation of one owner-projected Session event; identity must match the variant. */
export declare function parseConsoleSessionEvent(value: unknown): ConsoleSessionEventView;
/** Closed validation of a create success result; rejects model/config/provider fields. */
export declare function parseSessionCreateResult(value: unknown): SessionCreateResult;
/** Closed validation of a confirmed permission reply; the engine option is never invented. */
export declare function parsePermissionReplyResult(value: unknown): PermissionReplyResult;
/** Closed validation of a typed cancel unknown detail; baseAccepted stays three-state. */
export declare function parseSessionCancelUnknownDetail(value: unknown): SessionCancelUnknownDetail;
/** Closed validation of a confirmed cancel result; only the unique-owned abort shape passes. */
export declare function parseSessionCancelConfirmed(value: unknown): SessionCancelConfirmed;
/** Closed validation of the full owner projection, including the additive rows. */
export declare function parseConsoleProjection(value: unknown): ConsoleProjectionV1;
