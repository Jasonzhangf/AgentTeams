import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { AcpFault } from '../control-protocol/acp.ts';
import type { RelationRole } from '../control-protocol/teams-connection.ts';
import type { AcpPolicySnapshot } from '../config/acp-policy.ts';
import type { PeerIntent } from '../config/daemon-intent.ts';
import type { AcpHost } from '../agent-host/acp-host.ts';
import type { TeamsConnectionHistory } from '../network/teams-connection-history.ts';
import type { TeamsConnectionLedger } from '../network/teams-ingress.ts';
/**
 * Serve entry egress owner (owner: runtime).
 *
 * The agent daemon dials the peers its own accepted config declares. This module
 * is the one production caller of `network/teams-egress.ts`: it resolves one
 * declared `PeerIntent`, reads the target facts the initiator negotiation
 * requires from the scoped directory readback, dials the peer with the same
 * `buildDirectWssRoutePlan` + `connectDirectWssTarget` pair the D05 closure
 * black box proves, and composes `openTeamsEgress` over the authenticated
 * connection. It keeps the live handle keyed by the peer's own `agentId` so the
 * daemon can disconnect exactly the peer it dialed.
 *
 * The execution model is the user's decision: the agent daemon reacts on its own
 * and dials/tears down itself; the control daemon is never a relay and there is
 * no control -> agent channel. This module therefore owns composition and
 * lifecycle only. Every mechanism it needs already has one owner and is reused:
 * route planning (`network/route-plan.ts`), the authenticated direct-WSS dial
 * (`network/direct-route.ts`), the initiator negotiation and ACP channel
 * (`network/teams-egress.ts`), the durable `kind=connection` history and the
 * live ledger (network owners).
 *
 * Target facts. `openTeamsEgress` needs `expectedTargetGeneration` and
 * `expectedTargetCapabilitiesRevision`, and `PeerIntent` carries neither. They
 * are NOT invented here:
 *
 * - `expectedTargetCapabilitiesRevision` is the responder's published directory
 *   declaration revision (`RelayPeer.declaration.revision`). The D05 closure
 *   black box reads exactly that value and asserts it equals the responder's
 *   readiness `capabilitiesRevision`; this owner reads the same scoped directory
 *   through the existing registration client.
 * - `expectedTargetGeneration` is the responder's own published listener
 *   generation. The serve entry binds its listener target with one runtime
 *   constant (`TARGET_GENERATION`), and the responder's `teams.connection.context`
 *   echoes that same constant as `targetGeneration`; the directory does not carry
 *   it (the relay login generation is a different value). The caller therefore
 *   supplies it as the same runtime constant, never as a guessed per-peer value.
 */
/** The target facts an initiator dial must know before it opens the socket. */
export interface ServeEgressTargetFacts {
    /** The confirmed directory generation the route plan was assembled from. */
    readonly directoryGeneration: number;
    /** The responder's published listener generation (`teams.connection.context.targetGeneration`). */
    readonly targetGeneration: number;
    /** The responder's published declaration revision (`RelayPeer.declaration.revision`). */
    readonly targetCapabilitiesRevision: string;
}
/** One real connect attempt that did not produce a live row. */
export interface ServeEgressFailure {
    readonly peerName: string;
    readonly agentId: string;
    readonly code: AcpFault['code'];
    readonly message: string;
}
/** One live dialed connection, keyed by the peer's own authenticated `agentId`. */
export interface ServeEgressRow {
    readonly peerName: string;
    readonly agentId: string;
    readonly connectionId: string;
    /** The peer's own authenticated identity, never a payload value. */
    readonly peer: AuthenticatedAgent;
    readonly role: RelationRole | undefined;
    readonly state: string;
}
export interface ServeEgressOwner {
    /** Dial one declared peer and keep its live row. Throws the typed refusal on failure. */
    connect(peerName: string): Promise<ServeEgressRow>;
    /** Close the live session and transport of one peer, then remove its row. */
    disconnect(agentId: string): Promise<void>;
    /** The live rows only; a failed or closed connection is never a live row. */
    list(): readonly ServeEgressRow[];
    /** Every recorded typed connect failure in this owner's lifetime. */
    failures(): readonly ServeEgressFailure[];
    /** Close every live row (daemon stop). */
    close(): Promise<void>;
}
export interface ServeEgressOwnerInput {
    /** The accepted intent's declared peers, keyed by the config's peer name. */
    readonly peers: Readonly<Record<string, PeerIntent>>;
    /** This daemon's own authenticated identity. */
    readonly self: AuthenticatedAgent;
    readonly selfGeneration: number;
    readonly selfCapabilitiesRevision: string;
    /** The accepted config revision; never a policy snapshot hash. */
    readonly selfPolicyRevision: number;
    /** `RelationsIntent.allowed` for this daemon. */
    readonly allowedRoles: readonly RelationRole[];
    /** The capabilities this side asks for; the peer admits or refuses each. */
    readonly requestedCapabilities: readonly string[];
    readonly host: AcpHost;
    readonly policy: AcpPolicySnapshot;
    readonly engineInstanceId: string;
    readonly history: TeamsConnectionHistory;
    readonly ledger: TeamsConnectionLedger;
    /**
     * The scoped directory readback for one declared peer. It must return the
     * responder's own published facts, never a guessed value; a peer that the
     * directory cannot confirm is a typed failure.
     */
    readonly readTargetFacts: (input: {
        readonly peerName: string;
        readonly peer: PeerIntent;
    }) => Promise<ServeEgressTargetFacts>;
    readonly env?: NodeJS.ProcessEnv;
    readonly now?: () => string;
    /** Observable connect failure; a refused dial is recorded, never swallowed. */
    readonly onFailure?: (failure: ServeEgressFailure) => void;
    readonly connectTimeoutMs?: number;
    readonly helloTimeoutMs?: number;
    readonly negotiationTimeoutMs?: number;
    readonly openTimeoutMs?: number;
    readonly maxMessageBytes?: number;
    readonly maxBufferedBytes?: number;
    readonly maxPendingFrames?: number;
}
/**
 * Create the daemon's own egress owner. It dials nothing until `connect` is
 * called, and every live row it returns is a real, negotiated, channel-open
 * connection; a refused dial records a typed failure and leaves no row.
 */
export declare function createServeEgressOwner(input: ServeEgressOwnerInput): ServeEgressOwner;
