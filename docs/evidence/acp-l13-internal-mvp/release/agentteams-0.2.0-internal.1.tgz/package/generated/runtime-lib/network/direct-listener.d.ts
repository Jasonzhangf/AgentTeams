import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import { type TargetTransportTarget, type TargetTransportState } from './target-transport.ts';
import { WssConnectionError, type WssFrame } from './wss-connection.ts';
type MaybePromise<T> = T | Promise<T>;
export interface DirectWssListenerOptions {
    readonly host?: string;
    readonly port: number;
    readonly key: string | Buffer;
    readonly cert: string | Buffer;
    readonly admissions: readonly DirectWssAdmission[];
    readonly target: TargetTransportTarget;
    readonly maxPayload: number;
    readonly maxConnections: number;
    readonly maxMessageBytes: number;
    readonly maxBufferedBytes: number;
    readonly maxPendingFrames: number;
    readonly helloTimeoutMs: number;
    readonly onConnection?: (connection: DirectWssAcceptedConnection) => MaybePromise<void>;
}
/** Local admission truth. The reference may be published; the credential never is. */
export interface DirectWssAdmission {
    readonly admissionRef: string;
    readonly peer: AuthenticatedAgent;
    readonly credential: string;
}
export interface DirectWssAcceptedConnection {
    readonly connectionId: string;
    readonly hello: TargetTransportTarget;
    readonly peer: AuthenticatedAgent;
    readonly admissionRef: string;
    readonly connection: {
        readonly closed: Promise<WssConnectionError>;
        read(): Promise<WssFrame>;
        send(frame: WssFrame): Promise<void>;
        close(): Promise<void>;
    };
    readonly closed: Promise<WssConnectionError>;
    readonly state: TargetTransportState;
    assertGeneration(generation: number): void;
    close(reason?: string): Promise<void>;
}
export interface DirectWssListener {
    readonly url: string;
    readonly port: number;
    readonly connections: readonly DirectWssAcceptedConnection[];
    close(): Promise<void>;
}
export declare function createDirectWssListener(options: DirectWssListenerOptions): Promise<DirectWssListener>;
export {};
