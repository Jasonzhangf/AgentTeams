import type { RelationRole } from '../control-protocol/teams-connection.ts';
import type { AcpPolicyIntent } from './acp-policy.ts';
import type { AgentModelBinding, ConfigErrorCode, ModelEntry, ProviderInstance, VersionedRuntimeConfig } from './runtime-config.ts';
export type DaemonKind = 'agent' | 'control' | 'registry';
export type EngineKind = 'opencode' | 'dsh';
/**
 * Re-export only: `RelationRole` is declared once in control-protocol
 * (`teams-connection.ts`), which owns relation semantics.
 */
export type { RelationRole };
/** The frozen single-daemon config schema version. One file declares one daemon. */
export declare const DAEMON_INTENT_VERSION = 4;
export type DaemonIntentVersion = typeof DAEMON_INTENT_VERSION;
/** Registry is the canonical public kind; the implementation reuses server/Relay. */
export type RegistryImplementation = 'server/Relay';
export declare const REGISTRY_IMPLEMENTATION: RegistryImplementation;
/**
 * Intent errors reuse the existing config error vocabulary. `UNSUPPORTED_VERSION`
 * marks a rejected older file version, `UNSUPPORTED_CONFIGURATION` an accepted
 * schema used in a way this daemon kind cannot satisfy, and
 * `AUTHENTICATION_REQUIRED` a missing non-loopback admission.
 */
export type DaemonIntentErrorCode = ConfigErrorCode | 'UNSUPPORTED_CONFIGURATION' | 'AUTHENTICATION_REQUIRED';
export declare class DaemonIntentError extends Error {
    readonly code: DaemonIntentErrorCode;
    constructor(code: DaemonIntentErrorCode, message: string);
}
export interface DaemonIdentity<K extends DaemonKind = DaemonKind> {
    readonly kind: K;
    readonly id: string;
    readonly hostId: string;
    readonly accountId: string;
    readonly scopeId: string;
    readonly dataDirectory: string;
}
export interface EngineIntent {
    readonly kind: EngineKind;
    /** Absolute installed executable. Resolution stays outside Config. */
    readonly executable?: string;
    /** Relative paths resolve against the config file directory in compile. */
    readonly workspace?: string;
}
export interface ListenIntent {
    readonly ip: string;
    readonly port: number;
    readonly tlsCertRef?: string;
    readonly tlsKeyRef?: string;
}
export interface WebUiAuthIntent {
    readonly username: string;
    /** Existing Console auth uses a bare environment-variable name here. */
    readonly passwordEnv: string;
}
export interface WebUiIntent {
    readonly ip: string;
    readonly port: number;
    readonly auth?: WebUiAuthIntent;
    readonly allowedOrigin?: string;
    readonly tlsCertRef?: string;
    readonly tlsKeyRef?: string;
}
export interface RelationsIntent {
    readonly allowed: readonly RelationRole[];
}
export interface DiscoveryServerConfig {
    readonly serverId: string;
    readonly endpoint: string;
    readonly credentialRef: string;
    readonly tlsTrustRef: string;
}
export interface PeerIntent {
    readonly agentId: string;
    readonly hostId: string;
    readonly accountId: string;
    readonly scopeId: string;
    readonly endpoint?: string;
    readonly admissionRef?: string;
    readonly credentialRef: string;
    readonly tlsTrustRef?: string;
}
export interface AdmissionIntent {
    readonly admissionRef: string;
    readonly agentId: string;
    readonly accountId: string;
    readonly scopeId: string;
    readonly credentialRef: string;
}
export interface AgentDaemonIntent {
    readonly version: DaemonIntentVersion;
    readonly daemon: DaemonIdentity<'agent'>;
    readonly engine?: EngineIntent;
    readonly listen?: ListenIntent;
    readonly acp: AcpPolicyIntent;
    readonly relations: RelationsIntent;
    readonly admissions: readonly AdmissionIntent[];
    readonly discovery?: DiscoveryServerConfig;
    readonly peers: Readonly<Record<string, PeerIntent>>;
    readonly providers: Readonly<Record<string, ProviderInstance>>;
    readonly models: readonly ModelEntry[];
    readonly model?: AgentModelBinding;
}
export interface ControlDaemonIntent {
    readonly version: DaemonIntentVersion;
    readonly daemon: DaemonIdentity<'control'>;
    readonly webui: WebUiIntent;
    readonly relations: RelationsIntent;
    readonly admissions: readonly AdmissionIntent[];
    readonly discovery?: DiscoveryServerConfig;
    readonly peers: Readonly<Record<string, PeerIntent>>;
}
export interface RegistryDaemonIntent {
    readonly version: DaemonIntentVersion;
    readonly daemon: DaemonIdentity<'registry'>;
    readonly listen: ListenIntent;
    readonly admissions: readonly AdmissionIntent[];
}
export type DaemonIntentV4 = AgentDaemonIntent | ControlDaemonIntent | RegistryDaemonIntent;
/**
 * `daemon.kind` is nested, so TypeScript cannot narrow the parent union from
 * `intent.daemon.kind`. These guards keep the narrowing honest instead of
 * casting at each call site. `isAgentIntent` is exported because the `--serve`
 * entry must narrow the same union before it may start an engine.
 */
export declare function isAgentIntent(intent: DaemonIntentV4): intent is AgentDaemonIntent;
/**
 * Shared parse context for a process that may read more than one config file.
 * It rejects duplicate daemon identity, duplicate host/account/scope ownership
 * and duplicate data directories before two daemons can claim the same state.
 */
export interface DaemonIntentContext {
    readonly seen: Map<string, string>;
}
export declare function createDaemonIntentContext(): DaemonIntentContext;
/** Explicit CLI values. A defined member always wins over the config file. */
export interface DaemonCliOverrides {
    /** `--serve <engine>`; selects the agent engine kind. */
    readonly engine?: EngineKind;
    /** `--ip`; overrides the daemon listener address. */
    readonly ip?: string;
    /** `--port`; overrides the daemon listener port. */
    readonly port?: number;
}
/** Effective values the CLI may print after overrides; never a secret. */
export interface DaemonEffectiveConfig {
    readonly kind: DaemonKind;
    readonly daemonId: string;
    readonly dataDirectory: string;
    readonly engine?: EngineKind;
    readonly listener?: {
        readonly ip: string;
        readonly port: number;
    };
}
/**
 * Parse one already-decoded config document into the v4 single-daemon intent.
 *
 * Exactly one `[daemon]` table is accepted. A v1/v2/v3 file, including the old
 * multi-agent `[agents.*]` shape, is rejected explicitly; the old
 * init/start/status/work/console entrypoints keep their own v3 handling.
 */
export declare function parseDaemonIntent(value: unknown, context?: DaemonIntentContext): DaemonIntentV4;
/** Parse TOML text into the v4 intent. TOML syntax errors stay explicit. */
export declare function parseDaemonConfigText(text: string, context?: DaemonIntentContext): DaemonIntentV4;
/**
 * Resolve every filesystem-bearing field without reading a secret or changing
 * the source file. Runtime consumes this resolved value for launch wiring.
 */
export declare function resolveDaemonIntent(intent: DaemonIntentV4, context: {
    readonly configDirectory: string;
}): DaemonIntentV4;
/**
 * Compile one v4 intent into the existing accepted runtime config shape.
 * The versioned config intentionally has no effectiveRevision; binding
 * references are closed by the canonical accepted-config rule.
 */
export declare function compileDaemonIntent(intent: DaemonIntentV4, context: {
    readonly configDirectory: string;
}): VersionedRuntimeConfig;
/**
 * Apply explicit CLI values over a parsed config intent. A defined CLI value
 * always wins over the file, the input intent is never mutated, and every
 * listener policy rule is re-checked on the effective value. The result is the
 * effective intent, so a later readback cannot show a stale config value.
 */
export declare function applyDaemonCliOverrides(intent: DaemonIntentV4, overrides: DaemonCliOverrides): DaemonIntentV4;
/** Effective values the CLI may print; never reads a credential. */
export declare function readDaemonEffectiveConfig(intent: DaemonIntentV4): DaemonEffectiveConfig;
