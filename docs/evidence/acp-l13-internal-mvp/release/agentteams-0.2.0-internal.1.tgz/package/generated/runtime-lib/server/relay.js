import { randomUUID } from 'node:crypto';
import { once } from 'node:events';
import { createServer } from 'node:https';
import WebSocket, { WebSocketServer } from 'ws';
import { assertEnvelopeKeys } from "../control-protocol/json-value.js";
import { parseAgentDeclaration } from "../control-protocol/relay-codec.js";
import { attachDeclarationEndpoints, projectPeerEndpoints } from "./endpoint-discovery.js";
import { assertEndpointIdentity } from "../control-protocol/endpoint-ref.js";
/** Node refuses a timer delay above this value. */
const MAX_TIMER_MS = 2_147_483_647;
/**
 * Server-owned default presence lease. It matches the directory stale window
 * (`removeStaleHosts` defaults to 90s) so one LAN lease policy exists. A peer
 * that stops heartbeating for this long is published offline even when its
 * socket never sent a close frame.
 */
export const DEFAULT_PEER_TTL_MS = 90_000;
function grantOpened(stored) {
    return stored.sourceData?.opened === true && stored.targetData?.opened === true;
}
class RelayFailure extends Error {
    code;
    requestId;
    closeSocket;
    constructor(code, message, requestId, closeSocket = false) {
        super(message);
        this.code = code;
        this.requestId = requestId;
        this.closeSocket = closeSocket;
    }
}
function object(value, label) {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        throw new RelayFailure('INVALID_INPUT', `${label} must be an object`);
    }
    return value;
}
function string(value, label) {
    if (typeof value !== 'string' || value.length === 0) {
        throw new RelayFailure('INVALID_INPUT', `${label} must be a non-empty string`);
    }
    return value;
}
function knownFields(value, fields, label) {
    try {
        assertEnvelopeKeys(value, fields, label);
    }
    catch (error) {
        throw new RelayFailure('INVALID_INPUT', error instanceof Error ? error.message : `${label} has unsupported fields`);
    }
}
function parseDeclaration(value) {
    try {
        return parseAgentDeclaration(value);
    }
    catch (error) {
        throw new RelayFailure('INVALID_INPUT', error instanceof Error ? error.message : 'invalid declaration');
    }
}
function endpointsFor(declaration) {
    try {
        return attachDeclarationEndpoints(declaration);
    }
    catch (error) {
        const code = error && typeof error === 'object' && 'code' in error && typeof error.code === 'string'
            ? error.code
            : 'INVALID_INPUT';
        throw new RelayFailure(code, error instanceof Error ? error.message : 'invalid Endpoint admission');
    }
}
function peerWithEndpoints(peer) {
    return { ...peer, endpoints: endpointsFor(peer.declaration) };
}
function positiveInteger(value, label) {
    if (!Number.isSafeInteger(value) || value < 1) {
        throw new RelayFailure('INVALID_INPUT', `${label} must be a positive safe integer`);
    }
    return value;
}
function boolean(value, label) {
    if (typeof value !== 'boolean')
        throw new RelayFailure('INVALID_INPUT', `${label} must be boolean`);
    return value;
}
function parseControlMessage(data, isBinary) {
    if (isBinary)
        throw new RelayFailure('INVALID_INPUT', 'control message must be text', undefined, true);
    let parsed;
    try {
        const text = Array.isArray(data)
            ? Buffer.concat(data).toString('utf8')
            : data instanceof ArrayBuffer
                ? Buffer.from(data).toString('utf8')
                : data.toString();
        parsed = JSON.parse(text);
    }
    catch {
        throw new RelayFailure('INVALID_INPUT', 'control message is not valid JSON', undefined, true);
    }
    const input = object(parsed, 'control message');
    const kind = string(input.kind, 'kind');
    const fields = {
        'relay.login': ['kind', 'protocolVersion', 'declaration'],
        'relay.publish': ['kind', 'generation', 'declaration'],
        'relay.presence': ['kind', 'generation'],
        'relay.logout': ['kind', 'requestId', 'generation'],
        'relay.directory': ['kind', 'requestId', 'subscribe'],
        'relay.connect': ['kind', 'requestId', 'generation', 'targetAgentId', 'targetGeneration'],
        'relay.open': ['kind', 'requestId', 'grantId', 'generation'],
    };
    const allowed = fields[kind];
    if (allowed)
        knownFields(input, allowed, `control message ${kind}`);
    return input;
}
function identityKey(agent) {
    return JSON.stringify([agent.accountId, agent.scopeId, agent.agentId]);
}
function sameIdentity(agent, declaration) {
    return agent.accountId === declaration.identity.accountId
        && agent.scopeId === declaration.scopeId
        && agent.agentId === declaration.identity.agentId;
}
function validateAuthenticatedAgent(value) {
    if (typeof value !== 'object' || value === null)
        throw new RelayFailure('UNAUTHENTICATED', 'authentication returned no agent');
    string(value.accountId, 'authenticated accountId');
    string(value.scopeId, 'authenticated scopeId');
    string(value.agentId, 'authenticated agentId');
    return value;
}
function authorization(request) {
    const value = request.headers.authorization;
    return Array.isArray(value) ? value[0] : value;
}
function errorValue(failure) {
    return { code: failure.code, message: failure.message };
}
function open(socket) {
    return socket.readyState === WebSocket.OPEN;
}
function rawDataSize(data) {
    if (Array.isArray(data))
        return data.reduce((total, part) => total + part.byteLength, 0);
    return data.byteLength;
}
function safeCloseReason(reason) {
    return Buffer.byteLength(reason, 'utf8') <= 123 ? reason : 'relay error';
}
class RelayServerImpl {
    options;
    httpsServer;
    wsServer;
    sockets = new Set();
    connections = new Set();
    controls = new Map();
    activeByIdentity = new Map();
    generations = new Map();
    peers = new Map();
    grants = new Map();
    now;
    idFactory;
    peerTtlMs;
    revision = 0;
    closing = false;
    closePromise;
    leaseTimer;
    constructor(options, httpsServer, wsServer) {
        this.options = options;
        this.httpsServer = httpsServer;
        this.wsServer = wsServer;
        this.now = options.now ?? (() => new Date());
        this.idFactory = options.idFactory ?? randomUUID;
        this.peerTtlMs = options.peerTtlMs ?? DEFAULT_PEER_TTL_MS;
        this.httpsServer.on('connection', (connection) => {
            this.connections.add(connection);
            connection.on('close', () => this.connections.delete(connection));
        });
    }
    get port() {
        const address = this.httpsServer.address();
        if (address === null || typeof address === 'string')
            throw new Error('relay: server has no bound address');
        return address.port;
    }
    get url() {
        return `wss://${this.options.host ?? '127.0.0.1'}:${this.port}`;
    }
    accept(socket, request) {
        if (this.closing || this.sockets.size >= this.options.maxConnections) {
            socket.close(1013, 'relay connection limit');
            return;
        }
        const state = {
            socket,
            request,
            connectionId: this.idFactory(),
            queue: Promise.resolve(),
            pendingMessages: 0,
            pendingBytes: 0,
            role: 'unknown',
            subscribed: false,
            opened: false,
            closed: false,
            closing: false,
        };
        this.sockets.add(state);
        socket.on('message', (data, isBinary) => {
            if (state.closed || state.closing)
                return;
            const bytes = rawDataSize(data);
            const overMessageLimit = state.pendingMessages >= this.options.maxPendingMessages;
            const overByteLimit = bytes > this.options.maxPendingBytes || state.pendingBytes > this.options.maxPendingBytes - bytes;
            if (overMessageLimit || overByteLimit) {
                this.handleFailure(state, new RelayFailure('RESOURCE_EXHAUSTED', overMessageLimit ? 'relay pending message limit reached' : 'relay pending byte limit reached', undefined, true));
                return;
            }
            state.pendingMessages += 1;
            state.pendingBytes += bytes;
            state.queue = state.queue
                .then(() => this.handleMessage(state, data, isBinary))
                .catch((error) => this.handleFailure(state, error))
                .finally(() => {
                state.pendingMessages -= 1;
                state.pendingBytes -= bytes;
            });
        });
        socket.on('close', () => this.handleClose(state));
        socket.on('error', () => undefined);
    }
    async close() {
        if (this.closePromise)
            return this.closePromise;
        this.closing = true;
        if (this.leaseTimer) {
            clearTimeout(this.leaseTimer);
            this.leaseTimer = undefined;
        }
        this.closePromise = (async () => {
            for (const grantId of [...this.grants.keys()])
                this.closeGrant(grantId, { code: 'UNAVAILABLE', message: 'relay closing' });
            for (const state of this.sockets)
                state.socket.terminate();
            await new Promise((resolve) => {
                this.wsServer.close(() => resolve());
            });
            // `server.close()` stops accepting and waits for existing connections to end
            // on their own; it never destroys them. A TCP/TLS connection can reach the
            // listener and never complete the WebSocket upgrade, so it is held by the
            // listener but absent from `this.sockets`. Both an idle connection that sent
            // no bytes and one that sent only a partial request survive
            // `closeIdleConnections()` and `closeAllConnections()`. Destroying the
            // tracked listener connections is what makes `close()` deterministic, and
            // without it `close()` hangs and the relay never exits after SIGTERM.
            for (const connection of [...this.connections])
                connection.destroy();
            this.connections.clear();
            await new Promise((resolve, reject) => {
                this.httpsServer.close((error) => {
                    if (error && error.code !== 'ERR_SERVER_NOT_RUNNING')
                        reject(error);
                    else
                        resolve();
                });
            });
        })();
        return this.closePromise;
    }
    async handleMessage(state, data, isBinary) {
        if (state.closed || state.closing)
            return;
        if (state.role === 'data' && state.opened) {
            this.forwardData(state, data, isBinary);
            return;
        }
        if (state.role === 'data') {
            const input = parseControlMessage(data, isBinary);
            if (input.kind !== 'relay.open')
                throw new RelayFailure('INVALID_INPUT', 'data connection must open with relay.open', undefined, true);
            await this.openDataConnection(state, input);
            return;
        }
        const input = parseControlMessage(data, isBinary);
        if (state.role === 'unknown') {
            if (input.kind === 'relay.open') {
                await this.openDataConnection(state, input);
                return;
            }
            if (input.kind !== 'relay.login') {
                throw new RelayFailure('UNAUTHENTICATED', 'relay.login is required before control operations', undefined, true);
            }
            await this.login(state, input);
            return;
        }
        await this.handleControl(state, input);
    }
    async authenticate(state) {
        if (state.auth)
            return state.auth;
        let result;
        try {
            result = await this.options.authenticate(authorization(state.request));
        }
        catch {
            throw new RelayFailure('UNAUTHENTICATED', 'authentication failed', undefined, true);
        }
        if (!result)
            throw new RelayFailure('UNAUTHENTICATED', 'authentication failed', undefined, true);
        state.auth = validateAuthenticatedAgent(result);
        return state.auth;
    }
    async login(state, input) {
        const protocolVersion = positiveInteger(input.protocolVersion, 'protocolVersion');
        if (protocolVersion !== 2)
            throw new RelayFailure('UNSUPPORTED_VERSION', `protocol version ${protocolVersion} is unsupported`, undefined, true);
        const authenticated = await this.authenticate(state);
        if (state.closed || !open(state.socket))
            throw new RelayFailure('UNAVAILABLE', 'connection closed during authentication', undefined, true);
        const declaration = parseDeclaration(input.declaration);
        if (!sameIdentity(authenticated, declaration)) {
            throw new RelayFailure('FORBIDDEN', 'declaration identity does not match authenticated identity', undefined, true);
        }
        const key = identityKey(authenticated);
        const generation = (this.generations.get(key) ?? 0) + 1;
        this.generations.set(key, generation);
        const previous = this.activeByIdentity.get(key);
        if (previous && previous !== state) {
            this.invalidateGrantsForConnection(previous.connectionId, { code: 'UNAVAILABLE', message: 'control connection replaced' });
            this.closeSocket(previous, 4001, 'control connection replaced');
        }
        state.role = 'control';
        state.identityKey = key;
        state.generation = generation;
        state.declaration = declaration;
        state.subscribed = false;
        this.activeByIdentity.set(key, state);
        this.controls.set(state.connectionId, state);
        const peer = peerWithEndpoints({
            declaration,
            connectionId: state.connectionId,
            generation,
            lastSeenAt: this.now().toISOString(),
            presence: 'online',
        });
        this.setPeer(peer);
        this.send(state.socket, { kind: 'relay.admitted', connectionId: state.connectionId, generation });
    }
    async handleControl(state, input) {
        // Presence is a lease: every control operation observes the current leases
        // before it answers, so a silently dead socket cannot stay online in a
        // directory snapshot or be granted a connection.
        this.sweepPeerLeases();
        if (input.kind !== 'relay.login')
            this.assertCurrentControl(state);
        switch (input.kind) {
            case 'relay.login':
                throw new RelayFailure('CONFLICT', 'control connection is already admitted');
            case 'relay.publish':
                await this.publish(state, input);
                return;
            case 'relay.presence':
                this.presence(state, input);
                return;
            case 'relay.logout':
                this.logout(state, input);
                return;
            case 'relay.directory':
                this.directory(state, input);
                return;
            case 'relay.connect':
                await this.connect(state, input);
                return;
            case 'relay.open':
                throw new RelayFailure('UNSUPPORTED_OPERATION', 'relay.open requires a dedicated data connection');
            default:
                throw new RelayFailure('UNSUPPORTED_OPERATION', `unsupported relay operation ${String(input.kind)}`);
        }
    }
    assertCurrentControl(state, requestId) {
        if (!state.identityKey || state.closed || !open(state.socket) || this.activeByIdentity.get(state.identityKey) !== state) {
            throw new RelayFailure('STALE_GENERATION', 'control connection is no longer current', requestId, true);
        }
    }
    assertCurrentGeneration(state, value, label) {
        const generation = positiveInteger(value, label);
        if (generation !== state.generation)
            throw new RelayFailure('STALE_GENERATION', `${label} is stale`);
        return generation;
    }
    async publish(state, input) {
        this.assertCurrentGeneration(state, input.generation, 'generation');
        const declaration = parseDeclaration(input.declaration);
        if (!state.auth || !sameIdentity(state.auth, declaration))
            throw new RelayFailure('FORBIDDEN', 'declaration identity does not match authenticated identity');
        const key = state.identityKey;
        if (!key)
            throw new RelayFailure('UNAUTHENTICATED', 'control identity is unavailable');
        const previous = this.peers.get(key);
        if (!previous || declaration.revision <= previous.declaration.revision) {
            throw new RelayFailure('REVISION_CONFLICT', 'declaration revision must increase');
        }
        state.declaration = declaration;
        this.setPeer(peerWithEndpoints({ ...previous, declaration, lastSeenAt: this.now().toISOString(), presence: 'online' }));
    }
    presence(state, input) {
        this.assertCurrentGeneration(state, input.generation, 'generation');
        const key = state.identityKey;
        if (!key)
            throw new RelayFailure('UNAUTHENTICATED', 'control identity is unavailable');
        const previous = this.peers.get(key);
        if (!previous)
            throw new RelayFailure('NOT_FOUND', 'authenticated peer is not published');
        this.setPeer({ ...previous, lastSeenAt: this.now().toISOString(), presence: 'online', connectionId: state.connectionId, generation: state.generation ?? previous.generation });
    }
    logout(state, input) {
        const requestId = string(input.requestId, 'requestId');
        this.assertCurrentGeneration(state, input.generation, 'generation');
        const key = state.identityKey;
        if (!key)
            throw new RelayFailure('UNAUTHENTICATED', 'control identity is unavailable', requestId);
        const previous = this.peers.get(key);
        if (!previous)
            throw new RelayFailure('NOT_FOUND', 'authenticated peer is not published', requestId);
        if (previous.presence === 'online') {
            this.setPeer({ ...previous, lastSeenAt: this.now().toISOString(), presence: 'offline', connectionId: state.connectionId, generation: state.generation ?? previous.generation });
        }
        this.send(state.socket, { kind: 'relay.logged-out', requestId });
    }
    directory(state, input) {
        const requestId = string(input.requestId, 'requestId');
        state.subscribed = boolean(input.subscribe, 'subscribe');
        if (!state.auth)
            throw new RelayFailure('UNAUTHENTICATED', 'control identity is unavailable', requestId);
        const peers = [...this.peers.values()]
            .filter((peer) => peer.declaration.identity.accountId === state.auth?.accountId && peer.declaration.scopeId === state.auth?.scopeId)
            .map((peer) => projectPeerEndpoints(peer, state.auth));
        this.send(state.socket, { kind: 'relay.directory', requestId, revision: this.revision, peers });
    }
    async connect(state, input) {
        const requestId = string(input.requestId, 'requestId');
        const generation = this.assertCurrentGeneration(state, input.generation, 'generation');
        const rawTarget = string(input.targetAgentId, 'targetAgentId');
        let targetAgentId;
        try {
            targetAgentId = assertEndpointIdentity(rawTarget, 'targetAgentId');
        }
        catch (error) {
            throw new RelayFailure('INVALID_INPUT', error instanceof Error ? error.message : 'targetAgentId is not a transport target');
        }
        const targetGeneration = positiveInteger(input.targetGeneration, 'targetGeneration');
        if (!state.auth || !state.identityKey)
            throw new RelayFailure('UNAUTHENTICATED', 'control identity is unavailable', requestId);
        const target = [...this.peers.values()].find((peer) => peer.declaration.identity.accountId === state.auth?.accountId && peer.declaration.scopeId === state.auth?.scopeId && peer.declaration.identity.agentId === targetAgentId);
        if (!target)
            throw new RelayFailure('FORBIDDEN', 'target is outside the authenticated scope', requestId);
        if (target.declaration.identity.agentId === state.auth.agentId)
            throw new RelayFailure('FORBIDDEN', 'self relay is not allowed', requestId);
        if (target.presence !== 'online')
            throw new RelayFailure('UNAVAILABLE', 'target is offline', requestId);
        if (target.generation !== targetGeneration)
            throw new RelayFailure('STALE_GENERATION', 'target generation is stale', requestId);
        const targetState = this.controls.get(target.connectionId);
        if (!targetState || targetState.closed || !open(targetState.socket) || targetState.generation !== targetGeneration) {
            throw new RelayFailure('STALE_GENERATION', 'target connection generation is stale', requestId);
        }
        if (this.options.authorizeTarget && !(await this.options.authorizeTarget(state.auth, target))) {
            throw new RelayFailure('FORBIDDEN', 'target policy denied the connection', requestId);
        }
        this.assertCurrentControl(state, requestId);
        const targetKey = identityKey({
            accountId: target.declaration.identity.accountId,
            scopeId: target.declaration.scopeId,
            agentId: target.declaration.identity.agentId,
        });
        if (targetState.closed || !open(targetState.socket) || this.activeByIdentity.get(targetKey) !== targetState || targetState.generation !== targetGeneration) {
            throw new RelayFailure('STALE_GENERATION', 'target connection generation is stale', requestId);
        }
        this.purgeExpiredGrants();
        if (this.grants.size >= this.options.maxGrants)
            throw new RelayFailure('RESOURCE_EXHAUSTED', 'relay grant capacity is exhausted', requestId);
        const grant = {
            grantId: this.idFactory(),
            accountId: state.auth.accountId,
            scopeId: state.auth.scopeId,
            sourceAgentId: state.auth.agentId,
            targetAgentId,
            sourceGeneration: generation,
            targetGeneration,
            expiresAt: new Date(this.now().getTime() + this.options.grantTtlMs).toISOString(),
        };
        const stored = {
            grant,
            sourceConnectionId: state.connectionId,
            targetConnectionId: targetState.connectionId,
            expiryTimer: setTimeout(() => this.expireGrant(grant.grantId), this.options.grantTtlMs),
        };
        stored.expiryTimer.unref?.();
        this.grants.set(grant.grantId, stored);
        this.send(state.socket, { kind: 'relay.grant', requestId, grant });
        this.send(targetState.socket, { kind: 'relay.offer', grant });
    }
    async openDataConnection(state, input) {
        const requestId = string(input.requestId, 'requestId');
        const grantId = string(input.grantId, 'grantId');
        const generation = positiveInteger(input.generation, 'generation');
        const authenticated = await this.authenticate(state);
        if (state.closed || !open(state.socket))
            throw new RelayFailure('UNAVAILABLE', 'connection closed during authentication', requestId, true);
        const stored = this.grants.get(grantId);
        if (!stored)
            throw new RelayFailure('NOT_FOUND', 'relay grant is unknown', requestId, true);
        if (!grantOpened(stored) && Date.parse(stored.grant.expiresAt) <= this.now().getTime()) {
            this.closeGrant(grantId, { code: 'UNAVAILABLE', message: 'relay grant expired' });
            throw new RelayFailure('UNAVAILABLE', 'relay grant expired', requestId, true);
        }
        const side = this.grantSide(stored.grant, authenticated, generation, requestId);
        const controlKey = identityKey({
            accountId: stored.grant.accountId,
            scopeId: stored.grant.scopeId,
            agentId: authenticated.agentId,
        });
        const control = this.activeByIdentity.get(controlKey);
        const expectedConnectionId = side === 'source' ? stored.sourceConnectionId : stored.targetConnectionId;
        const expectedGeneration = side === 'source' ? stored.grant.sourceGeneration : stored.grant.targetGeneration;
        if (!control || control.closed || !open(control.socket) || control.connectionId !== expectedConnectionId || control.generation !== expectedGeneration) {
            throw new RelayFailure('STALE_GENERATION', 'relay grant is bound to an older control connection', requestId, true);
        }
        if (side === 'source' && stored.sourceData)
            throw new RelayFailure('CONFLICT', 'source data connection already exists', requestId, true);
        if (side === 'target' && stored.targetData)
            throw new RelayFailure('CONFLICT', 'target data connection already exists', requestId, true);
        state.role = 'data';
        state.auth = authenticated;
        state.grantId = grantId;
        state.side = side;
        if (side === 'source') {
            stored.sourceData = state;
            stored.sourceRequestId = requestId;
        }
        else {
            stored.targetData = state;
            stored.targetRequestId = requestId;
        }
        if (!stored.sourceData || !stored.targetData)
            return;
        stored.sourceData.opened = true;
        stored.targetData.opened = true;
        clearTimeout(stored.expiryTimer);
        this.send(stored.sourceData.socket, { kind: 'relay.opened', requestId: stored.sourceRequestId ?? requestId, grantId });
        this.send(stored.targetData.socket, { kind: 'relay.opened', requestId: stored.targetRequestId ?? requestId, grantId });
    }
    grantSide(grant, authenticated, generation, requestId) {
        const sameScope = authenticated.accountId === grant.accountId && authenticated.scopeId === grant.scopeId;
        if (!sameScope)
            throw new RelayFailure('FORBIDDEN', 'relay grant scope does not match authentication', requestId, true);
        if (authenticated.agentId === grant.sourceAgentId) {
            if (generation !== grant.sourceGeneration)
                throw new RelayFailure('STALE_GENERATION', 'source generation is stale', requestId, true);
            return 'source';
        }
        if (authenticated.agentId === grant.targetAgentId) {
            if (generation !== grant.targetGeneration)
                throw new RelayFailure('STALE_GENERATION', 'target generation is stale', requestId, true);
            return 'target';
        }
        throw new RelayFailure('FORBIDDEN', 'authenticated agent is not a grant participant', requestId, true);
    }
    forwardData(state, data, isBinary) {
        const grant = state.grantId ? this.grants.get(state.grantId) : undefined;
        if (!grant || !state.side) {
            throw new RelayFailure('UNAVAILABLE', 'relay data connection is no longer active', undefined, true);
        }
        const target = state.side === 'source' ? grant.targetData : grant.sourceData;
        if (!target || !target.opened || !open(target.socket)) {
            throw new RelayFailure('UNAVAILABLE', 'relay peer data connection is not open', undefined, true);
        }
        const frameSize = rawDataSize(data);
        if (frameSize > this.options.maxBufferedAmount || target.socket.bufferedAmount > this.options.maxBufferedAmount - frameSize) {
            const failure = { code: 'RESOURCE_EXHAUSTED', message: 'relay peer send buffer limit reached' };
            this.closeGrant(grant.grant.grantId, failure);
            throw new RelayFailure(failure.code, failure.message, undefined, true);
        }
        try {
            target.socket.send(data, { binary: isBinary }, (error) => {
                if (error)
                    this.closeGrant(grant.grant.grantId, { code: 'UPSTREAM_ERROR', message: 'relay peer send failed' });
            });
        }
        catch (error) {
            const failure = { code: 'UPSTREAM_ERROR', message: error instanceof Error ? error.message : 'relay peer send failed' };
            this.closeGrant(grant.grant.grantId, failure);
            throw new RelayFailure(failure.code, failure.message, undefined, true);
        }
    }
    handleFailure(state, error) {
        if (state.closed || state.closing)
            return;
        const failure = error instanceof RelayFailure
            ? error
            : new RelayFailure('UPSTREAM_ERROR', error instanceof Error ? error.message : 'relay operation failed', undefined, true);
        if (state.role === 'data' && state.opened) {
            if (state.grantId)
                this.closeGrant(state.grantId, errorValue(failure));
            this.closeSocket(state, 1008, failure.message);
            return;
        }
        this.send(state.socket, { kind: 'relay.error', ...(failure.requestId === undefined ? {} : { requestId: failure.requestId }), error: errorValue(failure) });
        if (failure.closeSocket || state.role === 'unknown' || state.role === 'data')
            this.closeSocket(state, 1008, failure.message);
    }
    handleClose(state) {
        if (state.closed)
            return;
        state.closed = true;
        this.sockets.delete(state);
        if (state.role === 'data' && state.grantId) {
            this.closeGrant(state.grantId, { code: 'UNAVAILABLE', message: 'relay data connection closed' });
            return;
        }
        if (state.role !== 'control' || !state.identityKey)
            return;
        this.controls.delete(state.connectionId);
        if (this.activeByIdentity.get(state.identityKey) !== state)
            return;
        this.activeByIdentity.delete(state.identityKey);
        this.invalidateGrantsForConnection(state.connectionId, { code: 'UNAVAILABLE', message: 'control connection closed' });
        const previous = this.peers.get(state.identityKey);
        if (previous?.presence === 'online')
            this.setPeer({ ...previous, connectionId: state.connectionId, generation: state.generation ?? previous.generation, presence: 'offline', lastSeenAt: this.now().toISOString() });
    }
    closeGrant(grantId, error) {
        const stored = this.grants.get(grantId);
        if (!stored)
            return;
        clearTimeout(stored.expiryTimer);
        this.grants.delete(grantId);
        for (const data of [stored.sourceData, stored.targetData]) {
            if (data && !data.closed)
                data.socket.close(1000, 'relay closed');
        }
        const source = this.controls.get(stored.sourceConnectionId);
        const target = this.controls.get(stored.targetConnectionId);
        const message = { kind: 'relay.closed', grantId, ...(error === undefined ? {} : { error }) };
        if (source)
            this.send(source.socket, message);
        if (target && target !== source)
            this.send(target.socket, message);
    }
    invalidateGrantsForConnection(connectionId, error) {
        for (const [grantId, stored] of this.grants) {
            if (stored.sourceConnectionId === connectionId || stored.targetConnectionId === connectionId)
                this.closeGrant(grantId, error);
        }
    }
    purgeExpiredGrants() {
        const now = this.now().getTime();
        for (const [grantId, stored] of this.grants) {
            if (!grantOpened(stored) && Date.parse(stored.grant.expiresAt) <= now) {
                this.closeGrant(grantId, { code: 'UNAVAILABLE', message: 'relay grant expired' });
            }
        }
    }
    expireGrant(grantId) {
        const stored = this.grants.get(grantId);
        if (!stored)
            return;
        if (grantOpened(stored))
            return;
        const remainingMs = Date.parse(stored.grant.expiresAt) - this.now().getTime();
        if (remainingMs > 0) {
            stored.expiryTimer = setTimeout(() => this.expireGrant(grantId), remainingMs);
            stored.expiryTimer.unref?.();
            return;
        }
        this.closeGrant(grantId, { code: 'UNAVAILABLE', message: 'relay grant expired' });
    }
    setPeer(peer) {
        const key = identityKey({
            accountId: peer.declaration.identity.accountId,
            scopeId: peer.declaration.scopeId,
            agentId: peer.declaration.identity.agentId,
        });
        this.peers.set(key, peer);
        this.revision += 1;
        for (const state of this.controls.values()) {
            if (!state.identityKey || this.activeByIdentity.get(state.identityKey) !== state || !state.subscribed || !state.auth || !open(state.socket))
                continue;
            if (state.auth.accountId !== peer.declaration.identity.accountId || state.auth.scopeId !== peer.declaration.scopeId)
                continue;
            this.send(state.socket, { kind: 'relay.changed', revision: this.revision, peer: projectPeerEndpoints(peer, state.auth) });
        }
        this.scheduleLeaseSweep();
    }
    /**
     * Publishes every peer whose lease has lapsed as offline. The entry, its
     * declaration and its generation stay in the directory as history, so an
     * offline peer is visible without impersonating a current presence.
     */
    sweepPeerLeases() {
        const now = this.now().getTime();
        for (const peer of [...this.peers.values()]) {
            if (peer.presence !== 'online')
                continue;
            if (Date.parse(peer.lastSeenAt) + this.peerTtlMs <= now) {
                this.setPeer({ ...peer, presence: 'offline' });
            }
        }
        this.scheduleLeaseSweep();
    }
    /** One timer owns the earliest lease deadline; it is unref'd so it never holds the process. */
    scheduleLeaseSweep() {
        if (this.leaseTimer !== undefined) {
            clearTimeout(this.leaseTimer);
            this.leaseTimer = undefined;
        }
        if (this.closing)
            return;
        let earliest;
        for (const peer of this.peers.values()) {
            if (peer.presence !== 'online')
                continue;
            const deadline = Date.parse(peer.lastSeenAt) + this.peerTtlMs;
            if (earliest === undefined || deadline < earliest)
                earliest = deadline;
        }
        if (earliest === undefined)
            return;
        const remainingMs = Math.min(Math.max(0, earliest - this.now().getTime()), MAX_TIMER_MS);
        this.leaseTimer = setTimeout(() => this.sweepPeerLeases(), remainingMs);
        this.leaseTimer.unref?.();
    }
    closeSocket(state, code, reason) {
        if (state.closed || state.closing)
            return;
        state.closing = true;
        if (open(state.socket))
            state.socket.close(code, safeCloseReason(reason));
        if (state.role === 'control')
            this.invalidateGrantsForConnection(state.connectionId, { code: 'UNAVAILABLE', message: 'control connection closed' });
    }
    stateForSocket(socket) {
        for (const state of this.sockets) {
            if (state.socket === socket)
                return state;
        }
        return undefined;
    }
    closeSocketAfterSendFailure(socket, code, reason) {
        const state = this.stateForSocket(socket);
        if (state) {
            this.closeSocket(state, code, reason);
            return;
        }
        if (open(socket))
            socket.close(code, safeCloseReason(reason));
    }
    send(socket, message) {
        if (!open(socket))
            return;
        const payload = JSON.stringify(message);
        const payloadBytes = Buffer.byteLength(payload, 'utf8');
        if (payloadBytes > this.options.maxBufferedAmount || socket.bufferedAmount > this.options.maxBufferedAmount - payloadBytes) {
            this.closeSocketAfterSendFailure(socket, 1013, 'relay control send buffer limit reached');
            return;
        }
        try {
            socket.send(payload, (error) => {
                if (error)
                    this.closeSocketAfterSendFailure(socket, 1011, 'relay control send failed');
            });
        }
        catch {
            this.closeSocketAfterSendFailure(socket, 1011, 'relay control send failed');
        }
    }
}
export async function createRelayServer(options) {
    if (!Number.isInteger(options.port) || options.port < 0 || options.port > 65535)
        throw new Error('relay: port is invalid');
    if (!Number.isInteger(options.maxPayload) || options.maxPayload < 1)
        throw new Error('relay: maxPayload must be positive');
    if (!Number.isInteger(options.maxConnections) || options.maxConnections < 1)
        throw new Error('relay: maxConnections must be positive');
    if (!Number.isInteger(options.maxGrants) || options.maxGrants < 1)
        throw new Error('relay: maxGrants must be positive');
    if (!Number.isInteger(options.maxBufferedAmount) || options.maxBufferedAmount < 1)
        throw new Error('relay: maxBufferedAmount must be positive');
    if (!Number.isInteger(options.maxPendingMessages) || options.maxPendingMessages < 1)
        throw new Error('relay: maxPendingMessages must be positive');
    if (!Number.isInteger(options.maxPendingBytes) || options.maxPendingBytes < 1)
        throw new Error('relay: maxPendingBytes must be positive');
    if (!Number.isInteger(options.grantTtlMs) || options.grantTtlMs < 1)
        throw new Error('relay: grantTtlMs must be positive');
    if (options.peerTtlMs !== undefined && (!Number.isSafeInteger(options.peerTtlMs) || options.peerTtlMs < 1 || options.peerTtlMs > MAX_TIMER_MS)) {
        throw new Error('relay: peerTtlMs must be a positive safe integer within the Node timer range');
    }
    const httpsServer = createServer({ key: options.key, cert: options.cert });
    const wsServer = new WebSocketServer({ server: httpsServer, maxPayload: options.maxPayload });
    const relay = new RelayServerImpl(options, httpsServer, wsServer);
    wsServer.on('connection', (socket, request) => relay.accept(socket, request));
    const listening = once(httpsServer, 'listening');
    httpsServer.listen(options.port, options.host ?? '127.0.0.1');
    await listening;
    return relay;
}
