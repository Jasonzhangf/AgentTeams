export type HostHealthState = 'starting' | 'ready' | 'error' | 'stale';
export type RouteCandidateKind = 'lan' | 'tailscale' | 'ipv6' | 'ipv4' | 'gateway' | 'relay-ws' | 'relay-webrtc';
export interface RouteCandidate {
    readonly candidateId: string;
    readonly kind: RouteCandidateKind;
    readonly endpoint?: string;
    readonly port?: number;
    readonly authRequired: boolean;
    readonly lastSeenAt: string;
}
export interface HostDirectoryEntry {
    readonly hostId: string;
    readonly machineId: string;
    readonly agentId: string;
    readonly agentKind: 'opencode' | 'acp' | 'custom';
    readonly accountId: string;
    readonly capabilitiesRevision: string;
    readonly health: HostHealthState;
    readonly routeCandidates: readonly RouteCandidate[];
    readonly updatedAt: string;
    readonly lastSeenAt: string;
}
export interface HostDirectory {
    readonly generation: number;
    readonly hosts: ReadonlyMap<string, HostDirectoryEntry>;
}
export type HostDirectoryInput = Omit<HostDirectoryEntry, 'health' | 'lastSeenAt' | 'updatedAt'> & {
    readonly health?: HostHealthState;
    readonly lastSeenAt?: string;
};
export declare function createHostDirectory(): HostDirectory;
export declare function upsertDirectoryHost(directory: HostDirectory, input: HostDirectoryInput, now?: string): HostDirectory;
export declare function touchHostPresence(directory: HostDirectory, hostId: string, now?: string): HostDirectory;
export declare function removeDirectoryHost(directory: HostDirectory, hostId: string): HostDirectory;
export declare function removeStaleHosts(directory: HostDirectory, now?: string, staleAfterMs?: number): HostDirectory;
export declare function listDirectoryHosts(directory: HostDirectory, accountId?: string): readonly HostDirectoryEntry[];
