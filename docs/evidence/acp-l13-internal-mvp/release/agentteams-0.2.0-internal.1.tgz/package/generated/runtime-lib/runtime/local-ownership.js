import { execFile as execFileCallback } from 'node:child_process';
import { resolve } from 'node:path';
import { promisify } from 'node:util';
const execFile = promisify(execFileCallback);
export function processAlive(pid) {
    try {
        process.kill(pid, 0);
        return true;
    }
    catch (error) {
        return error.code === 'EPERM';
    }
}
export async function processCommand(pid) {
    try {
        return (await execFile('ps', ['-p', String(pid), '-o', 'command='])).stdout;
    }
    catch {
        return undefined;
    }
}
function splitProcessCommand(command) {
    const args = [];
    let current = '';
    let quote;
    let escaped = false;
    for (const character of command.trim()) {
        if (escaped) {
            current += character;
            escaped = false;
            continue;
        }
        if (character === '\\' && quote !== "'") {
            escaped = true;
            continue;
        }
        if (quote !== undefined) {
            if (character === quote)
                quote = undefined;
            else
                current += character;
            continue;
        }
        if (character === '"' || character === "'") {
            quote = character;
            continue;
        }
        if (/\s/.test(character)) {
            if (current.length > 0) {
                args.push(current);
                current = '';
            }
        }
        else
            current += character;
    }
    if (escaped)
        current += '\\';
    if (current.length > 0)
        args.push(current);
    return args;
}
export function processOwnsConfigCommand(command, configPath, entryPath, startToken, tokenFlag = '--launcher-start-token') {
    if (startToken === undefined)
        return false;
    const args = splitProcessCommand(command);
    const entryIndex = args.findIndex(argument => resolve(argument) === resolve(entryPath));
    return entryIndex >= 0 && args[entryIndex + 1] === '--config' && args[entryIndex + 2] === resolve(configPath) && args[entryIndex + 3] === tokenFlag && args[entryIndex + 4] === startToken;
}
