import type { OpenCodeCompiledConfig } from '../opencode-adapter/src/index.ts';
export interface ManagedOpenCodeOptions {
    readonly executable: string;
    /** Caller holds the Agent's exclusive data-directory lease. */
    readonly directory: string;
    readonly port: number;
    readonly startupTimeoutMs: number;
    readonly stopTimeoutMs: number;
    readonly compiled: OpenCodeCompiledConfig;
    readonly resolveCredential: (reference: string) => Promise<string>;
}
/** Owns one substrate child; successful launch requires authenticated configuration readback. */
export declare function startManagedOpenCode(options: ManagedOpenCodeOptions): Promise<{
    url: string;
    authorization: string;
    pid: number;
    effectiveRevision: number;
    compiled: OpenCodeCompiledConfig;
    closed: Promise<{
        code: number | null;
        signal: NodeJS.Signals | null;
    }>;
    stop: () => Promise<void>;
}>;
