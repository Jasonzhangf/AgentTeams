import type { ConfigApplyResult } from './runtime-config.ts';
/**
 * Durable Session observation: one record per agent, written by the agent daemon and read
 * by the control daemon.
 *
 * The agent daemon owns every Session and permission fact on this path — the sessions its
 * engine actually opened and the permission callbacks its engine is actually awaiting. This
 * record is how those facts reach the control daemon's Console projection, because the
 * control daemon declares no Teams listener and therefore has no channel to ask an agent
 * daemon for them. The direction is the mirror image of `config/session-intent-store.ts`:
 * there the control daemon writes the Session writes and the agent daemon reads them; here
 * the agent daemon publishes its own observation and the control daemon reads it. Neither
 * direction adds a control-to-agent channel, a second Session owner, or a Console data
 * path.
 *
 * The record carries projection rows only. It never carries Session business payloads, no
 * transcript, no permission option set and no credential, and the agent's own host stays
 * the only owner of the facts it publishes.
 */
export declare const SESSION_OBSERVATION_VERSION = 1;
export type SessionObservationVersion = typeof SESSION_OBSERVATION_VERSION;
/** Fixed file name inside the same account and scope record directory the intent record uses. */
export declare const SESSION_OBSERVATION_FILE_NAME = "session-observation.json";
/** One engine Session the agent daemon really opened on an open channel. */
export interface SessionObservationSession {
    readonly sessionId: string;
}
/**
 * One engine permission callback the agent daemon is really awaiting. `permissionId` is the
 * id the controller received with the request, so it is the address a Console
 * `permission.reply` must use; `notificationId` is the projection row's own stable id
 * derived from it.
 */
export interface SessionObservationPermission {
    readonly notificationId: string;
    readonly sessionId: string;
    readonly permissionId: string;
}
export interface SessionObservationRecord {
    readonly version: SessionObservationVersion;
    readonly agentId: string;
    readonly revision: number;
    readonly updatedAt: string;
    readonly sessions: readonly SessionObservationSession[];
    readonly permissions: readonly SessionObservationPermission[];
}
/** The observation the agent daemon publishes; the store owns version, revision and time. */
export interface SessionObservationSnapshot {
    readonly agentId: string;
    readonly sessions: readonly SessionObservationSession[];
    readonly permissions: readonly SessionObservationPermission[];
}
/**
 * The one record path both daemons derive independently.
 *
 * The directory is the one shared account-and-scope layout `config/session-intent-store.ts`
 * owns, so the two Session records for one agent live side by side under one directory and
 * this module does not restate the layout rule.
 */
export declare function sessionObservationScopePath(input: {
    readonly home: string;
    readonly accountId: string;
    readonly scopeId: string;
    readonly agentId: string;
}): string;
/**
 * Read the observation record. A missing file means this agent has published nothing yet,
 * which is an honest absence rather than an empty observation. A broken stored record is a
 * typed throw: the reader never falls back to a default that would look like a real
 * observation.
 */
export declare function readSessionObservationRecord(path: string): Promise<SessionObservationRecord | undefined>;
/**
 * Publish one observation with compare-and-swap on the durable revision. The agent daemon
 * is this record's single writer; the fence is what keeps a retry from reporting success
 * for an observation it did not store. `0` creates a record that does not exist yet.
 *
 * The snapshot is the whole observation, not a patch: a Session that closed and a permission
 * that resolved must disappear from the next revision, because a reader that keeps stale
 * rows would project a Session the engine no longer holds.
 */
export declare function writeSessionObservationRecord(path: string, expectedRevision: number, snapshot: SessionObservationSnapshot): Promise<ConfigApplyResult>;
