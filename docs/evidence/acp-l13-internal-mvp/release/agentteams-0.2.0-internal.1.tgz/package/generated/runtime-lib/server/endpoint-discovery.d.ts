import type { AgentDeclaration, AuthenticatedAgent, RelayPeer } from '../control-protocol/agent-services.ts';
import { type EndpointDiscoveryView } from '../control-protocol/endpoint-ref.ts';
/** Sole compile/admission conversion from published Agent capabilities into discovery summaries. */
export declare function compileDeclarationEndpoints(declaration: AgentDeclaration): EndpointDiscoveryView[];
export declare function attachDeclarationEndpoints(declaration: AgentDeclaration): EndpointDiscoveryView[];
export declare function projectPeerEndpoints(peer: RelayPeer, viewer: AuthenticatedAgent): RelayPeer;
