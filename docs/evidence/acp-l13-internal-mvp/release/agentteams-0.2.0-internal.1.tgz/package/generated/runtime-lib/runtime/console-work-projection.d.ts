import type { AgentWork } from '../control-protocol/agent-services.ts';
import type { ConsoleRelationView, ConsoleWorkView } from '../control-protocol/console-api.ts';
/** Map durable Agent Work control fields only; request payloads never enter Console observation. */
export declare function projectConsoleWorkObservations(agentId: string, works: readonly AgentWork[]): {
    readonly works: readonly ConsoleWorkView[];
    readonly relations: readonly ConsoleRelationView[];
};
