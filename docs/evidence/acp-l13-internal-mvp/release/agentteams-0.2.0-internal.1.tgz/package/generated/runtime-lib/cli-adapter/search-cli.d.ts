import { type FixedProcessRunner } from './fixed-process.ts';
import { type SearchRequest, type SearchResult } from './contracts.ts';
export interface ReadOnlySearchCliOptions {
    readonly root: string;
    readonly executable: string;
    readonly timeoutMs?: number;
    readonly maxOutputBytes?: number;
    readonly runner?: FixedProcessRunner;
}
export interface ReadOnlySearchCliAdapter {
    search(request: SearchRequest): Promise<SearchResult>;
}
export declare function createReadOnlySearchCliAdapter(options: ReadOnlySearchCliOptions): ReadOnlySearchCliAdapter;
