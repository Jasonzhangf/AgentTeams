import { assertJsonValue } from "../control-protocol/json-value.js";
import { parseRelayAdmission, RelayProtocolError } from "../control-protocol/relay-admission.js";
import { connectWss } from "./wss-connection.js";
export async function loginRelay(options) {
    if (!Number.isSafeInteger(options.admissionTimeoutMs) || options.admissionTimeoutMs < 1 || options.admissionTimeoutMs > 2_147_483_647) {
        throw new RelayProtocolError('INVALID_INPUT', 'relay: admission timeout must be a valid positive timer duration');
    }
    const request = { kind: 'relay.login', protocolVersion: 2, declaration: options.declaration };
    assertJsonValue(request, 'relay login');
    // Snapshot the configured declaration before network awaits; no business fields are inferred.
    const bytes = Buffer.from(JSON.stringify(request));
    const transport = await connectWss(options.transport);
    let timer;
    const deadline = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new RelayProtocolError('UNAVAILABLE', 'relay: admission timed out')), options.admissionTimeoutMs);
    });
    try {
        return await Promise.race([
            deadline,
            (async () => {
                await transport.send({ bytes, binary: false });
                const frame = await transport.read();
                if (frame.binary)
                    throw new RelayProtocolError('INVALID_INPUT', 'relay: admission requires a text control frame');
                const response = parseRelayAdmission(frame.bytes.toString('utf8'));
                if (response.kind === 'relay.error')
                    throw new RelayProtocolError(response.error.code, response.error.message);
                return { receipt: { connectionId: response.connectionId, generation: response.generation }, transport };
            })(),
        ]);
    }
    catch (error) {
        await transport.close();
        throw error;
    }
    finally {
        clearTimeout(timer);
    }
}
