import type { AcpHost } from '../agent-host/acp-host.ts';
import type { ConfigErrorCode } from '../config/runtime-config.ts';
/**
 * Publish this daemon's own Session and permission observation.
 *
 * The agent daemon owns every Session and permission fact here: the Sessions its engine
 * really holds on an open channel, and the permission callbacks its engine is really
 * awaiting. The control daemon has no channel to ask for them, so this publisher writes
 * them to the one durable observation record the control daemon reads
 * (`config/session-observation-store.ts`). The direction mirrors the pending-Session-write
 * record: there the control daemon writes and this daemon reads; here this daemon publishes
 * and the control daemon reads. Neither adds a control-to-agent channel, and the Console
 * stays out of the data path.
 *
 * The record is a whole snapshot, so a Session whose channel closed and a permission the
 * engine no longer awaits disappear from the next revision. A pass that observes no change
 * writes nothing: the record's revision is a real event count, not a heartbeat.
 */
export interface SessionObservationPublisherInput {
    readonly host: Pick<AcpHost, 'openedSessions' | 'pendingPermissions'>;
    /** The one record path for this daemon. `config/session-observation-store.ts` owns it. */
    readonly recordPath: string;
    /** This daemon's own accepted identity. A record that names another agent is refused. */
    readonly agentId: string;
}
/**
 * One typed refusal to publish, with the agent it belongs to. `code` is the store's own
 * configuration code, plus the `FORBIDDEN` this publisher raises when the record at its own
 * path names another agent. Nothing is flattened into a generic failure.
 */
export interface SessionObservationFailure {
    readonly agentId: string;
    readonly code: ConfigErrorCode | 'FORBIDDEN';
    readonly message: string;
}
export interface SessionObservationPublisher {
    /** One pass: publish the current observation when it differs from the published one. */
    publish(): Promise<void>;
    readonly recordPath: string;
    /** Every typed refusal this publisher recorded in its lifetime. */
    failures(): readonly SessionObservationFailure[];
}
/**
 * The projection row's own id for one pending permission. The permission id is the engine
 * callback id the controller received, so the row is stable while that callback is open and
 * disappears with it; the prefix keeps the row namespace the record's own.
 */
export declare function sessionObservationNotificationId(permissionId: string): string;
export declare function createSessionObservationPublisher(input: SessionObservationPublisherInput): SessionObservationPublisher;
