import { parseWorkEndpointReference } from "./endpoint-ref.js";
import { assertEnvelopeKeys, assertJsonValue } from "./json-value.js";
import { parseServiceError, RelayProtocolError } from "./relay-codec.js";
function object(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new RelayProtocolError('INVALID_INPUT', 'Work control must be an object');
    return value;
}
function string(value) {
    if (typeof value !== 'string' || !value)
        throw new RelayProtocolError('INVALID_INPUT', 'Work control requires a non-empty string');
}
function positive(value) {
    if (!Number.isSafeInteger(value) || value < 1)
        throw new RelayProtocolError('INVALID_INPUT', 'Work control requires a positive safe integer');
}
function error(value) {
    parseServiceError(value, 'Work error');
}
function proposal(value, state) {
    const fields = object(value);
    assertEnvelopeKeys(fields, ['workId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion', 'policyRevision', 'endpoint', ...(state ? ['state'] : [])], 'Work proposal');
    for (const key of ['workId', 'consumerAgentId', 'providerAgentId', 'capabilityId', 'capabilityVersion'])
        string(fields[key]);
    positive(fields.policyRevision);
    if (fields.endpoint !== undefined)
        parseWorkEndpointReference(fields.endpoint);
    if (state && !['accepted', 'closing', 'closed', 'rejected'].includes(fields.state))
        throw new Error('invalid Work state');
}
export function parseWorkWireFrame(text) {
    const frame = object(JSON.parse(text));
    assertJsonValue(frame, 'Work frame');
    string(frame.correlationId);
    switch (frame.kind) {
        case 'work.propose':
            assertEnvelopeKeys(frame, ['kind', 'correlationId', 'proposal'], 'Work proposal frame');
            proposal(frame.proposal, false);
            break;
        case 'work.state':
            assertEnvelopeKeys(frame, ['kind', 'correlationId', 'work'], 'Work state frame');
            proposal(frame.work, true);
            break;
        case 'work.get':
            assertEnvelopeKeys(frame, ['kind', 'correlationId', 'workId', 'requestId'], 'Work query');
            string(frame.workId);
            string(frame.requestId);
            break;
        case 'work.close':
            assertEnvelopeKeys(frame, ['kind', 'correlationId', 'workId'], 'Work close');
            string(frame.workId);
            break;
        case 'work.error':
            assertEnvelopeKeys(frame, ['kind', 'correlationId', 'error'], 'Work error');
            error(frame.error);
            break;
        case 'work.request': {
            assertEnvelopeKeys(frame, ['kind', 'correlationId', 'control', 'payload'], 'Work request');
            if (!Object.hasOwn(frame, 'payload'))
                throw new Error('Work request payload is required');
            const control = object(frame.control);
            assertEnvelopeKeys(control, ['workId', 'requestId', 'operation', 'targetGeneration', 'demands'], 'Work request control');
            string(control.workId);
            string(control.requestId);
            string(control.operation);
            positive(control.targetGeneration);
            if (!Array.isArray(control.demands))
                throw new Error('Work demands must be an array');
            for (const item of control.demands) {
                const demand = object(item);
                assertEnvelopeKeys(demand, ['resourceId', 'amount'], 'Work demand');
                string(demand.resourceId);
                positive(demand.amount);
            }
            break;
        }
        case 'work.result': {
            assertEnvelopeKeys(frame, ['kind', 'correlationId', 'control', 'payload'], 'Work result');
            const control = object(frame.control);
            assertEnvelopeKeys(control, ['workId', 'requestId', 'state', 'error'], 'Work result control');
            string(control.workId);
            string(control.requestId);
            if (!['running', 'succeeded', 'failed', 'cancel_requested', 'cancelled', 'unknown'].includes(control.state))
                throw new Error('invalid Work request state');
            if (control.error !== undefined)
                error(control.error);
            break;
        }
        default: throw new RelayProtocolError('INVALID_INPUT', 'unknown Work frame');
    }
    return frame;
}
