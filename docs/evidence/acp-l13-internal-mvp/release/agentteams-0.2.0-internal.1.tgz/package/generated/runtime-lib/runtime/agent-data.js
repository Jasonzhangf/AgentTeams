import { createWorkChannel } from "../network/work-channel.js";
import { serveConsole } from "../network/console-channel.js";
import { RelayProtocolError } from "../control-protocol/relay-codec.js";
/** The first typed frame selects a protocol; authorization stays in each Agent ingress. */
export async function acceptAgentData(socket, options) {
    let timer;
    try {
        if (!Number.isSafeInteger(options.work.timeoutMs) || options.work.timeoutMs < 1 || options.work.timeoutMs > 2_147_483_647)
            throw new RelayProtocolError('INVALID_INPUT', 'Agent opening timeout invalid');
        const first = await Promise.race([
            socket.read(),
            new Promise((_, reject) => { timer = setTimeout(() => reject(new RelayProtocolError('UNAVAILABLE', 'Agent data opening deadline elapsed')), options.work.timeoutMs); }),
        ]);
        clearTimeout(timer);
        if (first.binary)
            throw new RelayProtocolError('INVALID_INPUT', 'Agent opening frame must be JSON text');
        const frame = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(first.bytes));
        const kind = frame && typeof frame === 'object' && !Array.isArray(frame) ? frame.kind : undefined;
        let consumed = false;
        const input = {
            closed: socket.closed, close: () => socket.close(), send: frame => socket.send(frame),
            read: () => { if (!consumed) {
                consumed = true;
                return Promise.resolve(first);
            } return socket.read(); },
        };
        if (typeof kind === 'string' && kind.startsWith('console.'))
            await serveConsole(input, options.console, options.work.timeoutMs);
        else if (typeof kind === 'string' && kind.startsWith('work.'))
            await createWorkChannel(input, options.work).closed;
        else
            throw new RelayProtocolError('UNSUPPORTED_OPERATION', 'Unsupported Agent data protocol');
    }
    finally {
        clearTimeout(timer);
        await socket.close();
    }
}
