import { type EndpointDescriptor, type EndpointKind, type EndpointLifecycle } from './types.ts';
export declare function parseEndpointKind(value: unknown, path: string): EndpointKind;
export declare function parseEndpointLifecycle(value: unknown, path: string): EndpointLifecycle;
export declare function validateEndpointDescriptor(value: unknown): EndpointDescriptor;
export declare function endpointKey(ownerAgentId: string, endpointId: string): string;
