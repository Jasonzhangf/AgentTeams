export type AgentMessageKind = 'request.capability' | 'reply.capability' | 'task.result' | 'notify' | 'error';
export interface AgentMessage {
    readonly kind: AgentMessageKind;
    readonly correlationId: string;
    readonly payload: Readonly<Record<string, unknown>>;
}
export interface AgentPairChannelRef {
    readonly channelId: string;
    readonly relationId: string;
    readonly fromAgentId: string;
    readonly toAgentId: string;
    readonly targetGeneration: number;
}
export declare function validateAgentMessage(value: unknown): AgentMessage;
export declare function validateAgentPairChannelRef(value: unknown): AgentPairChannelRef;
export declare function buildAgentPairChannelId(agentA: string, agentB: string): string;
