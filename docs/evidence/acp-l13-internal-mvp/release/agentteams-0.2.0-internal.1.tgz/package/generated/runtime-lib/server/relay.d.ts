import type { AuthenticatedAgent, RelayPeer } from '../control-protocol/agent-services.ts';
type MaybePromise<T> = T | Promise<T>;
type Credential = string | undefined;
/**
 * Server-owned default presence lease. It matches the directory stale window
 * (`removeStaleHosts` defaults to 90s) so one LAN lease policy exists. A peer
 * that stops heartbeating for this long is published offline even when its
 * socket never sent a close frame.
 */
export declare const DEFAULT_PEER_TTL_MS = 90000;
export interface RelayServerOptions {
    readonly host?: string;
    readonly port: number;
    readonly key: string | Buffer;
    readonly cert: string | Buffer;
    readonly maxPayload: number;
    readonly maxConnections: number;
    readonly maxGrants: number;
    readonly maxBufferedAmount: number;
    readonly maxPendingMessages: number;
    readonly maxPendingBytes: number;
    readonly grantTtlMs: number;
    /**
     * Presence lease. `relay.presence` renews it; the peer is published offline
     * when `lastSeenAt + peerTtlMs` passes. The control socket is left in place so
     * a late heartbeat can renew the same generation.
     */
    readonly peerTtlMs?: number;
    readonly authenticate: (credential: Credential) => MaybePromise<AuthenticatedAgent | null>;
    readonly authorizeTarget?: (source: AuthenticatedAgent, target: RelayPeer) => MaybePromise<boolean>;
    readonly now?: () => Date;
    readonly idFactory?: () => string;
}
export interface RelayServer {
    readonly url: string;
    readonly port: number;
    close(): Promise<void>;
}
export declare function createRelayServer(options: RelayServerOptions): Promise<RelayServer>;
export {};
