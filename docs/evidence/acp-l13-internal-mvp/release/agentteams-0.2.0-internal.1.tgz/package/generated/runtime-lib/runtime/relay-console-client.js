import { randomUUID } from 'node:crypto';
import { parseConsoleWireRequest } from "../control-protocol/console-wire.js";
import { assertJsonValue } from "../control-protocol/json-value.js";
import { RelayProtocolError } from "../control-protocol/relay-codec.js";
import { requestConsole } from "../network/console-channel.js";
export class ConsoleProjectionError extends Error {
    error;
    constructor(error) {
        super(error.message);
        this.error = error;
    }
}
/**
 * One Agent binding over the existing authenticated relay; directory state never grants management rights.
 * A Session message carries a whole model turn, so its exchange gets its own deadline: the
 * control deadline must stay tight, because a hung Agent must fail fast for projection and commands.
 */
export function createRelayConsoleClient(relay, agentId, timeoutMs, sessionTimeoutMs = timeoutMs) {
    const validDeadline = (value) => Number.isSafeInteger(value) && value >= 1 && value <= 2_147_483_647;
    if (!agentId || !validDeadline(timeoutMs) || !validDeadline(sessionTimeoutMs))
        throw new RelayProtocolError('INVALID_INPUT', 'Invalid Console relay binding');
    const exchange = async (input, deadlineMs = timeoutMs) => {
        assertJsonValue(input, 'Console client request');
        const snapshot = parseConsoleWireRequest(JSON.stringify({ ...input, correlationId: randomUUID(), targetGeneration: 1 }));
        const targetId = snapshot.kind === 'console.command' ? snapshot.command.agentId : snapshot.agentId;
        if (targetId !== agentId)
            throw new RelayProtocolError('FORBIDDEN', 'Console client is bound to another Agent');
        const peer = (await relay.directory(false)).find(peer => peer.declaration.identity.agentId === agentId);
        if (!peer)
            throw new RelayProtocolError('NOT_FOUND', 'Agent is absent from the admitted directory');
        if (peer.presence !== 'online')
            throw new RelayProtocolError('UNAVAILABLE', 'Agent is offline');
        const grant = await relay.connect(agentId, peer.generation);
        const socket = await relay.openData(grant);
        return requestConsole(socket, { ...snapshot, targetGeneration: peer.generation }, deadlineMs);
    };
    return {
        readProjection: async () => {
            const reply = await exchange({ kind: 'console.projection', agentId });
            if (reply.kind === 'console.projection.result')
                return reply.projection;
            if (!reply.result.ok)
                throw new ConsoleProjectionError(reply.result.error);
            throw new RelayProtocolError('INVALID_INPUT', 'Console projection result missing');
        },
        command: async (command) => {
            const reply = await exchange({ kind: 'console.command', command });
            if (reply.kind !== 'console.result')
                throw new RelayProtocolError('INVALID_INPUT', 'Unexpected Console command response');
            return reply.result;
        },
        sendSession: async (target, payload) => {
            const reply = await exchange({ kind: 'console.session', ...target, payload }, sessionTimeoutMs);
            if (reply.kind !== 'console.result')
                throw new RelayProtocolError('INVALID_INPUT', 'Unexpected Console Session response');
            return reply.result;
        },
    };
}
