import type { CompileLegacyAgentCapabilitiesInput, EndpointDescriptor } from './types.ts';
/**
 * Sole compile/admission conversion from old Agent capability input into one Endpoint descriptor.
 * Callers must supply a stable endpointId; it is never derived from a capability name.
 */
export declare function compileLegacyAgentCapabilities(input: CompileLegacyAgentCapabilitiesInput): EndpointDescriptor;
