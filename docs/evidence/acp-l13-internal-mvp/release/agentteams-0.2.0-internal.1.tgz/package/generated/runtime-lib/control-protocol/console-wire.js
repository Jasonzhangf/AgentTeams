import { parseConsoleCommand, parseConsoleProjection, parsePermissionReplyResult, parseSessionCancelConfirmed, parseSessionCancelUnknownDetail, parseSessionCreateResult, } from "./console-api.js";
import { assertEnvelopeKeys, assertJsonValue } from "./json-value.js";
import { parseServiceError, RelayProtocolError } from "./relay-codec.js";
/** This decoder grants no permission: runtime binds the authenticated peer and checks generation. */
export function parseConsoleWireRequest(text) {
    const input = JSON.parse(text);
    assertJsonValue(input, 'Console wire request');
    if (input === null || typeof input !== 'object' || Array.isArray(input))
        throw new RelayProtocolError('INVALID_INPUT', 'Console request must be an object');
    const frame = input;
    const requireText = (value) => {
        if (typeof value !== 'string' || !value)
            throw new RelayProtocolError('INVALID_INPUT', 'Console request identity is required');
    };
    requireText(frame.correlationId);
    if (!Number.isSafeInteger(frame.targetGeneration) || frame.targetGeneration < 1)
        throw new RelayProtocolError('INVALID_INPUT', 'Console request generation is invalid');
    const common = ['kind', 'correlationId', 'targetGeneration'];
    switch (frame.kind) {
        case 'console.projection':
            assertEnvelopeKeys(frame, [...common, 'agentId'], 'Console projection request');
            requireText(frame.agentId);
            break;
        case 'console.command':
            assertEnvelopeKeys(frame, [...common, 'command'], 'Console command request');
            parseConsoleCommand(frame.command);
            break;
        case 'console.session':
            assertEnvelopeKeys(frame, [...common, 'agentId', 'sessionId', 'payload'], 'Console Session request');
            requireText(frame.agentId);
            requireText(frame.sessionId);
            if (!Object.hasOwn(frame, 'payload'))
                throw new RelayProtocolError('INVALID_INPUT', 'Console Session payload is required');
            break;
        default: throw new RelayProtocolError('INVALID_INPUT', 'Unknown Console request');
    }
    return frame;
}
function record(value, keys) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Console response object required');
    const result = value;
    assertEnvelopeKeys(result, keys, 'Console response');
    return result;
}
function string(value) {
    if (typeof value !== 'string' || !value)
        throw new Error('Console response identity required');
}
function optionalString(value) {
    if (value !== undefined && typeof value !== 'string')
        throw new Error('Console response string required');
}
function error(value) {
    const input = record(value, ['code', 'message', 'execution', 'status', 'providerInstanceId', 'detail']);
    // Validate shared fields through their owner; the Console-only credential code is retained verbatim.
    const configOnly = input.code === 'CREDENTIAL_UNAVAILABLE' || input.code === 'SOURCE_CHANGED' || input.code === 'MIGRATION_CONFLICT' || input.code === 'APPLY_TARGET_MISMATCH';
    parseServiceError({ code: configOnly ? 'UNAVAILABLE' : input.code, message: input.message,
        ...(input.execution === undefined ? {} : { execution: input.execution }) }, 'Console error');
    optionalString(input.providerInstanceId);
    if (input.status !== undefined && (!Number.isSafeInteger(input.status) || input.status < 100 || input.status > 599))
        throw new Error('Console response HTTP status invalid');
    if (input.detail !== undefined)
        parseSessionCancelUnknownDetail(input.detail);
}
function projection(value) {
    // One closed projection parser owns the field set; the wire only decides the envelope.
    parseConsoleProjection(value);
}
function commandResult(value) {
    const result = record(value, ['ok', 'result', 'error']);
    if (result.ok !== true && result.ok !== false)
        throw new Error('Console response enum invalid');
    if (result.ok === true) {
        assertEnvelopeKeys(result, ['ok', 'result'], 'Console success');
        if (result.result !== undefined) {
            assertJsonValue(result.result, 'Console success result');
            const payload = result.result;
            if (typeof payload === 'object' && payload !== null && !Array.isArray(payload)) {
                const kind = payload.kind;
                if (kind === 'session.create')
                    parseSessionCreateResult(payload);
                else if (kind === 'session.cancel')
                    parseSessionCancelConfirmed(payload);
                else if (kind === 'permission.reply')
                    parsePermissionReplyResult(payload);
            }
        }
    }
    else {
        assertEnvelopeKeys(result, ['ok', 'error'], 'Console failure');
        error(result.error);
    }
}
export function parseConsoleWireReply(text) {
    const value = JSON.parse(text);
    assertJsonValue(value, 'Console response');
    const frame = record(value, ['kind', 'correlationId', 'projection', 'result']);
    string(frame.correlationId);
    if (frame.kind === 'console.projection.result') {
        assertEnvelopeKeys(frame, ['kind', 'correlationId', 'projection'], 'Console projection response');
        projection(frame.projection);
    }
    else if (frame.kind === 'console.result') {
        assertEnvelopeKeys(frame, ['kind', 'correlationId', 'result'], 'Console command response');
        commandResult(frame.result);
    }
    else
        throw new Error('Unknown Console response kind');
    return frame;
}
