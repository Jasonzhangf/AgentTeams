import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { RegistryDaemonIntent } from '../config/daemon-intent.ts';
import { type RegistryImplementation } from '../config/daemon-intent.ts';
import { type RelayServerOptions } from './relay.ts';
/**
 * The single owner that maps the frozen `RegistryDaemonIntent` onto the
 * existing `server/Relay` server options. `RelayProcessConfig` v1 JSON stays an
 * internal projection of the local launcher and is never a second editable
 * source for the registry; this module is the only registry mapping site.
 */
/**
 * A registry `listen` always needs an explicit certificate and key, including a
 * loopback listener. The runtime never generates a certificate and never
 * downgrades to plaintext `ws`.
 */
export declare const REGISTRY_TLS_OPENSSL_COMMAND = "openssl req -x509 -newkey rsa:2048 -nodes -days 365 -subj \"/CN=<registry-host>\" -keyout certs/registry-key.pem -out certs/registry-cert.pem";
/** Reuses the deployed Relay limit policy and adds the server-owned presence lease. */
export declare const REGISTRY_SERVER_DEFAULTS: {
    readonly maxPayload: 65536;
    readonly maxConnections: 64;
    readonly maxGrants: 32;
    readonly maxBufferedAmount: 65536;
    readonly maxPendingMessages: 32;
    readonly maxPendingBytes: 65536;
    readonly grantTtlMs: 10000;
    readonly peerTtlMs: 90000;
};
export type RegistryIntentFaultCode = 'TLS_REQUIRED' | 'UNSUPPORTED_CONFIGURATION' | 'INVALID_INPUT' | 'UNAUTHENTICATED' | 'CONFLICT' | 'NOT_FOUND';
export declare class RegistryIntentFault extends Error {
    readonly code: RegistryIntentFaultCode;
    constructor(code: RegistryIntentFaultCode, message: string, cause?: unknown);
}
export interface RegistryCredentialBinding {
    readonly admissionRef: string;
    readonly identity: AuthenticatedAgent;
    /** `env:NAME` or `file:<absolute-path>`; the value itself is never stored here. */
    readonly credentialRef: string;
}
export interface RegistryServerPlan {
    readonly implementation: RegistryImplementation;
    readonly host: string;
    readonly port: number;
    readonly tls: {
        readonly certFile: string;
        readonly keyFile: string;
    };
    readonly limits: typeof REGISTRY_SERVER_DEFAULTS;
    readonly credentials: readonly RegistryCredentialBinding[];
}
/**
 * Pure projection of one already-resolved registry intent. It reads no secret
 * and touches no file, so `registry status` can print it without a credential.
 */
export declare function resolveRegistryServerPlan(intent: RegistryDaemonIntent): RegistryServerPlan;
export interface RegistryCredentialLoadOptions {
    readonly env?: NodeJS.ProcessEnv;
    /** Test seam only; production reads the referenced file. */
    readonly readFile?: (path: string) => Promise<string>;
}
/**
 * Resolves every admitted credential value exactly once. The returned map is
 * keyed by the exact `Authorization` header value; it is never a projection
 * field and never enters a directory entry or control frame.
 */
export declare function loadRegistryCredentials(plan: RegistryServerPlan, options?: RegistryCredentialLoadOptions): Promise<ReadonlyMap<string, AuthenticatedAgent>>;
export interface RegistryRelayTls {
    readonly key: string | Buffer;
    readonly cert: string | Buffer;
}
/**
 * Assembles the exact `RelayServerOptions` for one registry. Identity matching
 * against the declaration stays owned by `createRelayServer`.
 */
export declare function createRegistryRelayOptions(plan: RegistryServerPlan, input: {
    readonly credentials: ReadonlyMap<string, AuthenticatedAgent>;
    readonly tls: RegistryRelayTls;
}): RelayServerOptions;
