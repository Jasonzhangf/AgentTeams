import { parseRelayServerControl, RelayProtocolError } from "./relay-codec.js";
export { RelayProtocolError } from "./relay-codec.js";
/** First server frame only. A directory or arbitrary object cannot imply admission. */
export function parseRelayAdmission(text) {
    try {
        const input = parseRelayServerControl(text);
        if (input.kind === 'relay.admitted' || input.kind === 'relay.error')
            return input;
        throw new Error('unexpected admission frame');
    }
    catch {
        throw new RelayProtocolError('INVALID_INPUT', 'relay: invalid admission response');
    }
}
