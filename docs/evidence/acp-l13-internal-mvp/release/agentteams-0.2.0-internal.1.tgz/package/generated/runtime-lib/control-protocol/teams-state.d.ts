import type { AcpFault, HistoryRecord } from './acp.ts';
import { type ConsoleProjectionV1, type SessionObservationState } from './console-api.ts';
import type { RelationRole } from './teams-connection.ts';
/**
 * Public Teams lifecycle and history read surface. Owner: control-protocol.
 * Version: 1 for the connection-status and history-query shapes below.
 *
 * Request/execution lifecycle is intentionally NOT redefined here. The canonical
 * vocabulary stays `RequestState` in `agent-services.ts`; registration presence
 * stays the server directory health vocabulary. This module only adds the two
 * facts no existing owner declares: the transport/negotiation lifecycle of one
 * Teams connection, and the history read request/response shape.
 */
export declare const TEAMS_CONNECTION_STATUS_VERSION = 1;
export declare const TEAMS_HISTORY_QUERY_VERSION = 1;
/** Transport and negotiation lifecycle for one Teams connection. */
export type TeamsConnectionState = 'disconnected' | 'connecting' | 'authenticating' | 'negotiating' | 'ready' | 'closed' | 'failed';
export declare const TEAMS_CONNECTION_STATES: readonly TeamsConnectionState[];
export interface TeamsConnectionStatus {
    readonly version: typeof TEAMS_CONNECTION_STATUS_VERSION;
    readonly remoteAgentId: string;
    readonly state: TeamsConnectionState;
    /** The target daemon generation this observation belongs to. */
    readonly targetGeneration: number;
    /** Owner event time; never derived from UI animation. */
    readonly observedAt: string;
    readonly connectionId?: string;
    readonly role?: RelationRole;
    /** Present only for `failed`; `closed` carries no error. */
    readonly error?: AcpFault;
}
/** One page of owner-recorded history. Records keep their owning sequence. */
export interface HistoryQuery {
    readonly version: typeof TEAMS_HISTORY_QUERY_VERSION;
    readonly kind?: 'request' | 'connection';
    readonly agentId?: string;
    readonly sessionId?: string;
    readonly limit: number;
    /** Return records with a strictly smaller sequence; enables paging. */
    readonly beforeSequence?: number;
}
export interface HistoryPage {
    readonly records: readonly HistoryRecord[];
    /** Set only when more matching records exist before this page. */
    readonly nextBeforeSequence?: number;
}
/** Read-only history port. agent-host owns request history, network owns connection history. */
export interface HistoryReadPort {
    query(query: HistoryQuery): Promise<HistoryPage>;
}
/**
 * One owner projection snapshot carried by the SSE stream. `seq` is the owner's own
 * monotonic projection sequence; a consumer that sees a gap treats the projection as
 * degraded instead of inventing the missing rows. The full projection is always carried,
 * so the UI never keeps a delta store as a second source of truth.
 */
export interface ConsoleProjectionSnapshot {
    readonly seq: number;
    readonly projection: ConsoleProjectionV1;
}
/**
 * Owner projection feed. The owner decides when a snapshot exists and when the owner is
 * lost; a subscriber must never fabricate liveness after `onHealth` reports loss.
 */
export interface ConsoleProjectionSink {
    onSnapshot(snapshot: ConsoleProjectionSnapshot): void;
    onHealth(state: SessionObservationState): void;
}
export type ConsoleProjectionUnsubscribe = () => void;
/** SSE source. Returns the unsubscribe handle that the server calls when the stream ends. */
export type ConsoleProjectionSubscriber = (sink: ConsoleProjectionSink) => ConsoleProjectionUnsubscribe;
export declare function parseTeamsConnectionState(value: unknown): TeamsConnectionState;
export declare function parseTeamsConnectionStatus(value: unknown): TeamsConnectionStatus;
export declare function parseHistoryQuery(value: unknown): HistoryQuery;
/** Closed validation of one SSE projection frame; the sequence is the owner's own counter. */
export declare function parseConsoleProjectionSnapshot(value: unknown): ConsoleProjectionSnapshot;
/**
 * The one HTTP query-string → `HistoryQuery` mapping. It refuses every parameter name
 * outside the frozen query, and every duplicate, before the closed parser runs.
 */
export declare function historyQueryFromSearchParams(params: URLSearchParams): HistoryQuery;
