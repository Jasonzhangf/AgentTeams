export const ENDPOINT_ERROR_CODES = [
    'INVALID_IDENTITY',
    'INVALID_REVISION',
    'INVALID_LIFECYCLE',
    'DUPLICATE_ENDPOINT_ID',
    'CROSS_AGENT_OWNERSHIP',
    'CAPABILITY_OUTSIDE_ENDPOINT',
    'RESOURCE_OUTSIDE_ENDPOINT',
    'ENDPOINT_DISABLED',
    'STALE_REVISION',
    'NOT_FOUND',
    'CONFLICT',
    'INVALID_INPUT',
];
export function isEndpointError(error) {
    return error instanceof Error && error.name === 'EndpointError' && ENDPOINT_ERROR_CODES.includes(error.code);
}
export function fail(code, message) {
    const error = new Error(`${code}: ${message}`);
    Object.defineProperty(error, 'name', { value: 'EndpointError' });
    Object.defineProperty(error, 'code', { value: code, enumerable: true });
    throw error;
}
