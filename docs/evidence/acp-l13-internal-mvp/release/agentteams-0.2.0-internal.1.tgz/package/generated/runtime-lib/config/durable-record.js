import { randomUUID } from 'node:crypto';
import { mkdir, rename, unlink, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
/**
 * The fence records the real substrate facts of an ambiguous write: the durable target (the
 * record path, which is the only identity this store owns), the revision the caller
 * accepted, and the revision the write intended to publish.
 */
export function recordWriteUncertainty(path, label, acceptedRevision, effectiveRevision, cause) {
    const target = resolve(path);
    return {
        target: {
            agentId: target,
            targetGeneration: 1,
            acceptedRevision,
            acceptedSourceRevision: 0,
            acceptedSourceHash: '',
            endpointFingerprint: target,
        },
        operation: { operationId: `apply:${target}:${Date.now()}:${randomUUID()}`, kind: 'apply' },
        error: {
            code: 'RESULT_UNKNOWN',
            message: `${label} outcome is unknown: ${path}: ${cause instanceof Error ? cause.message : String(cause)}`,
        },
        substrate: {
            effectiveRevision,
            effectiveHandleFingerprint: `${target}\u0000${effectiveRevision}`,
        },
    };
}
/** Best-effort removal of the temporary file; the first write error is what matters. */
async function discard(temporary) {
    try {
        await unlink(temporary);
    }
    catch { /* keep the first failure */ }
}
export async function writeRecordAtomically(input) {
    const temporary = `${input.path}.${process.pid}.${randomUUID()}.tmp`;
    try {
        await mkdir(dirname(input.path), { recursive: true });
        await writeFile(temporary, `${JSON.stringify(input.record)}\n`, { encoding: 'utf8', mode: 0o600 });
    }
    catch {
        await discard(temporary);
        return { status: 'failed', error: { code: 'UNAVAILABLE', message: `${input.label} could not be saved: ${input.path}` } };
    }
    try {
        await rename(temporary, input.path);
    }
    catch (cause) {
        await discard(temporary);
        const fence = recordWriteUncertainty(input.path, input.label, input.acceptedRevision, input.effectiveRevision, cause);
        return { status: 'uncertain', error: fence.error, fence };
    }
    return { status: 'applied', effectiveRevision: input.effectiveRevision };
}
