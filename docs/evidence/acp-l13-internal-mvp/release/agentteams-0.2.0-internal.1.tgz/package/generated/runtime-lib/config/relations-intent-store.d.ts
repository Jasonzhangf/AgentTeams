import type { RelationRole } from '../control-protocol/teams-connection.ts';
import type { ConfigApplyResult } from './runtime-config.ts';
/**
 * Durable desired-relations intent: one record per agent identity.
 *
 * The control daemon writes the peer relations it wants; the agent daemon reads
 * the same record at the shared conventional path (`relationsIntentPathFor`). The
 * record owns only the desired intent and its revision. It never mirrors live
 * connection state, negotiation results, or credentials, and a reader never falls
 * back to a default when the record is missing or broken.
 */
export declare const RELATIONS_INTENT_VERSION = 1;
export type RelationsIntentVersion = typeof RELATIONS_INTENT_VERSION;
/** Fixed file name inside the agent's record directory. */
export declare const RELATIONS_INTENT_FILE_NAME = "relations-intent.json";
/** One desired peer relation; `role` is the frozen control-protocol role. */
export interface DesiredPeerRelation {
    readonly agentId: string;
    readonly role: RelationRole;
}
export interface RelationsIntentRecord {
    readonly version: RelationsIntentVersion;
    readonly revision: number;
    readonly peers: readonly DesiredPeerRelation[];
    readonly updatedAt: string;
}
/** The three mutations the frozen relation commands need. */
export type RelationsIntentChange = {
    readonly op: 'connect';
    readonly agentId: string;
    readonly role: RelationRole;
} | {
    readonly op: 'disconnect';
    readonly agentId: string;
} | {
    readonly op: 'replace';
    readonly peers: readonly DesiredPeerRelation[];
};
/** The owning daemon's record path. One derivation serves the writer and the reader. */
export declare function relationsIntentPath(dataDirectory: string): string;
/**
 * The shared record path both daemons derive independently.
 *
 * The writer (the control daemon) and the reader (the agent daemon) must agree
 * without a new config key, and the frozen v4 `PeerIntent` carries no peer
 * `dataDirectory`. The one identity both sides already carry is the account and
 * scope pair: the writer reads the target peer's `accountId` and `scopeId` from
 * its own declared `peers`, and the reader reads its own `daemon.accountId` and
 * `daemon.scopeId`. `~/.agentteams` is the project's established local root
 * (`runtime/acp-serve.ts` resolves its own `configDirectory` from it, and
 * `config/`'s local layout uses it), so the record is one desired membership set
 * per account and scope.
 *
 * Limitation: a control daemon and an agent daemon in different accounts or
 * scopes resolve different records. The quick-start layout gives both `local`.
 */
export declare function relationsIntentScopeDirectory(input: {
    readonly home: string;
    readonly accountId: string;
    readonly scopeId: string;
}): string;
/** The one shared record path for one account and scope. */
export declare function relationsIntentScopePath(input: {
    readonly home: string;
    readonly accountId: string;
    readonly scopeId: string;
}): string;
/**
 * Read the durable record. A missing file is `undefined`; a broken file is a
 * typed `RuntimeConfigError` carrying a real `ConfigErrorCode`, never a default.
 */
export declare function readRelationsIntentRecord(path: string): Promise<RelationsIntentRecord | undefined>;
/**
 * Apply one change with compare-and-swap on the durable revision. The revision
 * is monotonic and starts at 1. `expectedRevision` is the caller's CAS
 * expectation; `0` creates a record that does not exist yet. A `disconnect` of
 * an absent agent is a no-op that still bumps the revision, because a caller
 * that retries the same command at the same expectation must then move on.
 *
 * Input that cannot name a valid change is a `failed` result with
 * `INVALID_INPUT`; a broken stored file is the read's typed throw. A refused
 * write never touches the durable target.
 */
export declare function writeRelationsIntentRecord(path: string, expectedRevision: number, next: RelationsIntentChange): Promise<ConfigApplyResult>;
