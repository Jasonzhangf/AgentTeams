import { spawn as nodeSpawn } from 'node:child_process';
import { access, lstat, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { createConnection } from 'node:net';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { parseLocalConsoleProjectionConfig, projectLocalChildConfigs, readLocalInternalConfig, writeLocalInternalConsoleRuntime, writeLocalInternalLauncherState, writeLocalInternalRecoveryState, writeLocalInternalState, writeLocalInternalWorkControl, writeLocalLauncherOwnership } from "./local-config.js";
import { processAlive, processCommand, processOwnsConfigCommand } from "./local-ownership.js";
import { startLocalWorkControlListener } from "./local-work-control.js";
export function localWorkControlSocketPath(internalPath) {
    return resolve(dirname(internalPath), '.internal', 'work-control.sock');
}
export class LocalConsoleLifecycleError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'LocalConsoleLifecycleError';
    }
}
function projectionRecord(value, label) {
    if (typeof value !== 'object' || value === null || Array.isArray(value))
        throw new Error(`${label} must be an object`);
    return value;
}
function projectionText(value, label) {
    if (typeof value !== 'string' || value.trim() === '')
        throw new Error(`${label} must be a non-empty string`);
    return value;
}
function projectionPositiveInteger(value, label) {
    if (!Number.isSafeInteger(value) || value < 1)
        throw new Error(`${label} must be a positive safe integer`);
    return value;
}
function projectionFields(value, allowed, label) {
    const unknown = Object.keys(value).filter(key => !allowed.includes(key));
    if (unknown.length > 0)
        throw new Error(`${label} has unsupported fields: ${unknown.join(', ')}`);
}
/** Validate the Agent-owned status snapshot before it becomes runtime projection truth. */
export function parseLocalDaemonEndpointProjection(value, label = 'local daemon endpoint') {
    const input = projectionRecord(value, label);
    projectionFields(input, ['agentId', 'identity', 'role', 'presence', 'state', 'generation', 'capabilities'], label);
    const identityInput = projectionRecord(input.identity, `${label}.identity`);
    projectionFields(identityInput, ['hostId', 'machineId', 'agentId', 'accountId', 'agentKind', 'label'], `${label}.identity`);
    const identity = {
        hostId: projectionText(identityInput.hostId, `${label}.identity.hostId`),
        machineId: projectionText(identityInput.machineId, `${label}.identity.machineId`),
        agentId: projectionText(identityInput.agentId, `${label}.identity.agentId`),
        accountId: projectionText(identityInput.accountId, `${label}.identity.accountId`),
        agentKind: (() => {
            const value = identityInput.agentKind;
            if (value !== 'opencode' && value !== 'acp' && value !== 'custom')
                throw new Error(`${label}.identity.agentKind is invalid`);
            return value;
        })(),
        label: projectionText(identityInput.label, `${label}.identity.label`),
    };
    const role = input.role;
    if (role !== 'provider' && role !== 'receiver' && role !== 'hybrid')
        throw new Error(`${label}.role is invalid`);
    const presence = input.presence;
    if (presence !== 'online' && presence !== 'offline' && presence !== 'unknown')
        throw new Error(`${label}.presence is invalid`);
    const state = input.state;
    if (state !== 'online' && state !== 'stopped' && state !== 'failed')
        throw new Error(`${label}.state is invalid`);
    const agentId = projectionText(input.agentId, `${label}.agentId`);
    if (agentId !== identity.agentId)
        throw new Error(`${label}.agentId must match identity.agentId`);
    if (!Array.isArray(input.capabilities))
        throw new Error(`${label}.capabilities must be an array`);
    const capabilities = input.capabilities.map((capability, index) => {
        const capabilityInput = projectionRecord(capability, `${label}.capabilities[${index}]`);
        projectionFields(capabilityInput, ['capabilityId', 'version', 'operations', 'resources'], `${label}.capabilities[${index}]`);
        if (!Array.isArray(capabilityInput.operations) || capabilityInput.operations.length === 0) {
            throw new Error(`${label}.capabilities[${index}].operations must be a non-empty array`);
        }
        const operations = capabilityInput.operations.map((operation, operationIndex) => projectionText(operation, `${label}.capabilities[${index}].operations[${operationIndex}]`));
        if (!Array.isArray(capabilityInput.resources))
            throw new Error(`${label}.capabilities[${index}].resources must be an array`);
        const resources = capabilityInput.resources.map((resource, resourceIndex) => {
            const resourceInput = projectionRecord(resource, `${label}.capabilities[${index}].resources[${resourceIndex}]`);
            projectionFields(resourceInput, ['resourceId', 'capacity', 'unit'], `${label}.capabilities[${index}].resources[${resourceIndex}]`);
            const unit = resourceInput.unit;
            if (unit !== 'slot' && unit !== 'context')
                throw new Error(`${label}.capabilities[${index}].resources[${resourceIndex}].unit is invalid`);
            const parsed = {
                resourceId: projectionText(resourceInput.resourceId, `${label}.capabilities[${index}].resources[${resourceIndex}].resourceId`),
                capacity: projectionPositiveInteger(resourceInput.capacity, `${label}.capabilities[${index}].resources[${resourceIndex}].capacity`),
                unit,
            };
            return parsed;
        });
        return {
            capabilityId: projectionText(capabilityInput.capabilityId, `${label}.capabilities[${index}].capabilityId`),
            version: projectionText(capabilityInput.version, `${label}.capabilities[${index}].version`),
            operations,
            resources,
        };
    });
    return {
        agentId,
        identity,
        role,
        presence,
        state,
        generation: projectionPositiveInteger(input.generation, `${label}.generation`),
        capabilities,
    };
}
export function parseLocalDaemonStatusProjection(value, label = 'local daemon status projection') {
    const input = projectionRecord(value, label);
    projectionFields(input, ['version', 'generation', 'startToken', 'daemons'], label);
    if (input.version !== 1)
        throw new Error(`${label}.version must be 1`);
    const daemonsInput = projectionRecord(input.daemons, `${label}.daemons`);
    const daemons = {};
    for (const [id, endpoint] of Object.entries(daemonsInput)) {
        daemons[id] = parseLocalDaemonEndpointProjection(endpoint, `${label}.daemons.${id}`);
    }
    return {
        version: 1,
        generation: (() => {
            if (!Number.isSafeInteger(input.generation) || input.generation < 0)
                throw new Error(`${label}.generation must be a non-negative safe integer`);
            return input.generation;
        })(),
        startToken: projectionText(input.startToken, `${label}.startToken`),
        daemons,
    };
}
export function localDaemonStatusProjectionPath(internalPath) {
    return resolve(dirname(internalPath), '.internal', 'daemon-status.json');
}
export async function writeLocalDaemonStatusProjection(internalPath, projection) {
    const path = localDaemonStatusProjectionPath(internalPath);
    await mkdir(dirname(path), { recursive: true, mode: 0o700 });
    const temporary = `${path}.${randomUUID()}.tmp`;
    await writeFile(temporary, `${JSON.stringify(projection, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
    try {
        await rename(temporary, path);
    }
    catch (error) {
        try {
            await rm(temporary, { force: true });
        }
        catch { /* preserve original failure */ }
        throw error;
    }
    return path;
}
export async function readLocalDaemonStatusProjection(internalPath) {
    const path = localDaemonStatusProjectionPath(internalPath);
    let text;
    try {
        text = await readFile(path, 'utf8');
    }
    catch (error) {
        if (error.code === 'ENOENT')
            return undefined;
        throw new Error(`local daemon status projection cannot be read: ${path}: ${error instanceof Error ? error.message : String(error)}`);
    }
    let parsed;
    try {
        parsed = JSON.parse(text);
    }
    catch (error) {
        throw new Error(`local daemon status projection is not valid JSON: ${path}: ${error instanceof Error ? error.message : String(error)}`);
    }
    return parseLocalDaemonStatusProjection(parsed);
}
function defaultEntry(name) {
    const runtimeDirectory = dirname(fileURLToPath(import.meta.url));
    const directory = name === 'relay-process' ? 'server' : 'runtime';
    return resolve(runtimeDirectory, `../${directory}/${name}.js`);
}
export function planLocalProcesses(config, options = {}) {
    const relayEntry = options.relayEntry ?? defaultEntry('relay-process');
    const agentEntry = options.agentEntry ?? defaultEntry('agent-process');
    const consoleEntry = options.consoleEntry ?? defaultEntry('console-process');
    const specs = [{ id: 'relay', kind: 'relay', entry: relayEntry, args: ['--config', config.relay.configPath] }];
    for (const daemon of config.daemons) {
        if (daemon.enabled)
            specs.push({ id: daemon.id, kind: 'agent', entry: agentEntry, args: ['--config', daemon.configPath] });
    }
    if (config.console?.enabled === true) {
        specs.push({ id: 'console', kind: 'console', entry: consoleEntry, args: ['--config', config.console.configPath] });
    }
    return specs;
}
async function readConsoleProjectionFile(path) {
    if (path === undefined)
        return undefined;
    let text;
    try {
        text = await readFile(path, 'utf8');
    }
    catch (cause) {
        if (cause.code === 'ENOENT')
            return undefined;
        throw cause;
    }
    const parsed = JSON.parse(text);
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
        throw new LocalConsoleLifecycleError('CONSOLE_STATUS_UNAVAILABLE', 'Console projection is not an object');
    }
    return parsed;
}
function consoleCredentialFromProjection(projection, env) {
    const auth = projection?.auth;
    const passwordEnv = typeof auth === 'object' && auth !== null && !Array.isArray(auth)
        ? auth.passwordEnv
        : undefined;
    if (typeof passwordEnv !== 'string' || passwordEnv.length === 0)
        return 'missing';
    const value = env[passwordEnv];
    return typeof value === 'string' && value.length > 0 ? 'configured' : 'missing';
}
async function ownsConsoleRuntime(config, internal) {
    const runtime = internal.consoleRuntime;
    const projectionPath = internal.console?.projectionPath ?? config.console?.configPath;
    if (runtime?.pid === undefined || runtime.entryPath === undefined || runtime.startToken === undefined || projectionPath === undefined)
        return false;
    if (!processAlive(runtime.pid))
        return false;
    const command = await processCommand(runtime.pid);
    return command !== undefined && processOwnsConfigCommand(command, projectionPath, runtime.entryPath, runtime.startToken);
}
async function consoleListenerAlive(url, timeoutMs = 250) {
    if (url === undefined)
        return false;
    let parsed;
    try {
        parsed = new URL(url);
    }
    catch {
        return false;
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:')
        return false;
    const port = parsed.port === '' ? (parsed.protocol === 'https:' ? 443 : 80) : Number(parsed.port);
    if (!Number.isSafeInteger(port) || port < 1 || port > 65_535)
        return false;
    return await new Promise(resolveProbe => {
        let settled = false;
        const socket = createConnection({ host: parsed.hostname, port });
        const timer = setTimeout(() => finish(false), timeoutMs);
        const finish = (value) => {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            socket.destroy();
            resolveProbe(value);
        };
        socket.once('connect', () => finish(true));
        socket.once('error', () => finish(false));
    });
}
/**
 * Read-only Console classification shared by the supervisor socket handler and
 * the public CLI status path. It never writes runtime facts and never invents
 * online availability from a stale durable record.
 */
export async function classifyLocalConsoleStatus(config, internal, env = process.env, fallback = {
    state: internal.launcher?.state ?? 'stopped',
    generation: internal.launcher?.generation ?? 0,
}) {
    const projection = internal.console?.config === undefined
        ? await readConsoleProjectionFile(config.console?.configPath)
        : parseLocalConsoleProjectionConfig(internal.console.config);
    const runtime = internal.consoleRuntime;
    const enabled = config.console?.enabled === true && projection?.enabled === true;
    const credential = consoleCredentialFromProjection(projection, env);
    // `disabled` means no child responsibility at all. A recorded non-terminal runtime still
    // holds the Console port, so it must be surfaced as its own state instead of disabled.
    const pendingChild = runtime !== undefined && runtime.state !== 'stopped' && runtime.state !== 'disabled';
    if (!enabled && !pendingChild) {
        return {
            enabled: false,
            state: 'disabled',
            generation: runtime?.generation ?? 0,
            launcherState: fallback.state,
            launcherGeneration: fallback.generation,
            credential,
        };
    }
    let state = runtime?.state ?? 'stopped';
    let error = runtime?.error;
    if ((state === 'online' || state === 'starting') && !(await ownsConsoleRuntime(config, internal))) {
        state = 'failed';
        error = { code: 'CONSOLE_PROCESS_EXITED', message: `Console pid=${runtime?.pid ?? 'missing'} is not owned by this launcher` };
    }
    else if (state === 'online' && !(await consoleListenerAlive(runtime?.url))) {
        state = 'failed';
        error = { code: 'CONSOLE_PROCESS_EXITED', message: `Console listener is not accepting connections at ${runtime?.url ?? 'the persisted URL'}` };
    }
    return {
        enabled,
        state,
        generation: runtime?.generation ?? 0,
        launcherState: fallback.state,
        launcherGeneration: fallback.generation,
        credential,
        ...(state === 'online' && runtime?.url !== undefined ? { url: runtime.url, origin: runtime.origin } : {}),
        ...(state === 'online' && runtime?.pid !== undefined ? { pid: runtime.pid } : {}),
        ...(state === 'starting' && runtime?.pid !== undefined ? { pid: runtime.pid } : {}),
        ...(runtime?.identityRef === undefined ? {} : { identityRef: runtime.identityRef }),
        ...(error === undefined ? {} : { error }),
    };
}
function timeout(value, fallback, label) {
    const result = value ?? fallback;
    if (!Number.isSafeInteger(result) || result < 1 || result > 2_147_483_647)
        throw new Error(`${label} must be a positive safe integer`);
    return result;
}
function waitForExit(child, deadlineMs) {
    if (child.exitCode !== null || child.signalCode !== null)
        return Promise.resolve();
    return new Promise((resolveExit, reject) => {
        const timer = setTimeout(() => finish(new Error('local daemon exit remains unconfirmed')), deadlineMs);
        const onExit = () => finish();
        const finish = (error) => {
            clearTimeout(timer);
            child.off('exit', onExit);
            if (error)
                reject(error);
            else
                resolveExit();
        };
        child.once('exit', onExit);
    });
}
async function waitForReady(child, kind, deadlineMs, requireEndpointProjection = false) {
    const output = { stdout: '', stderr: '' };
    return await new Promise((resolveReady, reject) => {
        let timer;
        let registrationFallback;
        let endpoint;
        let registration;
        const finish = (error, value) => {
            if (timer !== undefined)
                clearTimeout(timer);
            if (registrationFallback !== undefined)
                clearTimeout(registrationFallback);
            child.off('error', onError);
            child.off('exit', onExit);
            child.off('message', onMessage);
            child.stdout?.off('data', onStdout);
            child.stderr?.off('data', onStderr);
            if (error)
                reject(error);
            else
                resolveReady(value);
        };
        const onError = (error) => finish(error);
        const onExit = (code, signal) => {
            // A legacy Agent may exit in the same turn as its registration frame.
            // Preserve that frame as readiness so the supervisor's existing
            // post-readiness liveness check reports the precise immediate-exit error.
            if (kind === 'agent' && registration !== undefined && (!requireEndpointProjection || endpoint !== undefined))
                finish(undefined, { ...registration, ...(endpoint === undefined ? {} : { endpoint }) });
            else if (kind === 'agent' && registration !== undefined && requireEndpointProjection)
                finish(new Error('local agent exited after registration without status projection'));
            else
                finish(new Error(`local ${kind} exited before readiness code=${code ?? 'null'} signal=${signal ?? 'null'} stderr=${output.stderr}`));
        };
        const onStdout = (chunk) => {
            output.stdout += chunk.toString();
            if (kind === 'relay' && output.stdout.includes('relay listening '))
                finish();
        };
        const onStderr = (chunk) => { output.stderr += chunk.toString(); };
        const onMessage = (message) => {
            if (typeof message !== 'object' || message === null)
                return;
            const control = message;
            if (kind === 'console') {
                if (control.kind === 'console.listening')
                    finish(undefined, control);
                return;
            }
            if (kind !== 'agent')
                return;
            // The registration frame remains the established readiness signal. The
            // status projection follows on the same IPC queue when supported.
            if (control.kind === 'daemon.status') {
                endpoint = control.endpoint;
                if (registration !== undefined)
                    finish(undefined, { ...registration, endpoint });
                return;
            }
            if (control.kind === 'daemon.registered') {
                registration = control;
                if (endpoint !== undefined)
                    finish(undefined, { ...registration, endpoint });
                else if (!requireEndpointProjection)
                    registrationFallback = setTimeout(() => finish(undefined, registration), 25);
            }
        };
        child.once('error', onError);
        child.once('exit', onExit);
        child.stdout?.on('data', onStdout);
        child.stderr?.on('data', onStderr);
        if (kind === 'agent' || kind === 'console')
            child.on('message', onMessage);
        timer = setTimeout(() => finish(new Error(`local ${kind} startup deadline stderr=${output.stderr}`)), deadlineMs);
    });
}
export function createLocalSupervisor(config, options = {}) {
    const nodeExecutable = options.nodeExecutable ?? process.execPath;
    const startupTimeoutMs = timeout(options.startupTimeoutMs, 10_000, 'startupTimeoutMs');
    const stopTimeoutMs = timeout(options.stopTimeoutMs, 5_000, 'stopTimeoutMs');
    const spawnProcess = options.spawn ?? nodeSpawn;
    const specs = planLocalProcesses(config, options);
    const children = new Map();
    const states = new Map();
    const endpoints = new Map();
    const unwatch = new Map();
    const receivers = Object.fromEntries(config.daemons
        .filter(daemon => daemon.enabled && (daemon.role === 'receiver' || daemon.role === 'hybrid') && daemon.connection !== undefined)
        .map(daemon => [daemon.id, true]));
    const socketPath = config.internalPath === undefined ? undefined : localWorkControlSocketPath(config.internalPath);
    const pendingWork = new Map();
    let workControl;
    let lifecycle = 'stopped';
    let lastFailure;
    // Set for the whole of one teardown. The teardown loop owns the diagnosis of
    // every child it stops, so a child exit observed during teardown must never
    // overwrite lastFailure. Reading lifecycle alone is not enough: the loop marks
    // the launcher failed as soon as one child cannot confirm its exit, so later
    // child exits would otherwise replace the real cleanup failure with a
    // misleading "exited unexpectedly" message.
    // Boundary: a failed teardown keeps its children in `children` and leaves
    // lifecycle 'failed', so a child that dies after the flag clears (rather than
    // during teardown) still gets no new attribution. That window is already
    // marked failed and the child is reaped by the teardown that failed it.
    let tearingDown = false;
    let lifecycleGeneration = 0;
    let starting;
    let stopping;
    const startToken = options.startToken ?? randomUUID();
    let reservedLauncherGeneration;
    let activeChildEnv = { ...process.env, ...options.env };
    let consoleLifecycle = Promise.resolve({
        enabled: config.console?.enabled === true,
        state: config.console?.enabled === true ? 'stopped' : 'disabled',
        generation: 0,
        launcherState: 'stopped',
        launcherGeneration: 0,
        credential: 'missing',
    });
    const readConsoleProjection = () => readConsoleProjectionFile(config.console?.configPath);
    const consoleCredentialState = (projection) => consoleCredentialFromProjection(projection, activeChildEnv);
    async function consoleAssetsAvailable(projection) {
        for (const key of ['staticRoot', 'uiRoot']) {
            const value = projection[key];
            if (typeof value !== 'string' || value.length === 0)
                return false;
            try {
                await access(value);
            }
            catch {
                return false;
            }
        }
        return true;
    }
    async function patchConsole(patch) {
        if (config.internalPath === undefined)
            return;
        await writeLocalInternalConsoleRuntime(config.internalPath, patch);
    }
    function consoleErrorCode(cause) {
        const message = cause instanceof Error ? cause.message : String(cause);
        for (const code of ['CONSOLE_DISABLED', 'CONSOLE_CREDENTIAL_MISSING', 'CONSOLE_PORT_OCCUPIED', 'CONSOLE_ASSET_MISSING', 'CONSOLE_RETAINED']) {
            if (message.includes(code))
                return code;
        }
        const errno = cause?.code;
        if (errno === 'EADDRINUSE')
            return 'CONSOLE_PORT_OCCUPIED';
        if (message.includes('EADDRINUSE'))
            return 'CONSOLE_PORT_OCCUPIED';
        return 'CONSOLE_START_FAILED';
    }
    async function consoleStatusRead() {
        const internal = config.internalPath === undefined ? undefined : await readLocalInternalConfig(config.internalPath);
        if (internal === undefined) {
            const projection = await readConsoleProjection();
            const enabled = config.console?.enabled === true && projection?.enabled === true;
            return {
                enabled,
                state: enabled ? 'stopped' : 'disabled',
                generation: 0,
                launcherState: lifecycle,
                launcherGeneration: lifecycleGeneration,
                credential: consoleCredentialState(projection),
            };
        }
        return await classifyLocalConsoleStatus(config, internal, activeChildEnv, {
            state: internal.launcher?.state ?? lifecycle,
            generation: internal.launcher?.generation ?? lifecycleGeneration,
        });
    }
    const statusFromRuntime = async () => {
        const internal = config.internalPath === undefined ? undefined : await readLocalInternalConfig(config.internalPath);
        const fallback = { state: lifecycle, generation: lifecycleGeneration };
        if (internal === undefined) {
            return {
                enabled: config.console?.enabled === true,
                state: config.console?.enabled === true ? 'stopped' : 'disabled',
                generation: 0,
                launcherState: lifecycle,
                launcherGeneration: lifecycleGeneration,
                credential: consoleCredentialState(await readConsoleProjection()),
            };
        }
        const classified = await classifyLocalConsoleStatus(config, internal, activeChildEnv, fallback);
        if (classified.state === 'online' || classified.state === 'starting') {
            const child = children.get('console');
            if (child === undefined || child.exitCode !== null || child.signalCode !== null) {
                return classifyLocalConsoleStatus(config, {
                    ...internal,
                    consoleRuntime: internal.consoleRuntime === undefined
                        ? undefined
                        : { ...internal.consoleRuntime, state: 'failed', error: { code: 'CONSOLE_PROCESS_EXITED', message: 'Console child is not running' } },
                }, activeChildEnv, fallback);
            }
        }
        return classified;
    };
    async function startConsoleChild() {
        const projection = await readConsoleProjection();
        if (config.console?.enabled !== true || projection?.enabled !== true) {
            // CONSOLE_DISABLED is a rejection with zero child, zero port and zero
            // [consoleRuntime] write, so a disabled Console never gains a runtime row.
            throw new LocalConsoleLifecycleError('CONSOLE_DISABLED', 'Console is disabled; set [console].enabled=true in config.toml');
        }
        if (consoleCredentialState(projection) !== 'configured') {
            await patchConsole({ enabled: true, state: 'failed', pid: null, startToken: null, error: { code: 'CONSOLE_CREDENTIAL_MISSING', message: 'Console password environment variable is not configured' } });
            throw new LocalConsoleLifecycleError('CONSOLE_CREDENTIAL_MISSING', 'Console password environment variable is not configured');
        }
        if (!(await consoleAssetsAvailable(projection))) {
            await patchConsole({ enabled: true, state: 'failed', pid: null, startToken: null, error: { code: 'CONSOLE_ASSET_MISSING', message: 'Console static or UI asset root is missing' } });
            throw new LocalConsoleLifecycleError('CONSOLE_ASSET_MISSING', 'Console static or UI asset root is missing');
        }
        const spec = specs.find(candidate => candidate.kind === 'console');
        if (spec === undefined || config.internalPath === undefined) {
            throw new LocalConsoleLifecycleError('CONSOLE_STATUS_UNAVAILABLE', 'Console child plan is not available');
        }
        const internal = await readLocalInternalConfig(config.internalPath);
        const generation = (internal.consoleRuntime?.generation ?? 0) + 1;
        const childStartToken = randomUUID();
        const child = spawnProcess(nodeExecutable, [...(options.nodeArguments ?? []), spec.entry, ...spec.args, '--launcher-start-token', childStartToken], {
            env: activeChildEnv,
            stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
        });
        children.set('console', child);
        if (child.pid === undefined) {
            children.delete('console');
            await patchConsole({ enabled: true, state: 'failed', pid: null, startToken: null, error: { code: 'CONSOLE_START_FAILED', message: 'Console child did not return a pid' } });
            throw new LocalConsoleLifecycleError('CONSOLE_START_FAILED', 'Console child did not return a pid');
        }
        try {
            await patchConsole({ enabled: true, pid: child.pid, generation, startToken: childStartToken, entryPath: spec.entry, state: 'starting' });
            const ready = await waitForReady(child, 'console', startupTimeoutMs);
            const url = typeof ready?.url === 'string' ? ready.url : undefined;
            if (url === undefined)
                throw new LocalConsoleLifecycleError('CONSOLE_START_FAILED', 'Console readiness did not publish its bound URL');
            const parsed = new URL(url);
            await patchConsole({
                enabled: true,
                pid: child.pid,
                generation,
                startToken: childStartToken,
                state: 'online',
                url,
                origin: parsed.origin,
                identityRef: 'console:local',
                error: null,
            });
            const onExit = (code, signal) => {
                if (children.get('console') !== child)
                    return;
                children.delete('console');
                unwatch.delete('console');
                if (lifecycle === 'stopping' || lifecycle === 'stopped')
                    return;
                void patchConsole({
                    state: 'failed',
                    pid: null,
                    startToken: null,
                    error: { code: 'CONSOLE_PROCESS_EXITED', message: `Console exited unexpectedly code=${code ?? 'null'} signal=${signal ?? 'null'}` },
                }).catch(() => undefined);
            };
            const onError = (cause) => {
                if (children.get('console') !== child)
                    return;
                children.delete('console');
                unwatch.delete('console');
                if (lifecycle === 'stopping' || lifecycle === 'stopped')
                    return;
                void patchConsole({
                    state: 'failed',
                    pid: null,
                    startToken: null,
                    error: { code: 'CONSOLE_PROCESS_EXITED', message: cause.message },
                }).catch(() => undefined);
            };
            child.once('exit', onExit);
            child.once('error', onError);
            unwatch.set('console', () => { child.off('exit', onExit); child.off('error', onError); });
            return await statusFromRuntime();
        }
        catch (cause) {
            let cleaned = true;
            if (child.exitCode === null && child.signalCode === null) {
                child.kill('SIGTERM');
                try {
                    await waitForExit(child, stopTimeoutMs);
                }
                catch {
                    cleaned = false;
                }
            }
            const code = consoleErrorCode(cause);
            const message = cause instanceof Error ? cause.message : String(cause);
            if (cleaned) {
                unwatch.get('console')?.();
                unwatch.delete('console');
                children.delete('console');
                await patchConsole({ enabled: true, state: 'failed', pid: null, startToken: null, error: { code, message } });
            }
            else {
                const unwatchChild = () => { child.off('exit', onExit); child.off('error', onError); };
                const onExit = (code, signal) => {
                    if (children.get('console') !== child)
                        return;
                    unwatch.get('console')?.();
                    unwatch.delete('console');
                    children.delete('console');
                    void patchConsole({
                        enabled: true,
                        state: 'failed',
                        pid: null,
                        startToken: null,
                        error: { code: 'CONSOLE_PROCESS_EXITED', message: `Console exited unexpectedly code=${code ?? 'null'} signal=${signal ?? 'null'}` },
                    }).catch(() => undefined);
                };
                const onError = (cause) => {
                    if (children.get('console') !== child)
                        return;
                    unwatch.get('console')?.();
                    unwatch.delete('console');
                    children.delete('console');
                    void patchConsole({
                        enabled: true,
                        state: 'failed',
                        pid: null,
                        startToken: null,
                        error: { code: 'CONSOLE_PROCESS_EXITED', message: cause.message },
                    }).catch(() => undefined);
                };
                children.set('console', child);
                child.once('exit', onExit);
                child.once('error', onError);
                unwatch.set('console', unwatchChild);
                await patchConsole({ enabled: true, pid: child.pid, generation, startToken: childStartToken, entryPath: spec.entry, state: 'retained', error: { code: 'CONSOLE_RETAINED', message } });
            }
            throw new LocalConsoleLifecycleError(code, message);
        }
    }
    async function stopConsoleChild(expectedConsoleGeneration) {
        const status = await consoleStatusRead();
        // A recorded child outlives the `[console]` flag, so only a truly disabled status
        // returns here; any other state still has responsibility to reclaim.
        if (!status.enabled && status.state === 'disabled')
            return status;
        if (expectedConsoleGeneration !== undefined && expectedConsoleGeneration !== status.generation) {
            throw new LocalConsoleLifecycleError('STALE_GENERATION', `stale Console generation expected=${expectedConsoleGeneration} current=${status.generation}`);
        }
        const child = children.get('console');
        if (child === undefined || child.exitCode !== null || child.signalCode !== null) {
            if (status.state === 'stopped' || status.state === 'disabled')
                return status;
            // A failed record means the child already exited and cleared its pid; it
            // is honest terminal truth, not an unconfirmed retained child.
            if (status.state === 'failed')
                return status;
            const message = `Console state=${status.state} has no owned live child; termination is unconfirmed`;
            await patchConsole({ enabled: true, state: 'retained', error: { code: 'CONSOLE_RETAINED', message } });
            throw new LocalConsoleLifecycleError('CONSOLE_RETAINED', message);
        }
        await patchConsole({ enabled: true, state: 'stopping' });
        child.kill('SIGTERM');
        try {
            await waitForExit(child, stopTimeoutMs);
        }
        catch (cause) {
            const message = cause instanceof Error ? cause.message : String(cause);
            await patchConsole({ enabled: true, state: 'retained', error: { code: 'CONSOLE_RETAINED', message } });
            throw new LocalConsoleLifecycleError('CONSOLE_RETAINED', message);
        }
        unwatch.get('console')?.();
        unwatch.delete('console');
        children.delete('console');
        await patchConsole({ enabled: true, state: 'stopped', pid: null, startToken: null, url: null, origin: null, error: null });
        return await statusFromRuntime();
    }
    async function shutdownConsole() {
        const child = children.get('console');
        if (child === undefined) {
            if (config.internalPath !== undefined) {
                try {
                    const internal = await readLocalInternalConfig(config.internalPath);
                    if (internal.consoleRuntime?.state === 'online' || internal.consoleRuntime?.state === 'starting') {
                        if (await ownsConsoleRuntime(config, internal)) {
                            const pid = internal.consoleRuntime.pid;
                            if (pid !== undefined) {
                                process.kill(pid, 'SIGTERM');
                                const deadline = Date.now() + stopTimeoutMs;
                                while (Date.now() < deadline && processAlive(pid))
                                    await new Promise(resolveDelay => setTimeout(resolveDelay, 25));
                                if (processAlive(pid))
                                    throw new LocalConsoleLifecycleError('CONSOLE_RETAINED', `owned Console pid=${pid} did not exit after SIGTERM`);
                            }
                            await patchConsole({ enabled: true, state: 'stopped', pid: null, startToken: null, url: null, origin: null, error: null });
                        }
                        else {
                            throw new LocalConsoleLifecycleError('CONSOLE_RETAINED', 'persisted Console child cannot be validated for shutdown');
                        }
                    }
                }
                catch (cause) {
                    const message = cause instanceof Error ? cause.message : String(cause);
                    try {
                        await patchConsole({ enabled: true, state: 'retained', error: { code: 'CONSOLE_RETAINED', message } });
                    }
                    catch { /* preserve the original retained reason */ }
                    throw new LocalConsoleLifecycleError('CONSOLE_RETAINED', message);
                }
            }
            return;
        }
        try {
            await patchConsole({ enabled: true, state: 'stopping' });
        }
        catch { /* preserve the child cleanup result */ }
        child.kill('SIGTERM');
        try {
            await waitForExit(child, stopTimeoutMs);
            unwatch.get('console')?.();
            unwatch.delete('console');
            children.delete('console');
            await patchConsole({ enabled: true, state: 'stopped', pid: null, startToken: null, url: null, origin: null, error: null });
        }
        catch (cause) {
            const message = cause instanceof Error ? cause.message : String(cause);
            try {
                await patchConsole({ enabled: true, state: 'retained', error: { code: 'CONSOLE_RETAINED', message } });
            }
            catch { /* retained responsibility stays explicit in the report */ }
            throw new LocalConsoleLifecycleError('CONSOLE_RETAINED', message);
        }
    }
    const consoleStart = (expectedConsoleGeneration) => {
        if (lifecycle !== 'running')
            return Promise.reject(new LocalConsoleLifecycleError('NOT_RUNNING', 'launcher is not running'));
        const operation = consoleLifecycle.then(async () => {
            if (lifecycle !== 'running')
                throw new LocalConsoleLifecycleError('NOT_RUNNING', 'launcher is not running');
            const status = await consoleStatusRead();
            if (!status.enabled) {
                // CONSOLE_DISABLED is a rejection with zero child, zero port and zero
                // [consoleRuntime] write, so a disabled Console never gains a runtime row.
                throw new LocalConsoleLifecycleError('CONSOLE_DISABLED', 'Console is disabled; set [console].enabled=true in config.toml');
            }
            if (expectedConsoleGeneration !== undefined && expectedConsoleGeneration !== status.generation) {
                throw new LocalConsoleLifecycleError('STALE_GENERATION', `stale Console generation expected=${expectedConsoleGeneration} current=${status.generation}`);
            }
            const child = children.get('console');
            const ownedLiveChild = child !== undefined && child.exitCode === null && child.signalCode === null;
            if (ownedLiveChild) {
                if (status.state === 'online')
                    return status;
                // A Console child this launcher still owns may never be replaced. Spawning
                // a second child would overwrite the persisted identity and leave the first
                // one holding the reused Console port with no owner left to stop it.
                throw new LocalConsoleLifecycleError('CONSOLE_RETAINED', `Console child ${child.pid} is still owned by this launcher in state ${status.state}`);
            }
            return await startConsoleChild();
        });
        consoleLifecycle = operation.catch(() => statusFromRuntime());
        return operation;
    };
    const consoleStop = (expectedConsoleGeneration) => {
        const operation = consoleLifecycle.then(async () => await stopConsoleChild(expectedConsoleGeneration));
        consoleLifecycle = operation.catch(() => statusFromRuntime());
        return operation;
    };
    const forwardWork = async (input) => {
        const receiverId = input.frame.control.receiverAgentId;
        const child = children.get(receiverId);
        if (child === undefined || child.exitCode !== null || child.signalCode !== null) {
            return { code: 'RECEIVER_NOT_FOUND', message: `Work receiver ${receiverId} is not available` };
        }
        const endpoint = endpoints.get(receiverId);
        if (endpoint === undefined)
            return { code: 'RECEIVER_NOT_FOUND', message: `Work receiver ${receiverId} has no live status projection` };
        const localCorrelation = randomUUID();
        const request = {
            kind: 'work.control',
            localCorrelation,
            receiverAgentId: receiverId,
            expectedLauncherGeneration: lifecycleGeneration,
            expectedAgentGeneration: endpoint.generation,
            frame: input.frame,
        };
        let reply;
        try {
            reply = await new Promise((resolveReply, rejectReply) => {
                const timer = setTimeout(() => { pendingWork.delete(localCorrelation); rejectReply(new Error('receiver did not answer the local Work request')); }, 120_000);
                pendingWork.set(localCorrelation, value => { clearTimeout(timer); resolveReply(value); });
                if (typeof child.send !== 'function') {
                    clearTimeout(timer);
                    pendingWork.delete(localCorrelation);
                    rejectReply(new Error('receiver child has no IPC channel'));
                    return;
                }
                child.send(request, error => {
                    if (error === null || error === undefined)
                        return;
                    clearTimeout(timer);
                    pendingWork.delete(localCorrelation);
                    rejectReply(error);
                });
            });
        }
        catch (cause) {
            return { code: 'LOCAL_CONTROL_UNAVAILABLE', message: cause instanceof Error ? cause.message : 'local Work forwarding failed' };
        }
        return reply.kind === 'work.result' ? reply.receipt : reply.error;
    };
    const stop = () => {
        if (stopping)
            return stopping;
        let operation;
        operation = (async () => {
            const hadFailure = lifecycle === 'failed' || lastFailure !== undefined;
            lifecycle = 'stopping';
            tearingDown = true;
            const failures = [];
            // Stop must not depend on a receiver reply. Closing the listener stops new
            // admissions synchronously, but its drain also waits for every accepted
            // handler, and an accepted handler waits for the receiver child reply up
            // to the forwarding timeout. Release the in-flight forwards first, so a
            // hung or exited receiver cannot hold stop and child cleanup open.
            const closingControl = workControl?.close();
            for (const resolvePending of pendingWork.values())
                resolvePending({ kind: 'work.error', requestId: 'unknown', error: { code: 'LOCAL_CONTROL_UNAVAILABLE', message: 'local Work listener is stopping' } });
            pendingWork.clear();
            try {
                await closingControl;
            }
            catch (error) {
                failures.push(error);
            }
            workControl = undefined;
            // The single Console lifecycle owner must settle before launcher cleanup.
            // Otherwise a Console start that is already queued could spawn a child
            // after shutdownConsole observed no child and orphaned it.
            await consoleLifecycle.catch(() => undefined);
            await shutdownConsole().catch(error => { failures.push(error); lastFailure = error instanceof Error ? error : new Error('Console cleanup remains unconfirmed'); });
            if (config.internalPath !== undefined) {
                try {
                    await writeLocalInternalWorkControl(config.internalPath, undefined);
                }
                catch (error) {
                    failures.push(error);
                }
            }
            for (const spec of [...specs].reverse()) {
                if (spec.kind === 'console')
                    continue;
                const child = children.get(spec.id);
                if (!child)
                    continue;
                try {
                    if (child.exitCode === null && child.signalCode === null)
                        child.kill('SIGTERM');
                    await waitForExit(child, stopTimeoutMs);
                    unwatch.get(spec.id)?.();
                    unwatch.delete(spec.id);
                }
                catch (error) {
                    failures.push(error);
                    lastFailure = error instanceof Error ? error : new Error('local daemon cleanup remains unconfirmed');
                    lifecycle = 'failed';
                }
            }
            if (config.internalPath !== undefined) {
                let failed = hadFailure || lifecycle === 'failed' || failures.length > 0;
                const persisted = Object.fromEntries([...states.entries()].map(([id, state]) => [id, { ...state, state: failed ? 'failed' : 'stopped' }]));
                // Daemon terminal records and the launcher terminal record share one
                // transactional write. A partial publication could otherwise leave a
                // durable successful launcher state behind a failed daemon set.
                let terminalWriteSucceeded = true;
                try {
                    await writeLocalInternalRecoveryState(config.internalPath, persisted, {
                        pid: process.pid,
                        generation: lifecycleGeneration,
                        startToken,
                        state: failed ? 'failed' : 'stopped',
                        ...(failed && lastFailure !== undefined ? { error: lastFailure.message } : {}),
                    });
                }
                catch (error) {
                    terminalWriteSucceeded = false;
                    failures.push(error);
                }
                if (failures.length > 0)
                    lastFailure = new AggregateError(failures, 'local daemon cleanup remains unconfirmed');
                try {
                    await writeLocalDaemonStatusProjection(config.internalPath, {
                        version: 1,
                        generation: lifecycleGeneration,
                        startToken,
                        daemons: Object.fromEntries([...endpoints.entries()].map(([id, endpoint]) => [id, {
                                ...endpoint,
                                presence: failed ? 'unknown' : 'offline',
                                state: failed ? 'failed' : 'stopped',
                            }])),
                    });
                }
                catch (error) {
                    terminalWriteSucceeded = false;
                    failures.push(error);
                    lastFailure = new AggregateError(failures, 'local daemon cleanup remains unconfirmed');
                }
                if (!terminalWriteSucceeded) {
                    // The terminal publication is unconfirmed, so the durable launcher
                    // state must not keep claiming a clean stop.
                    const forced = lastFailure ?? new AggregateError(failures, 'local daemon cleanup remains unconfirmed');
                    lastFailure = forced;
                    try {
                        await writeLocalInternalRecoveryState(config.internalPath, persisted, {
                            pid: process.pid,
                            generation: lifecycleGeneration,
                            startToken,
                            state: 'failed',
                            error: forced.message,
                        });
                    }
                    catch { /* The unconfirmed terminal publication stays the public failure. */ }
                }
            }
            if (failures.length > 0)
                throw lastFailure instanceof Error ? lastFailure : new AggregateError(failures, 'local daemon cleanup remains unconfirmed');
            children.clear();
            states.clear();
            lifecycle = 'stopped';
            lastFailure = undefined;
        })();
        let completion;
        completion = operation.catch(error => {
            if (lifecycle === 'stopping')
                lifecycle = lastFailure ? 'failed' : 'running';
            throw error;
        }).finally(() => {
            tearingDown = false;
            if (stopping === completion)
                stopping = undefined;
        });
        stopping = completion;
        return completion;
    };
    const start = () => {
        if (stopping)
            return Promise.reject(new Error('local daemon cannot start while cleanup is in progress'));
        if (lifecycle === 'failed')
            return Promise.reject(lastFailure ?? new Error('local daemon requires cleanup before restart'));
        if (lifecycle === 'running')
            return Promise.resolve();
        if (starting)
            return starting;
        starting = (async () => {
            lifecycle = 'starting';
            endpoints.clear();
            try {
                if (config.internalPath !== undefined)
                    await projectLocalChildConfigs(config.internalPath);
                if (config.internalPath !== undefined) {
                    const internal = await readLocalInternalConfig(config.internalPath);
                    if (internal.launcher?.state === 'starting' && internal.launcher.startToken === startToken && internal.launcher.generation !== undefined) {
                        reservedLauncherGeneration = internal.launcher.generation;
                        lifecycleGeneration = reservedLauncherGeneration;
                    }
                }
                const launcherGeneration = options.launcherGeneration ?? reservedLauncherGeneration;
                const childEnv = { ...process.env, ...options.env };
                if (config.internalPath !== undefined && launcherGeneration !== undefined) {
                    childEnv.TEAMS_LOCAL_CONFIG_PATH = config.configPath;
                    childEnv.TEAMS_LOCAL_INTERNAL_PATH = config.internalPath;
                    childEnv.TEAMS_LOCAL_LAUNCHER_GENERATION = String(launcherGeneration);
                }
                else {
                    delete childEnv.TEAMS_LOCAL_CONFIG_PATH;
                    delete childEnv.TEAMS_LOCAL_INTERNAL_PATH;
                    delete childEnv.TEAMS_LOCAL_LAUNCHER_GENERATION;
                }
                childEnv.TEAMS_LOCAL_START_TOKEN = startToken;
                activeChildEnv = childEnv;
                for (const spec of specs) {
                    if (spec.kind === 'console')
                        continue;
                    if (lifecycle !== 'starting') {
                        if (lifecycle === 'failed')
                            throw lastFailure ?? new Error('local daemon failed during startup');
                        throw new Error('local daemon startup was cancelled');
                    }
                    const child = spawnProcess(nodeExecutable, [...(options.nodeArguments ?? []), spec.entry, ...spec.args, '--launcher-start-token', startToken], { env: childEnv, stdio: ['ignore', 'pipe', 'pipe', 'ipc'] });
                    children.set(spec.id, child);
                    // daemon.generation is the launcher ownership generation used by the
                    // stale-writer guard. Child network generation is owned by the child
                    // readiness message and is not persisted into internal.toml.
                    states.set(spec.id, { pid: child.pid ?? 0, entryPath: spec.entry, startToken, state: 'online', ...(launcherGeneration === undefined ? {} : { generation: launcherGeneration }) });
                    if (config.internalPath !== undefined) {
                        await writeLocalInternalState(config.internalPath, { [spec.id]: { pid: child.pid ?? 0, entryPath: spec.entry, startToken, state: 'online', ...(launcherGeneration === undefined ? {} : { generation: launcherGeneration }) } });
                    }
                    const onExit = (code, signal) => {
                        if (tearingDown || lifecycle === 'stopping' || lifecycle === 'stopped')
                            return;
                        lastFailure = new Error(`local ${spec.kind} exited unexpectedly code=${code ?? 'null'} signal=${signal ?? 'null'}`);
                        lifecycle = 'failed';
                    };
                    const onError = (error) => {
                        if (tearingDown || lifecycle === 'stopping' || lifecycle === 'stopped')
                            return;
                        lastFailure = error;
                        lifecycle = 'failed';
                    };
                    child.once('exit', onExit);
                    child.once('error', onError);
                    unwatch.set(spec.id, () => { child.off('exit', onExit); child.off('error', onError); });
                    const ready = await waitForReady(child, spec.kind, startupTimeoutMs, config.internalPath !== undefined);
                    if (spec.kind === 'agent') {
                        if (config.internalPath !== undefined && ready?.endpoint === undefined) {
                            throw new Error(`local agent ${spec.id} readiness did not provide status projection`);
                        }
                        if (ready?.endpoint !== undefined) {
                            const endpoint = parseLocalDaemonEndpointProjection(ready.endpoint, `local agent ${spec.id} status`);
                            if (ready.agentId !== endpoint.agentId)
                                throw new Error(`local agent ${spec.id} registration identity does not match its status projection`);
                            if (ready.generation !== endpoint.generation)
                                throw new Error(`local agent ${spec.id} registration generation does not match its status projection`);
                            endpoints.set(spec.id, endpoint);
                        }
                        states.set(spec.id, { pid: child.pid ?? 0, entryPath: spec.entry, startToken, state: 'online', ...(launcherGeneration === undefined ? {} : { generation: launcherGeneration }) });
                        child.on('message', (message) => {
                            if (typeof message !== 'object' || message === null)
                                return;
                            const reply = message;
                            if (reply.kind !== 'work.reply' || typeof reply.localCorrelation !== 'string')
                                return;
                            const resolvePending = pendingWork.get(reply.localCorrelation);
                            if (resolvePending === undefined)
                                return;
                            pendingWork.delete(reply.localCorrelation);
                            resolvePending(reply.reply);
                        });
                    }
                    else
                        states.set(spec.id, { pid: child.pid ?? 0, entryPath: spec.entry, startToken, state: 'online', ...(launcherGeneration === undefined ? {} : { generation: launcherGeneration }) });
                    if (lifecycle !== 'starting')
                        throw lastFailure ?? new Error(`local ${spec.kind} failed during startup`);
                    if (child.exitCode !== null || child.signalCode !== null) {
                        throw new Error(`local ${spec.kind} exited immediately after readiness code=${child.exitCode ?? 'null'} signal=${child.signalCode ?? 'null'}`);
                    }
                }
                // A readiness IPC frame is not proof that the child stayed alive. Keep the
                // startup gate open for one bounded stability window so an immediate post-ready
                // exit is reported before the supervisor claims running.
                await new Promise(resolveReady => { setTimeout(resolveReady, 75); });
                if (lifecycle !== 'starting')
                    throw lastFailure ?? new Error('local daemon failed during startup');
                for (const child of children.values()) {
                    if (child.exitCode !== null || child.signalCode !== null)
                        throw new Error('local daemon exited during startup');
                }
                if (config.console?.enabled === true) {
                    try {
                        await startConsoleChild();
                    }
                    catch { /* Console is optional; its typed failure is durable and never fails daemon collaboration. */ }
                }
                if (config.internalPath !== undefined) {
                    const internal = await readLocalInternalConfig(config.internalPath);
                    const expectedReservation = options.launcherGeneration ?? reservedLauncherGeneration;
                    if (expectedReservation !== undefined) {
                        if (internal.launcher?.state !== 'starting' || internal.launcher.startToken !== startToken || internal.launcher.generation !== expectedReservation) {
                            throw new Error(`local supervisor start reservation was cancelled generation=${expectedReservation}`);
                        }
                        lifecycleGeneration = expectedReservation;
                    }
                    else if (internal.launcher?.state === 'starting' && (internal.launcher.pid === 0 || internal.launcher.pid === process.pid)) {
                        if (internal.launcher.startToken !== startToken)
                            throw new Error('local supervisor start token does not match launcher reservation');
                        lifecycleGeneration = internal.launcher.generation;
                    }
                    else
                        lifecycleGeneration += 1;
                }
                else
                    lifecycleGeneration += 1;
                // Open the local Work control socket and publish its exact refs before the
                // launcher advertises running; admission stays closed until listen succeeds.
                if (socketPath !== undefined && config.internalPath !== undefined) {
                    try {
                        const stale = await lstat(socketPath);
                        if (stale.isSocket())
                            await rm(socketPath, { force: true });
                    }
                    catch (cause) {
                        if (cause.code !== 'ENOENT')
                            throw cause;
                    }
                    workControl = await startLocalWorkControlListener({
                        socketPath,
                        launcherGeneration: lifecycleGeneration,
                        startToken,
                        receivers,
                        handler: async (input) => {
                            const result = await forwardWork(input);
                            await input.respond(result);
                            return result;
                        },
                        consoleHandler: async (input) => {
                            try {
                                const status = input.frame.kind === 'console.start'
                                    ? await consoleStart(input.frame.expectedConsoleGeneration)
                                    : input.frame.kind === 'console.stop'
                                        ? await consoleStop(input.frame.expectedConsoleGeneration)
                                        : await consoleStatusRead();
                                await input.respond({ kind: 'console.result', correlationId: input.frame.correlationId, ok: true, status });
                            }
                            catch (error) {
                                const code = error instanceof LocalConsoleLifecycleError ? error.code : 'CONSOLE_STATUS_UNAVAILABLE';
                                await input.respond({
                                    kind: 'console.result',
                                    correlationId: input.frame.correlationId,
                                    ok: false,
                                    error: { code, message: error instanceof Error ? error.message : String(error) },
                                });
                            }
                        },
                    });
                    await writeLocalInternalWorkControl(config.internalPath, {
                        socketPath,
                        launcherGeneration: lifecycleGeneration,
                        launcherStartToken: startToken,
                    });
                }
                if (config.internalPath !== undefined) {
                    await writeLocalInternalState(config.internalPath, Object.fromEntries(states.entries()));
                    await writeLocalLauncherOwnership(config.internalPath, { version: 1, pid: process.pid, startToken });
                    await writeLocalDaemonStatusProjection(config.internalPath, {
                        version: 1,
                        generation: lifecycleGeneration,
                        startToken,
                        daemons: Object.fromEntries([...endpoints.entries()].map(([id, endpoint]) => [id, {
                                ...endpoint,
                                presence: 'online',
                                state: 'online',
                            }])),
                    });
                    await writeLocalInternalLauncherState(config.internalPath, { pid: process.pid, generation: lifecycleGeneration, startToken, state: 'running' });
                }
                lifecycle = 'running';
            }
            catch (error) {
                lastFailure = error instanceof Error ? error : new Error(String(error));
                lifecycle = 'failed';
                try {
                    await stop();
                }
                catch (cleanupError) {
                    throw new AggregateError([error, cleanupError], 'local daemon startup and cleanup failed');
                }
                throw error;
            }
            finally {
                starting = undefined;
            }
        })();
        return starting;
    };
    return {
        state: () => lifecycle,
        failure: () => lastFailure,
        processes: () => specs,
        generation: () => lifecycleGeneration,
        start,
        stop,
        consoleStatus: consoleStatusRead,
        consoleStart,
        consoleStop,
    };
}
