import type { PluginInput, Hooks } from '@opencode-ai/plugin';
import type { Session } from '@opencode-ai/sdk';
import type { JsonValue } from '../../control-protocol/agent-services.ts';
import type { ConsoleSessionEventView, SessionCreateResult } from '../../control-protocol/console-api.ts';
import type { ProviderInstance, RuntimeConfigApplier, VersionedRuntimeConfig } from '../../config/runtime-config.ts';
export type OpenCodeAdapterErrorCode = 'UNAUTHENTICATED' | 'FORBIDDEN' | 'NOT_FOUND' | 'UPSTREAM_ERROR' | 'INVALID_RESPONSE' | 'UNAVAILABLE' | 'UNSUPPORTED_OPERATION' | 'INVALID_INPUT';
export declare class OpenCodeAdapterError extends Error {
    readonly code: OpenCodeAdapterErrorCode;
    readonly operation: string;
    readonly status?: number;
    constructor(operation: string, code: OpenCodeAdapterErrorCode, message: string, status?: number);
}
export interface OpenCodePluginInput {
    readonly client: unknown;
    readonly project: unknown;
    readonly directory: string;
    readonly worktree: string;
    readonly experimental_workspace: unknown;
    readonly serverUrl: URL;
    readonly $: unknown;
}
export interface OpenCodeEvent {
    readonly type: string;
    readonly properties?: Readonly<Record<string, unknown>>;
}
export interface OpenCodeEventInput {
    readonly event: OpenCodeEvent;
}
export interface OpenCodePermissionInput {
    readonly id: string;
    readonly sessionID: string;
}
export interface OpenCodeHooks {
    readonly event?: (input: OpenCodeEventInput) => Promise<void>;
    readonly 'permission.ask'?: (input: OpenCodePermissionInput, output: {
        status: 'ask' | 'deny' | 'allow';
    }) => Promise<void>;
}
export interface OpenCodeNotification {
    readonly source: 'opencode';
    readonly kind: 'session-created' | 'session-updated' | 'session-deleted' | 'session-status' | 'message-updated' | 'permission-request' | 'permission-processed';
    readonly sessionId: string;
    readonly requestId?: string;
    readonly interactive: boolean;
    readonly status: 'pending' | 'processed';
    readonly priority: 'normal' | 'high';
    readonly occurredAt: string;
}
export type OpenCodeNotificationSink = (notification: OpenCodeNotification) => void;
export interface OpenCodeNotificationStore {
    readonly pending: readonly OpenCodeNotification[];
    readonly processed: readonly OpenCodeNotification[];
}
export interface OpenCodeNotificationStoreBinding {
    readonly get: () => OpenCodeNotificationStore;
    readonly sink: OpenCodeNotificationSink;
    readonly acknowledge: (notificationId: string) => void;
}
export interface OpenCodeSessionProjection {
    readonly id: string;
    readonly title?: string;
    readonly directory?: string;
    readonly time?: Readonly<Record<string, unknown>>;
}
export interface OpenCodeHostProjection {
    readonly sessions: readonly OpenCodeSessionProjection[];
    readonly notifications: OpenCodeNotificationStore;
}
export interface OpenCodeAgentIdentity {
    readonly agentId: string;
    readonly machineId: string;
    readonly label: string;
    readonly machine: string;
    readonly provider: string;
    readonly model: string;
    readonly sessionIds: readonly string[];
    readonly currentSessionId?: string;
}
export interface OpenCodeTeamsProjection {
    readonly agents: readonly OpenCodeAgentIdentity[];
    readonly sessions: readonly (OpenCodeSessionProjection & {
        readonly agentId: string;
        readonly running: boolean;
    })[];
    readonly notifications: OpenCodeNotificationStore;
}
export interface TeamsNotificationProjectionItem {
    readonly id: string;
    readonly sessionId: string;
    readonly requestId?: string;
    readonly interactive: boolean;
    readonly processed: boolean;
    readonly priority: 'high' | 'medium';
    readonly createdAt: string;
}
export interface OpenCodeHostActions {
    readonly openSession: (sessionId: string) => Promise<void>;
    readonly sendMessage: (sessionId: string, payload: JsonValue) => Promise<void>;
    readonly replyPermission: (sessionId: string, permissionId: string, response: 'once' | 'always' | 'reject') => Promise<void>;
    readonly acknowledgeNotification: (notificationId: string) => void;
}
export interface OpenCodeHostFacade {
    readonly projection: () => OpenCodeHostProjection;
    readonly teamsProjection: (identities: readonly OpenCodeAgentIdentity[]) => OpenCodeTeamsProjection;
    readonly refreshSessions: (directory?: string) => Promise<readonly OpenCodeSessionProjection[]>;
    readonly subscribe: (listener: (projection: OpenCodeHostProjection) => void) => () => void;
    readonly actions: OpenCodeHostActions;
}
export interface OpenCodePluginRuntime {
    readonly facade: OpenCodeHostFacade;
    readonly hooks: Hooks;
}
export interface OpenCodeSdkResponse<T> {
    readonly data?: T;
    readonly error?: unknown;
    readonly response?: {
        readonly status: number;
    };
}
export type OpenCodeSdkResult<T> = T | OpenCodeSdkResponse<T>;
export interface OpenCodeModelTarget {
    readonly providerID: string;
    readonly modelID: string;
}
export interface OpenCodeSessionPromptBody {
    readonly parts: [{
        type: 'text';
        text: string;
    }];
    readonly model?: OpenCodeModelTarget;
    readonly messageID?: string;
}
/** Real 1.18.23 session-level status; auxiliary observation, never cancel proof. */
export type OpenCodeSessionStatus = {
    readonly type: 'idle';
} | {
    readonly type: 'retry';
    readonly attempt: number;
    readonly message: string;
    readonly next: number;
} | {
    readonly type: 'busy';
};
export interface OpenCodeSessionClient {
    readonly session: {
        list(options?: Readonly<Record<string, unknown>>): Promise<OpenCodeSdkResult<readonly Session[]>>;
        get(options: {
            path: {
                id: string;
            };
        }): Promise<OpenCodeSdkResult<Session>>;
        create(options?: {
            body?: {
                readonly parentID?: string;
                readonly title?: string;
            };
            query?: {
                readonly directory?: string;
            };
        }): Promise<OpenCodeSdkResult<Session>>;
        prompt(options: {
            path: {
                id: string;
            };
            body: OpenCodeSessionPromptBody;
        }): Promise<OpenCodeSdkResult<unknown>>;
        abort(options: {
            path: {
                id: string;
            };
        }): Promise<OpenCodeSdkResult<boolean>>;
        messages(options: {
            path: {
                id: string;
            };
            query?: {
                readonly directory?: string;
                readonly limit?: number;
            };
        }): Promise<OpenCodeSdkResult<readonly {
            readonly info: unknown;
            readonly parts: readonly unknown[];
        }[]>>;
        status(options?: {
            query?: {
                readonly directory?: string;
            };
        }): Promise<OpenCodeSdkResult<Readonly<Record<string, OpenCodeSessionStatus>>>>;
    };
    readonly postSessionIdPermissionsPermissionId: (options: {
        path: {
            id: string;
            permissionID: string;
        };
        body: {
            response: 'once' | 'always' | 'reject';
        };
    }) => Promise<OpenCodeSdkResult<unknown>>;
}
/** Raw SDK event; only the wire `type` and opaque `properties` are read by the pure classifier. */
export interface OpenCodeSdkEvent {
    readonly type: string;
    readonly properties: Readonly<Record<string, unknown>>;
}
export interface OpenCodeEventSubscription {
    readonly stream: AsyncGenerator<OpenCodeSdkEvent>;
}
export interface OpenCodeEventClient {
    readonly event: {
        subscribe(options?: Readonly<Record<string, unknown>>): Promise<OpenCodeSdkResult<OpenCodeEventSubscription>>;
    };
}
/** Single-event classification result produced only by `projectOpenCodeSessionEvent`. */
export type OpenCodeSessionEventProjection = {
    readonly kind: 'event';
    readonly event: ConsoleSessionEventView;
    readonly parentMessageId?: string;
} | {
    readonly kind: 'ignored';
    readonly reason: string;
    readonly raw: JsonValue;
} | {
    readonly kind: 'unsupported';
    readonly reason: string;
    readonly raw: JsonValue;
} | {
    readonly kind: 'invalid';
    readonly reason: string;
    readonly raw: JsonValue;
};
export interface OpenCodeCompiledTarget {
    /** The Teams provider-instance id; OpenCode does not own this identity. */
    readonly provider: string;
    readonly model: string;
    readonly protocol: ProviderInstance['protocol'];
    readonly baseUrl: string;
    /** An opaque reference only. The credential value never enters this projection. */
    readonly credentialRef?: string;
}
export interface OpenCodeCompiledConfig {
    readonly agentId: string;
    readonly acceptedRevision: number;
    readonly primary: OpenCodeCompiledTarget;
    readonly backup?: OpenCodeCompiledTarget;
}
export declare function listOpenCodeSessions(client: OpenCodeSessionClient, directory?: string): Promise<readonly OpenCodeSessionProjection[]>;
export declare function getOpenCodeSession(client: OpenCodeSessionClient, sessionId: string): Promise<OpenCodeSessionProjection>;
/**
 * Reads one Session's real message/tool history through the SDK pull path. The
 * adapter preserves the raw `{info, parts}` entries; the owner-side projector
 * applies the same closed event classification used for SSE events.
 */
export declare function readOpenCodeSessionMessages(client: OpenCodeSessionClient, sessionId: string, query?: {
    readonly directory?: string;
    readonly limit?: number;
}): Promise<readonly {
    readonly info: unknown;
    readonly parts: readonly unknown[];
}[]>;
/**
 * Reads the substrate's real session-level status map. Status is auxiliary
 * observation only: `idle` never confirms a cancel, and the runtime must not
 * derive cancel causality from it.
 */
export declare function readOpenCodeSessionStatus(client: OpenCodeSessionClient, query?: {
    readonly directory?: string;
}): Promise<Readonly<Record<string, OpenCodeSessionStatus>>>;
export declare function sendOpenCodeMessage(client: OpenCodeSessionClient, sessionId: string, text: string, target?: OpenCodeModelTarget): Promise<void>;
/**
 * OpenCode's `Session.Message.ID` is a `msg_`-prefixed identifier, and its prompt
 * route rejects any other shape before the message exists. The Session dispatch
 * path must allocate the prompt id before dispatch, because an event that arrives
 * before the synchronous response is correlated by that id. The substrate's
 * identifier format therefore stays owned here and is never re-derived by callers.
 */
export declare function createOpenCodePromptMessageId(): string;
/**
 * Assistant identity the synchronous prompt response proves for this exact request.
 * Absent whenever the response does not name this session's assistant message.
 */
export interface OpenCodePromptBinding {
    readonly messageId: string;
    readonly sessionId: string;
    readonly parentId: string;
}
/**
 * Dispatches one SDK prompt with an explicit, owner-resolved model target and an
 * owner-allocated user messageID. Both are required in the Session dispatch
 * path; the messageID is the SDK body field, never a Teams business part.
 *
 * The synchronous `{ info, parts }` response is one of the two allowed binding
 * sources, so it is decoded rather than discarded: a response only binds when it
 * names an assistant message whose session and parent are this request's.
 */
export declare function promptOpenCodeSession(client: OpenCodeSessionClient, sessionId: string, text: string, target: OpenCodeModelTarget, messageId: string, onDispatch?: () => void): Promise<OpenCodePromptBinding | undefined>;
/**
 * Maps the real 1.18.23 `Session` envelope; never synthesizes a default title or id.
 * `agentId` comes from the validated Teams target, never from the SDK.
 */
export declare function createOpenCodeSession(client: OpenCodeSessionClient, agentId: string, title?: string): Promise<SessionCreateResult>;
/** 1.18.23 `session.abort` base acceptance; absent stays absent and is never proof the cancel completed. */
export declare function cancelOpenCodeSession(client: OpenCodeSessionClient, sessionId: string): Promise<boolean | undefined>;
export type OpenCodeSessionMessageV1 = {
    readonly text: string;
};
/**
 * Binds the real `@opencode-ai/sdk` client to one owner-scoped managed handle.
 * The runtime consumes only the adapter; nothing else imports the SDK transport.
 */
export declare function createOpenCodeSessionClient(handle: {
    readonly url: string;
    readonly authorization: string;
}): OpenCodeSessionClient & OpenCodeEventClient;
/**
 * Sole Session message decoder: converts a supported business payload into the
 * SDK prompt input shape. It rejects lossy/extra shapes before any side effect.
 */
export declare function decodeOpenCodeSessionMessage(payload: JsonValue): OpenCodeSessionMessageV1;
/**
 * Thin wrapper over the real `client.event.subscribe`. It establishes no second
 * connection, performs no retry, buffers nothing, and holds no lifecycle state;
 * it only forwards the SDK stream to the caller and honors the abort signal.
 */
export declare function subscribeOpenCodeEvents(client: OpenCodeEventClient, signal: AbortSignal): AsyncGenerator<OpenCodeSdkEvent>;
/**
 * The sole SDK-shape classifier. Pure: it holds no state, decides nothing about
 * stream lifetime or observation status, and returns exactly one typed event,
 * `unsupported`, or `invalid` for one raw SDK event/part.
 */
export declare function projectOpenCodeSessionEvent(raw: unknown): OpenCodeSessionEventProjection;
/**
 * Converts the real `session.messages` response into the same closed event
 * projection used by the SSE ingress. The SDK shape classification stays in
 * this adapter, and a malformed entry is reported as `invalid` rather than
 * being silently dropped.
 */
export declare function projectOpenCodeSessionMessages(raw: unknown): readonly OpenCodeSessionEventProjection[];
export declare function replyOpenCodePermission(client: OpenCodeSessionClient, permissionId: string, sessionId: string, response: 'once' | 'always' | 'reject'): Promise<void>;
export declare function compileOpenCodeConfig(config: VersionedRuntimeConfig, agentId: string): OpenCodeCompiledConfig;
export declare function createOpenCodeConfigApplier(): RuntimeConfigApplier;
export declare function createOpenCodeHostFacade(client: OpenCodeSessionClient, binding?: OpenCodeNotificationStoreBinding): OpenCodeHostFacade;
export declare function projectOpenCodeTeamsProjection(sessions: readonly OpenCodeSessionProjection[], notifications: OpenCodeNotificationStore, identities: readonly OpenCodeAgentIdentity[]): OpenCodeTeamsProjection;
export declare function projectOpenCodeNotifications(notifications: OpenCodeNotificationStore): readonly TeamsNotificationProjectionItem[];
export declare function createOpenCodePluginRuntime(input: PluginInput, binding?: OpenCodeNotificationStoreBinding): Promise<OpenCodePluginRuntime>;
export declare function acknowledgeOpenCodeNotification(store: OpenCodeNotificationStore, notificationId: string): OpenCodeNotificationStore;
export declare function createOpenCodeNotificationStoreBinding(initial?: OpenCodeNotificationStore): OpenCodeNotificationStoreBinding;
export declare function sortOpenCodeNotifications(notifications: readonly OpenCodeNotification[]): readonly OpenCodeNotification[];
export declare function subscribeOpenCodeNotifications(sink: OpenCodeNotificationSink): () => void;
export declare function projectOpenCodeEvent(event: OpenCodeEvent): OpenCodeNotification | undefined;
export declare function projectOpenCodePermission(permission: OpenCodePermissionInput): OpenCodeNotification;
export declare function registerOpenCodeHooks(sink: OpenCodeNotificationSink): OpenCodeHooks;
export type OpenCodePlugin = (input: PluginInput) => Promise<Hooks>;
export declare function createTeamsOpenCodePlugin(sink: OpenCodeNotificationSink): OpenCodePlugin;
export declare const TeamsOpenCodePluginWithNotifications: OpenCodePlugin;
export declare const TeamsOpenCodePlugin: OpenCodePlugin;
/**
 * ACP engine adapter for the installed OpenCode ACP server. Declared here as
 * the package entry point; the implementation owns no second Session path and
 * reuses `compileOpenCodeConfig`/`createOpenCodeLaunchConfig` from this module.
 */
export { openCodeAcpAdapter, assertOpenCodeNativePolicy } from './acp-engine.ts';
export type { OpenCodeEngineAdapter } from './acp-engine.ts';
declare const _default: {
    id: string;
    server: OpenCodePlugin;
};
export default _default;
