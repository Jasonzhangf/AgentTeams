import { projectTeamsMembership } from "./teams-membership.js";
export function createTeamsStatusPort(input) {
    const now = input.now ?? (() => new Date().toISOString());
    return {
        connections: () => projectTeamsMembership({
            localAgentId: input.localAgentId,
            directory: input.directory,
            registration: input.registration,
            channels: input.ledger.list(),
            observedAt: now(),
        }).entries.map(entry => entry.status),
        history: query => input.history.query(query),
    };
}
