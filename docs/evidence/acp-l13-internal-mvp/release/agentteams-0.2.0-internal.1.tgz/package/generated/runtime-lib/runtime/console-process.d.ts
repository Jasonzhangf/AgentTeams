import { type ConsoleRuntimeOptions } from './console-runtime.ts';
export declare function loadConsoleProcessConfig(path: string, env?: NodeJS.ProcessEnv): Promise<ConsoleRuntimeOptions>;
export declare function runConsoleProcess(argv?: string[]): Promise<void>;
