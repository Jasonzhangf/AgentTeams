import { type AgentDaemonOptions } from './agent-daemon.ts';
export interface ConsoleRuntimeOptions {
    readonly daemon: AgentDaemonOptions;
    readonly agentIds: readonly string[];
    readonly sessionRequestTimeoutMs: number;
    readonly host: string;
    readonly port: number;
    readonly origin: string;
    readonly username: string;
    readonly password: string;
    readonly staticRoot: string;
    readonly uiRoot: string;
    readonly tls?: {
        readonly cert: Buffer;
        readonly key: Buffer;
    };
}
/** Console owns its listener and registration only; Agent execution lives elsewhere. */
export declare function startConsoleRuntime(options: ConsoleRuntimeOptions): Promise<{
    url: string;
    stop: () => Promise<void>;
    closed: Promise<void>;
}>;
