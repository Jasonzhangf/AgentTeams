import type { RouteCandidate } from '../server/directory.ts';
export type RoutePlanPolicy = 'manual' | 'auto';
export type RoutePlanState = 'pending' | 'active' | 'succeeded' | 'failed';
export type DirectWssRouteKind = Exclude<RouteCandidate['kind'], 'relay-ws' | 'relay-webrtc'>;
export interface DirectWssRouteCandidate extends RouteCandidate {
    readonly kind: DirectWssRouteKind;
    readonly endpoint: string;
}
export interface RoutePlan {
    readonly hostId: string;
    readonly directoryGeneration: number;
    readonly policy: RoutePlanPolicy;
    readonly candidates: readonly RouteCandidate[];
    readonly candidateOrder: readonly string[];
    readonly cursor: number;
    readonly state: RoutePlanState;
    readonly lastError?: string;
}
export interface BuildRoutePlanInput {
    readonly hostId: string;
    readonly directoryGeneration: number;
    readonly policy: RoutePlanPolicy;
    readonly candidates: readonly RouteCandidate[];
    readonly targetCandidateId?: string;
}
export declare function buildDirectWssRoutePlan(input: Omit<BuildRoutePlanInput, 'candidates'> & {
    readonly candidates: readonly RouteCandidate[];
}): RoutePlan;
export declare function activeDirectWssCandidate(plan: RoutePlan): DirectWssRouteCandidate;
export declare function buildRoutePlan(input: BuildRoutePlanInput): RoutePlan;
export declare function beginRouteCandidate(plan: RoutePlan): RoutePlan;
export declare function succeedRouteCandidate(plan: RoutePlan, candidateId: string): RoutePlan;
export declare function failRouteCandidate(plan: RoutePlan, candidateId: string, reason: string): RoutePlan;
