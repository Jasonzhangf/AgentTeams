import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { ConsoleClientV1, ConsoleCommandV1 } from '../control-protocol/console-api.ts';
import { type ConsoleWireReply, type ConsoleWireRequest } from '../control-protocol/console-wire.ts';
export type ConsoleAccess = {
    readonly kind: 'observe';
    readonly agentId: string;
} | {
    readonly kind: 'command';
    readonly agentId: string;
    readonly commandKind: ConsoleCommandV1['kind'];
} | {
    readonly kind: 'session';
    readonly agentId: string;
    readonly sessionId: string;
};
/** Relay authentication establishes the peer, not management authority. Policy sees only control. */
export declare function createConsoleIngress(options: {
    readonly agentId: string;
    readonly generation: () => number;
    readonly authorize: (peer: AuthenticatedAgent, access: ConsoleAccess) => boolean;
    readonly client: ConsoleClientV1;
}, authenticatedPeer: AuthenticatedAgent): (input: ConsoleWireRequest) => Promise<ConsoleWireReply>;
