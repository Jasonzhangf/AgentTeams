import { parseConsoleWorkRelationProjection, projectCapabilityDetails } from "../control-protocol/console-api.js";
import { RelayProtocolError } from "../control-protocol/relay-codec.js";
/**
 * One directory agent row projected from an admitted Relay peer. The peer's published
 * declaration owns the identity, generation, presence and capability facts; this is the
 * single mapper for a directory row, shared by the Console hub and the control daemon's
 * directory projection.
 */
export function directoryAgentObservation(peer) {
    return {
        kind: 'directory',
        agentId: peer.declaration.identity.agentId,
        label: peer.declaration.identity.label,
        machineId: peer.declaration.identity.machineId,
        generation: peer.generation,
        presence: peer.presence,
        capabilities: peer.declaration.capabilities.map(capability => capability.capabilityId),
        capabilityDetails: projectCapabilityDetails(peer.declaration.capabilities),
    };
}
/** Compose bound owners without storing a second copy of their state. Empty static bindings use directory discovery. */
export function createConsoleHub(bindings, discovery) {
    if (discovery && bindings.length > 0)
        throw new RelayProtocolError('INVALID_INPUT', 'Console cannot combine static bindings with directory discovery');
    const owners = new Map();
    for (const { agentId, client } of bindings) {
        if (!agentId || owners.has(agentId))
            throw new RelayProtocolError('INVALID_INPUT', 'Console requires unique Agent bindings');
        owners.set(agentId, client);
    }
    async function discovered() {
        if (!discovery)
            return { peers: [], client: () => { throw new RelayProtocolError('NOT_FOUND', 'Agent is not bound to this Console'); } };
        const result = await discovery();
        const ids = new Set();
        for (const peer of result.peers) {
            const agentId = peer.declaration.identity.agentId;
            if (!agentId || ids.has(agentId))
                throw new RelayProtocolError('INVALID_INPUT', 'Relay directory contains duplicate Agent identities');
            ids.add(agentId);
        }
        return result;
    }
    async function owner(agentId) {
        const client = owners.get(agentId);
        if (client)
            return client;
        const result = await discovered();
        const peer = result.peers.find(candidate => candidate.declaration.identity.agentId === agentId);
        if (!peer)
            throw new RelayProtocolError('NOT_FOUND', 'Agent is not admitted to this Console directory');
        if (peer.presence !== 'online')
            throw new RelayProtocolError('UNAVAILABLE', 'Agent is offline');
        return result.client(peer);
    }
    return {
        async readProjection() {
            const agents = [];
            const sessions = [];
            const configs = [];
            const notifications = [];
            const works = [];
            const relations = [];
            const sessionEvents = [];
            const discoveredState = await discovered();
            const entries = discovery
                ? discoveredState.peers.map(peer => ({ agentId: peer.declaration.identity.agentId, peer, client: peer.presence === 'online' ? discoveredState.client(peer) : undefined }))
                : [...owners].map(([agentId, client]) => ({ agentId, client, peer: undefined }));
            for (const { agentId, client, peer } of entries) {
                const directoryAgent = peer === undefined ? undefined : directoryAgentObservation(peer);
                if (client === undefined) {
                    if (directoryAgent)
                        agents.push(directoryAgent);
                    continue;
                }
                const projection = await client.readProjection();
                let observed;
                try {
                    observed = parseConsoleWorkRelationProjection(projection);
                }
                catch (error) {
                    throw new RelayProtocolError('INVALID_INPUT', error instanceof Error ? error.message : 'Console projection requires work and relation observations');
                }
                for (const rows of [projection.agents, projection.sessions, projection.configs, projection.notifications,
                    projection.sessionEvents ?? [], observed.works, observed.relations]) {
                    if (rows.some(row => row.agentId !== agentId))
                        throw new RelayProtocolError('INVALID_INPUT', 'Console projection crossed its Agent owner');
                }
                const projectedAgents = projection.agents.length === 0 && directoryAgent ? [directoryAgent] : projection.agents.map(agent => ({
                    ...agent,
                    // The online directory row owns the ID list and its detail together: never keep the
                    // runtime fixture's detail beside the directory's IDs.
                    ...(directoryAgent === undefined ? {} : { label: directoryAgent.label, machineId: directoryAgent.machineId,
                        generation: directoryAgent.generation, presence: directoryAgent.presence, capabilities: directoryAgent.capabilities,
                        capabilityDetails: directoryAgent.capabilityDetails }),
                }));
                agents.push(...projectedAgents);
                sessions.push(...projection.sessions);
                configs.push(...projection.configs);
                notifications.push(...projection.notifications);
                works.push(...observed.works);
                relations.push(...observed.relations);
                sessionEvents.push(...(projection.sessionEvents ?? []));
            }
            return { version: 1, agents, sessions, configs, notifications, works, relations, ...(sessionEvents.length === 0 ? {} : { sessionEvents }) };
        },
        command: async (command) => (await owner(command.agentId)).command(command),
        sendSession: async (target, payload) => (await owner(target.agentId)).sendSession(target, payload),
    };
}
