import { type ConfigTargetIdentity, type DaemonRuntimeConfigView, type ManagedConfigUncertainty, type ManagedConfigUncertaintyFence, type RuntimeConfigApplyRequest, type RuntimeConfigApplier, type RuntimeConfigObservationPatch } from '../config/runtime-config.ts';
import { startManagedOpenCode, type ManagedOpenCodeOptions } from './managed-opencode.ts';
/** Owner-scoped effective handle exposing the compiled primary model target. */
export interface ManagedEffectiveHandle {
    readonly url: string;
    readonly authorization: string;
    readonly effectiveRevision: number;
    readonly pid?: number;
    readonly modelTarget: {
        readonly providerID: string;
        readonly modelID: string;
    };
}
/** Owner-scoped readiness; never a Work capability and never a second config truth. */
export type ManagedRuntimeReadiness = {
    readonly state: 'changing';
} | {
    readonly state: 'stopped';
} | {
    readonly state: 'no-current';
} | {
    readonly state: 'uncertain';
    readonly effectiveRevision?: number;
} | {
    readonly state: 'current';
    readonly effectiveRevision: number;
    readonly modelTarget: {
        readonly providerID: string;
        readonly modelID: string;
    };
    readonly activeOperations: number;
};
type Options = Omit<ManagedOpenCodeOptions, 'compiled'> & {
    readonly agentId: string;
    readonly persistence: ManagedConfigOwnerPersistence;
};
/** Owner-scoped async uncertainty persistence port; U6 consumes `recover()` but never this port. */
export interface ManagedConfigOwnerPersistence {
    readRecovery(ownerAgentId: string): Promise<{
        readonly state: 'clean';
    } | {
        readonly state: 'uncertain';
        readonly fence: ManagedConfigUncertaintyFence;
    }>;
    persistUncertainty(input: {
        readonly fence: ManagedConfigUncertainty;
        readonly expectedAcceptedRevision: number;
    }): Promise<{
        readonly persistence: 'committed';
    }>;
    clearUncertainty(input: {
        readonly expectedFence: ManagedConfigUncertainty;
        readonly effectiveRevision: number;
        readonly currentTarget: ConfigTargetIdentity;
    }): Promise<{
        readonly persistence: 'committed';
    }>;
}
export interface ManagedConfigOwnerPersistenceOptions {
    readonly agentId: string;
    readonly internalPath: string;
    readonly persistence: RuntimeConfigStorePersistencePort;
}
type RuntimeConfigStorePersistencePort = {
    withLock<T>(task: () => Promise<T>): Promise<T>;
    loadDaemonUnlocked(agentId: string): Promise<DaemonRuntimeConfigView>;
    saveObservationUnlocked(agentId: string, patch: RuntimeConfigObservationPatch): Promise<void>;
};
/** Owner-owned persistence adapter over the single RuntimeConfigPersistence/store lock. */
export declare function createManagedConfigOwnerPersistence(options: ManagedConfigOwnerPersistenceOptions): ManagedConfigOwnerPersistence;
/** Serializes configuration replacement with operations using the owned substrate. */
export declare function createManagedConfigOwner(options: Options, launch?: typeof startManagedOpenCode): RuntimeConfigApplier & {
    recover(readRequest?: () => Promise<RuntimeConfigApplyRequest | undefined>): Promise<"clean" | "uncertain">;
    reconcile(request: RuntimeConfigApplyRequest): Promise<"clean" | "uncertain">;
    use<T>(operation: (handle: ManagedEffectiveHandle) => Promise<T>): Promise<T>;
    readiness(): ManagedRuntimeReadiness;
    currentHandle(): ManagedEffectiveHandle | undefined;
    stop(): Promise<void>;
    uncertainty(): boolean;
};
export {};
