import { filterVisibleEndpoints, parseEndpointDiscoveryView, } from "../control-protocol/endpoint-ref.js";
import { RelayProtocolError } from "../control-protocol/relay-codec.js";
import { compileLegacyAgentCapabilities } from "../endpoint/compile.js";
import { isEndpointError } from "../endpoint/errors.js";
function asProtocol(error) {
    if (error instanceof RelayProtocolError)
        throw error;
    throw new RelayProtocolError('INVALID_INPUT', isEndpointError(error) ? error.message : error instanceof Error ? error.message : 'invalid Endpoint admission');
}
/** Sole compile/admission conversion from published Agent capabilities into discovery summaries. */
export function compileDeclarationEndpoints(declaration) {
    if (declaration.capabilities.length === 0)
        return [];
    try {
        const compiled = compileLegacyAgentCapabilities({
            ownerAgentId: declaration.identity.agentId,
            endpointId: declaration.identity.agentId,
            kind: 'service',
            label: declaration.identity.label,
            capabilities: declaration.capabilities,
        });
        return [parseEndpointDiscoveryView({
                endpointId: compiled.endpointId,
                ownerAgentId: compiled.ownerAgentId,
                scopeId: declaration.scopeId,
                kind: compiled.kind,
                revision: declaration.revision,
                lifecycle: compiled.lifecycle,
                capabilities: compiled.capabilities.map(capability => ({
                    capabilityId: capability.capabilityId,
                    version: capability.version,
                    operations: capability.operations.map(operation => operation.operation),
                })),
                resources: compiled.resources.map(resource => ({
                    resourceId: resource.resourceId,
                    capacity: resource.capacity,
                    unit: resource.unit,
                })),
            })];
    }
    catch (error) {
        asProtocol(error);
    }
}
export function attachDeclarationEndpoints(declaration) {
    return compileDeclarationEndpoints(declaration);
}
export function projectPeerEndpoints(peer, viewer) {
    const endpoints = peer.endpoints ?? attachDeclarationEndpoints(peer.declaration);
    return { ...peer, endpoints: filterVisibleEndpoints(endpoints, viewer) };
}
