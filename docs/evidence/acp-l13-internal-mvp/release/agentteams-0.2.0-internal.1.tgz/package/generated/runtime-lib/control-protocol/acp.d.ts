import type { JsonValue } from './agent-services.ts';
import type { TeamsAgreement } from './teams-connection.ts';
/** A complete JSON-RPC object. Teams control never flattens or rewrites it. */
export type AcpFrame = Readonly<Record<string, JsonValue>>;
export type AcpRpcId = string | number;
export interface AcpChannelRef {
    readonly connectionId: string;
    readonly channelId: string;
    readonly targetGeneration: number;
    readonly engineInstanceId: string;
}
export interface AcpIngress extends AcpChannelRef {
    readonly frame: AcpFrame;
}
export interface AcpDelivery extends AcpIngress {
    /** The channel owner assigns this value in monotonically increasing order. */
    readonly sequence: number;
}
export type AcpFaultCode = 'INVALID_ACP_FRAME' | 'UNSUPPORTED_METHOD' | 'UNSUPPORTED_CAPABILITY' | 'UNSUPPORTED_POLICY' | 'UNSUPPORTED_CONFIGURATION' | 'CAPABILITY_DENIED' | 'AUTHENTICATION_REQUIRED' | 'STALE_GENERATION' | 'SESSION_OWNERSHIP_CONFLICT' | 'CALLBACK_UNAVAILABLE' | 'ENGINE_UNAVAILABLE' | 'RESULT_UNKNOWN' | 'HISTORY_UNAVAILABLE' | 'CONFLICT' | 'FORBIDDEN';
export interface AcpFault {
    readonly code: AcpFaultCode;
    readonly message: string;
    readonly detail?: JsonValue;
}
/** Typed local failure carrier for protocol, transport, and policy boundaries. */
export declare class AcpError extends Error {
    readonly code: AcpFaultCode;
    readonly detail?: JsonValue;
    constructor(code: AcpFaultCode, message: string, detail?: JsonValue);
    toFault(): AcpFault;
}
export interface HistoryRecord {
    readonly recordId: string;
    readonly sequence: number;
    readonly occurredAt: string;
    readonly agentId: string;
    readonly kind: 'request' | 'connection';
    readonly event: string;
    readonly connectionId?: string;
    readonly channelId?: string;
    readonly engineInstanceId?: string;
    readonly requestRecordId?: string;
    readonly sessionId?: string;
    readonly frame?: AcpFrame;
    readonly agreement?: TeamsAgreement;
    readonly outcome?: 'completed' | 'failed' | 'denied' | 'unknown';
    readonly error?: AcpFault;
}
/**
 * Validate a complete JSON-RPC envelope without cloning or coercing it.
 * Legal extension members, `_meta`, params, and results remain untouched.
 */
export declare function parseAcpFrame(value: unknown): AcpFrame;
export declare function parseAcpFault(value: unknown): AcpFault;
