import { type WorkChannelOptions } from '../network/work-channel.ts';
import type { WssConnection } from '../network/wss-connection.ts';
import type { ConsoleWireReply, ConsoleWireRequest } from '../control-protocol/console-wire.ts';
/** The first typed frame selects a protocol; authorization stays in each Agent ingress. */
export declare function acceptAgentData(socket: WssConnection, options: {
    readonly work: WorkChannelOptions;
    readonly console: (request: ConsoleWireRequest) => Promise<ConsoleWireReply>;
}): Promise<void>;
