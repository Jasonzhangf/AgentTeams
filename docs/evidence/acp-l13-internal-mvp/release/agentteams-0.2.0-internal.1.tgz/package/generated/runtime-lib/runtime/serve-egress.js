import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { AcpError } from "../control-protocol/acp.js";
import { DirectWssRouteError, connectDirectWssTarget } from "../network/direct-route.js";
import { buildDirectWssRoutePlan } from "../network/route-plan.js";
import { openTeamsEgress } from "../network/teams-egress.js";
const DEFAULT_CONNECT_TIMEOUT_MS = 5_000;
const DEFAULT_HELLO_TIMEOUT_MS = 5_000;
const DEFAULT_NEGOTIATION_TIMEOUT_MS = 10_000;
const DEFAULT_OPEN_TIMEOUT_MS = 10_000;
/** The serve entry's own LAN operational limits; this owner dials with the same values. */
const DEFAULT_MAX_MESSAGE_BYTES = 262_144;
const DEFAULT_MAX_BUFFERED_BYTES = 262_144;
const DEFAULT_MAX_PENDING_FRAMES = 64;
const ACP_FAULT_CODES = [
    'INVALID_ACP_FRAME', 'UNSUPPORTED_METHOD', 'UNSUPPORTED_CAPABILITY', 'UNSUPPORTED_POLICY',
    'UNSUPPORTED_CONFIGURATION', 'CAPABILITY_DENIED', 'AUTHENTICATION_REQUIRED', 'STALE_GENERATION',
    'SESSION_OWNERSHIP_CONFLICT', 'CALLBACK_UNAVAILABLE', 'ENGINE_UNAVAILABLE', 'RESULT_UNKNOWN',
    'HISTORY_UNAVAILABLE', 'CONFLICT', 'FORBIDDEN',
];
function faultCodeOf(error) {
    if (error instanceof AcpError)
        return error.code;
    if (error instanceof DirectWssRouteError) {
        const code = error.code;
        return ACP_FAULT_CODES.includes(code) ? code : 'ENGINE_UNAVAILABLE';
    }
    if (typeof error === 'object' && error !== null && 'code' in error && typeof error.code === 'string') {
        const code = error.code;
        if (ACP_FAULT_CODES.includes(code))
            return code;
    }
    return 'ENGINE_UNAVAILABLE';
}
function messageOf(error, fallback) {
    return error instanceof Error ? error.message : fallback;
}
function fileRefPath(reference) {
    return resolve(reference.startsWith('file:') ? reference.slice('file:'.length) : reference);
}
/**
 * Resolve one credential reference with the same vocabulary the serve entry uses
 * for admissions: `env:NAME`, `file:<path>` or a bare environment-variable name.
 */
async function resolveCredential(reference, env) {
    const fromEnvironment = (name) => {
        const value = env[name];
        if (typeof value !== 'string' || value.length === 0) {
            throw new AcpError('AUTHENTICATION_REQUIRED', `serve-egress: credential environment variable ${name} is not set`);
        }
        return value;
    };
    if (reference.startsWith('env:'))
        return fromEnvironment(reference.slice('env:'.length));
    if (reference.startsWith('file:')) {
        const path = fileRefPath(reference);
        try {
            const value = (await readFile(path, 'utf8')).replace(/\r?\n$/, '');
            if (value.length === 0)
                throw new AcpError('AUTHENTICATION_REQUIRED', `serve-egress: credential file ${path} is empty`);
            return value;
        }
        catch (cause) {
            if (cause instanceof AcpError)
                throw cause;
            throw new AcpError('AUTHENTICATION_REQUIRED', `serve-egress: credential file ${path} cannot be read: ${messageOf(cause, 'read failed')}`);
        }
    }
    if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(reference))
        return fromEnvironment(reference);
    throw new AcpError('UNSUPPORTED_CONFIGURATION', `serve-egress: credential reference ${reference} is not env:NAME, file:<path> or an environment-variable name`);
}
function portOf(endpoint) {
    try {
        const url = new URL(endpoint);
        if (url.port.length === 0)
            return url.protocol === 'wss:' ? 443 : undefined;
        const port = Number(url.port);
        return Number.isSafeInteger(port) && port > 0 && port <= 65_535 ? port : undefined;
    }
    catch {
        return undefined;
    }
}
function dialablePeer(peer) {
    const { endpoint, admissionRef, credentialRef, tlsTrustRef } = peer;
    if (endpoint === undefined || admissionRef === undefined || tlsTrustRef === undefined)
        return undefined;
    return { endpoint, admissionRef, credentialRef, tlsTrustRef };
}
/**
 * Create the daemon's own egress owner. It dials nothing until `connect` is
 * called, and every live row it returns is a real, negotiated, channel-open
 * connection; a refused dial records a typed failure and leaves no row.
 */
export function createServeEgressOwner(input) {
    if (typeof input.self.agentId !== 'string' || input.self.agentId.length === 0) {
        throw new AcpError('UNSUPPORTED_CONFIGURATION', 'serve-egress: the daemon identity is required');
    }
    if (!Number.isSafeInteger(input.selfGeneration) || input.selfGeneration < 1) {
        throw new AcpError('UNSUPPORTED_CONFIGURATION', 'serve-egress: selfGeneration must be a positive safe integer');
    }
    const env = input.env ?? process.env;
    const now = input.now ?? (() => new Date().toISOString());
    const connectTimeoutMs = input.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
    const helloTimeoutMs = input.helloTimeoutMs ?? DEFAULT_HELLO_TIMEOUT_MS;
    const negotiationTimeoutMs = input.negotiationTimeoutMs ?? DEFAULT_NEGOTIATION_TIMEOUT_MS;
    const openTimeoutMs = input.openTimeoutMs ?? DEFAULT_OPEN_TIMEOUT_MS;
    const maxMessageBytes = input.maxMessageBytes ?? DEFAULT_MAX_MESSAGE_BYTES;
    const maxBufferedBytes = input.maxBufferedBytes ?? DEFAULT_MAX_BUFFERED_BYTES;
    const maxPendingFrames = input.maxPendingFrames ?? DEFAULT_MAX_PENDING_FRAMES;
    const live = new Map();
    const failures = [];
    // The dialer's own role pair. The peer config declares no role, so the daemon's
    // accepted relations select it: peer/master when both are allowed, peer/peer
    // when the daemon only accepts `peer`. A daemon that does not accept `peer`
    // cannot dial at all, which is a typed refusal rather than an invented role.
    const requestedRole = 'peer';
    const requestedPeerRole = input.allowedRoles.includes('master') ? 'master' : 'peer';
    const recordFailure = (peerName, agentId, error) => {
        const code = faultCodeOf(error);
        const message = messageOf(error, 'serve-egress: the dial failed');
        const failure = { peerName, agentId, code, message };
        failures.push(failure);
        input.onFailure?.(failure);
        return error instanceof AcpError ? error : new AcpError(code, `serve-egress: peer ${peerName} could not be dialed: ${message}`);
    };
    const connect = async (peerName) => {
        if (typeof peerName !== 'string' || peerName.length === 0) {
            throw new AcpError('UNSUPPORTED_CONFIGURATION', 'serve-egress: a peer name is required');
        }
        const peer = input.peers[peerName];
        if (peer === undefined) {
            throw recordFailure(peerName, '', new AcpError('FORBIDDEN', `serve-egress: peer ${peerName} is not declared by the accepted intent`));
        }
        if (!input.allowedRoles.includes(requestedRole)) {
            throw recordFailure(peerName, peer.agentId, new AcpError('FORBIDDEN', `serve-egress: the daemon's accepted relations ${JSON.stringify(input.allowedRoles)} do not allow the initiator role ${requestedRole}`));
        }
        const dialable = dialablePeer(peer);
        if (dialable === undefined) {
            throw recordFailure(peerName, peer.agentId, new AcpError('UNSUPPORTED_CONFIGURATION', `serve-egress: peer ${peerName} declares no explicit endpoint, admissionRef and tlsTrustRef; a peer without an explicit endpoint is never dialed`));
        }
        if (live.has(peer.agentId)) {
            throw recordFailure(peerName, peer.agentId, new AcpError('CONFLICT', `serve-egress: peer ${peerName} (${peer.agentId}) already has a live connection`));
        }
        const connectionId = `serve-egress-${randomUUID()}`;
        let target;
        try {
            const [credential, ca, facts] = await Promise.all([
                resolveCredential(dialable.credentialRef, env),
                readFile(fileRefPath(dialable.tlsTrustRef)),
                input.readTargetFacts({ peerName, peer }),
            ]);
            if (!Number.isSafeInteger(facts.directoryGeneration) || facts.directoryGeneration < 1) {
                throw new AcpError('STALE_GENERATION', 'serve-egress: the directory readback reported no confirmed generation');
            }
            if (!Number.isSafeInteger(facts.targetGeneration) || facts.targetGeneration < 1) {
                throw new AcpError('STALE_GENERATION', 'serve-egress: the target facts reported no target generation');
            }
            if (typeof facts.targetCapabilitiesRevision !== 'string' || facts.targetCapabilitiesRevision.length === 0) {
                throw new AcpError('CONFLICT', 'serve-egress: the target facts reported no capability revision');
            }
            const port = portOf(dialable.endpoint);
            const candidate = {
                candidateId: `${peer.agentId}-lan`,
                kind: 'lan',
                endpoint: dialable.endpoint,
                ...(port === undefined ? {} : { port }),
                authRequired: true,
                lastSeenAt: now(),
            };
            const plan = buildDirectWssRoutePlan({
                hostId: peer.hostId,
                directoryGeneration: facts.directoryGeneration,
                policy: 'manual',
                targetCandidateId: candidate.candidateId,
                candidates: [candidate],
            });
            target = await connectDirectWssTarget({
                transport: {
                    endpoint: dialable.endpoint,
                    credential,
                    ca,
                    connectTimeoutMs,
                    maxMessageBytes,
                    maxBufferedBytes,
                    maxPendingFrames,
                },
                hello: {
                    hostId: peer.hostId,
                    agentId: peer.agentId,
                    targetGeneration: facts.targetGeneration,
                    protocolVersion: 1,
                    capabilitiesRevision: facts.targetCapabilitiesRevision,
                    source: input.self,
                    admissionRef: dialable.admissionRef,
                },
                plan,
                helloTimeoutMs,
            });
            const handle = await openTeamsEgress({
                endpoint: { peer: { accountId: peer.accountId, scopeId: peer.scopeId, agentId: peer.agentId }, connection: target.connection },
                self: input.self,
                selfGeneration: input.selfGeneration,
                selfCapabilitiesRevision: input.selfCapabilitiesRevision,
                selfPolicyRevision: input.selfPolicyRevision,
                allowedRoles: input.allowedRoles,
                requestedRole,
                requestedPeerRole,
                requestedCapabilities: input.requestedCapabilities,
                requestId: `serve-egress-${randomUUID()}`,
                expectedTargetGeneration: facts.targetGeneration,
                expectedTargetCapabilitiesRevision: facts.targetCapabilitiesRevision,
                connectionId,
                host: input.host,
                policy: input.policy,
                engineInstanceId: input.engineInstanceId,
                history: input.history,
                ledger: input.ledger,
                timeoutMs: negotiationTimeoutMs,
                openTimeoutMs,
                now,
            });
            const row = {
                peerName,
                agentId: peer.agentId,
                connectionId,
                peer: handle.peer,
                role: handle.negotiation.agreement?.sourceRole,
                state: handle.negotiation.state,
            };
            live.set(peer.agentId, { row, handle, target });
            return row;
        }
        catch (error) {
            // A refused dial never fabricates a live row. The egress already recorded
            // its own typed history/ledger facts; the transport is released here.
            if (target !== undefined)
                await target.close('serve-egress dial failed').catch(() => undefined);
            throw recordFailure(peerName, peer.agentId, error);
        }
    };
    const disconnect = async (agentId) => {
        const entry = live.get(agentId);
        if (entry === undefined) {
            throw new AcpError('CONFLICT', `serve-egress: peer ${agentId} has no live connection to disconnect`);
        }
        live.delete(agentId);
        await entry.handle.session.close().catch(() => undefined);
        await entry.target.close('serve-egress disconnected').catch(() => undefined);
    };
    const list = () => [...live.values()].map(entry => entry.row);
    const close = async () => {
        const entries = [...live.values()];
        live.clear();
        for (const entry of entries) {
            await entry.handle.session.close().catch(() => undefined);
            await entry.target.close('serve-egress owner closed').catch(() => undefined);
        }
    };
    return { connect, disconnect, list, failures: () => [...failures], close };
}
