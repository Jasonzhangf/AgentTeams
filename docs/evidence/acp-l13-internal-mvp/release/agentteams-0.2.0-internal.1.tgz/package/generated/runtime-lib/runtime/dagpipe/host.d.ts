import type { JsonValue, RequestState } from '../../control-protocol/agent-services.ts';
import { type AgentWorkClient } from '../agent-work-client.ts';
import { type HostCallFrame, type RunnerFinalFrame } from './protocol.ts';
export interface ExecutionIntentControl {
    readonly receiverAgentId: string;
    readonly targetAgentId: string;
    readonly targetGeneration?: number;
    readonly linkGeneration?: number;
    readonly serviceSelection?: 'endpoint' | 'capability';
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly workId: string;
    readonly requestId?: string;
}
export interface WorkIntentControl extends ExecutionIntentControl {
    readonly requestId: string;
    readonly policyRevision: number;
    readonly demands: readonly {
        readonly resourceId: string;
        readonly amount: number;
    }[];
}
export interface WorkOpenIntentControl extends ExecutionIntentControl {
    readonly targetGeneration: number;
    readonly requestId: string;
    readonly policyRevision: number;
    readonly demands: readonly {
        readonly resourceId: string;
        readonly amount: number;
    }[];
}
export interface WorkRequestIntentControl extends ExecutionIntentControl {
    readonly targetGeneration: number;
    readonly requestId: string;
    readonly demands: readonly {
        readonly resourceId: string;
        readonly amount: number;
    }[];
}
export interface WorkCloseIntentControl extends ExecutionIntentControl {
    readonly targetGeneration: number;
}
export interface QueryIntentControl extends ExecutionIntentControl {
    readonly requestId: string;
    readonly targetGeneration?: number;
    readonly linkGeneration?: number;
    readonly serviceSelection?: 'endpoint' | 'capability';
}
export type ExecutionControl = WorkIntentControl | WorkOpenIntentControl | WorkRequestIntentControl | WorkCloseIntentControl | QueryIntentControl;
export interface WorkExecutionRequest {
    readonly runnerPath: string;
    readonly graphPath: string;
    readonly projectId: string;
    readonly executionId: string;
    readonly attemptId: string;
    readonly intent: {
        readonly control: ExecutionControl;
        readonly business?: JsonValue;
    };
    readonly capabilities?: readonly string[];
    readonly onHostCall?: (frame: HostCallFrame) => void;
}
export interface ProjectExecutionControl {
    readonly projectId: string;
    readonly graphId: string;
    readonly graphVersion: string;
    readonly executionId: string;
    readonly attemptId: string;
    readonly workId?: string;
    readonly requestId?: string;
    readonly providerAgentId?: string;
    readonly targetGeneration?: number;
    readonly linkGeneration?: number;
    readonly serviceSelection?: 'endpoint' | 'capability';
    readonly capabilityId?: string;
    readonly capabilityVersion?: string;
    readonly operation?: string;
    readonly requestState?: RequestState;
    readonly workClosure?: 'closed' | 'retained' | 'close-failed';
    readonly deliveryState?: 'unconfirmed';
    readonly observed?: true;
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
}
export interface ProjectExecutionReceipt {
    readonly status: 'completed' | 'failed';
    readonly control: ProjectExecutionControl;
    readonly business?: JsonValue;
    readonly cleanup: {
        readonly channelsOpened: number;
        readonly channelsDisposed: number;
        readonly cleanupError?: {
            readonly code: string;
            readonly message: string;
        };
    };
    readonly evidence: {
        readonly execution: 'completed' | 'failed' | 'compile-failed' | 'runner-failed';
        readonly graphId: string;
        readonly graphVersion: string;
        readonly nodeSchedule: readonly string[];
        readonly nodeCompletion: readonly string[];
        readonly hostOperations: readonly string[];
        readonly errorKind?: string;
    };
}
export interface RunnerObservation {
    readonly final?: RunnerFinalFrame;
    readonly exitCode: number | null;
    readonly signal: NodeJS.Signals | null;
    readonly stderr: string;
    readonly finalCount: number;
}
/**
 * Run one Teams Work graph execution through the real SDK runner and the real
 * AgentWorkClient. Returns exactly one typed ProjectExecutionReceipt; provider
 * resource responsibility stays in the provider ledger.
 */
export declare function runWorkExecution(client: AgentWorkClient, request: WorkExecutionRequest): Promise<ProjectExecutionReceipt>;
