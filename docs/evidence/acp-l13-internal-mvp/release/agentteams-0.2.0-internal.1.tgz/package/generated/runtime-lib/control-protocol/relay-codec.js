import { parseEndpointDiscoveryView } from "./endpoint-ref.js";
import { assertEnvelopeKeys, assertJsonValue } from "./json-value.js";
export class RelayProtocolError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}
const errorCodes = [
    'INVALID_INPUT', 'UNAUTHENTICATED', 'FORBIDDEN', 'NOT_FOUND', 'UNSUPPORTED_VERSION',
    'UNSUPPORTED_OPERATION', 'STALE_GENERATION', 'REVISION_CONFLICT', 'RESOURCE_EXHAUSTED',
    'CONFLICT', 'RESULT_UNKNOWN', 'UNAVAILABLE', 'UPSTREAM_ERROR',
];
function invalid(message) {
    throw new RelayProtocolError('INVALID_INPUT', message);
}
function object(value, label) {
    if (typeof value !== 'object' || value === null || Array.isArray(value))
        invalid(`${label} must be an object`);
    return value;
}
function stringValue(value, label) {
    if (typeof value !== 'string' || value.length === 0)
        invalid(`${label} must be a non-empty string`);
    return value;
}
function positiveInteger(value, label) {
    if (!Number.isSafeInteger(value) || value < 1)
        invalid(`${label} must be a positive safe integer`);
    return value;
}
function nonNegativeInteger(value, label) {
    if (!Number.isSafeInteger(value) || value < 0)
        invalid(`${label} must be a non-negative safe integer`);
    return value;
}
function booleanValue(value, label) {
    if (typeof value !== 'boolean')
        invalid(`${label} must be boolean`);
    return value;
}
function enumValue(value, values, label) {
    if (typeof value !== 'string' || !values.includes(value))
        invalid(`${label} is unsupported`);
    return value;
}
function isoDate(value, label) {
    const parsed = stringValue(value, label);
    if (Number.isNaN(Date.parse(parsed)))
        invalid(`${label} must be an ISO date`);
    return parsed;
}
function jsonValue(value, label) {
    try {
        assertJsonValue(value, label);
    }
    catch (error) {
        invalid(error instanceof Error ? error.message : `${label} must contain only JSON values`);
    }
}
function jsonObject(value, label) {
    const input = object(value, label);
    jsonValue(input, label);
    return input;
}
function knownFields(value, fields, label) {
    try {
        assertEnvelopeKeys(value, fields, label);
    }
    catch (error) {
        invalid(error instanceof Error ? error.message : `${label} has unsupported fields`);
    }
}
function parseOperation(value, index) {
    const label = `declaration.capabilities[].operations[${index}]`;
    const input = object(value, label);
    knownFields(input, ['operation', 'inputSchema', 'outputSchema', 'cancellation'], label);
    return {
        operation: stringValue(input.operation, `${label}.operation`),
        inputSchema: jsonObject(input.inputSchema, `${label}.inputSchema`),
        outputSchema: jsonObject(input.outputSchema, `${label}.outputSchema`),
        cancellation: enumValue(input.cancellation, ['unsupported', 'cooperative'], `${label}.cancellation`),
    };
}
function parseResource(value, index) {
    const label = `declaration.capabilities[].resources[${index}]`;
    const input = object(value, label);
    knownFields(input, ['resourceId', 'capacity', 'unit', 'sharing', 'allocationScope'], label);
    return {
        resourceId: stringValue(input.resourceId, `${label}.resourceId`),
        capacity: positiveInteger(input.capacity, `${label}.capacity`),
        unit: enumValue(input.unit, ['slot', 'context'], `${label}.unit`),
        sharing: enumValue(input.sharing, ['exclusive', 'shared'], `${label}.sharing`),
        allocationScope: enumValue(input.allocationScope, ['request', 'work'], `${label}.allocationScope`),
    };
}
function parseCapability(value, index) {
    const label = `declaration.capabilities[${index}]`;
    const input = object(value, label);
    knownFields(input, ['capabilityId', 'version', 'operations', 'resources'], label);
    if (!Array.isArray(input.operations) || !Array.isArray(input.resources))
        invalid(`${label} operations/resources must be arrays`);
    jsonValue(input.operations, `${label}.operations`);
    jsonValue(input.resources, `${label}.resources`);
    return {
        capabilityId: stringValue(input.capabilityId, `${label}.capabilityId`),
        version: stringValue(input.version, `${label}.version`),
        operations: input.operations.map((operation, operationIndex) => parseOperation(operation, operationIndex)),
        resources: input.resources.map((resource, resourceIndex) => parseResource(resource, resourceIndex)),
    };
}
function parseRoute(value, index) {
    const label = `declaration.routes[${index}]`;
    const input = object(value, label);
    knownFields(input, ['candidateId', 'kind', 'endpoint', 'port', 'authRequired', 'lastSeenAt'], label);
    const route = {
        candidateId: stringValue(input.candidateId, `${label}.candidateId`),
        kind: enumValue(input.kind, ['lan', 'tailscale', 'ipv6', 'ipv4', 'gateway', 'relay-ws', 'relay-webrtc'], `${label}.kind`),
        authRequired: booleanValue(input.authRequired, `${label}.authRequired`),
        lastSeenAt: isoDate(input.lastSeenAt, `${label}.lastSeenAt`),
    };
    if (input.endpoint !== undefined)
        route.endpoint = stringValue(input.endpoint, `${label}.endpoint`);
    if (input.port !== undefined) {
        const port = positiveInteger(input.port, `${label}.port`);
        if (port > 65535)
            invalid(`${label}.port is invalid`);
        route.port = port;
    }
    return route;
}
export function parseAgentDeclaration(value) {
    const input = object(value, 'declaration');
    const identityInput = object(input.identity, 'declaration.identity');
    knownFields(input, ['identity', 'scopeId', 'revision', 'capabilities', 'routes'], 'declaration');
    knownFields(identityInput, ['hostId', 'machineId', 'agentId', 'accountId', 'agentKind', 'label'], 'declaration.identity');
    if (!Array.isArray(input.capabilities) || !Array.isArray(input.routes))
        invalid('declaration capabilities/routes must be arrays');
    jsonValue(input.capabilities, 'declaration.capabilities');
    jsonValue(input.routes, 'declaration.routes');
    return {
        identity: {
            hostId: stringValue(identityInput.hostId, 'declaration.identity.hostId'),
            machineId: stringValue(identityInput.machineId, 'declaration.identity.machineId'),
            agentId: stringValue(identityInput.agentId, 'declaration.identity.agentId'),
            accountId: stringValue(identityInput.accountId, 'declaration.identity.accountId'),
            agentKind: enumValue(identityInput.agentKind, ['opencode', 'acp', 'custom'], 'declaration.identity.agentKind'),
            label: stringValue(identityInput.label, 'declaration.identity.label'),
        },
        scopeId: stringValue(input.scopeId, 'declaration.scopeId'),
        revision: positiveInteger(input.revision, 'declaration.revision'),
        capabilities: input.capabilities.map((capability, index) => parseCapability(capability, index)),
        routes: input.routes.map((route, index) => parseRoute(route, index)),
    };
}
export function parseServiceError(value, label) {
    const input = object(value, label);
    knownFields(input, ['code', 'message', 'execution'], label);
    let execution;
    if (input.execution !== undefined) {
        const detail = object(input.execution, `${label}.execution`);
        knownFields(detail, ['kind', 'code', 'message', 'contextId', 'exitCode', 'signal', 'stdout', 'stderr'], `${label}.execution`);
        if (detail.kind !== 'cli')
            invalid(`${label}.execution.kind is unsupported`);
        if (detail.exitCode !== undefined && detail.exitCode !== null && (!Number.isSafeInteger(detail.exitCode) || detail.exitCode < 0))
            invalid(`${label}.execution.exitCode is invalid`);
        if (detail.signal !== undefined && detail.signal !== null)
            stringValue(detail.signal, `${label}.execution.signal`);
        for (const field of ['stdout', 'stderr']) {
            if (detail[field] !== undefined && typeof detail[field] !== 'string')
                invalid(`${label}.execution.${field} must be text`);
        }
        execution = { kind: 'cli', code: stringValue(detail.code, `${label}.execution.code`),
            message: stringValue(detail.message, `${label}.execution.message`),
            ...(detail.contextId === undefined ? {} : { contextId: stringValue(detail.contextId, `${label}.execution.contextId`) }),
            ...(detail.exitCode === undefined ? {} : { exitCode: detail.exitCode }),
            ...(detail.signal === undefined ? {} : { signal: detail.signal }),
            ...(detail.stdout === undefined ? {} : { stdout: detail.stdout }),
            ...(detail.stderr === undefined ? {} : { stderr: detail.stderr }) };
    }
    return {
        code: enumValue(input.code, errorCodes, `${label}.code`),
        message: stringValue(input.message, `${label}.message`),
        ...(execution ? { execution } : {}),
    };
}
function parsePeer(value, index) {
    const label = `peer[${index}]`;
    const input = object(value, label);
    knownFields(input, ['declaration', 'connectionId', 'generation', 'lastSeenAt', 'presence', 'endpoints'], label);
    if (input.endpoints !== undefined && !Array.isArray(input.endpoints))
        invalid(`${label}.endpoints must be an array`);
    return {
        declaration: parseAgentDeclaration(input.declaration),
        connectionId: stringValue(input.connectionId, `${label}.connectionId`),
        generation: positiveInteger(input.generation, `${label}.generation`),
        lastSeenAt: isoDate(input.lastSeenAt, `${label}.lastSeenAt`),
        presence: enumValue(input.presence, ['online', 'offline'], `${label}.presence`),
        ...(input.endpoints === undefined ? {} : {
            endpoints: input.endpoints.map(view => parseEndpointDiscoveryView(view)),
        }),
    };
}
function parseGrant(value, label) {
    const input = object(value, label);
    knownFields(input, ['grantId', 'accountId', 'scopeId', 'sourceAgentId', 'targetAgentId', 'sourceGeneration', 'targetGeneration', 'expiresAt'], label);
    return {
        grantId: stringValue(input.grantId, `${label}.grantId`),
        accountId: stringValue(input.accountId, `${label}.accountId`),
        scopeId: stringValue(input.scopeId, `${label}.scopeId`),
        sourceAgentId: stringValue(input.sourceAgentId, `${label}.sourceAgentId`),
        targetAgentId: stringValue(input.targetAgentId, `${label}.targetAgentId`),
        sourceGeneration: positiveInteger(input.sourceGeneration, `${label}.sourceGeneration`),
        targetGeneration: positiveInteger(input.targetGeneration, `${label}.targetGeneration`),
        expiresAt: isoDate(input.expiresAt, `${label}.expiresAt`),
    };
}
function parseText(text) {
    if (typeof text !== 'string')
        invalid('relay server control must be text');
    try {
        return JSON.parse(text);
    }
    catch {
        invalid('relay server control is not valid JSON');
    }
}
export function parseRelayServerControl(text) {
    const input = object(parseText(text), 'relay server control');
    const kind = stringValue(input.kind, 'kind');
    switch (kind) {
        case 'relay.admitted':
            knownFields(input, ['kind', 'connectionId', 'generation'], kind);
            stringValue(input.connectionId, 'connectionId');
            positiveInteger(input.generation, 'generation');
            return input;
        case 'relay.logged-out':
            knownFields(input, ['kind', 'requestId'], kind);
            stringValue(input.requestId, 'requestId');
            return input;
        case 'relay.directory':
            knownFields(input, ['kind', 'requestId', 'revision', 'peers'], kind);
            stringValue(input.requestId, 'requestId');
            nonNegativeInteger(input.revision, 'revision');
            if (!Array.isArray(input.peers))
                invalid('peers must be an array');
            jsonValue(input.peers, 'peers');
            input.peers.forEach((peer, index) => parsePeer(peer, index));
            return input;
        case 'relay.changed':
            knownFields(input, ['kind', 'revision', 'peer'], kind);
            nonNegativeInteger(input.revision, 'revision');
            parsePeer(input.peer, 0);
            return input;
        case 'relay.grant':
            knownFields(input, ['kind', 'requestId', 'grant'], kind);
            stringValue(input.requestId, 'requestId');
            parseGrant(input.grant, 'grant');
            return input;
        case 'relay.offer':
            knownFields(input, ['kind', 'grant'], kind);
            parseGrant(input.grant, 'grant');
            return input;
        case 'relay.opened':
            knownFields(input, ['kind', 'requestId', 'grantId'], kind);
            stringValue(input.requestId, 'requestId');
            stringValue(input.grantId, 'grantId');
            return input;
        case 'relay.closed':
            knownFields(input, ['kind', 'grantId', 'error'], kind);
            stringValue(input.grantId, 'grantId');
            if (input.error !== undefined)
                parseServiceError(input.error, 'error');
            return input;
        case 'relay.error':
            knownFields(input, ['kind', 'requestId', 'error'], kind);
            if (input.requestId !== undefined)
                stringValue(input.requestId, 'requestId');
            parseServiceError(input.error, 'error');
            return input;
        default:
            invalid(`unknown relay server control: ${kind}`);
    }
}
