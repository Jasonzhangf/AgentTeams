import { type EndpointDiscoveryView } from '../control-protocol/endpoint-ref.ts';
import type { AgentWork, AuthenticatedAgent, CapabilityDeclaration, JsonValue, OperationDeclaration, ResourceAllocation, RequestState, ServiceError, WorkProposal, WorkRequest } from '../control-protocol/agent-services.ts';
export interface WorkServiceError extends Error {
    readonly error: ServiceError;
}
export interface ProviderWorkPolicy {
    readonly revision: number;
    readonly authorizeWork: (consumer: AuthenticatedAgent, proposal: WorkProposal) => boolean;
    readonly authorizeRequest?: (consumer: AuthenticatedAgent, work: AgentWork, operation: OperationDeclaration) => boolean;
}
export interface StoredWorkRequest {
    readonly control: WorkRequest['control'];
    readonly payload: JsonValue;
    readonly state: RequestState;
    readonly response?: JsonValue;
    readonly error?: ServiceError;
    readonly allocationIds: readonly string[];
}
export interface WorkLedgerSnapshot {
    readonly version: 1;
    readonly revision: number;
    readonly provider: AuthenticatedAgent;
    readonly works: readonly AgentWork[];
    readonly requests: readonly StoredWorkRequest[];
    readonly allocations: readonly ResourceAllocation[];
}
export interface WorkStore {
    load(): WorkLedgerSnapshot | undefined;
    save(expectedRevision: number, snapshot: WorkLedgerSnapshot): void;
}
export interface WorkLedgerOptions {
    readonly provider: AuthenticatedAgent;
    readonly generation: number;
    readonly capabilities: readonly CapabilityDeclaration[];
    readonly endpointCatalog?: readonly EndpointDiscoveryView[];
    readonly store: WorkStore;
}
export interface WorkLedger {
    readonly provider: AuthenticatedAgent;
    readonly capabilities: readonly CapabilityDeclaration[];
    readonly endpointCatalog: readonly EndpointDiscoveryView[];
    readonly store: WorkStore;
    currentGeneration: number;
    snapshot: WorkLedgerSnapshot;
}
export interface WorkRequestRecord {
    readonly control: WorkRequest['control'];
    readonly payload: JsonValue;
    readonly state: RequestState;
    readonly response?: JsonValue;
    readonly error?: ServiceError;
    readonly allocations: readonly ResourceAllocation[];
}
export interface RequestWorkResult {
    readonly request: WorkRequestRecord;
    readonly executionAllowed: boolean;
    readonly duplicate: boolean;
}
export interface RequestCompletion {
    readonly outcome: 'succeeded' | 'failed' | 'cancelled' | 'unknown';
    readonly payload?: JsonValue;
    readonly error?: ServiceError;
}
export interface RecoveryAllocationObservation {
    readonly allocationId: string;
    readonly state: 'held' | 'released' | 'unknown';
}
export interface RecoveryObservation {
    readonly workId: string;
    readonly requestId?: string;
    readonly requestState?: RequestState;
    /** Terminal reconciliation must carry trusted completion data, not only a state label. */
    readonly completion?: RequestCompletion;
    readonly allocations?: readonly RecoveryAllocationObservation[];
}
/** Local authority is never part of WorkRequestControl or any remote reply. */
export interface TrustedWorkAuthority {
    readonly kind: 'trusted-local-work-authority';
}
export interface FileLockOwnerIdentity {
    readonly pid: number;
    readonly startToken: string;
}
export interface FileLockRecoveryProof {
    readonly ownerPid: number;
    readonly ownerStartToken: string;
    readonly lockToken: string;
}
export type VerifyFileLockOwnerExited = (owner: FileLockOwnerIdentity) => boolean;
/**
 * The runtime persists this token beside its daemon lease so it can prove that
 * a stale work-store lock belonged to the previous daemon owner. It is never
 * sent over the network or included in Work payloads.
 */
export declare function currentWorkProcessStartToken(): string;
export declare function createTrustedWorkAuthority(): TrustedWorkAuthority;
export declare function isWorkServiceError(error: unknown): error is WorkServiceError;
export declare function readFileWorkStoreLockProof(filePath: string): FileLockRecoveryProof | undefined;
/**
 * Remove a crashed writer lock only after the daemon owner proves the exact
 * PID/start-token pair exited. The daemon must serialize recovery with any
 * replacement writer; this API never uses lock age or a timeout as proof.
 */
export declare function recoverFileWorkStoreLock(filePath: string, authority: TrustedWorkAuthority, proof: FileLockRecoveryProof, verifyOwnerExited: VerifyFileLockOwnerExited): void;
export declare function createFileWorkStore(filePath: string): WorkStore;
export declare function createWorkLedger(options: WorkLedgerOptions): WorkLedger;
export declare function proposeWork(ledger: WorkLedger, authenticatedConsumer: AuthenticatedAgent, proposal: WorkProposal, policy: ProviderWorkPolicy): AgentWork;
export declare function requestWork(ledger: WorkLedger, input: {
    readonly authenticatedConsumer: AuthenticatedAgent;
    readonly request: WorkRequest;
    readonly policy: ProviderWorkPolicy;
}): RequestWorkResult;
export declare function getRequest(ledger: WorkLedger, workId: string, requestId: string): WorkRequestRecord;
export declare function requestCancellation(ledger: WorkLedger, authenticatedConsumer: AuthenticatedAgent, workId: string, requestId: string): WorkRequestRecord;
export declare function completeRequest(ledger: WorkLedger, authority: TrustedWorkAuthority, workId: string, requestId: string, completion: RequestCompletion): WorkRequestRecord;
export declare function closeWork(ledger: WorkLedger, authenticatedConsumer: AuthenticatedAgent, workId: string): AgentWork;
export declare function confirmWorkDestroyed(ledger: WorkLedger, authority: TrustedWorkAuthority, workId: string): AgentWork;
export declare function recover(ledger: WorkLedger, authority: TrustedWorkAuthority, observations: readonly RecoveryObservation[]): WorkLedger;
