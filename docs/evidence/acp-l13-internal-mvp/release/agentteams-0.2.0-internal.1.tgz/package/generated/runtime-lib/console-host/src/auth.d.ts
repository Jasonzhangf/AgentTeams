import type { IncomingMessage } from 'node:http';
import type { ConsoleClientV1 } from '../../control-protocol/console-api.ts';
/** Credentials are supplied by runtime; daemon management policy remains independent. */
export declare function createConsoleAuthorization(options: {
    readonly username: string;
    readonly password: string;
    readonly origin: string;
    readonly client: ConsoleClientV1;
}): (request: IncomingMessage) => Promise<ConsoleClientV1 | undefined>;
