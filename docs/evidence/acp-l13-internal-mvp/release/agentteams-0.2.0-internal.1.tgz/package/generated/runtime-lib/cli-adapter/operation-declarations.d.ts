import type { OperationDeclaration } from '../control-protocol/agent-services.ts';
import type { CliOperation } from './contracts.ts';
/** Public argument/result schemas. Operation selection stays in Work control. */
export declare const cliOperationDeclarations: Readonly<Record<CliOperation, OperationDeclaration>>;
