import { type DaemonIntentV4, type DiscoveryServerConfig } from '../config/daemon-intent.ts';
import type { AgentDeclaration, CapabilityDeclaration } from '../control-protocol/agent-services.ts';
import type { RouteCandidate } from '../server/directory.ts';
import { type RegistrationClient, type RegistrationReconnectPolicy, type RegistrationStatus } from '../network/registration-client.ts';
/**
 * Runtime single writer that selects the registration endpoint from one v4
 * daemon config and composes the network registration client.
 *
 * Config selection is explicit: a config without `[discovery]` reports
 * `discovery-not-configured` and opens no socket. The client never switches to
 * another server, and a registry outage only changes the registration status;
 * it never stops the engine that hosts the daemon.
 */
export interface RegistrationDisabledPlan {
    readonly state: 'disabled';
    readonly reason: 'discovery-not-configured';
}
export interface RegistrationEnabledPlan {
    readonly state: 'enabled';
    readonly discovery: DiscoveryServerConfig;
    readonly heartbeatIntervalMs: number;
    readonly reconnect: RegistrationReconnectPolicy;
}
export type RegistrationPlan = RegistrationDisabledPlan | RegistrationEnabledPlan;
/**
 * Client-owned operational defaults. The frozen v4 schema has no heartbeat or
 * backoff field, so the client owns these values; they are not a second config
 * source. The heartbeat stays well inside the server-owned 90s presence lease.
 */
export declare const DEFAULT_REGISTRATION_HEARTBEAT_INTERVAL_MS = 15000;
export declare const DEFAULT_REGISTRATION_RECONNECT: RegistrationReconnectPolicy;
export type RegistrationProcessErrorCode = 'INVALID_CONFIG' | 'UNAUTHENTICATED' | 'UNSUPPORTED_CONFIGURATION' | 'NOT_FOUND';
export declare class RegistrationProcessError extends Error {
    readonly code: RegistrationProcessErrorCode;
    constructor(code: RegistrationProcessErrorCode, message: string, cause?: unknown);
}
/** Pure selection: the config either declares one discovery server or disables discovery. */
export declare function resolveRegistrationPlan(intent: DaemonIntentV4): RegistrationPlan;
export interface RegistrationBootstrap {
    readonly credential: string;
    readonly ca: Buffer;
}
export interface RegistrationBootstrapOptions {
    readonly env?: NodeJS.ProcessEnv;
    readonly readFile?: (path: string) => Promise<string>;
}
/**
 * Reads the discovery credential and the TLS trust anchor exactly once. The
 * credential value never enters a declaration, a directory entry or a log line.
 */
export declare function loadRegistrationBootstrap(discovery: DiscoveryServerConfig, options?: RegistrationBootstrapOptions): Promise<RegistrationBootstrap>;
/**
 * Publishes the declared daemon identity. The frozen v4 schema has no separate
 * machineId, agentKind or label, so the declared `hostId` is the machine
 * identity and `id` is the label. `agentKind` reports what this daemon actually
 * serves: a v4 agent daemon with a declared engine carries the ACP increment and
 * declares `acp`; a daemon without an engine, and a control daemon, declare
 * `custom`. Nothing is guessed about authority: capabilities and routes start
 * empty and are published by the owning daemon.
 */
export declare function declarationForDaemon(intent: DaemonIntentV4): AgentDeclaration;
export type AgentRegistration = {
    readonly state: 'disabled';
    readonly reason: 'discovery-not-configured';
    readonly status: RegistrationStatus;
} | {
    readonly state: 'enabled';
    readonly client: RegistrationClient;
    readonly status: RegistrationStatus;
};
export interface PublishedDaemonSurfaces {
    readonly capabilities: readonly CapabilityDeclaration[];
    readonly routes: readonly RouteCandidate[];
}
/**
 * R4: the daemon's real listener route, projected from the declared listener.
 * A daemon that declares no listener publishes no route. This is a projection of
 * the one declared listener, not a second endpoint or directory source.
 */
export declare function listenerRouteCandidates(intent: DaemonIntentV4, observedAt: string): readonly RouteCandidate[];
/**
 * R4: one additive publication of the daemon's real surfaces (listener route
 * plus ACP capability) over the existing D04 registration path. Identity, scope
 * and agentKind are preserved and the declaration revision advances by one, so
 * the directory observes a new `capabilitiesRevision`. It adds no second
 * registry, directory or publication path.
 */
export declare function declarationWithPublishedSurfaces(declaration: AgentDeclaration, surfaces: PublishedDaemonSurfaces): AgentDeclaration;
/**
 * Composes one config-selected registration for a consumer such as D05/D06. A
 * disabled plan reports `disabled` and opens no socket; a failed first attempt
 * returns the typed reconnecting status with the original error while retries
 * continue in the background.
 */
export declare function startDaemonRegistration(intent: DaemonIntentV4, options?: RegistrationBootstrapOptions & {
    readonly heartbeatIntervalMs?: number;
    readonly reconnect?: RegistrationReconnectPolicy;
    readonly onStatus?: (status: RegistrationStatus) => void;
}): Promise<AgentRegistration>;
export interface RegistrationProcessArgs {
    readonly configPath: string;
    readonly statusFile?: string;
    readonly query: boolean;
    readonly heartbeatIntervalMs?: number;
}
export declare function parseRegistrationProcessArgs(argv: readonly string[]): RegistrationProcessArgs;
/**
 * Process entry for one registration client. `--query` registers, reads the
 * scoped directory once and exits with the first attempt's outcome (no retry);
 * without it the client keeps its heartbeat until SIGTERM/SIGINT. A config
 * without `[discovery]` reports disabled and exits without a socket.
 */
export declare function runRegistrationProcess(argv?: readonly string[], env?: NodeJS.ProcessEnv): Promise<number>;
