import { AcpError, parseAcpFault } from "./acp.js";
import { parseConsoleProjection } from "./console-api.js";
/**
 * Public Teams lifecycle and history read surface. Owner: control-protocol.
 * Version: 1 for the connection-status and history-query shapes below.
 *
 * Request/execution lifecycle is intentionally NOT redefined here. The canonical
 * vocabulary stays `RequestState` in `agent-services.ts`; registration presence
 * stays the server directory health vocabulary. This module only adds the two
 * facts no existing owner declares: the transport/negotiation lifecycle of one
 * Teams connection, and the history read request/response shape.
 */
export const TEAMS_CONNECTION_STATUS_VERSION = 1;
export const TEAMS_HISTORY_QUERY_VERSION = 1;
export const TEAMS_CONNECTION_STATES = [
    'disconnected',
    'connecting',
    'authenticating',
    'negotiating',
    'ready',
    'closed',
    'failed',
];
function fail(message) {
    // Malformed DTOs reuse the single fault carrier; this module declares no
    // second error class or code vocabulary.
    throw new AcpError('INVALID_ACP_FRAME', message);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function unknownKeys(value, allowed, label) {
    const unknown = Object.keys(value).filter(key => !allowed.includes(key));
    if (unknown.length > 0)
        fail(`${label} has unsupported fields: ${unknown.join(', ')}`);
}
function text(value, label) {
    if (typeof value !== 'string' || value.length === 0)
        fail(`${label} must be a non-empty string`);
    return value;
}
export function parseTeamsConnectionState(value) {
    if (typeof value !== 'string' || !TEAMS_CONNECTION_STATES.includes(value)) {
        fail(`Teams connection state is unsupported: ${String(value)}`);
    }
    return value;
}
export function parseTeamsConnectionStatus(value) {
    if (!isRecord(value))
        fail('Teams connection status must be an object');
    unknownKeys(value, ['version', 'remoteAgentId', 'state', 'targetGeneration', 'observedAt', 'connectionId', 'role', 'error'], 'Teams connection status');
    if (value.version !== TEAMS_CONNECTION_STATUS_VERSION) {
        fail(`Teams connection status version must be ${TEAMS_CONNECTION_STATUS_VERSION}`);
    }
    const state = parseTeamsConnectionState(value.state);
    if (!Number.isSafeInteger(value.targetGeneration) || value.targetGeneration < 1) {
        fail('Teams connection status targetGeneration must be a positive integer');
    }
    const observedAt = text(value.observedAt, 'Teams connection status observedAt');
    if (Number.isNaN(Date.parse(observedAt)))
        fail('Teams connection status observedAt must be an ISO timestamp');
    if (value.connectionId !== undefined)
        text(value.connectionId, 'Teams connection status connectionId');
    if (value.role !== undefined && value.role !== 'master' && value.role !== 'peer') {
        fail('Teams connection status role must be master or peer');
    }
    if (state === 'failed') {
        if (value.error === undefined)
            fail('Teams connection status requires an error when failed');
        // The fault shape has one owner; reuse its parser instead of re-checking fields.
        parseAcpFault(value.error);
    }
    else if (value.error !== undefined) {
        fail('Teams connection status carries an error only when failed');
    }
    return value;
}
export function parseHistoryQuery(value) {
    if (!isRecord(value))
        fail('history query must be an object');
    unknownKeys(value, ['version', 'kind', 'agentId', 'sessionId', 'limit', 'beforeSequence'], 'history query');
    if (value.version !== TEAMS_HISTORY_QUERY_VERSION) {
        fail(`history query version must be ${TEAMS_HISTORY_QUERY_VERSION}`);
    }
    if (value.kind !== undefined && value.kind !== 'request' && value.kind !== 'connection') {
        fail('history query kind must be request or connection');
    }
    if (!Number.isSafeInteger(value.limit) || value.limit < 1 || value.limit > 500) {
        fail('history query limit must be an integer from 1 to 500');
    }
    if (value.beforeSequence !== undefined && (!Number.isSafeInteger(value.beforeSequence) || value.beforeSequence < 1)) {
        fail('history query beforeSequence must be a positive integer');
    }
    if (value.agentId !== undefined)
        text(value.agentId, 'history query agentId');
    if (value.sessionId !== undefined)
        text(value.sessionId, 'history query sessionId');
    return value;
}
/** Closed validation of one SSE projection frame; the sequence is the owner's own counter. */
export function parseConsoleProjectionSnapshot(value) {
    if (!isRecord(value))
        fail('projection snapshot must be an object');
    unknownKeys(value, ['seq', 'projection'], 'projection snapshot');
    if (!Number.isSafeInteger(value.seq) || value.seq < 0)
        fail('projection snapshot seq must be a non-negative integer');
    parseConsoleProjection(value.projection);
    return value;
}
const HISTORY_QUERY_FIELDS = ['version', 'kind', 'agentId', 'sessionId', 'limit', 'beforeSequence'];
/**
 * The one HTTP query-string → `HistoryQuery` mapping. It refuses every parameter name
 * outside the frozen query, and every duplicate, before the closed parser runs.
 */
export function historyQueryFromSearchParams(params) {
    for (const key of params.keys()) {
        if (!HISTORY_QUERY_FIELDS.includes(key))
            fail(`history query has unsupported fields: ${key}`);
        if (params.getAll(key).length !== 1)
            fail(`history query has duplicate fields: ${key}`);
    }
    const query = {};
    const version = params.get('version');
    if (version === null || version.length === 0)
        fail('history query version is required');
    query.version = Number(version);
    const limit = params.get('limit');
    if (limit === null || limit.length === 0)
        fail('history query limit is required');
    query.limit = Number(limit);
    const kind = params.get('kind');
    if (kind !== null)
        query.kind = kind;
    const agentId = params.get('agentId');
    if (agentId !== null)
        query.agentId = agentId;
    const sessionId = params.get('sessionId');
    if (sessionId !== null)
        query.sessionId = sessionId;
    const beforeSequence = params.get('beforeSequence');
    if (beforeSequence !== null)
        query.beforeSequence = Number(beforeSequence);
    return parseHistoryQuery(query);
}
