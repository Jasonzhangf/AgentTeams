import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { assertEnvelopeKeys } from "../control-protocol/json-value.js";
import { RelayProtocolError } from "../control-protocol/relay-codec.js";
export function object(value, keys, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new RelayProtocolError('INVALID_INPUT', `${label} must be an object`);
    const record = value;
    assertEnvelopeKeys(record, keys, label);
    return record;
}
export function text(value, label) {
    if (typeof value !== 'string' || !value)
        throw new RelayProtocolError('INVALID_INPUT', `${label} is required`);
    return value;
}
export function number(value, label, max = 2_147_483_647) {
    if (!Number.isSafeInteger(value) || value < 1 || value > max)
        throw new RelayProtocolError('INVALID_INPUT', `${label} is outside its positive integer range`);
    return value;
}
export function credential(value, env) {
    const reference = text(value, 'credential environment reference');
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(reference))
        throw new RelayProtocolError('INVALID_INPUT', 'invalid credential environment reference');
    return text(env[reference], 'configured credential environment');
}
/** Shared runtime bootstrap config owner; credentials never enter declarations. */
export async function loadRelayConfig(input, declaration, configPath, env) {
    const relay = object(input, ['endpoint', 'credentialEnv', 'caFile', 'connectTimeoutMs', 'admissionTimeoutMs', 'requestTimeoutMs',
        'maxMessageBytes', 'maxBufferedBytes', 'maxPendingFrames', 'maxPendingRequests', 'maxDataConnections'], 'relay');
    const auth = credential(relay.credentialEnv, env);
    return { declaration, transport: { endpoint: text(relay.endpoint, 'relay.endpoint'), credential: auth,
            ...(relay.caFile === undefined ? {} : { ca: await readFile(resolve(dirname(configPath), text(relay.caFile, 'relay.caFile'))) }),
            connectTimeoutMs: number(relay.connectTimeoutMs, 'connectTimeoutMs'), maxMessageBytes: number(relay.maxMessageBytes, 'maxMessageBytes'),
            maxBufferedBytes: number(relay.maxBufferedBytes, 'maxBufferedBytes'), maxPendingFrames: number(relay.maxPendingFrames, 'maxPendingFrames') },
        admissionTimeoutMs: number(relay.admissionTimeoutMs, 'admissionTimeoutMs'), requestTimeoutMs: number(relay.requestTimeoutMs, 'requestTimeoutMs'),
        maxPendingRequests: number(relay.maxPendingRequests, 'maxPendingRequests'), maxDataConnections: number(relay.maxDataConnections, 'maxDataConnections') };
}
export function loadDirectListenerConfig(input, declaration, configPath, env) {
    const direct = object(input, ['host', 'port', 'keyFile', 'certFile', 'credentialEnv', 'admissions', 'target', 'maxPayload', 'maxConnections',
        'maxMessageBytes', 'maxBufferedBytes', 'maxPendingFrames', 'helloTimeoutMs'], 'directListener');
    const target = object(direct.target, ['hostId', 'agentId', 'protocolVersion', 'capabilitiesRevision'], 'directListener.target');
    const parsedTarget = {
        hostId: text(target.hostId, 'directListener.target.hostId'),
        agentId: text(target.agentId, 'directListener.target.agentId'),
        protocolVersion: number(target.protocolVersion, 'directListener.target.protocolVersion'),
        capabilitiesRevision: text(target.capabilitiesRevision, 'directListener.target.capabilitiesRevision'),
    };
    if (parsedTarget.hostId !== declaration.identity.hostId || parsedTarget.agentId !== declaration.identity.agentId) {
        throw new RelayProtocolError('INVALID_INPUT', 'directListener.target identity must match Agent identity');
    }
    const admissions = [];
    if (direct.admissions !== undefined) {
        if (!Array.isArray(direct.admissions) || direct.admissions.length === 0)
            throw new RelayProtocolError('INVALID_INPUT', 'directListener.admissions must be a non-empty array');
        const refs = new Set();
        const agents = new Set();
        for (const [index, value] of direct.admissions.entries()) {
            const admission = object(value, ['admissionRef', 'agentId', 'credentialEnv'], `directListener.admissions[${index}]`);
            const admissionRef = text(admission.admissionRef, `directListener.admissions[${index}].admissionRef`);
            const agentId = text(admission.agentId, `directListener.admissions[${index}].agentId`);
            if (refs.has(admissionRef) || agents.has(agentId))
                throw new RelayProtocolError('INVALID_INPUT', 'directListener admissions must have unique references and Agent IDs');
            refs.add(admissionRef);
            agents.add(agentId);
            admissions.push({ admissionRef, agentId, credential: credential(admission.credentialEnv, env) });
        }
    }
    const legacyCredential = direct.admissions === undefined ? credential(direct.credentialEnv, env) : '';
    return {
        ...(direct.host === undefined ? {} : { host: text(direct.host, 'directListener.host') }),
        port: number(direct.port, 'directListener.port', 65535),
        keyFile: resolve(dirname(configPath), text(direct.keyFile, 'directListener.keyFile')),
        certFile: resolve(dirname(configPath), text(direct.certFile, 'directListener.certFile')),
        credential: legacyCredential,
        admissions,
        target: parsedTarget,
        maxPayload: number(direct.maxPayload, 'directListener.maxPayload'),
        maxConnections: number(direct.maxConnections, 'directListener.maxConnections'),
        maxMessageBytes: number(direct.maxMessageBytes, 'directListener.maxMessageBytes'),
        maxBufferedBytes: number(direct.maxBufferedBytes, 'directListener.maxBufferedBytes'),
        maxPendingFrames: number(direct.maxPendingFrames, 'directListener.maxPendingFrames'),
        helloTimeoutMs: number(direct.helloTimeoutMs, 'directListener.helloTimeoutMs'),
    };
}
