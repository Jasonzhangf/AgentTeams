import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { AcpFault } from '../control-protocol/acp.ts';
import type { RelationRole } from '../control-protocol/teams-connection.ts';
import type { AcpPolicySnapshot } from '../config/acp-policy.ts';
import type { AcpHost } from '../agent-host/acp-host.ts';
import type { TeamsConnectionHistory } from './teams-connection-history.ts';
import { type TeamsNegotiationState } from './teams-negotiation.ts';
import { type TeamsConnectionLedger } from './teams-ingress.ts';
import { type TeamsSession } from './teams-session.ts';
/** The byte-level socket this daemon dialed and authenticated. */
export interface TeamsEgressSocket {
    /** Resolves when the socket is gone, from either side. */
    readonly closed: Promise<unknown>;
    read(): Promise<{
        readonly bytes: Buffer;
        readonly binary: boolean;
    }>;
    send(frame: {
        readonly bytes: Buffer;
        readonly binary: boolean;
    }): Promise<void>;
    close(): Promise<void>;
}
export interface TeamsEgressEndpoint {
    /** The authenticated peer identity; never read from a payload. */
    readonly peer: AuthenticatedAgent;
    readonly connection: TeamsEgressSocket;
}
export interface OpenTeamsEgressInput {
    readonly endpoint: TeamsEgressEndpoint;
    /** This daemon's own authenticated identity. */
    readonly self: AuthenticatedAgent;
    readonly selfGeneration: number;
    readonly selfCapabilitiesRevision: string;
    /** The accepted config revision; never a policy snapshot hash. */
    readonly selfPolicyRevision: number;
    readonly allowedRoles: readonly RelationRole[];
    /** The role this side asks for and the role it asks the peer to take. */
    readonly requestedRole: RelationRole;
    readonly requestedPeerRole: RelationRole;
    /** The capabilities this side asks for; the peer admits or refuses each. */
    readonly requestedCapabilities: readonly string[];
    /** The fresh request id for this one negotiation attempt. */
    readonly requestId: string;
    /** The target generation and capability revision from the directory/route. */
    readonly expectedTargetGeneration: number;
    readonly expectedTargetCapabilitiesRevision: string;
    /** The connection id this side allocates for the dialed transport. */
    readonly connectionId: string;
    readonly host: AcpHost;
    readonly policy: AcpPolicySnapshot;
    readonly engineInstanceId: string;
    readonly history: TeamsConnectionHistory;
    readonly ledger: TeamsConnectionLedger;
    readonly timeoutMs?: number;
    readonly openTimeoutMs?: number;
    readonly pollIntervalMs?: number;
    /** Live clock; defaults to the system clock. */
    readonly now?: () => string;
    /** Observable history-write failure; never carried inside a Teams frame. */
    readonly onHistoryFault?: (fault: AcpFault) => void;
}
export interface TeamsEgressHandle {
    readonly connectionId: string;
    readonly peer: AuthenticatedAgent;
    readonly negotiation: TeamsNegotiationState;
    /** The session whose one channel is already open; it serves the peer. */
    readonly session: TeamsSession;
    /** Settles when the session read loop ends; a read-loop failure is recorded, never thrown here. */
    readonly done: Promise<void>;
}
/**
 * Open the initiator side of one authenticated connection.
 *
 * The order is fixed and never rearranged: ledger, negotiation, then the ACP
 * handshake. A rejected or timed-out negotiation records `connection.failed`,
 * marks the ledger entry failed, closes the transport and throws the typed fault,
 * so the dialing caller can report or retry. A peer that agreed but published no
 * D00 amendment A3 engine instance fails inside `session.open()` and is released
 * exactly like any other handshake failure.
 *
 * An agreed negotiation records `connection.negotiated`, creates the session,
 * opens the one channel, records `channel.opened` and starts the read loop; the
 * caller never awaits the loop.
 */
export declare function openTeamsEgress(input: OpenTeamsEgressInput): Promise<TeamsEgressHandle>;
