import type { AgentModelBinding, ModelRef, ProviderInstance, VersionedRuntimeConfig } from '../config/runtime-config.ts';
export type DshProviderApi = 'openai-completions' | 'openai-responses';
/**
 * Engine-side pi-ai route name for a Teams provider instance.
 *
 * The prefix keeps the derived route disjoint from the routes the installed
 * DSH composition already owns (`deepseek-official`, the pi-ai catalog, and any
 * other mounted adapter's route). Registering a route another adapter owns
 * fails DSH plugin loading, so a prefixed name turns a possible collision into
 * an explicit, impossible condition instead of a start failure.
 */
export declare function dshProviderRoute(providerInstanceId: string): string;
/** Map the frozen Teams provider protocol onto the DSH pi-ai wire protocol. */
export declare function dshProviderApi(protocol: ProviderInstance['protocol']): DshProviderApi;
export interface DshPiAiRoute {
    readonly api: DshProviderApi;
    readonly baseURL: string;
    readonly apiKeyEnv?: string;
    readonly models: readonly {
        readonly id: string;
        readonly name: string;
    }[];
}
export interface DshPiAiPatchEntry {
    readonly id: 'llm-pi-ai';
    readonly config: {
        readonly providers: Readonly<Record<string, DshPiAiRoute>>;
    };
}
export interface DshAcpPatchEntry {
    readonly id: 'acp';
    readonly config: {
        readonly provider: string;
        readonly model: string;
    };
}
/** A DSH profile patch list: row-id targeted, last write winning per row. */
export type DshProfilePatch = readonly [DshPiAiPatchEntry, DshAcpPatchEntry];
export interface DshNativeConfig {
    /** The engine route the derived patch selects. */
    readonly providerRoute: string;
    readonly modelId: string;
    /** The Teams model references this derivation proved and carried. */
    readonly modelTargets: readonly ModelRef[];
    /** Launch env key -> Teams credential reference; resolved by the runtime. */
    readonly credentialEnvRefs: Readonly<Record<string, string>>;
    readonly patch: DshProfilePatch;
    readonly patchContent: string;
}
export interface CompileDshNativeConfigInput {
    readonly accepted: VersionedRuntimeConfig;
    readonly binding: AgentModelBinding;
}
/**
 * Derive the DSH profile patch and credential references for one daemon's
 * accepted binding. Every rejection is explicit: a missing, disabled,
 * catalog-less or model-less provider never falls back to a DSH shipped route.
 */
export declare function compileDshNativeConfig(input: CompileDshNativeConfigInput): DshNativeConfig;
