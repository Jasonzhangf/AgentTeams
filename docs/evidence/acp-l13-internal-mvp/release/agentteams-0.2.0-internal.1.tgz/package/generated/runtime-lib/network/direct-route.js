import { parseTargetControlFrame } from "../control-protocol/frames.js";
import { RelayProtocolError } from "../control-protocol/relay-codec.js";
import { activeDirectWssCandidate, beginRouteCandidate, failRouteCandidate, succeedRouteCandidate, } from "./route-plan.js";
import { assertTargetGeneration, beginTargetTransport, closeTargetTransport, receiveHelloAck, } from "./target-transport.js";
import { connectWss } from "./wss-connection.js";
const serviceErrorCodes = new Set([
    'INVALID_INPUT', 'UNAUTHENTICATED', 'FORBIDDEN', 'NOT_FOUND', 'UNSUPPORTED_VERSION',
    'UNSUPPORTED_OPERATION', 'STALE_GENERATION', 'REVISION_CONFLICT', 'RESOURCE_EXHAUSTED',
    'CONFLICT', 'RESULT_UNKNOWN', 'UNAVAILABLE', 'UPSTREAM_ERROR',
]);
export class DirectWssRouteError extends RelayProtocolError {
    plan;
    constructor(code, message, plan) {
        super(code, message);
        this.plan = plan;
    }
}
function codeFromTransport(code) {
    return serviceErrorCodes.has(code) ? code : 'INVALID_INPUT';
}
function codeFromError(error, fallback) {
    if (typeof error === 'object' && error !== null && 'code' in error && typeof error.code === 'string') {
        return codeFromTransport(error.code);
    }
    return fallback;
}
function retiredPlan(active, candidateId, reason) {
    try {
        return failRouteCandidate(active, candidateId, reason);
    }
    catch {
        return active;
    }
}
export async function connectDirectWssTarget(input) {
    if (!Number.isSafeInteger(input.helloTimeoutMs) || input.helloTimeoutMs < 1 || input.helloTimeoutMs > 2_147_483_647) {
        throw new RelayProtocolError('INVALID_INPUT', 'direct-route: hello timeout must be a valid positive timer duration');
    }
    const active = beginRouteCandidate(input.plan);
    let candidate;
    try {
        candidate = activeDirectWssCandidate(active);
    }
    catch (error) {
        const reason = error instanceof Error ? error.message : 'direct-route: active candidate is not direct WSS';
        throw new DirectWssRouteError('INVALID_INPUT', reason, retiredPlan(active, active.candidateOrder[active.cursor], reason));
    }
    const hello = parseTargetControlFrame({
        kind: 'transport.hello',
        targetGeneration: input.hello.targetGeneration,
        protocolVersion: input.hello.protocolVersion,
        hostId: input.hello.hostId,
        agentId: input.hello.agentId,
        capabilitiesRevision: input.hello.capabilitiesRevision,
        source: input.hello.source,
        admissionRef: input.hello.admissionRef,
    });
    let connection;
    let timer;
    try {
        connection = await connectWss(input.transport);
        const established = connection;
        const deadline = new Promise((_, reject) => {
            timer = setTimeout(() => reject(new RelayProtocolError('RESULT_UNKNOWN', 'direct-route: hello deadline elapsed; do not replay')), input.helloTimeoutMs);
        });
        const ready = await Promise.race([
            deadline,
            (async () => {
                await established.send({ bytes: Buffer.from(JSON.stringify(hello)), binary: false });
                const frame = await established.read();
                if (frame.binary)
                    throw new RelayProtocolError('INVALID_INPUT', 'direct-route: hello response must be text');
                let parsed;
                try {
                    parsed = parseTargetControlFrame(JSON.parse(frame.bytes.toString('utf8')));
                }
                catch {
                    throw new RelayProtocolError('INVALID_INPUT', 'direct-route: hello response is not a valid target control frame');
                }
                if (parsed.kind === 'transport.error') {
                    throw new RelayProtocolError(codeFromTransport(parsed.code), parsed.message);
                }
                if (parsed.kind !== 'transport.hello_ack') {
                    throw new RelayProtocolError('INVALID_INPUT', 'direct-route: expected transport.hello_ack');
                }
                if (parsed.targetGeneration !== input.hello.targetGeneration) {
                    throw new RelayProtocolError('STALE_GENERATION', 'direct-route: hello ack generation is stale');
                }
                return parsed;
            })(),
        ]);
        void ready;
        const plan = succeedRouteCandidate(active, candidate.candidateId);
        let state = receiveHelloAck(beginTargetTransport(input.hello));
        const markClosed = (reason) => {
            if (state.state === 'ready' || state.state === 'connecting') {
                state = closeTargetTransport(state, reason);
            }
        };
        const closed = established.closed.then(error => {
            markClosed(error.message);
            return error;
        });
        let reconnecting;
        let successor;
        const reconnect = async () => {
            if (state.state !== 'closed') {
                throw new DirectWssRouteError('CONFLICT', 'direct-route: reconnect requires a closed target', plan);
            }
            if (successor)
                return successor;
            if (reconnecting)
                return reconnecting;
            const attempt = connectDirectWssTarget(input);
            reconnecting = attempt;
            void attempt.then(target => {
                if (reconnecting === attempt)
                    reconnecting = undefined;
                successor = target;
                void target.closed.then(() => {
                    if (successor === target)
                        successor = undefined;
                });
            }, () => { if (reconnecting === attempt)
                reconnecting = undefined; });
            return attempt;
        };
        return {
            connection: established,
            plan,
            get state() { return state; },
            closed,
            assertGeneration: generation => assertTargetGeneration(state, generation),
            close: async (reason = 'direct route closed') => {
                markClosed(reason);
                await established.close();
            },
            reconnect,
        };
    }
    catch (error) {
        try {
            await connection?.close();
        }
        catch { /* socket cleanup is best-effort */ }
        const code = error instanceof RelayProtocolError ? error.code
            : error instanceof SyntaxError ? 'INVALID_INPUT'
                : codeFromError(error, 'UNAVAILABLE');
        const message = error instanceof Error ? error.message : 'direct-route: direct WSS target failed';
        throw new DirectWssRouteError(code, message, retiredPlan(active, candidate.candidateId, message));
    }
    finally {
        if (timer !== undefined)
            clearTimeout(timer);
    }
}
