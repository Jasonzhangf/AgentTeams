import { resolveHostFromDirectory } from "./account-directory.js";
import { activeDirectWssCandidate, buildDirectWssRoutePlan } from "./route-plan.js";
import { connectDirectWssTarget } from "./direct-route.js";
export class PeerRouteError extends Error {
    code;
    constructor(code, message, cause) {
        super(message, { cause });
        this.code = code;
    }
}
function requiredString(value, label) {
    if (typeof value !== 'string' || value.length === 0) {
        throw new PeerRouteError('INVALID_INPUT', `peer-route: ${label} is required`);
    }
    return value;
}
function positiveSafeInteger(value, label) {
    if (!Number.isSafeInteger(value) || value < 1) {
        throw new PeerRouteError('INVALID_INPUT', `peer-route: ${label} must be a positive safe integer`);
    }
    return value;
}
function confirmedDirectoryGeneration(directory) {
    if (directory.confirmedGeneration === undefined) {
        throw new PeerRouteError('STALE_GENERATION', 'peer-route: confirmed directory generation is required');
    }
    if (directory.confirmedGeneration !== directory.generation) {
        throw new PeerRouteError('STALE_GENERATION', 'peer-route: confirmed directory generation is stale');
    }
    return directory.confirmedGeneration;
}
function assertTargetGeneration(directory, hostId, targetGeneration) {
    const requestedGeneration = positiveSafeInteger(targetGeneration, 'targetGeneration');
    const peerState = directory.peerStates?.find(peer => peer.hostId === hostId);
    if (!peerState) {
        throw new PeerRouteError('STALE_GENERATION', `peer-route: confirmed directory peer generation is missing for host ${hostId}`);
    }
    if (peerState.presence !== 'online') {
        throw new PeerRouteError('UNAVAILABLE', `peer-route: target host is not online (${peerState.presence})`);
    }
    if (peerState.generation !== requestedGeneration) {
        throw new PeerRouteError('STALE_GENERATION', `peer-route: target generation is stale for host ${hostId}`);
    }
    return requestedGeneration;
}
function readyPeer(directory, hostId) {
    const resolvedHostId = requiredString(hostId, 'hostId');
    let peer;
    try {
        peer = resolveHostFromDirectory(directory, resolvedHostId);
    }
    catch (error) {
        throw new PeerRouteError('NOT_FOUND', `peer-route: unknown peer host ${resolvedHostId}`, error);
    }
    if (peer.accountId !== directory.accountId) {
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: peer host is outside the confirmed account directory');
    }
    requiredString(peer.agentId, 'agentId');
    requiredString(peer.capabilitiesRevision, 'capabilitiesRevision');
    if (peer.health !== 'ready') {
        throw new PeerRouteError('UNAVAILABLE', `peer-route: peer host is not ready (${peer.health})`);
    }
    return peer;
}
function selectedCandidate(peer, candidateId) {
    const selected = peer.routeCandidates.find(candidate => candidate.candidateId === requiredString(candidateId, 'targetCandidateId'));
    if (!selected)
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: selected target candidate is missing');
    return selected;
}
function bindingFor(directoryGeneration, targetGeneration, binding, kind, candidateId) {
    return {
        kind,
        connectionId: requiredString(binding.connectionId, 'connectionId'),
        connectionGeneration: positiveSafeInteger(binding.connectionGeneration, 'connectionGeneration'),
        directoryGeneration,
        targetGeneration: positiveSafeInteger(targetGeneration, 'targetGeneration'),
        candidateId: requiredString(candidateId, 'targetCandidateId'),
    };
}
function validateProtocolAndTimeout(protocolVersion, helloTimeoutMs) {
    positiveSafeInteger(protocolVersion, 'protocol version');
    positiveSafeInteger(helloTimeoutMs, 'hello timeout');
    if (helloTimeoutMs > 2_147_483_647) {
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: hello timeout must be a valid positive timer duration');
    }
}
function validateTransport(transport) {
    if (typeof transport.credential !== 'string' || transport.credential.length === 0 || /[\r\n]/.test(transport.credential)) {
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: a valid authorization credential is required');
    }
    for (const key of ['connectTimeoutMs', 'maxMessageBytes', 'maxBufferedBytes', 'maxPendingFrames']) {
        positiveSafeInteger(transport[key], key);
    }
    if (transport.connectTimeoutMs > 2_147_483_647) {
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: connection timeout exceeds timer range');
    }
}
function relayKind(candidate) {
    if (candidate.kind !== 'relay-ws' && candidate.kind !== 'relay-webrtc') {
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: selected target candidate is a direct candidate');
    }
    return candidate.kind;
}
export function assembleDirectWssTargetOptions(input) {
    const directoryGeneration = confirmedDirectoryGeneration(input.directory);
    const peer = readyPeer(input.directory, input.hostId);
    const targetGeneration = assertTargetGeneration(input.directory, peer.hostId, input.targetGeneration);
    const targetCandidate = selectedCandidate(peer, input.targetCandidateId);
    if (targetCandidate.kind === 'relay-ws' || targetCandidate.kind === 'relay-webrtc') {
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: selected target candidate is a relay candidate');
    }
    validateProtocolAndTimeout(input.protocolVersion, input.helloTimeoutMs);
    if (!input.admissionRef || !input.source.accountId || !input.source.scopeId || !input.source.agentId) {
        throw new PeerRouteError('INVALID_INPUT', 'peer-route: direct admission source and reference are required');
    }
    validateTransport(input.transport);
    let plan;
    let candidate;
    try {
        plan = buildDirectWssRoutePlan({
            hostId: peer.hostId,
            directoryGeneration,
            policy: 'manual',
            candidates: [targetCandidate],
            targetCandidateId: input.targetCandidateId,
        });
        candidate = activeDirectWssCandidate(plan);
    }
    catch (error) {
        throw new PeerRouteError('INVALID_INPUT', error instanceof Error ? `peer-route: ${error.message}` : 'peer-route: direct route is invalid', error);
    }
    return {
        kind: 'direct-wss',
        transport: { ...input.transport, endpoint: candidate.endpoint },
        hello: {
            hostId: peer.hostId,
            agentId: peer.agentId,
            targetGeneration,
            protocolVersion: input.protocolVersion,
            capabilitiesRevision: peer.capabilitiesRevision,
            source: input.source,
            admissionRef: input.admissionRef,
        },
        plan,
        helloTimeoutMs: input.helloTimeoutMs,
        peerRoute: bindingFor(directoryGeneration, targetGeneration, input.binding, 'direct-wss', targetCandidate.candidateId),
    };
}
export function assembleRelayPeerRoute(input) {
    const directoryGeneration = confirmedDirectoryGeneration(input.directory);
    const peer = readyPeer(input.directory, input.hostId);
    const targetGeneration = assertTargetGeneration(input.directory, peer.hostId, input.targetGeneration);
    const candidate = selectedCandidate(peer, input.targetCandidateId);
    const kind = relayKind(candidate);
    const peerRoute = bindingFor(directoryGeneration, targetGeneration, input.binding, kind, candidate.candidateId);
    return {
        kind: 'relay',
        peerRoute: peerRoute,
        target: {
            hostId: peer.hostId,
            agentId: peer.agentId,
            capabilitiesRevision: peer.capabilitiesRevision,
            targetGeneration,
        },
    };
}
export function assemblePeerRoute(input) {
    return 'transport' in input ? assembleDirectWssTargetOptions(input) : assembleRelayPeerRoute(input);
}
export function connectDirectPeerRoute(input) {
    return connectDirectWssTarget(assembleDirectWssTargetOptions(input));
}
export function assertPeerRouteBinding(route, expected) {
    if (route.connectionId !== requiredString(expected.connectionId, 'connectionId')) {
        throw new PeerRouteError('CONFLICT', 'peer-route: connection binding does not match the selected route');
    }
    if (route.connectionGeneration !== positiveSafeInteger(expected.connectionGeneration, 'connectionGeneration')) {
        throw new PeerRouteError('STALE_GENERATION', 'peer-route: connection generation is stale');
    }
    if (route.directoryGeneration !== positiveSafeInteger(expected.directoryGeneration, 'directoryGeneration')) {
        throw new PeerRouteError('STALE_GENERATION', 'peer-route: directory generation is stale');
    }
    if (route.targetGeneration !== positiveSafeInteger(expected.targetGeneration, 'targetGeneration')) {
        throw new PeerRouteError('STALE_GENERATION', 'peer-route: target generation is stale');
    }
}
