import { type LocalDaemonEndpointProjection, type LocalSupervisor } from './local-supervisor.ts';
import { loadLocalConfig } from './local-config.ts';
import { type LocalConsolePublicStatus } from './local-work-control.ts';
export interface LocalLauncherStatus {
    readonly configPath: string;
    readonly internalPath: string;
    readonly pid?: number;
    readonly generation: number;
    readonly state: 'stopped' | 'starting' | 'running' | 'failed';
    readonly error?: string;
    readonly endpoints?: readonly LocalDaemonEndpointProjection[];
    readonly console?: LocalConsolePublicStatus;
}
export declare class LocalProcessError extends Error {
    readonly code: 'NOT_RUNNING' | 'STALE_GENERATION' | 'STALE_OWNER' | 'START_TIMEOUT' | 'ALREADY_RUNNING' | 'STARTING' | 'INVALID_STATUS' | 'CONSOLE_NOT_RUNNING' | 'CONSOLE_DISABLED' | 'CONSOLE_CREDENTIAL_MISSING' | 'CONSOLE_PORT_OCCUPIED' | 'CONSOLE_ASSET_MISSING' | 'CONSOLE_RETAINED' | 'CONSOLE_START_FAILED' | 'CONSOLE_STATUS_UNAVAILABLE' | 'CONSOLE_PROCESS_EXITED';
    constructor(code: 'NOT_RUNNING' | 'STALE_GENERATION' | 'STALE_OWNER' | 'START_TIMEOUT' | 'ALREADY_RUNNING' | 'STARTING' | 'INVALID_STATUS' | 'CONSOLE_NOT_RUNNING' | 'CONSOLE_DISABLED' | 'CONSOLE_CREDENTIAL_MISSING' | 'CONSOLE_PORT_OCCUPIED' | 'CONSOLE_ASSET_MISSING' | 'CONSOLE_RETAINED' | 'CONSOLE_START_FAILED' | 'CONSOLE_STATUS_UNAVAILABLE' | 'CONSOLE_PROCESS_EXITED', message: string);
}
export interface LocalProcessStartOptions {
    readonly env?: NodeJS.ProcessEnv;
    readonly nodeExecutable?: string;
    readonly nodeArguments?: readonly string[];
    readonly relayEntry?: string;
    readonly agentEntry?: string;
    readonly consoleEntry?: string;
    readonly startupTimeoutMs?: number;
}
export interface LocalConsoleLifecycleOptions {
    /** Launcher generation guard; a mismatch returns STALE_GENERATION. */
    readonly expectedLauncherGeneration?: number;
    readonly timeoutMs?: number;
}
export declare function parseLocalProcessArgs(argv: readonly string[]): string;
export type LocalSupervisorFactory = (config: Awaited<ReturnType<typeof loadLocalConfig>>) => LocalSupervisor;
export declare function runLocalProcess(argv?: readonly string[], createSupervisor?: LocalSupervisorFactory): Promise<void>;
export declare function startLocalProcess(configPath?: string, options?: LocalProcessStartOptions): Promise<LocalLauncherStatus>;
export declare function statusLocalProcess(configPath?: string): Promise<LocalLauncherStatus>;
export declare function stopLocalProcess(configPath?: string, expectedGeneration?: number): Promise<LocalLauncherStatus>;
export declare function consoleStatusLocalProcess(configPath?: string, options?: LocalConsoleLifecycleOptions): Promise<LocalConsolePublicStatus>;
export declare function consoleStartLocalProcess(configPath?: string, options?: LocalConsoleLifecycleOptions): Promise<LocalConsolePublicStatus>;
export declare function consoleStopLocalProcess(configPath?: string, options?: LocalConsoleLifecycleOptions): Promise<LocalConsolePublicStatus>;
