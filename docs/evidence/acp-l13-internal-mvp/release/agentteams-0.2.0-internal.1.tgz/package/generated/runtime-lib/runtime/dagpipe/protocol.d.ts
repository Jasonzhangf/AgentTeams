import type { AgentWork, JsonValue, ResourceDemand } from '../../control-protocol/agent-services.ts';
import type { AgentWorkServiceSelection, AgentWorkTarget } from '../agent-work-client.ts';
export declare class HostProtocolError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export interface RunnerIdentity {
    readonly project_id: string;
    readonly graph_id: string;
    readonly graph_version: string;
    readonly execution_id: string;
    readonly attempt_id: string;
}
export interface HostCallControlBase {
    readonly request_id: string;
    readonly operator: string;
    readonly node_id: string;
    readonly identity: RunnerIdentity;
}
export interface FindProviderArgs {
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly providerAgentId?: string;
    readonly serviceSelection?: AgentWorkServiceSelection;
}
export interface OpenWorkArgs {
    readonly target: AgentWorkTarget;
}
export interface ProposeWorkArgs {
    readonly channelRef: string;
    readonly workId: string;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly policyRevision: number;
}
export interface RequestWorkArgs {
    readonly channelRef: string;
    readonly workId: string;
    readonly requestId: string;
    readonly operation: string;
    readonly demands: readonly ResourceDemand[];
}
export interface GetWorkArgs {
    readonly channelRef: string;
    readonly workId: string;
    readonly requestId: string;
}
export interface CloseWorkArgs {
    readonly channelRef: string;
    readonly workId: string;
}
export interface DisposeWorkArgs {
    readonly channelRef: string;
}
export type HostCallControl = (HostCallControlBase & {
    readonly operation: 'agentWork.findProvider';
    readonly args: FindProviderArgs;
}) | (HostCallControlBase & {
    readonly operation: 'agentWork.open';
    readonly args: OpenWorkArgs;
}) | (HostCallControlBase & {
    readonly operation: 'agentWork.propose';
    readonly args: ProposeWorkArgs;
}) | (HostCallControlBase & {
    readonly operation: 'agentWork.request';
    readonly args: RequestWorkArgs;
}) | (HostCallControlBase & {
    readonly operation: 'agentWork.get';
    readonly args: GetWorkArgs;
}) | (HostCallControlBase & {
    readonly operation: 'agentWork.close';
    readonly args: CloseWorkArgs;
}) | (HostCallControlBase & {
    readonly operation: 'agentWork.dispose';
    readonly args: DisposeWorkArgs;
});
export interface HostCallFrame {
    readonly type: 'host.call';
    readonly control: HostCallControl;
    /** Original business value only; never operation arguments or control facts. */
    readonly business?: JsonValue;
}
export interface ArcValue {
    readonly id: string;
    readonly version: number;
    readonly schema: string;
    readonly payload: {
        readonly control: Record<string, JsonValue>;
        readonly business?: JsonValue;
    };
}
export interface JournalEvent {
    readonly kind: string;
    readonly node_id?: string;
    readonly [key: string]: unknown;
}
export interface ExecutionResultFrame {
    readonly type: 'execution.result';
    readonly identity: RunnerIdentity;
    readonly compiled: {
        readonly id: string;
        readonly version: string;
        readonly node_ids: readonly string[];
        readonly input_arcs: readonly string[];
        readonly output_arcs: readonly string[];
    };
    readonly outputs: Record<string, ArcValue>;
    readonly journal: readonly JournalEvent[];
}
export interface ExecutionFailureFrame {
    readonly type: 'execution.failure';
    readonly kind: string;
    readonly message: string;
    readonly journal: readonly JournalEvent[];
}
export interface CompileResultFrame {
    readonly type: 'compile.result';
    readonly graph_id: string;
    readonly graph_version: string;
    readonly node_ids: readonly string[];
    readonly capabilities: readonly string[];
}
export interface CompileFailureFrame {
    readonly type: 'compile.failure';
    readonly stage: string;
    readonly message: string;
    readonly graph_id?: string;
    readonly graph_version?: string;
}
export interface RunnerFailureFrame {
    readonly type: 'usage.failure' | 'run.failure';
    readonly message: string;
}
export type RunnerFinalFrame = ExecutionResultFrame | ExecutionFailureFrame | CompileResultFrame | CompileFailureFrame | RunnerFailureFrame;
export type RunnerFrame = HostCallFrame | RunnerFinalFrame;
export declare function decodeRunnerFrame(line: string): RunnerFrame;
export interface HostOperationResult {
    readonly result: JsonValue;
    /** Original business result only; absent when the operation has no business result. */
    readonly business?: JsonValue;
}
export interface HostResultControlBase {
    readonly request_id: string;
    readonly operation: string;
    readonly status: 'ok';
}
export type HostResultControl = (HostResultControlBase & {
    readonly operation: 'agentWork.findProvider';
    readonly result: {
        readonly target: AgentWorkTarget;
    };
}) | (HostResultControlBase & {
    readonly operation: 'agentWork.open';
    readonly result: {
        readonly channelRef: string;
    };
}) | (HostResultControlBase & {
    readonly operation: 'agentWork.propose';
    readonly result: {
        readonly accepted: AgentWork;
    };
}) | (HostResultControlBase & {
    readonly operation: 'agentWork.request';
    readonly result: {
        readonly replyControl: JsonValue;
    };
}) | (HostResultControlBase & {
    readonly operation: 'agentWork.get';
    readonly result: {
        readonly replyControl: JsonValue;
    };
}) | (HostResultControlBase & {
    readonly operation: 'agentWork.close';
    readonly result: {
        readonly work: AgentWork;
    };
}) | (HostResultControlBase & {
    readonly operation: 'agentWork.dispose';
    readonly result: Record<string, never>;
});
export interface HostResultFrame {
    readonly type: 'host.result';
    readonly control: HostResultControl;
    readonly business?: JsonValue;
}
export interface HostErrorFrame {
    readonly type: 'host.error';
    readonly control: {
        readonly request_id: string;
        readonly operation?: string;
        readonly status: 'error';
        readonly error: {
            readonly code: string;
            readonly message: string;
            readonly deliveryState?: 'unconfirmed';
        };
    };
}
export type HostResponseFrame = HostResultFrame | HostErrorFrame;
export declare function requiredString(value: unknown, label: string): string;
export declare function requiredInteger(value: unknown, label: string): number;
export declare function requiredBoolean(value: unknown, label: string): boolean;
export declare function requiredObject(value: unknown, label: string): Record<string, JsonValue>;
export declare function decodeResourceDemands(value: unknown, label: string): readonly ResourceDemand[];
export declare function decodeAgentWorkServiceSelection(value: unknown, label: string): AgentWorkServiceSelection;
