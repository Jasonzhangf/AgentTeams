import type { ServiceError } from '../control-protocol/agent-services.ts';
import type { AcpFault } from '../control-protocol/acp.ts';
import type { RelationRole } from '../control-protocol/teams-connection.ts';
import type { TeamsConnectionState, TeamsConnectionStatus } from '../control-protocol/teams-state.ts';
import type { HostDirectoryEntry, RouteCandidate } from '../server/directory.ts';
import type { AccountDirectorySnapshot } from './account-directory.ts';
import type { RegistrationClientState, RegistrationStatus } from './registration-client.ts';
import type { TeamsConnectionHistoryEntry } from './teams-connection-history.ts';
/**
 * Teams membership and role view (owner: network).
 *
 * It assembles the per-remote-agent frozen `TeamsConnectionStatus` from the
 * three surfaces network already owns: the account directory/route projection,
 * the registration client health, and the live connection observations reported
 * by the session layer. It declares no fourth source and stores nothing.
 *
 * A registry outage is a health fact, not a connection fact: a lost registry
 * never closes, downgrades or rewrites an established channel. Half-open and
 * role facts travel as typed status plus typed connection-history events, never
 * through a Session payload.
 */
export interface MembershipChannelObservation {
    readonly remoteAgentId: string;
    readonly connectionId?: string;
    readonly state: TeamsConnectionState;
    readonly targetGeneration: number;
    readonly role?: RelationRole;
    readonly observedAt: string;
    /** True when the connection is established but its peer stopped answering. */
    readonly halfOpen?: boolean;
    readonly error?: AcpFault;
}
export interface TeamsMembershipInput {
    readonly localAgentId: string;
    readonly directory: AccountDirectorySnapshot;
    readonly registration: RegistrationStatus;
    readonly channels: readonly MembershipChannelObservation[];
    readonly observedAt: string;
}
export interface TeamsMembershipRegistryView {
    readonly state: RegistrationClientState;
    /** True when the registry surface is not online; never a reason to drop a channel. */
    readonly degraded: boolean;
    readonly endpoint?: string;
    readonly lastError?: ServiceError;
}
export interface TeamsMembershipEntry {
    readonly remoteAgentId: string;
    readonly status: TeamsConnectionStatus;
    readonly halfOpen: boolean;
    readonly hosts: readonly HostDirectoryEntry[];
    readonly routes: readonly RouteCandidate[];
}
export interface TeamsMembershipView {
    readonly observedAt: string;
    readonly localAgentId: string;
    readonly registry: TeamsMembershipRegistryView;
    readonly entries: readonly TeamsMembershipEntry[];
}
export declare function projectTeamsMembership(input: TeamsMembershipInput): TeamsMembershipView;
/**
 * Typed connection/role history events for a membership transition.
 *
 * A degraded registry produces one registry event and never a `connection.closed`
 * event. Per-connection events carry the remote agent id; the daemon-wide
 * registry event carries the local agent id.
 */
export declare function membershipHistoryEvents(previous: TeamsMembershipView | undefined, next: TeamsMembershipView): readonly TeamsConnectionHistoryEntry[];
