import type { AgentWork, AuthenticatedAgent, JsonValue, ResourceDemand, WorkProposal, WorkReply } from '../control-protocol/agent-services.ts';
import type { WorkEndpointReference } from '../control-protocol/endpoint-ref.ts';
import { RelayProtocolError } from '../control-protocol/relay-codec.ts';
import type { RelayClient } from '../network/relay-client.ts';
export interface AgentWorkClientOptions {
    readonly timeoutMs: number;
    readonly maxPending: number;
}
export interface AgentWorkTarget {
    readonly providerAgentId: string;
    readonly generation: number;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly serviceSelection: 'endpoint' | 'capability';
    readonly endpoint?: Omit<WorkEndpointReference, 'workId'>;
}
export type AgentWorkServiceSelection = {
    readonly mode: 'endpoint';
} | {
    readonly mode: 'capability';
    readonly providerAgentId: string;
    /** Original Work generation; it is never replaced by the current link generation. */
    readonly targetGeneration: number;
    /** Exact pins the original generation; current resolves the current authorized generation. */
    readonly generationPolicy: 'exact' | 'current';
    /** Query-only current authorized generation. Omit to resolve the current generation. */
    readonly linkGeneration?: number;
};
export interface FindProviderInput {
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    /** Legacy endpoint callers may omit this; persistent callers must pass capability explicitly. */
    readonly serviceSelection?: AgentWorkServiceSelection;
    readonly providerAgentId?: string;
}
/** A local transport failure after dispatch; the provider may or may not have observed the command. */
export declare class AgentWorkTransportError extends RelayProtocolError {
    readonly deliveryState: "unconfirmed";
}
export interface AgentWorkChannel {
    propose(proposal: Omit<WorkProposal, 'consumerAgentId' | 'providerAgentId'>): Promise<AgentWork>;
    request(input: {
        readonly workId: string;
        readonly requestId: string;
        readonly operation: string;
        readonly demands: readonly ResourceDemand[];
        readonly payload: JsonValue;
    }): Promise<WorkReply>;
    get(workId: string, requestId: string): Promise<WorkReply>;
    close(workId: string): Promise<AgentWork>;
    dispose(): Promise<void>;
    readonly closed: Promise<Error>;
}
export interface AgentWorkClient {
    findProvider(input: FindProviderInput): Promise<AgentWorkTarget>;
    open(target: AgentWorkTarget): Promise<AgentWorkChannel>;
    dispose(): Promise<void>;
}
export declare function createAgentWorkClient(relay: RelayClient, consumerIdentity: AuthenticatedAgent, input: AgentWorkClientOptions): AgentWorkClient;
