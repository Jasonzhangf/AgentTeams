import { type WorkWireReply, type WorkWireRequest } from '../control-protocol/work-wire.ts';
import type { WssConnection } from './wss-connection.ts';
type Command = WorkWireRequest extends infer T ? T extends WorkWireRequest ? Omit<T, 'correlationId'> : never : never;
export interface WorkChannelOptions {
    readonly timeoutMs: number;
    readonly maxPending: number;
    readonly maxIncoming: number;
    /** Handler is bound to the authenticated peer by the runtime, outside business content. */
    readonly onRequest?: (request: WorkWireRequest) => Promise<WorkWireReply>;
}
export interface WorkChannel {
    request(command: Command): Promise<WorkWireReply>;
    readonly closed: Promise<Error>;
    close(): Promise<void>;
}
export declare function createWorkChannel(socket: WssConnection, input: WorkChannelOptions): WorkChannel;
export {};
