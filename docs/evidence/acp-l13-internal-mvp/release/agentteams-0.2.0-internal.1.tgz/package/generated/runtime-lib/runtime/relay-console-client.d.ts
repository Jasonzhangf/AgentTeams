import type { ConsoleClientV1, ConsoleServiceError } from '../control-protocol/console-api.ts';
import type { RelayClient } from '../network/relay-client.ts';
export declare class ConsoleProjectionError extends Error {
    readonly error: ConsoleServiceError;
    constructor(error: ConsoleServiceError);
}
/**
 * One Agent binding over the existing authenticated relay; directory state never grants management rights.
 * A Session message carries a whole model turn, so its exchange gets its own deadline: the
 * control deadline must stay tight, because a hung Agent must fail fast for projection and commands.
 */
export declare function createRelayConsoleClient(relay: RelayClient, agentId: string, timeoutMs: number, sessionTimeoutMs?: number): ConsoleClientV1;
