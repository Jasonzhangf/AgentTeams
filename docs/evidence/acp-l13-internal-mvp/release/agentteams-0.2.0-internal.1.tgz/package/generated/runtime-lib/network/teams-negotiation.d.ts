import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { AcpFault } from '../control-protocol/acp.ts';
import type { RelationRole, TeamsAgreement, TeamsConnectionFrame } from '../control-protocol/teams-connection.ts';
/**
 * Teams negotiation state machine (owner: network).
 *
 * It carries ACP setup over the frozen D00 Teams frames only
 * (`teams.connection.context|propose|accept|reject|confirm|ready`). It declares
 * no second envelope, adds no field to `transport.hello`/`hello_ack`, and never
 * reaches an engine: the only way to obtain an agreement is the terminal
 * `agreed` state.
 *
 * Identity is never read from a frame. `self` and `peer` are the authenticated
 * transport identities the caller already established; a frame that names a
 * role, generation, capability revision or capability outside this daemon's
 * accepted facts is refused with a typed `AcpFault`, never downgraded.
 *
 * R3 (D00 amendment A1): `sourcePolicyRevision`/`targetPolicyRevision` are the
 * integer accepted config revision (`config/runtime-config.ts`
 * `acceptedRevision`). They are NOT `AcpPolicySnapshot.revision`, which is a
 * sha256 string; nothing is hashed or truncated here, and a non-integer value is
 * refused as an invalid input. The responder no longer takes the peer revision
 * as an unauthenticated caller input: the initiator's own revision arrives in
 * `propose.sourcePolicyRevision` and the responder's own revision arrives in
 * `context.policyRevision`. The initiator records the context revision as
 * `state.targetPolicyRevision` and requires the accept agreement to echo it.
 */
export type TeamsNegotiationSide = 'initiator' | 'responder';
export type TeamsNegotiationStateName = 'awaiting-context' | 'awaiting-propose' | 'awaiting-accept' | 'awaiting-confirm' | 'awaiting-ready' | 'agreed' | 'rejected';
export interface TeamsInitiatorOptions {
    readonly side: 'initiator';
    /** This side's transport-scoped connection id. */
    readonly connectionId: string;
    readonly self: AuthenticatedAgent;
    readonly peer: AuthenticatedAgent;
    readonly selfGeneration: number;
    readonly selfCapabilitiesRevision: string;
    /** Integer accepted config revision (`acceptedRevision`), not a policy snapshot hash. */
    readonly selfPolicyRevision: number;
    /** `RelationsIntent.allowed` for this daemon. */
    readonly allowedRoles: readonly RelationRole[];
    readonly requestedRole: RelationRole;
    readonly requestedPeerRole: RelationRole;
    readonly requestedCapabilities: readonly string[];
    readonly requestId: string;
    /** The target generation learned from the directory/route; a context must match it. */
    readonly expectedTargetGeneration: number;
    readonly expectedTargetCapabilitiesRevision: string;
}
export interface TeamsResponderOptions {
    readonly side: 'responder';
    /** This side's transport-scoped connection id; a propose must name it. */
    readonly connectionId: string;
    readonly self: AuthenticatedAgent;
    readonly peer: AuthenticatedAgent;
    readonly selfGeneration: number;
    readonly selfCapabilitiesRevision: string;
    /** Integer accepted config revision (`acceptedRevision`), not a policy snapshot hash. */
    readonly selfPolicyRevision: number;
    readonly allowedRoles: readonly RelationRole[];
    /** Capabilities this daemon admits for one connection. */
    readonly admittedCapabilities: readonly string[];
    /**
     * D00 amendment A3: this responder's own live engine instance. It is published
     * on `teams.connection.context` so the initiator can name it on `acp.open`.
     */
    readonly engineInstanceId: string;
}
export type TeamsNegotiationOptions = TeamsInitiatorOptions | TeamsResponderOptions;
export interface TeamsNegotiationState {
    readonly side: TeamsNegotiationSide;
    readonly state: TeamsNegotiationStateName;
    readonly options: TeamsNegotiationOptions;
    readonly self: AuthenticatedAgent;
    readonly peer: AuthenticatedAgent;
    readonly connectionId: string;
    readonly selfGeneration: number;
    readonly requestId?: string;
    /** The responder's transport connection id, learned from the context frame. */
    readonly targetConnectionId?: string;
    readonly targetGeneration?: number;
    readonly targetCapabilitiesRevision?: string;
    /**
     * The responder's integer accepted config revision, learned from
     * `context.policyRevision`. The accept agreement must echo it.
     */
    readonly targetPolicyRevision?: number;
    /**
     * D00 amendment A3: the responder's live engine instance, learned from
     * `context.engineInstanceId`. The initiator names it on `acp.open`, and the
     * responder refuses a different value with `STALE_GENERATION`.
     */
    readonly targetEngineInstanceId?: string;
    readonly agreement?: TeamsAgreement;
    readonly fault?: AcpFault;
}
export interface TeamsNegotiationStep {
    readonly state: TeamsNegotiationState;
    readonly outbound?: TeamsConnectionFrame;
}
export interface TeamsNegotiationPort {
    read(): Promise<unknown>;
    send(frame: TeamsConnectionFrame): Promise<void>;
}
export declare function startTeamsNegotiation(options: TeamsNegotiationOptions): TeamsNegotiationStep;
export declare function receiveTeamsNegotiationFrame(state: TeamsNegotiationState, frame: unknown): TeamsNegotiationStep;
export declare function timeoutTeamsNegotiation(state: TeamsNegotiationState, message?: string): TeamsNegotiationState;
/** The one agreed connection. Refuses every state that is not `agreed`. */
export declare function negotiatedAgreement(state: TeamsNegotiationState): TeamsAgreement;
export declare function negotiationFault(state: TeamsNegotiationState): AcpFault;
export interface RunTeamsNegotiationInput {
    readonly options: TeamsNegotiationOptions;
    readonly port: TeamsNegotiationPort;
    readonly timeoutMs: number;
}
/**
 * Drives one handshake over an authenticated read/send port. A silent or
 * one-sided peer becomes a typed `RESULT_UNKNOWN` fault; a structurally invalid
 * frame still throws the frozen `INVALID_ACP_FRAME` fault.
 */
export declare function runTeamsNegotiation(input: RunTeamsNegotiationInput): Promise<TeamsNegotiationState>;
