import type { JsonValue } from '../control-protocol/agent-services.ts';
import type { ConfigApplyResult } from './runtime-config.ts';
/**
 * Durable Session-write intent: one record per account and scope.
 *
 * The control daemon writes the Session writes the Console submitted; the agent daemon
 * reads the same record at the shared conventional path (`sessionIntentScopePath`). The
 * record owns only the pending writes and their revision. It never mirrors Session state,
 * transcripts, permission options or credentials, and a reader never falls back to a
 * default when the record is missing or broken.
 *
 * Why a record and not a control-to-agent channel: the user decision recorded for
 * `connection.connect` (2026-10-14) is that the agent daemon reacts on its own and the
 * control daemon only writes desired intent, so no control-to-agent channel exists. A
 * Session write is an event rather than a desired state, so the record carries an ordered
 * window of pending intents and each reading daemon keeps its own consumed watermark in
 * its own directory. Exactly one writer owns the record and its one compare-and-swap
 * fence.
 */
export declare const SESSION_INTENT_VERSION = 1;
export type SessionIntentVersion = typeof SESSION_INTENT_VERSION;
/** Fixed file name inside the account and scope record directory. */
export declare const SESSION_INTENT_FILE_NAME = "session-intent.json";
/**
 * The retained window. The writer drops the oldest intents beyond this count and reports
 * the oldest revision it still carries, so a reader that fell behind refuses instead of
 * skipping a write it can no longer see.
 */
export declare const SESSION_INTENT_WINDOW = 256;
/** The frozen Console permission decision vocabulary (`ConsoleCommandV1` `permission.reply`). */
export type SessionPermissionDecision = 'once' | 'always' | 'reject';
/** One pending Session write. `payload` stays verbatim `JsonValue`-compatible data. */
export type SessionIntent = {
    readonly intentId: string;
    readonly kind: 'permission.reply';
    readonly agentId: string;
    readonly sessionId: string;
    readonly permissionId: string;
    readonly decision: SessionPermissionDecision;
    /**
     * The engine option the Console chose, carried verbatim from the frozen command. The
     * reading daemon must answer with exactly this option, never with a same-kind guess.
     */
    readonly optionId?: string;
} | {
    readonly intentId: string;
    readonly kind: 'session.cancel';
    readonly agentId: string;
    readonly sessionId: string;
} | {
    readonly intentId: string;
    readonly kind: 'session.message';
    readonly agentId: string;
    readonly sessionId: string;
    /** The business body, carried verbatim; the transport never parses or strips it. */
    readonly payload: JsonValue;
};
export interface SessionIntentRecord {
    readonly version: SessionIntentVersion;
    readonly revision: number;
    /** Oldest revision still retained; equals `revision` when no intent was dropped yet. */
    readonly oldestRevision: number;
    readonly intents: readonly SessionIntent[];
    readonly updatedAt: string;
}
/** The three mutations the frozen Session write commands need. */
export type SessionIntentChange = {
    readonly op: 'permission.reply';
    readonly agentId: string;
    readonly sessionId: string;
    readonly permissionId: string;
    readonly decision: SessionPermissionDecision;
    readonly optionId?: string;
} | {
    readonly op: 'session.cancel';
    readonly agentId: string;
    readonly sessionId: string;
} | {
    readonly op: 'session.message';
    readonly agentId: string;
    readonly sessionId: string;
    readonly payload: JsonValue;
};
/** The owning daemon's record path. One derivation serves the writer and the reader. */
export declare function sessionIntentPath(dataDirectory: string): string;
/**
 * The one record path both daemons derive independently.
 *
 * The writer (the control daemon) and the reader (the agent daemon) must agree without a new
 * config key, and the frozen v4 `PeerIntent` carries no peer `dataDirectory`. The identities
 * both sides already carry are the target agent plus the account and scope pair: the writer
 * reads the target peer's `agentId`, `accountId` and `scopeId` from its own declared
 * `peers`, and the reader reads its own `daemon.id`, `daemon.accountId` and
 * `daemon.scopeId`. `~/.agentteams` is the project's established local root and
 * `config/relations-intent-store.ts` already uses the same account and scope convention.
 *
 * One record serves one target agent, so one record has exactly one reading daemon and one
 * writer. A write a daemon cannot apply therefore delays only that daemon's own later
 * writes; it never blocks another agent's.
 *
 * Limitation: a control daemon and an agent daemon in different accounts, scopes or
 * identities resolve different records. The quick-start layout gives both `local`.
 */
export declare function sessionIntentScopeDirectory(input: {
    readonly home: string;
    readonly accountId: string;
    readonly scopeId: string;
    readonly agentId: string;
}): string;
/** The one record path for one target agent. */
export declare function sessionIntentScopePath(input: {
    readonly home: string;
    readonly accountId: string;
    readonly scopeId: string;
    readonly agentId: string;
}): string;
/**
 * The reading daemon's own consumed watermark. It lives in the reader's own data
 * directory, so the writer and the reader never share a fence and the writer's record
 * stays single-writer.
 */
export declare const SESSION_INTENT_WATERMARK_FILE_NAME = "session-intent-watermark.json";
export interface SessionIntentWatermark {
    readonly version: SessionIntentVersion;
    /** Highest revision this daemon already applied. */
    readonly appliedRevision: number;
}
export declare function sessionIntentWatermarkPath(dataDirectory: string): string;
/**
 * Read the durable record. A missing file is `undefined`; a broken file is a typed
 * `RuntimeConfigError` carrying a real `ConfigErrorCode`, never a default.
 */
export declare function readSessionIntentRecord(path: string): Promise<SessionIntentRecord | undefined>;
/**
 * Read the reading daemon's own consumed watermark. A missing file means nothing was
 * applied yet, which is revision `0`.
 */
export declare function readSessionIntentWatermark(path: string): Promise<SessionIntentWatermark>;
/**
 * Persist the reading daemon's own watermark. The reader owns this file alone, so there is
 * no fence here: a lost write only makes the reader apply an intent twice, and the apply
 * path is what refuses an already-satisfied write.
 */
export declare function writeSessionIntentWatermark(path: string, appliedRevision: number): Promise<void>;
/**
 * The reading daemon's view of one record. Both sides derive the intent revision from the
 * same rule, so the derivation lives here rather than in the reader: the intent at index
 * `i` carries revision `oldestRevision + i`.
 *
 * `behind` is the honest refusal. The record carries only a fixed window, so a reader whose
 * watermark is older than the window can no longer see the writes it missed. It must refuse
 * instead of skipping them, and the writer's own retained boundary is the evidence.
 */
export type SessionIntentPending = {
    readonly state: 'pending';
    readonly intents: readonly SessionIntent[];
    readonly throughRevision: number;
} | {
    readonly state: 'behind';
    readonly appliedRevision: number;
    readonly oldestRevision: number;
};
export declare function pendingSessionIntents(record: SessionIntentRecord | undefined, appliedRevision: number): SessionIntentPending;
/**
 * Apply one change with compare-and-swap on the durable revision. The revision is monotonic
 * and starts at 1. `expectedRevision` is the caller's CAS expectation; `0` creates a record
 * that does not exist yet.
 *
 * Input that cannot name a valid change is a `failed` result with `INVALID_INPUT`; a broken
 * stored file is the read's typed throw. A refused write never touches the durable target.
 */
export declare function writeSessionIntentRecord(path: string, expectedRevision: number, next: SessionIntentChange): Promise<ConfigApplyResult>;
