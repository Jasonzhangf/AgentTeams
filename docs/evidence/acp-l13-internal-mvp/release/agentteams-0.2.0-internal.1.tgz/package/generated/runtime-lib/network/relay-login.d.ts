import type { AgentDeclaration } from '../control-protocol/agent-services.ts';
import { type WssConnection, type WssConnectionOptions } from './wss-connection.ts';
export interface RelayLoginOptions {
    readonly transport: WssConnectionOptions;
    readonly declaration: AgentDeclaration;
    readonly admissionTimeoutMs: number;
}
export interface RelayLogin {
    /** Historical admission receipt; readiness also requires a live transport. */
    readonly receipt: {
        readonly connectionId: string;
        readonly generation: number;
    };
    readonly transport: WssConnection;
}
export declare function loginRelay(options: RelayLoginOptions): Promise<RelayLogin>;
