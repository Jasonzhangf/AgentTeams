import { isIP } from 'node:net';
import { homedir } from 'node:os';
import { isAbsolute, resolve } from 'node:path';
import { parse as parseToml } from 'toml';
import { RuntimeConfigError, assertBindingTargets, validateBinding, validateModelEntry, validateProvider, } from "./runtime-config.js";
/** The frozen single-daemon config schema version. One file declares one daemon. */
export const DAEMON_INTENT_VERSION = 4;
export const REGISTRY_IMPLEMENTATION = 'server/Relay';
export class DaemonIntentError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.name = 'DaemonIntentError';
        this.code = code;
    }
}
/**
 * `daemon.kind` is nested, so TypeScript cannot narrow the parent union from
 * `intent.daemon.kind`. These guards keep the narrowing honest instead of
 * casting at each call site. `isAgentIntent` is exported because the `--serve`
 * entry must narrow the same union before it may start an engine.
 */
export function isAgentIntent(intent) {
    return intent.daemon.kind === 'agent';
}
function isControlIntent(intent) {
    return intent.daemon.kind === 'control';
}
function isRegistryIntent(intent) {
    return intent.daemon.kind === 'registry';
}
export function createDaemonIntentContext() {
    return { seen: new Map() };
}
function assertNoDuplicateDaemon(context, daemon) {
    if (context === undefined)
        return;
    const label = `${daemon.kind}:${daemon.id}`;
    const claims = [
        [`identity\u0000${daemon.kind}\u0000${daemon.hostId}\u0000${daemon.accountId}\u0000${daemon.scopeId}\u0000${daemon.id}`, 'duplicate daemon identity'],
        [`owner\u0000${daemon.hostId}\u0000${daemon.accountId}\u0000${daemon.scopeId}`, 'duplicate host/account/scope ownership'],
        [`data\u0000${daemon.dataDirectory}`, 'duplicate dataDirectory'],
    ];
    for (const [key, reason] of claims) {
        const previous = context.seen.get(key);
        if (previous !== undefined)
            fail('CONFLICT', `${reason}: ${label} conflicts with ${previous}`);
    }
    for (const [key] of claims)
        context.seen.set(key, label);
}
/**
 * Identity relations inside one file: a daemon cannot admit or connect to
 * itself, and two peer/admission entries cannot claim the same agent identity.
 */
function assertIdentityRelations(input) {
    const self = input.daemon.id;
    const peers = new Set();
    for (const [name, peer] of Object.entries(input.peers)) {
        if (peer.agentId === self) {
            fail('INVALID_INPUT', `peers.${name}.agentId must not be the daemon's own identity ${self}`);
        }
        if (peers.has(peer.agentId))
            fail('INVALID_INPUT', `peers must not declare duplicate agentId ${peer.agentId}`);
        peers.add(peer.agentId);
    }
    const admitted = new Set();
    for (const admission of input.admissions) {
        if (admission.agentId === self) {
            fail('INVALID_INPUT', `admissions must not admit the daemon's own identity ${self}`);
        }
        if (admitted.has(admission.agentId)) {
            fail('INVALID_INPUT', `admissions must not declare duplicate agentId ${admission.agentId}`);
        }
        admitted.add(admission.agentId);
    }
}
const MODEL_METADATA_KEYS = [
    'label',
    'contextWindow',
    'maxOutputTokens',
    'tools',
    'streaming',
    'reasoning',
    'inputModalities',
    'outputModalities',
];
const DAEMON_ID = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
const ENV_NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;
function fail(code, message) {
    throw new DaemonIntentError(code, message);
}
/**
 * Reuse the canonical config validators. Provider and model semantics have one
 * implementation; the intent parser only maps file fields onto it.
 */
function reuseConfigValidation(validate) {
    try {
        validate();
    }
    catch (error) {
        if (error instanceof RuntimeConfigError)
            fail(error.code, error.message);
        throw error;
    }
}
function record(value, label) {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        fail('INVALID_INPUT', `${label} must be a table`);
    }
    return value;
}
function fields(value, allowed, label) {
    const unknown = Object.keys(value).filter(key => !allowed.includes(key));
    if (unknown.length > 0)
        fail('INVALID_INPUT', `${label} has unsupported fields: ${unknown.join(', ')}`);
}
function requiredString(value, label) {
    if (typeof value !== 'string' || value.trim().length === 0) {
        fail('INVALID_INPUT', `${label} must be a non-empty string`);
    }
    return value;
}
function optionalString(value, label) {
    return value === undefined ? undefined : requiredString(value, label);
}
function boolean(value, fallback, label) {
    if (value === undefined)
        return fallback;
    if (typeof value !== 'boolean')
        fail('INVALID_INPUT', `${label} must be boolean`);
    return value;
}
function stringArray(value, fallback, label) {
    if (value === undefined)
        return fallback;
    if (!Array.isArray(value) || value.some(item => typeof item !== 'string' || item.length === 0)) {
        fail('INVALID_INPUT', `${label} must be an array of non-empty strings`);
    }
    return [...value];
}
function relationRoles(value, fallback, label) {
    if (value === undefined)
        return fallback;
    if (!Array.isArray(value) || value.some(item => item !== 'master' && item !== 'peer')) {
        fail('INVALID_INPUT', `${label} must contain only master or peer`);
    }
    const roles = [...value];
    if (new Set(roles).size !== roles.length)
        fail('INVALID_INPUT', `${label} must not contain duplicates`);
    return roles;
}
function numericPort(value, label) {
    if (!Number.isSafeInteger(value) || value < 1 || value > 65535) {
        fail('INVALID_INPUT', `${label} must be an integer from 1 to 65535`);
    }
    return value;
}
function isLoopback(ip) {
    if (isIP(ip) === 4)
        return ip.startsWith('127.');
    return ip === '::1';
}
function numericIp(value, label) {
    const ip = requiredString(value, label);
    const version = isIP(ip);
    if (version !== 4 && version !== 6)
        fail('INVALID_INPUT', `${label} must be a numeric IPv4 or IPv6 address`);
    if (ip === '0.0.0.0' || ip === '::')
        fail('INVALID_INPUT', `${label} must not be a wildcard address`);
    return ip;
}
function fileRef(value, label) {
    const ref = requiredString(value, label);
    if (!ref.startsWith('file:'))
        fail('INVALID_INPUT', `${label} must use the file: reference form`);
    if (ref.length === 'file:'.length)
        fail('INVALID_INPUT', `${label} must name a file`);
    return ref;
}
function credentialRef(value, label) {
    const ref = requiredString(value, label);
    if (ref.startsWith('env:')) {
        if (!ENV_NAME.test(ref.slice('env:'.length))) {
            fail('INVALID_INPUT', `${label} must use env:NAME with a valid environment-variable name`);
        }
        return ref;
    }
    if (ref.startsWith('file:'))
        return fileRef(ref, label);
    fail('INVALID_INPUT', `${label} must use env:NAME or file:relative-path`);
}
function parseTlsRefs(input, label) {
    const tlsCertRef = input.tlsCertRef === undefined ? undefined : fileRef(input.tlsCertRef, `${label}.tlsCertRef`);
    const tlsKeyRef = input.tlsKeyRef === undefined ? undefined : fileRef(input.tlsKeyRef, `${label}.tlsKeyRef`);
    if ((tlsCertRef === undefined) !== (tlsKeyRef === undefined)) {
        fail('INVALID_INPUT', `${label} TLS requires both tlsCertRef and tlsKeyRef`);
    }
    return {
        ...(tlsCertRef === undefined ? {} : { tlsCertRef }),
        ...(tlsKeyRef === undefined ? {} : { tlsKeyRef }),
    };
}
function assertNonLoopbackAdmission(ip, tls, admissions, label) {
    if (isLoopback(ip))
        return;
    if (tls.tlsCertRef === undefined || tls.tlsKeyRef === undefined) {
        fail('INVALID_INPUT', `${label} requires TLS certificate and key references for a non-loopback address`);
    }
    if (admissions.length === 0) {
        fail('INVALID_INPUT', `${label} requires explicit admissions for a non-loopback address`);
    }
}
function parseIdentity(value, kind) {
    const input = record(value, 'daemon');
    fields(input, ['kind', 'id', 'hostId', 'accountId', 'scopeId', 'dataDirectory'], 'daemon');
    if (input.kind !== kind)
        fail('INVALID_INPUT', `daemon.kind must be ${kind}`);
    const id = requiredString(input.id, 'daemon.id');
    if (!DAEMON_ID.test(id))
        fail('INVALID_INPUT', 'daemon.id is not valid');
    const dataDirectory = requiredString(input.dataDirectory, 'daemon.dataDirectory');
    if (dataDirectory === '.' || dataDirectory === '..') {
        fail('INVALID_INPUT', 'daemon.dataDirectory must name a daemon-owned directory, not the config directory');
    }
    return {
        kind,
        id,
        hostId: requiredString(input.hostId, 'daemon.hostId'),
        accountId: requiredString(input.accountId, 'daemon.accountId'),
        scopeId: requiredString(input.scopeId, 'daemon.scopeId'),
        dataDirectory,
    };
}
function parseEngine(value) {
    const input = record(value, 'engine');
    fields(input, ['kind', 'executable', 'workspace'], 'engine');
    const kind = input.kind;
    if (kind !== 'opencode' && kind !== 'dsh')
        fail('INVALID_INPUT', 'engine.kind must be opencode or dsh');
    const executable = optionalString(input.executable, 'engine.executable');
    if (executable !== undefined && !isAbsolute(executable)) {
        fail('INVALID_INPUT', 'engine.executable must be an absolute installed path');
    }
    const workspace = optionalString(input.workspace, 'engine.workspace');
    return {
        kind,
        ...(executable === undefined ? {} : { executable }),
        ...(workspace === undefined ? {} : { workspace }),
    };
}
function parseListen(value, label) {
    const input = record(value, label);
    fields(input, ['ip', 'port', 'tlsCertRef', 'tlsKeyRef'], label);
    return {
        ip: numericIp(input.ip, `${label}.ip`),
        port: numericPort(input.port, `${label}.port`),
        ...parseTlsRefs(input, label),
    };
}
function parseWebUiAuth(value) {
    const input = record(value, 'webui.auth');
    fields(input, ['username', 'passwordEnv'], 'webui.auth');
    const passwordEnv = requiredString(input.passwordEnv, 'webui.auth.passwordEnv');
    if (!ENV_NAME.test(passwordEnv)) {
        fail('INVALID_INPUT', 'webui.auth.passwordEnv must be an environment-variable name');
    }
    return { username: requiredString(input.username, 'webui.auth.username'), passwordEnv };
}
function assertWebUiPolicy(webui) {
    if (isLoopback(webui.ip))
        return;
    if (webui.auth === undefined)
        fail('AUTHENTICATION_REQUIRED', 'non-loopback webui requires webui.auth');
    if (webui.tlsCertRef === undefined || webui.tlsKeyRef === undefined) {
        fail('INVALID_INPUT', 'non-loopback webui requires TLS certificate and key references');
    }
}
function parseWebUi(value) {
    const input = record(value, 'webui');
    fields(input, ['ip', 'port', 'auth', 'allowedOrigin', 'tlsCertRef', 'tlsKeyRef'], 'webui');
    const ip = numericIp(input.ip, 'webui.ip');
    const auth = input.auth === undefined ? undefined : parseWebUiAuth(input.auth);
    const allowedOrigin = optionalString(input.allowedOrigin, 'webui.allowedOrigin');
    if (allowedOrigin !== undefined) {
        let origin;
        try {
            origin = new URL(allowedOrigin);
        }
        catch {
            fail('INVALID_INPUT', 'webui.allowedOrigin must be an http(s) URL');
        }
        if (origin.protocol !== 'http:' && origin.protocol !== 'https:') {
            fail('INVALID_INPUT', 'webui.allowedOrigin must be an http(s) URL');
        }
    }
    const webui = {
        ip,
        port: numericPort(input.port, 'webui.port'),
        ...(auth === undefined ? {} : { auth }),
        ...(allowedOrigin === undefined ? {} : { allowedOrigin }),
        ...parseTlsRefs(input, 'webui'),
    };
    assertWebUiPolicy(webui);
    return webui;
}
function parseAcp(value) {
    if (value === undefined) {
        return { enabled: false, required: [], blacklist: [], clientCapabilities: [], callbackExecutor: 'controller' };
    }
    const input = record(value, 'acp');
    fields(input, ['enabled', 'required', 'blacklist', 'clientCapabilities', 'callbackExecutor'], 'acp');
    const callbackExecutor = input.callbackExecutor === undefined
        ? 'controller'
        : input.callbackExecutor;
    if (callbackExecutor !== 'controller')
        fail('INVALID_INPUT', 'acp.callbackExecutor must be controller');
    return {
        enabled: boolean(input.enabled, false, 'acp.enabled'),
        required: stringArray(input.required, [], 'acp.required'),
        blacklist: stringArray(input.blacklist, [], 'acp.blacklist'),
        clientCapabilities: stringArray(input.clientCapabilities, [], 'acp.clientCapabilities'),
        callbackExecutor,
    };
}
function parseRelations(value) {
    if (value === undefined)
        return { allowed: ['peer'] };
    const input = record(value, 'relations');
    fields(input, ['allowed'], 'relations');
    return { allowed: relationRoles(input.allowed, ['peer'], 'relations.allowed') };
}
function parseDiscovery(value) {
    const input = record(value, 'discovery');
    fields(input, ['serverId', 'endpoint', 'credentialRef', 'tlsTrustRef'], 'discovery');
    const endpoint = requiredString(input.endpoint, 'discovery.endpoint');
    let url;
    try {
        url = new URL(endpoint);
    }
    catch {
        fail('INVALID_INPUT', 'discovery.endpoint must be a valid wss URL');
    }
    if (url.protocol !== 'wss:')
        fail('INVALID_INPUT', 'discovery.endpoint must use wss');
    return {
        serverId: requiredString(input.serverId, 'discovery.serverId'),
        endpoint,
        credentialRef: credentialRef(input.credentialRef, 'discovery.credentialRef'),
        tlsTrustRef: fileRef(input.tlsTrustRef, 'discovery.tlsTrustRef'),
    };
}
function parsePeer(name, value) {
    const label = `peers.${name}`;
    const input = record(value, label);
    fields(input, ['agentId', 'hostId', 'accountId', 'scopeId', 'endpoint', 'admissionRef', 'credentialRef', 'tlsTrustRef'], label);
    const endpoint = optionalString(input.endpoint, `${label}.endpoint`);
    if (endpoint !== undefined) {
        let url;
        try {
            url = new URL(endpoint);
        }
        catch {
            fail('INVALID_INPUT', `${label}.endpoint must be a valid wss URL`);
        }
        if (url.protocol !== 'wss:')
            fail('INVALID_INPUT', `${label}.endpoint must use wss`);
    }
    const tlsTrustRef = input.tlsTrustRef === undefined ? undefined : fileRef(input.tlsTrustRef, `${label}.tlsTrustRef`);
    if (endpoint !== undefined && tlsTrustRef === undefined) {
        fail('INVALID_INPUT', `${label}.tlsTrustRef is required when an endpoint is explicit`);
    }
    return {
        agentId: requiredString(input.agentId, `${label}.agentId`),
        hostId: requiredString(input.hostId, `${label}.hostId`),
        accountId: requiredString(input.accountId, `${label}.accountId`),
        scopeId: requiredString(input.scopeId, `${label}.scopeId`),
        ...(endpoint === undefined ? {} : { endpoint }),
        ...(input.admissionRef === undefined ? {} : { admissionRef: requiredString(input.admissionRef, `${label}.admissionRef`) }),
        credentialRef: credentialRef(input.credentialRef, `${label}.credentialRef`),
        ...(tlsTrustRef === undefined ? {} : { tlsTrustRef }),
    };
}
function parsePeers(value) {
    if (value === undefined)
        return {};
    const input = record(value, 'peers');
    return Object.fromEntries(Object.entries(input).map(([name, peer]) => [name, parsePeer(name, peer)]));
}
function parseAdmissions(value) {
    if (value === undefined)
        return [];
    if (!Array.isArray(value))
        fail('INVALID_INPUT', 'admissions must be an array of tables');
    const admissions = value.map((entry, index) => {
        const label = `admissions[${index}]`;
        const input = record(entry, label);
        fields(input, ['admissionRef', 'agentId', 'accountId', 'scopeId', 'credentialRef'], label);
        return {
            admissionRef: requiredString(input.admissionRef, `${label}.admissionRef`),
            agentId: requiredString(input.agentId, `${label}.agentId`),
            accountId: requiredString(input.accountId, `${label}.accountId`),
            scopeId: requiredString(input.scopeId, `${label}.scopeId`),
            credentialRef: credentialRef(input.credentialRef, `${label}.credentialRef`),
        };
    });
    const refs = admissions.map(entry => entry.admissionRef);
    if (new Set(refs).size !== refs.length)
        fail('INVALID_INPUT', 'admissions must not contain duplicate admissionRef values');
    return admissions;
}
function parseProvider(id, value) {
    const label = `providers.${id}`;
    const input = record(value, label);
    fields(input, ['protocol', 'apiBaseUrl', 'label', 'enabled', 'credentialEnv'], label);
    const protocol = input.protocol;
    if (protocol !== 'openai-chat' && protocol !== 'openai-responses') {
        fail('INVALID_INPUT', `${label}.protocol must be openai-chat or openai-responses`);
    }
    const credentialEnv = optionalString(input.credentialEnv, `${label}.credentialEnv`);
    if (credentialEnv !== undefined && !ENV_NAME.test(credentialEnv)) {
        fail('INVALID_INPUT', `${label}.credentialEnv must be an environment-variable name`);
    }
    const provider = {
        id,
        label: requiredString(input.label, `${label}.label`),
        protocol,
        apiBaseUrl: requiredString(input.apiBaseUrl, `${label}.apiBaseUrl`),
        enabled: boolean(input.enabled, true, `${label}.enabled`),
        auth: credentialEnv === undefined ? { kind: 'none' } : { kind: 'bearer', credentialRef: credentialEnv },
    };
    reuseConfigValidation(() => validateProvider(provider));
    return provider;
}
function parseModelMetadata(input, label) {
    const metadata = {};
    for (const key of MODEL_METADATA_KEYS) {
        if (input[key] !== undefined)
            metadata[key] = input[key];
    }
    // Values stay unchecked here on purpose: validateModelEntry owns every
    // metadata rule, so a malformed file value fails through the canonical
    // validator instead of a second copy of the same checks.
    return metadata;
}
function parseModels(value) {
    if (value === undefined)
        return [];
    if (!Array.isArray(value))
        fail('INVALID_INPUT', 'models must be an array of tables');
    const models = value.map((entry, index) => {
        const label = `models[${index}]`;
        const input = record(entry, label);
        fields(input, ['provider', 'id', ...MODEL_METADATA_KEYS], label);
        const model = {
            ref: {
                providerInstanceId: requiredString(input.provider, `${label}.provider`),
                modelId: requiredString(input.id, `${label}.id`),
            },
            origin: 'manual',
            base: parseModelMetadata(input, label),
            overrides: {},
        };
        reuseConfigValidation(() => validateModelEntry(model));
        return model;
    });
    const refs = models.map(entry => `${entry.ref.providerInstanceId}\u0000${entry.ref.modelId}`);
    if (new Set(refs).size !== refs.length)
        fail('INVALID_INPUT', 'models must not contain duplicate provider/model references');
    return models;
}
function parseModelRef(value, label) {
    const input = record(value, label);
    fields(input, ['provider', 'model'], label);
    return {
        providerInstanceId: requiredString(input.provider, `${label}.provider`),
        modelId: requiredString(input.model, `${label}.model`),
    };
}
function parseModel(value) {
    const input = record(value, 'model');
    fields(input, ['primary', 'backup'], 'model');
    const primary = parseModelRef(input.primary, 'model.primary');
    const backup = input.backup === undefined ? undefined : parseModelRef(input.backup, 'model.backup');
    const binding = { primary, ...(backup === undefined ? {} : { backup }) };
    reuseConfigValidation(() => validateBinding(binding, 'model'));
    return binding;
}
function assertAgentIntentPolicy(intent) {
    if (intent.acp.enabled && intent.engine === undefined)
        fail('INVALID_INPUT', 'enabled acp requires engine');
    if (intent.acp.enabled && intent.listen === undefined)
        fail('INVALID_INPUT', 'enabled acp requires listen');
    if (intent.listen === undefined)
        return;
    assertNonLoopbackAdmission(intent.listen.ip, intent.listen, intent.admissions, 'listen');
}
function parseAgent(root, daemon, context) {
    fields(root, ['version', 'daemon', 'engine', 'listen', 'acp', 'relations', 'admissions', 'discovery', 'peers', 'providers', 'models', 'model'], 'agent daemon');
    const engine = root.engine === undefined ? undefined : parseEngine(root.engine);
    const listen = root.listen === undefined ? undefined : parseListen(root.listen, 'listen');
    const acp = parseAcp(root.acp);
    const admissions = parseAdmissions(root.admissions);
    const providersInput = root.providers === undefined ? {} : record(root.providers, 'providers');
    const providers = Object.fromEntries(Object.entries(providersInput).map(([id, value]) => [id, parseProvider(id, value)]));
    const models = parseModels(root.models);
    const model = root.model === undefined ? undefined : parseModel(root.model);
    const intent = {
        version: DAEMON_INTENT_VERSION,
        daemon,
        ...(engine === undefined ? {} : { engine }),
        ...(listen === undefined ? {} : { listen }),
        acp,
        relations: parseRelations(root.relations),
        admissions,
        ...(root.discovery === undefined ? {} : { discovery: parseDiscovery(root.discovery) }),
        peers: parsePeers(root.peers),
        providers,
        models,
        ...(model === undefined ? {} : { model }),
    };
    assertAgentIntentPolicy(intent);
    assertIdentityRelations({ daemon, peers: intent.peers, admissions: intent.admissions });
    assertNoDuplicateDaemon(context, daemon);
    return intent;
}
function parseControl(root, daemon, context) {
    fields(root, ['version', 'daemon', 'webui', 'relations', 'admissions', 'discovery', 'peers'], 'control daemon');
    if (root.webui === undefined)
        fail('INVALID_INPUT', 'control daemon requires webui');
    const intent = {
        version: DAEMON_INTENT_VERSION,
        daemon,
        webui: parseWebUi(root.webui),
        relations: parseRelations(root.relations),
        admissions: parseAdmissions(root.admissions),
        ...(root.discovery === undefined ? {} : { discovery: parseDiscovery(root.discovery) }),
        peers: parsePeers(root.peers),
    };
    assertIdentityRelations({ daemon, peers: intent.peers, admissions: intent.admissions });
    assertNoDuplicateDaemon(context, daemon);
    return intent;
}
function parseRegistry(root, daemon, context) {
    fields(root, ['version', 'daemon', 'listen', 'admissions'], 'registry daemon');
    if (root.listen === undefined)
        fail('INVALID_INPUT', 'registry daemon requires listen');
    const listen = parseListen(root.listen, 'listen');
    const admissions = parseAdmissions(root.admissions);
    assertNonLoopbackAdmission(listen.ip, listen, admissions, 'listen');
    const intent = { version: DAEMON_INTENT_VERSION, daemon, listen, admissions };
    assertIdentityRelations({ daemon, peers: {}, admissions });
    assertNoDuplicateDaemon(context, daemon);
    return intent;
}
/**
 * Parse one already-decoded config document into the v4 single-daemon intent.
 *
 * Exactly one `[daemon]` table is accepted. A v1/v2/v3 file, including the old
 * multi-agent `[agents.*]` shape, is rejected explicitly; the old
 * init/start/status/work/console entrypoints keep their own v3 handling.
 */
export function parseDaemonIntent(value, context) {
    const root = record(value, 'daemon config');
    if (Array.isArray(root.daemon)) {
        fail('UNSUPPORTED_CONFIGURATION', 'one config declares exactly one daemon; start one daemon per config file');
    }
    if (root.version === 3) {
        fail('UNSUPPORTED_VERSION', 'version 3 multi-agent config is not accepted by --serve; migrate to version 4 with one daemon per file');
    }
    if (root.version !== DAEMON_INTENT_VERSION) {
        fail('UNSUPPORTED_VERSION', `daemon config version must be ${DAEMON_INTENT_VERSION}`);
    }
    const daemonInput = record(root.daemon, 'daemon');
    const kind = daemonInput.kind;
    if (kind !== 'agent' && kind !== 'control' && kind !== 'registry') {
        fail('INVALID_INPUT', 'daemon.kind must be agent, control, or registry');
    }
    if (kind === 'agent')
        return parseAgent(root, parseIdentity(root.daemon, 'agent'), context);
    if (kind === 'control')
        return parseControl(root, parseIdentity(root.daemon, 'control'), context);
    return parseRegistry(root, parseIdentity(root.daemon, 'registry'), context);
}
/** Parse TOML text into the v4 intent. TOML syntax errors stay explicit. */
export function parseDaemonConfigText(text, context) {
    let parsed;
    try {
        parsed = parseToml(text);
    }
    catch (cause) {
        throw new DaemonIntentError('INVALID_INPUT', `daemon config is not valid TOML: ${cause instanceof Error ? cause.message : String(cause)}`);
    }
    return parseDaemonIntent(parsed, context);
}
function resolvePath(value, configDirectory) {
    const expanded = value === '~'
        ? homedir()
        : value.startsWith('~/')
            ? resolve(homedir(), value.slice(2))
            : value;
    return isAbsolute(expanded) ? resolve(expanded) : resolve(configDirectory, expanded);
}
function resolveFileRef(ref, configDirectory) {
    const path = ref.slice('file:'.length);
    return `file:${resolvePath(path, configDirectory)}`;
}
function resolveCredentialRef(ref, configDirectory) {
    return ref.startsWith('env:') ? ref : resolveFileRef(ref, configDirectory);
}
function resolveDiscovery(discovery, configDirectory) {
    return {
        ...discovery,
        credentialRef: resolveCredentialRef(discovery.credentialRef, configDirectory),
        tlsTrustRef: resolveFileRef(discovery.tlsTrustRef, configDirectory),
    };
}
function resolvePeer(peer, configDirectory) {
    return {
        ...peer,
        credentialRef: resolveCredentialRef(peer.credentialRef, configDirectory),
        ...(peer.tlsTrustRef === undefined ? {} : { tlsTrustRef: resolveFileRef(peer.tlsTrustRef, configDirectory) }),
    };
}
function resolveAdmission(admission, configDirectory) {
    return { ...admission, credentialRef: resolveCredentialRef(admission.credentialRef, configDirectory) };
}
function resolveListen(listen, configDirectory) {
    return {
        ...listen,
        ...(listen.tlsCertRef === undefined ? {} : { tlsCertRef: resolveFileRef(listen.tlsCertRef, configDirectory) }),
        ...(listen.tlsKeyRef === undefined ? {} : { tlsKeyRef: resolveFileRef(listen.tlsKeyRef, configDirectory) }),
    };
}
/**
 * Resolve every filesystem-bearing field without reading a secret or changing
 * the source file. Runtime consumes this resolved value for launch wiring.
 */
export function resolveDaemonIntent(intent, context) {
    const configDirectory = resolve(context.configDirectory);
    if (isAgentIntent(intent)) {
        const agent = intent;
        return {
            ...agent,
            daemon: { ...agent.daemon, dataDirectory: resolvePath(agent.daemon.dataDirectory, configDirectory) },
            ...(agent.engine === undefined ? {} : {
                engine: {
                    ...agent.engine,
                    ...(agent.engine.workspace === undefined ? {} : { workspace: resolvePath(agent.engine.workspace, configDirectory) }),
                },
            }),
            ...(agent.listen === undefined ? {} : { listen: resolveListen(agent.listen, configDirectory) }),
            ...(agent.discovery === undefined ? {} : { discovery: resolveDiscovery(agent.discovery, configDirectory) }),
            admissions: agent.admissions.map(admission => resolveAdmission(admission, configDirectory)),
            peers: Object.fromEntries(Object.entries(agent.peers).map(([name, peer]) => [name, resolvePeer(peer, configDirectory)])),
        };
    }
    if (isControlIntent(intent)) {
        const control = intent;
        return {
            ...control,
            daemon: { ...control.daemon, dataDirectory: resolvePath(control.daemon.dataDirectory, configDirectory) },
            webui: {
                ...control.webui,
                ...(control.webui.tlsCertRef === undefined ? {} : { tlsCertRef: resolveFileRef(control.webui.tlsCertRef, configDirectory) }),
                ...(control.webui.tlsKeyRef === undefined ? {} : { tlsKeyRef: resolveFileRef(control.webui.tlsKeyRef, configDirectory) }),
            },
            ...(control.discovery === undefined ? {} : { discovery: resolveDiscovery(control.discovery, configDirectory) }),
            admissions: control.admissions.map(admission => resolveAdmission(admission, configDirectory)),
            peers: Object.fromEntries(Object.entries(control.peers).map(([name, peer]) => [name, resolvePeer(peer, configDirectory)])),
        };
    }
    if (!isRegistryIntent(intent))
        throw new DaemonIntentError('INVALID_INPUT', 'unsupported daemon kind');
    const registry = intent;
    return {
        ...registry,
        daemon: { ...registry.daemon, dataDirectory: resolvePath(registry.daemon.dataDirectory, configDirectory) },
        listen: resolveListen(registry.listen, configDirectory),
        admissions: registry.admissions.map(admission => resolveAdmission(admission, configDirectory)),
    };
}
function compileAgentConfig(intent) {
    const catalogs = {};
    for (const provider of Object.values(intent.providers)) {
        const entries = intent.models.filter(entry => entry.ref.providerInstanceId === provider.id);
        catalogs[provider.id] = { state: entries.length === 0 ? 'empty' : 'ready', entries };
    }
    for (const entry of intent.models) {
        if (intent.providers[entry.ref.providerInstanceId] === undefined) {
            fail('NOT_FOUND', `models references unknown provider ${entry.ref.providerInstanceId}`);
        }
    }
    const config = {
        revision: 1,
        acceptedRevision: 1,
        providers: intent.providers,
        catalogs,
        agents: intent.model === undefined ? {} : { [intent.daemon.id]: intent.model },
    };
    const model = intent.model;
    if (model !== undefined)
        reuseConfigValidation(() => assertBindingTargets(config, model));
    return config;
}
/**
 * Compile one v4 intent into the existing accepted runtime config shape.
 * The versioned config intentionally has no effectiveRevision; binding
 * references are closed by the canonical accepted-config rule.
 */
export function compileDaemonIntent(intent, context) {
    // Compile from the resolved intent: path resolution has one call site and its
    // result is consumed, so the accepted snapshot never comes from an unresolved
    // copy of the same config.
    const resolved = resolveDaemonIntent(intent, context);
    if (isAgentIntent(resolved))
        return compileAgentConfig(resolved);
    return { revision: 1, acceptedRevision: 1, providers: {}, catalogs: {}, agents: {} };
}
function overrideListen(listen, ip, port) {
    return listen === undefined ? { ip, port } : { ...listen, ip, port };
}
/**
 * Apply explicit CLI values over a parsed config intent. A defined CLI value
 * always wins over the file, the input intent is never mutated, and every
 * listener policy rule is re-checked on the effective value. The result is the
 * effective intent, so a later readback cannot show a stale config value.
 */
export function applyDaemonCliOverrides(intent, overrides) {
    if (overrides.engine !== undefined && intent.daemon.kind !== 'agent') {
        fail('UNSUPPORTED_CONFIGURATION', '--serve <engine> requires an agent daemon config');
    }
    const ip = overrides.ip === undefined ? undefined : numericIp(overrides.ip, '--ip');
    const port = overrides.port === undefined ? undefined : numericPort(overrides.port, '--port');
    if ((ip === undefined) !== (port === undefined))
        fail('INVALID_INPUT', '--ip and --port must be given together');
    if (isAgentIntent(intent)) {
        const engine = overrides.engine === undefined
            ? intent.engine
            : overrides.engine === intent.engine?.kind
                ? intent.engine
                : {
                    // A different engine kind drops the configured executable: an
                    // installed OpenCode binary is not a DSH binary. `workspace` is a
                    // directory chosen for this agent, so it survives the switch.
                    kind: overrides.engine,
                    ...(intent.engine?.workspace === undefined ? {} : { workspace: intent.engine.workspace }),
                };
        const listen = ip === undefined || port === undefined
            ? intent.listen
            : overrideListen(intent.listen, ip, port);
        const next = {
            ...intent,
            ...(engine === undefined ? {} : { engine }),
            ...(listen === undefined ? {} : { listen }),
        };
        assertAgentIntentPolicy(next);
        return next;
    }
    if (isControlIntent(intent)) {
        const webui = ip === undefined || port === undefined
            ? intent.webui
            : { ...intent.webui, ip, port };
        assertWebUiPolicy(webui);
        return { ...intent, webui };
    }
    const listen = ip === undefined || port === undefined
        ? intent.listen
        : overrideListen(intent.listen, ip, port);
    assertNonLoopbackAdmission(listen.ip, listen, intent.admissions, 'listen');
    return { ...intent, listen };
}
/** Effective values the CLI may print; never reads a credential. */
export function readDaemonEffectiveConfig(intent) {
    const base = {
        kind: intent.daemon.kind,
        daemonId: intent.daemon.id,
        dataDirectory: intent.daemon.dataDirectory,
    };
    if (isAgentIntent(intent)) {
        const listener = intent.listen === undefined ? undefined : { ip: intent.listen.ip, port: intent.listen.port };
        return {
            ...base,
            ...(intent.engine === undefined ? {} : { engine: intent.engine.kind }),
            ...(listener === undefined ? {} : { listener }),
        };
    }
    if (isControlIntent(intent)) {
        return { ...base, listener: { ip: intent.webui.ip, port: intent.webui.port } };
    }
    return { ...base, listener: { ip: intent.listen.ip, port: intent.listen.port } };
}
