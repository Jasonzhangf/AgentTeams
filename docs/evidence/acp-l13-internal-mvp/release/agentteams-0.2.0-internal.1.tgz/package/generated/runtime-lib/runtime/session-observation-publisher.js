import { readSessionObservationRecord, writeSessionObservationRecord, } from "../config/session-observation-store.js";
/**
 * The projection row's own id for one pending permission. The permission id is the engine
 * callback id the controller received, so the row is stable while that callback is open and
 * disappears with it; the prefix keeps the row namespace the record's own.
 */
export function sessionObservationNotificationId(permissionId) {
    return `permission:${permissionId}`;
}
/** The whole observation this pass observes, in one canonical order. */
function observe(input) {
    const sessions = [...new Set(input.host.openedSessions())].sort();
    const byNotification = new Map();
    for (const pending of input.host.pendingPermissions()) {
        const notificationId = sessionObservationNotificationId(pending.permissionId);
        // A permission whose Session the host no longer reports would cross the record's own
        // rule, and the store refuses it. Drop it here for the same reason: a row the reader
        // cannot name its Session for is not an observation this daemon may publish.
        if (!sessions.includes(pending.sessionId))
            continue;
        byNotification.set(notificationId, { notificationId, sessionId: pending.sessionId, permissionId: pending.permissionId });
    }
    return {
        agentId: input.agentId,
        sessions: sessions.map(sessionId => ({ sessionId })),
        permissions: [...byNotification.values()].sort((left, right) => left.notificationId.localeCompare(right.notificationId)),
    };
}
function same(left, right) {
    return left !== undefined && JSON.stringify(left) === JSON.stringify(right);
}
export function createSessionObservationPublisher(input) {
    const failures = [];
    const recorded = new Set();
    // A poll repeats the same refusal every tick, so the list keeps each distinct refusal once.
    const refuse = (code, message) => {
        const key = `${code}\u0000${message}`;
        if (recorded.has(key))
            return;
        recorded.add(key);
        failures.push({ agentId: input.agentId, code, message });
    };
    /** What this publisher last observed and the revision the record carried for it. */
    let published;
    let revision = 0;
    let seeded = false;
    /**
     * The pass that is running, if any. The poll tick and the stop-time publish share this one
     * publisher, and clearing the interval does not cancel a pass that already started. Two
     * passes would read the same revision, so one of them would fail a CAS conflict it did not
     * cause, and a stop pass that lost that race would leave the last non-empty observation on
     * disk while the daemon holds nothing. Chaining also makes a stop-time publish run after the
     * pass in flight, which is the order the stop path needs.
     */
    let inFlight;
    const seed = async () => {
        const record = await readSessionObservationRecord(input.recordPath);
        if (record !== undefined && record.agentId !== input.agentId) {
            // The record path is derived from the target agent, so a record naming another agent
            // was written where it does not belong. Refuse it instead of replacing another's bytes.
            throw Object.assign(new Error(`session observation record names agent ${record.agentId}, but this daemon is ${input.agentId}`), { code: 'FORBIDDEN' });
        }
        published = record === undefined
            ? undefined
            : { agentId: record.agentId, sessions: record.sessions, permissions: record.permissions };
        revision = record?.revision ?? 0;
        seeded = true;
    };
    /**
     * One pass. It never rejects: every refusal, including a read or a host read that throws, is
     * recorded as a typed refusal instead of escaping an interval callback, where an unhandled
     * rejection could take the daemon down.
     */
    const runPass = async () => {
        try {
            if (!seeded)
                await seed();
            const snapshot = observe(input);
            // Nothing changed: the revision stays, so the control daemon's polling readback reports
            // no new event and the Console receives no frame for a heartbeat.
            if (same(published, snapshot))
                return;
            const result = await writeSessionObservationRecord(input.recordPath, revision, snapshot);
            if (result.status === 'applied') {
                published = snapshot;
                revision = result.effectiveRevision;
                return;
            }
            // A refused write is not an observation the reader may treat as published. A revision
            // conflict means someone else wrote this record; re-seed so the next pass rebases onto
            // the durable revision instead of retrying a base that is already gone.
            refuse(result.error.code, result.error.message);
            if (result.error.code === 'REVISION_CONFLICT')
                seeded = false;
        }
        catch (error) {
            refuse(error.code ?? 'UNAVAILABLE', error instanceof Error ? error.message : String(error));
        }
    };
    const publish = async () => {
        const pass = (inFlight ?? Promise.resolve()).then(runPass);
        inFlight = pass;
        await pass;
    };
    return { publish, recordPath: input.recordPath, failures: () => [...failures] };
}
