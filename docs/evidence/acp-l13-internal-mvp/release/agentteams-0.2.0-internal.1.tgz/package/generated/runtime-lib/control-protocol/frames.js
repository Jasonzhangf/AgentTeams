import { validateAgentMessage } from "./agent-message.js";
import { validateRelationReport } from "./relation-report.js";
import { assertEnvelopeKeys, assertJsonValue } from "./json-value.js";
function record(value, label) {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        throw new Error(`${label} must be an object`);
    }
    return value;
}
function stringValue(value, label) {
    if (typeof value !== 'string' || value.length === 0) {
        throw new Error(`${label} must be a non-empty string`);
    }
    return value;
}
function positiveInteger(value, label) {
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 1) {
        throw new Error(`${label} must be a positive integer`);
    }
    return value;
}
function booleanValue(value, label) {
    if (typeof value !== 'boolean') {
        throw new Error(`${label} must be a boolean`);
    }
    return value;
}
function enumValue(value, values, label) {
    if (typeof value !== 'string' || !values.includes(value)) {
        throw new Error(`${label} is invalid`);
    }
    return value;
}
function assertIsoDate(value, label) {
    const parsed = stringValue(value, label);
    if (Number.isNaN(Date.parse(parsed))) {
        throw new Error(`${label} must be an ISO date`);
    }
}
function assertSessionRef(value) {
    const input = record(value, 'sessionRef');
    return {
        hostId: stringValue(input.hostId, 'sessionRef.hostId'),
        agentId: stringValue(input.agentId, 'sessionRef.agentId'),
        sessionId: stringValue(input.sessionId, 'sessionRef.sessionId'),
    };
}
function assertPermissionRequest(value) {
    const input = record(value, 'permissionRequest');
    return {
        hostId: stringValue(input.hostId, 'permissionRequest.hostId'),
        agentId: stringValue(input.agentId, 'permissionRequest.agentId'),
        sessionId: stringValue(input.sessionId, 'permissionRequest.sessionId'),
        permissionId: stringValue(input.permissionId, 'permissionRequest.permissionId'),
    };
}
function assertNotification(value) {
    const input = record(value, 'notification');
    const result = {
        notificationId: stringValue(input.notificationId, 'notification.notificationId'),
        hostId: stringValue(input.hostId, 'notification.hostId'),
        agentId: stringValue(input.agentId, 'notification.agentId'),
        priority: enumValue(input.priority, ['low', 'normal', 'high', 'critical'], 'notification.priority'),
        status: enumValue(input.status, ['pending', 'processed'], 'notification.status'),
        occurredAt: stringValue(input.occurredAt, 'notification.occurredAt'),
    };
    assertIsoDate(result.occurredAt, 'notification.occurredAt');
    if (input.sessionId !== undefined)
        result.sessionId = stringValue(input.sessionId, 'notification.sessionId');
    if (input.permissionId !== undefined)
        result.permissionId = stringValue(input.permissionId, 'notification.permissionId');
    return result;
}
function assertChannelId(input) {
    return stringValue(input.channelId, 'channelId');
}
export function parseTargetControlFrame(value) {
    const input = record(value, 'target control frame');
    const kind = stringValue(input.kind, 'kind');
    if (!Object.hasOwn(targetControlValidators, kind)) {
        throw new Error(`unknown target control frame: ${kind}`);
    }
    assertEnvelopeKeys(input, ['kind', 'targetGeneration', ...targetControlFields[kind]], 'target control frame');
    targetControlValidators[kind](input);
    return input;
}
const targetControlFields = {
    'transport.hello': ['protocolVersion', 'hostId', 'agentId', 'capabilitiesRevision', 'source', 'admissionRef'],
    'transport.hello_ack': [],
    'transport.ping': ['nonce'],
    'transport.pong': ['nonce'],
    'transport.health': ['health'],
    'transport.generation': [],
    'transport.capability': ['capabilitiesRevision', 'capabilities'],
    'transport.route_info': ['route'],
    'transport.error': ['code', 'message'],
    'channel.open': ['channelId', 'sessionRef'],
    'channel.open_ack': ['channelId'],
    'channel.close': ['channelId', 'reason'],
    'channel.close_ack': ['channelId'],
    'channel.error': ['channelId', 'code', 'message'],
};
const targetControlValidators = {
    'transport.hello': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        positiveInteger(input.protocolVersion, 'protocolVersion');
        stringValue(input.hostId, 'hostId');
        stringValue(input.agentId, 'agentId');
        stringValue(input.capabilitiesRevision, 'capabilitiesRevision');
        const source = record(input.source, 'source');
        stringValue(source.accountId, 'source.accountId');
        stringValue(source.scopeId, 'source.scopeId');
        stringValue(source.agentId, 'source.agentId');
        stringValue(input.admissionRef, 'admissionRef');
    },
    'transport.hello_ack': (input) => positiveInteger(input.targetGeneration, 'targetGeneration'),
    'transport.ping': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        stringValue(input.nonce, 'nonce');
    },
    'transport.pong': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        stringValue(input.nonce, 'nonce');
    },
    'transport.health': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        enumValue(input.health, ['starting', 'ready', 'error'], 'health');
    },
    'transport.generation': (input) => positiveInteger(input.targetGeneration, 'targetGeneration'),
    'transport.capability': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        stringValue(input.capabilitiesRevision, 'capabilitiesRevision');
        if (!Array.isArray(input.capabilities) || input.capabilities.some((item) => typeof item !== 'string' || item.length === 0)) {
            throw new Error('capabilities must be a non-empty string array');
        }
    },
    'transport.route_info': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        const route = record(input.route, 'route');
        enumValue(route.kind, ['manual', 'auto'], 'route.kind');
        positiveInteger(route.generation, 'route.generation');
        assertIsoDate(route.confirmedAt, 'route.confirmedAt');
        if (!Array.isArray(route.candidates))
            throw new Error('route.candidates must be an array');
        route.candidates.forEach(assertRouteCandidate);
    },
    'transport.error': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        stringValue(input.code, 'code');
        stringValue(input.message, 'message');
    },
    'channel.open': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        assertSessionRef(input.sessionRef);
    },
    'channel.open_ack': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
    },
    'channel.close': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.reason, 'reason');
    },
    'channel.close_ack': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
    },
    'channel.error': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.code, 'code');
        stringValue(input.message, 'message');
    },
};
function assertRouteCandidate(value) {
    const candidate = record(value, 'route.candidates[]');
    stringValue(candidate.candidateId, 'route.candidates[].candidateId');
    enumValue(candidate.kind, ['lan', 'tailscale', 'ipv6', 'ipv4', 'gateway', 'relay-ws', 'relay-webrtc'], 'route.candidates[].kind');
    if (candidate.endpoint !== undefined)
        stringValue(candidate.endpoint, 'route.candidates[].endpoint');
    if (candidate.port !== undefined) {
        const port = positiveInteger(candidate.port, 'route.candidates[].port');
        if (port > 65535)
            throw new Error('route.candidates[].port is invalid');
    }
    booleanValue(candidate.authRequired, 'route.candidates[].authRequired');
    assertIsoDate(candidate.lastSeenAt, 'route.candidates[].lastSeenAt');
}
export function parseSessionChannelFrame(value) {
    const input = record(value, 'session channel frame');
    const kind = stringValue(input.kind, 'kind');
    if (!Object.hasOwn(sessionChannelValidators, kind)) {
        throw new Error(`unknown session channel frame: ${kind}`);
    }
    assertEnvelopeKeys(input, ['kind', 'targetGeneration', 'channelId', ...sessionChannelFields[kind]], 'session channel frame');
    sessionChannelValidators[kind](input);
    return input;
}
const sessionChannelFields = {
    'session.list': ['requestId'],
    'session.list_result': ['requestId', 'sessions'],
    'session.current': ['requestId'],
    'session.open': ['requestId', 'sessionId'],
    'session.message': ['sessionId', 'correlationId', 'role', 'body', 'metadata'],
    'session.message_delta': ['sessionId', 'correlationId', 'delta'],
    'permission.ask': ['requestId', 'permissionRequest'],
    'permission.reply': ['requestId', 'permissionId', 'action'],
    'notification.upsert': ['notification'],
    'notification.ack': ['requestId', 'notificationId'],
    'agent.message': ['message'],
    'relation.report': ['report'],
};
const sessionChannelValidators = {
    'session.list': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.requestId, 'requestId');
    },
    'session.list_result': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.requestId, 'requestId');
        if (!Array.isArray(input.sessions))
            throw new Error('sessions must be an array');
    },
    'session.current': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.requestId, 'requestId');
    },
    'session.open': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.requestId, 'requestId');
        stringValue(input.sessionId, 'sessionId');
    },
    'session.message': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.sessionId, 'sessionId');
        stringValue(input.correlationId, 'correlationId');
        enumValue(input.role, ['user', 'assistant', 'system', 'tool'], 'role');
        const body = record(input.body, 'body');
        assertJsonValue(body, 'body');
        if (input.metadata !== undefined) {
            const metadata = record(input.metadata, 'metadata');
            assertJsonValue(metadata, 'metadata');
        }
    },
    'session.message_delta': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.sessionId, 'sessionId');
        stringValue(input.correlationId, 'correlationId');
        assertJsonValue(input.delta, 'delta');
    },
    'permission.ask': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.requestId, 'requestId');
        assertPermissionRequest(input.permissionRequest);
    },
    'permission.reply': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.requestId, 'requestId');
        stringValue(input.permissionId, 'permissionId');
        enumValue(input.action, ['once', 'always', 'reject'], 'action');
    },
    'notification.upsert': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        assertNotification(input.notification);
    },
    'notification.ack': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        stringValue(input.requestId, 'requestId');
        stringValue(input.notificationId, 'notificationId');
    },
    'agent.message': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        validateAgentMessage(input.message);
    },
    'relation.report': (input) => {
        positiveInteger(input.targetGeneration, 'targetGeneration');
        assertChannelId(input);
        validateRelationReport(input.report);
    },
};
