import type { AgentDeclaration, CapabilityDeclaration, JsonValue } from '../control-protocol/agent-services.ts';
import type { AcpFaultCode } from '../control-protocol/acp.ts';
import type { EngineAdapter, EngineStopResult } from '../control-protocol/engine.ts';
import type { AgentDaemonIntent, DaemonEffectiveConfig, EngineKind, PeerIntent } from '../config/daemon-intent.ts';
import type { AcpPolicySnapshot } from '../config/acp-policy.ts';
import type { AgentModelBinding, ModelRef, VersionedRuntimeConfig } from '../config/runtime-config.ts';
import { type SessionObservationFailure } from './session-observation-publisher.ts';
import { type AcpHost } from '../agent-host/acp-host.ts';
import type { RegistrationStatus } from '../network/registration-client.ts';
import { type TeamsStatusPort } from '../network/teams-status.ts';
import { type AcpAgentDaemon } from './acp-daemon.ts';
import { type AgentRegistration } from './registry-registration.ts';
import { type ServeEgressFailure, type ServeEgressOwner } from './serve-egress.ts';
export interface AcpServeIntentInput {
    /** Omitted means the CLI quick-start base intent (no provider/model binding). */
    readonly configPath?: string;
    readonly engine: EngineKind;
    readonly ip?: string;
    readonly port?: number;
    readonly home?: string;
}
export interface AcpServeIntent {
    /** Null when the quick-start base intent was built instead of a config file. */
    readonly configPath: string | null;
    readonly intent: AgentDaemonIntent;
    readonly accepted: VersionedRuntimeConfig;
    /** The one binding the entry proved present before it may start an engine. */
    readonly binding: AgentModelBinding;
    readonly effective: DaemonEffectiveConfig;
    /** sha256 of the exact config text the accepted snapshot was compiled from. */
    readonly sourceHash: string;
}
export interface AcpServeRuntimeOptions {
    readonly env?: NodeJS.ProcessEnv;
    readonly initializeTimeoutMs?: number;
    readonly stopTimeoutMs?: number;
    /** Live registration status transitions; the readiness line reports the start state. */
    readonly onRegistrationStatus?: (status: RegistrationStatus) => void;
}
/** Which inbound channel the configured listener address selects. */
export type ServeListenerClass = 'local' | 'lan';
/** The real bound local ACP channel address. */
export interface AcpServeLocalChannel {
    readonly ip: string;
    readonly port: number;
}
/** The real bound authenticated LAN channel, with the revision its hello advertises. */
export interface AcpServeLanChannel {
    readonly endpoint: string;
    readonly port: number;
    readonly capabilitiesRevision: string;
}
export interface AcpServeReadiness {
    readonly agentId: string;
    readonly engineInstanceId: string;
    readonly enginePid: number;
    readonly listener: {
        readonly ip: string;
        readonly port: number;
    };
    /** Non-null only when the engine's own session/new result proves this model. */
    readonly modelTarget: ModelRef | null;
    readonly modelVerification: string;
    readonly effectiveRevision: number;
    readonly evidence: JsonValue;
}
export interface AcpServeStopReceipt {
    readonly engine: EngineStopResult;
    /** Live ACP channels that were destroyed by the stop. */
    readonly channels: number;
}
export interface AcpServeHandle {
    readonly agentId: string;
    /** The engine kind this handle really started, from the compiled intent. */
    readonly engineKind: EngineKind;
    readonly engineInstanceId: string;
    readonly enginePid: number;
    readonly configPath: string | null;
    readonly dataDirectory: string;
    readonly listener: {
        readonly ip: string;
        readonly port: number;
    };
    /** The real bound local (plain newline-JSON) channel. */
    readonly localChannel: AcpServeLocalChannel;
    /** The real bound authenticated LAN channel; null for a loopback-only listener. */
    readonly lanChannel: AcpServeLanChannel | null;
    /** `String(declaration.revision)` of the declaration the LAN hello advertises. */
    readonly capabilitiesRevision: string;
    /** Live registration status; `disabled` when the config declares no `[discovery]`. */
    readonly registration: RegistrationStatus;
    /** Read-only D06 handoff over the live ledger and the durable history. */
    readonly teamsStatus: TeamsStatusPort;
    /**
     * The daemon's own egress owner: it dialed every declared dialable peer at
     * start and owns the live initiator connections. `list()` is the live rows and
     * `disconnect(agentId)` tears one down; `stop()` closes them all before the host.
     */
    readonly egress: ServeEgressOwner;
    /** Every declared peer whose connect attempt failed, with its typed code. */
    readonly egressFailures: readonly ServeEgressFailure[];
    /**
     * The desired-relations record this daemon observes. The control daemon owns the
     * file; this daemon polls it and reacts, and `failures()` is every typed refusal
     * the watch recorded (an undeclared desired agent, or a broken record).
     */
    readonly relationsIntent: {
        readonly path: string;
        failures(): readonly RelationsIntentWatchFailure[];
    };
    /**
     * The pending-Session-write record this daemon observes. The control daemon owns the
     * file; this daemon polls it and applies each write to its own host. `failures()` is
     * every typed refusal the watch recorded, so a write this daemon could not apply stays
     * visible instead of disappearing.
     */
    readonly sessionIntent: {
        readonly path: string;
        readonly watermarkPath: string;
        failures(): readonly SessionIntentWatchFailure[];
    };
    /**
     * The Session-observation record this daemon publishes. The agent daemon owns the file
     * because it owns the Sessions and permission callbacks it carries; the control daemon
     * reads it to project them. `failures()` is every typed refusal this publisher recorded,
     * so an observation it could not store stays visible instead of disappearing.
     */
    readonly sessionObservation: {
        readonly path: string;
        failures(): readonly SessionObservationFailure[];
    };
    readonly readiness: AcpServeReadiness;
    readonly daemon: AcpAgentDaemon;
    stop(): Promise<AcpServeStopReceipt>;
}
/**
 * Pure listener classification: the address, not a second config key, selects
 * the channel. A loopback address is the local plain ACP channel; every other
 * address is the authenticated LAN channel.
 */
export declare function classifyServeListener(listen: {
    readonly ip: string;
}): ServeListenerClass;
/**
 * Pure projection of the effective ACP policy into the one published capability.
 * Only the effective `method:` keys become operations, and cancellation is
 * cooperative only when `method:session/cancel` is effective; the projection
 * never declares a method the accepted policy denied.
 */
export declare function acpCapabilityDeclarations(policy: AcpPolicySnapshot): readonly CapabilityDeclaration[];
/**
 * The CLI quick-start base intent (D00 §5.7 single writer). It carries no
 * provider, catalog or model, so the entry refuses it with an explicit missing
 * binding instead of letting the engine pick a default model.
 */
export declare function buildQuickStartAgentIntent(input: {
    readonly engine: EngineKind;
    readonly ip: string;
    readonly port: number;
    readonly home?: string;
}): AgentDaemonIntent;
/**
 * Read one v4 agent config (or build the quick-start base intent), apply the
 * explicit `--serve/--ip/--port` overrides, resolve paths, compile the accepted
 * snapshot and enforce the entry's preconditions: an agent daemon, an enabled
 * ACP policy, a served listener (a non-loopback listener requires `[discovery]`),
 * a delivered engine adapter and a real provider/model binding. It starts
 * nothing.
 */
export declare function readAcpServeIntent(input: AcpServeIntentInput): Promise<AcpServeIntent>;
/** The installed OpenCode executable: config path, then project env, then PATH. */
export declare function resolveOpenCodeExecutable(configured: string | undefined, env: NodeJS.ProcessEnv): string;
/** The installed DSH executable: config path, then project env, then PATH. */
export declare function resolveDshExecutable(configured: string | undefined, env: NodeJS.ProcessEnv): string;
/**
 * The entry's dispatcher view of an engine adapter: the frozen
 * `control-protocol/engine.ts` port plus the two policy sets the adapter
 * declares and the entry passes through to the host. It is a type-only view,
 * not a third adapter implementation: `OpenCodeEngineAdapter` and
 * `DshEngineAdapter` each already extend `EngineAdapter`, so this adds only the
 * members the one dispatch point needs and declares no `compileLaunch` or
 * `verifyEffective` shape of its own.
 *
 * `enforceablePolicies` stays optional here so an adapter that omits it fails
 * with an explicit typed fault instead of being silently repaired.
 */
export type ServeEngineAdapter = EngineAdapter & {
    readonly declaredMethods: readonly string[];
    readonly enforceablePolicies?: readonly string[];
};
/**
 * The one dispatch point from a configured engine kind to its adapter. D00
 * freezes the kinds as opencode|dsh and both adapters are delivered, so the
 * `never` binding makes the mapping exhaustive at compile time; the default
 * clause is unreachable for every value the config parser can produce.
 */
export declare function engineAdapterFor(kind: EngineKind): ServeEngineAdapter;
/**
 * The adapter owns which policies it can enforce. An adapter that declares no
 * enforceable set is a wiring fault, not a reason to fall back to a different
 * set; the fault names the adapter that owes the declaration.
 */
export declare function requireEnforceablePolicies(adapter: ServeEngineAdapter): readonly string[];
/**
 * Publish the daemon's real surfaces through the existing D04 path. It publishes
 * only when the config selected registration and the client is online; a
 * disabled plan or a registry outage changes the registration status and never
 * stops the engine. The caller owns `declarationForDaemon` +
 * `declarationWithPublishedSurfaces`, so the published revision is the one the
 * LAN target already advertised.
 */
export declare function publishServeRegistration(input: {
    readonly registration: AgentRegistration;
    readonly declaration: AgentDeclaration;
}): Promise<RegistrationStatus | null>;
/**
 * The named poll interval of the agent daemon's desired-relations watch and of its
 * pending-Session-write watch. One control daemon writes one durable record and this
 * daemon reads it, so the Console stays out of the data path and no control-to-agent
 * channel is added.
 */
export declare const RELATIONS_INTENT_POLL_INTERVAL_MS = 500;
/** One typed refusal the watch recorded instead of dialing or crashing. */
export interface RelationsIntentWatchFailure {
    readonly agentId: string;
    readonly code: AcpFaultCode;
    readonly message: string;
}
/** The live-relation surface the watch drives; the real owner is `ServeEgressOwner`. */
export interface RelationsIntentWatchInput {
    /** The already-built egress owner. The watch never builds a second one. */
    readonly owner: Pick<ServeEgressOwner, 'connect' | 'disconnect' | 'list'>;
    /** The one shared record path. `config/relations-intent-store.ts` owns its derivation. */
    readonly recordPath: string;
    /** The accepted intent's declared peers. An agentId outside this set is never dialed. */
    readonly peers: Readonly<Record<string, PeerIntent>>;
}
export interface RelationsIntentWatch {
    /** One reconcile pass: make the live rows match the record's desired set. */
    reconcile(): Promise<void>;
    /** The one shared record path this watch observes. */
    readonly recordPath: string;
    /** Every typed refusal this watch recorded in its lifetime. */
    failures(): readonly RelationsIntentWatchFailure[];
}
/**
 * React to the durable desired-relations record that the control daemon owns. One
 * reconcile pass dials each newly desired declared peer and disconnects each live
 * peer the record no longer desires.
 *
 * The record carries the control daemon's desired role, but it never overrides this
 * daemon's own accepted policy: the role pair still comes from `relations.allowed`
 * (`runtime/serve-egress.ts`), so a desired role this daemon does not accept stays a
 * typed dial refusal instead of an escalated grant.
 *
 * A missing record is a plain no-op, and a broken record is a typed refusal that
 * leaves the live rows untouched. Neither one crashes the daemon.
 */
export declare function createRelationsIntentWatch(input: RelationsIntentWatchInput): RelationsIntentWatch;
/**
 * The one shared record path this daemon reads. It is derived from the daemon's own
 * accepted account and scope plus the established `~/.agentteams` local root, so the
 * control daemon resolves the same file without a new config key.
 */
export declare function agentRelationsIntentPath(home: string, daemon: AgentDaemonIntent['daemon']): string;
/** One typed refusal to apply a pending Session write, with the write it belongs to. */
export interface SessionIntentWatchFailure {
    readonly intentId: string;
    readonly code: AcpFaultCode;
    readonly message: string;
}
/**
 * The Session surface the watch drives. The real owner is the agent daemon's own
 * `AcpHost`, which is the A2.6 permission owner and the only place that knows which
 * Session each open channel owns.
 */
export interface SessionIntentWatchInput {
    readonly host: Pick<AcpHost, 'receive' | 'pendingPermissions' | 'channelForSession'>;
    /** The one record path for this daemon. `config/session-intent-store.ts` owns it. */
    readonly recordPath: string;
    /** This daemon's own consumed watermark, in its own data directory. */
    readonly watermarkPath: string;
    /** This daemon's own accepted identity. A record that names another agent is refused. */
    readonly agentId: string;
}
export interface SessionIntentWatch {
    /** One pass: apply every pending write addressed to this daemon, in revision order. */
    reconcile(): Promise<void>;
    readonly recordPath: string;
    readonly watermarkPath: string;
    /** Every typed refusal this watch recorded in its lifetime. */
    failures(): readonly SessionIntentWatchFailure[];
}
/**
 * React to the durable pending-Session-write record that the control daemon owns.
 *
 * This daemon applies a write to its own `AcpHost` and reports nothing back: no
 * control-to-agent channel exists, and the Console stays out of the data path. The three
 * frozen writes map to the engine exactly as ACP defines them.
 *
 *  - `permission.reply` becomes a JSON-RPC response to the engine's own pending
 *    `session/request_permission` callback. The write names the permission by the id the
 *    controller received with that request. The decision is the Console vocabulary, so the
 *    watch selects the engine option whose `kind` equals it. When the engine offered no
 *    such option, or when no callback matches, the watch refuses: a stale or missing
 *    callback never becomes an approval.
 *  - `session.cancel` becomes the `session/cancel` notification for that Session.
 *  - `session.message` becomes `session/prompt` with the body carried verbatim.
 *
 * Ordering and retry: the pass stops at the first write it cannot apply and does not
 * advance the watermark, so the next tick retries that write and every later one. Order is
 * therefore preserved per daemon, and a write is never silently skipped. A write this
 * daemon can never apply keeps its typed refusal and eventually pushes the reader past the
 * retained window, where the store reports the honest `behind` refusal instead of a gap.
 */
export declare function createSessionIntentWatch(input: SessionIntentWatchInput): SessionIntentWatch;
/**
 * The one record path this daemon reads. It is derived from the daemon's own accepted
 * identity, account and scope plus the established `~/.agentteams` local root, so the
 * control daemon resolves the same file without a new config key.
 */
export declare function agentSessionIntentPath(home: string, daemon: AgentDaemonIntent['daemon']): string;
/**
 * The one observation record path this daemon publishes. It is derived from the same
 * accepted identity, account and scope the pending-Session-write record uses, so the
 * control daemon resolves the same file without a new config key and the two Session
 * records for one agent sit in one directory.
 */
export declare function agentSessionObservationPath(home: string, daemon: AgentDaemonIntent['daemon']): string;
/**
 * Start exactly one agent daemon and serve local ACP channels on its configured
 * listener. Every failure before the listener is bound stops the spawned engine
 * and rethrows the typed fault, so a failed start never leaves a child behind.
 */
export declare function startAcpServe(intent: AcpServeIntent, options?: AcpServeRuntimeOptions): Promise<AcpServeHandle>;
/** The one readiness line the entry prints before it starts serving. */
export declare function formatAcpServeReady(handle: AcpServeHandle): string;
/**
 * The registration status line the entry prints on a live transition. The
 * readiness line reports the start state; later lines report degradation and
 * recovery while the engine keeps serving.
 */
export declare function formatAcpServeRegistration(status: RegistrationStatus): string;
/** The one stop line, carrying the real EngineStopResult. */
export declare function formatAcpServeStopped(handle: AcpServeHandle, receipt: AcpServeStopReceipt): string;
export interface RunAcpServeInput extends AcpServeIntentInput {
    readonly env?: NodeJS.ProcessEnv;
    readonly report?: (line: string) => void;
    readonly signal?: AbortSignal;
    readonly initializeTimeoutMs?: number;
    readonly stopTimeoutMs?: number;
}
/**
 * The process-level serve entry: read the intent, start one daemon, print the
 * honest readiness line, run until SIGINT/SIGTERM (or the injected abort), then
 * stop the engine and print the real stop receipt.
 */
export declare function runAcpServe(input: RunAcpServeInput): Promise<void>;
