import type { AcpFrame } from '../control-protocol/acp.ts';
export interface AcpPolicyIntent {
    readonly enabled: boolean;
    readonly required: readonly string[];
    readonly blacklist: readonly string[];
    readonly clientCapabilities: readonly string[];
    readonly callbackExecutor: 'controller';
}
export interface AcpPolicySnapshot {
    readonly revision: string;
    readonly engineInstanceId: string;
    readonly supported: readonly string[];
    readonly effective: readonly string[];
    readonly denied: readonly string[];
}
/**
 * Fault carrier for policy rejections. `AcpError` in control-protocol is the
 * single owner of the fault type and code vocabulary; policy does not declare a
 * second error class with the same code space.
 */
export { AcpError as AcpPolicyError } from '../control-protocol/acp.ts';
/**
 * Convert a real ACP initialize result plus adapter-verified extension keys
 * into the policy vocabulary. False capability booleans never become supported.
 */
export declare function extractAcpCapabilities(initializeResult: AcpFrame, adapterMethods?: readonly string[]): readonly string[];
export declare function resolveAcpPolicy(input: {
    readonly intent: AcpPolicyIntent;
    readonly engineInstanceId: string;
    readonly supported: readonly string[];
    readonly enforceablePolicies: readonly string[];
}): AcpPolicySnapshot;
/**
 * Validate an ACP frame against the effective policy before dispatch.
 * The method/parameter checks happen before any child write or executor call.
 */
export declare function assertAcpAllowed(input: {
    readonly policy: AcpPolicySnapshot;
    readonly direction: 'to-engine' | 'from-engine';
    readonly frame: AcpFrame;
}): void;
