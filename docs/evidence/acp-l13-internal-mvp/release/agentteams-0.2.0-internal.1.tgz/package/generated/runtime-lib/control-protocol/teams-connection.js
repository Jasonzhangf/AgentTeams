import { AcpError, parseAcpFault, parseAcpFrame } from "./acp.js";
import { assertEnvelopeKeys, assertJsonValue } from "./json-value.js";
const RELATION_ROLES = ['master', 'peer'];
/** Only these ordered role pairs are bilateral. subordinate/master-master never exist. */
const ALLOWED_ROLE_PAIRS = [
    ['master', 'peer'],
    ['peer', 'master'],
    ['peer', 'peer'],
];
function fail(message) {
    throw new AcpError('INVALID_ACP_FRAME', message);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function assertText(value, path) {
    if (typeof value !== 'string' || value.length === 0)
        fail(`${path} must be a non-empty string`);
}
function assertPositiveInteger(value, path) {
    if (!Number.isSafeInteger(value) || value < 1)
        fail(`${path} must be a positive finite integer`);
}
function assertRole(value, path) {
    if (typeof value !== 'string' || !RELATION_ROLES.includes(value)) {
        fail(`${path} must be master or peer`);
    }
}
function assertRolePair(sourceRole, targetRole) {
    if (!ALLOWED_ROLE_PAIRS.some(([source, target]) => source === sourceRole && target === targetRole)) {
        fail(`${sourceRole}/${targetRole} relation is not allowed`);
    }
}
function assertIdentity(value, path) {
    if (!isRecord(value))
        fail(`${path} must be an object`);
    assertEnvelopeKeys(value, ['accountId', 'scopeId', 'agentId'], path);
    assertText(value.accountId, `${path}.accountId`);
    assertText(value.scopeId, `${path}.scopeId`);
    assertText(value.agentId, `${path}.agentId`);
    return value;
}
function assertCapabilities(value, path) {
    if (!Array.isArray(value) || value.some(item => typeof item !== 'string' || item.length === 0)) {
        fail(`${path} must be an array of non-empty strings`);
    }
}
function assertAgreement(value, path) {
    if (!isRecord(value))
        fail(`${path} must be an object`);
    assertEnvelopeKeys(value, [
        'connectionId',
        'relationRevision',
        'source',
        'target',
        'sourceRole',
        'targetRole',
        'sourceGeneration',
        'targetGeneration',
        'sourceCapabilitiesRevision',
        'targetCapabilitiesRevision',
        'sourcePolicyRevision',
        'targetPolicyRevision',
        'capabilities',
    ], path);
    assertText(value.connectionId, `${path}.connectionId`);
    assertPositiveInteger(value.relationRevision, `${path}.relationRevision`);
    const source = assertIdentity(value.source, `${path}.source`);
    const target = assertIdentity(value.target, `${path}.target`);
    if (source.accountId === target.accountId && source.scopeId === target.scopeId && source.agentId === target.agentId) {
        fail(`${path} cannot name the same source and target identity`);
    }
    assertRole(value.sourceRole, `${path}.sourceRole`);
    assertRole(value.targetRole, `${path}.targetRole`);
    assertRolePair(value.sourceRole, value.targetRole);
    assertPositiveInteger(value.sourceGeneration, `${path}.sourceGeneration`);
    assertPositiveInteger(value.targetGeneration, `${path}.targetGeneration`);
    assertText(value.sourceCapabilitiesRevision, `${path}.sourceCapabilitiesRevision`);
    assertText(value.targetCapabilitiesRevision, `${path}.targetCapabilitiesRevision`);
    assertPositiveInteger(value.sourcePolicyRevision, `${path}.sourcePolicyRevision`);
    assertPositiveInteger(value.targetPolicyRevision, `${path}.targetPolicyRevision`);
    assertCapabilities(value.capabilities, `${path}.capabilities`);
    return value;
}
function assertChannelRef(value, path) {
    if (!isRecord(value))
        fail(`${path} must be an object`);
    assertEnvelopeKeys(value, ['connectionId', 'channelId', 'targetGeneration', 'engineInstanceId'], path);
    assertText(value.connectionId, `${path}.connectionId`);
    assertText(value.channelId, `${path}.channelId`);
    assertPositiveInteger(value.targetGeneration, `${path}.targetGeneration`);
    assertText(value.engineInstanceId, `${path}.engineInstanceId`);
    return value;
}
function parseTeamsConnectionFrameValue(value) {
    try {
        assertJsonValue(value, 'Teams connection frame');
    }
    catch (error) {
        fail(error instanceof Error ? error.message : 'Teams connection frame must contain JSON values');
    }
    if (!isRecord(value))
        fail('Teams connection frame must be an object');
    if (value.version !== 1)
        fail('Teams connection frame.version must equal 1');
    if (typeof value.kind !== 'string')
        fail('Teams connection frame.kind must be a string');
    const common = ['version', 'kind'];
    switch (value.kind) {
        case 'teams.connection.context': {
            assertEnvelopeKeys(value, [
                ...common,
                'connectionId',
                'targetGeneration',
                'capabilitiesRevision',
                'policyRevision',
                'engineInstanceId',
            ], 'Teams connection context');
            assertText(value.connectionId, 'context.connectionId');
            assertPositiveInteger(value.targetGeneration, 'context.targetGeneration');
            assertText(value.capabilitiesRevision, 'context.capabilitiesRevision');
            assertPositiveInteger(value.policyRevision, 'context.policyRevision');
            // D00 amendment A3: absence must fail here, because assertEnvelopeKeys only
            // rejects unknown keys. No default placeholder is supplied.
            assertText(value.engineInstanceId, 'context.engineInstanceId');
            break;
        }
        case 'teams.connection.propose': {
            assertEnvelopeKeys(value, [
                ...common,
                'requestId',
                'connectionId',
                'sourceGeneration',
                'targetGeneration',
                'sourceCapabilitiesRevision',
                'targetCapabilitiesRevision',
                'sourcePolicyRevision',
                'requestedRole',
                'requestedPeerRole',
                'requestedCapabilities',
            ], 'Teams connection propose');
            assertText(value.requestId, 'propose.requestId');
            assertText(value.connectionId, 'propose.connectionId');
            assertPositiveInteger(value.sourceGeneration, 'propose.sourceGeneration');
            assertPositiveInteger(value.targetGeneration, 'propose.targetGeneration');
            assertText(value.sourceCapabilitiesRevision, 'propose.sourceCapabilitiesRevision');
            assertText(value.targetCapabilitiesRevision, 'propose.targetCapabilitiesRevision');
            assertPositiveInteger(value.sourcePolicyRevision, 'propose.sourcePolicyRevision');
            assertRole(value.requestedRole, 'propose.requestedRole');
            assertRole(value.requestedPeerRole, 'propose.requestedPeerRole');
            assertRolePair(value.requestedRole, value.requestedPeerRole);
            assertCapabilities(value.requestedCapabilities, 'propose.requestedCapabilities');
            break;
        }
        case 'teams.connection.accept': {
            assertEnvelopeKeys(value, [...common, 'requestId', 'agreement'], 'Teams connection accept');
            assertText(value.requestId, 'accept.requestId');
            assertAgreement(value.agreement, 'accept.agreement');
            break;
        }
        case 'teams.connection.reject': {
            assertEnvelopeKeys(value, [...common, 'requestId', 'connectionId', 'error'], 'Teams connection reject');
            assertText(value.requestId, 'reject.requestId');
            assertText(value.connectionId, 'reject.connectionId');
            parseAcpFault(value.error);
            break;
        }
        case 'teams.connection.confirm': {
            assertEnvelopeKeys(value, [...common, 'requestId', 'agreement'], 'Teams connection confirm');
            assertText(value.requestId, 'confirm.requestId');
            assertAgreement(value.agreement, 'confirm.agreement');
            break;
        }
        case 'teams.connection.ready': {
            assertEnvelopeKeys(value, [...common, 'requestId', 'agreement'], 'Teams connection ready');
            assertText(value.requestId, 'ready.requestId');
            assertAgreement(value.agreement, 'ready.agreement');
            break;
        }
        case 'acp.open':
            assertEnvelopeKeys(value, [...common, 'ref'], 'ACP open');
            assertChannelRef(value.ref, 'open.ref');
            break;
        case 'acp.open_ack':
            assertEnvelopeKeys(value, [...common, 'ref'], 'ACP open ack');
            assertChannelRef(value.ref, 'open_ack.ref');
            break;
        case 'acp.frame': {
            assertEnvelopeKeys(value, [...common, 'ref', 'frame'], 'ACP frame');
            assertChannelRef(value.ref, 'frame.ref');
            parseAcpFrame(value.frame);
            break;
        }
        case 'acp.close':
            assertEnvelopeKeys(value, [...common, 'ref'], 'ACP close');
            assertChannelRef(value.ref, 'close.ref');
            break;
        case 'acp.error':
            assertEnvelopeKeys(value, [...common, 'ref', 'error'], 'ACP error');
            assertChannelRef(value.ref, 'error.ref');
            parseAcpFault(value.error);
            break;
        default:
            fail(`unsupported Teams connection frame kind ${value.kind}`);
    }
    return value;
}
export function parseTeamsConnectionFrame(value) {
    try {
        return parseTeamsConnectionFrameValue(value);
    }
    catch (error) {
        if (error instanceof AcpError)
            throw error;
        throw new AcpError('INVALID_ACP_FRAME', error instanceof Error ? error.message : 'Teams connection frame is invalid');
    }
}
