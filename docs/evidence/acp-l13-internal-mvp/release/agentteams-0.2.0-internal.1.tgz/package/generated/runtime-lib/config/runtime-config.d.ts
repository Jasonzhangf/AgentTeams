import type { ServiceErrorCode } from '../control-protocol/agent-services.ts';
export type ProviderProtocol = 'openai-chat' | 'openai-responses';
export interface ModelRef {
    readonly providerInstanceId: string;
    readonly modelId: string;
}
export interface ProviderInstance {
    readonly id: string;
    readonly label: string;
    readonly protocol: ProviderProtocol;
    readonly apiBaseUrl: string;
    readonly enabled: boolean;
    readonly auth: {
        readonly kind: 'none';
    } | {
        readonly kind: 'bearer';
        readonly credentialRef: string;
    };
}
export interface ModelMetadata {
    readonly label?: string;
    readonly contextWindow?: number;
    readonly maxOutputTokens?: number;
    readonly tools?: boolean;
    readonly streaming?: boolean;
    readonly reasoning?: boolean;
    readonly inputModalities?: readonly string[];
    readonly outputModalities?: readonly string[];
}
export interface ModelEntry {
    readonly ref: ModelRef;
    readonly origin: 'discovered' | 'manual';
    readonly base: ModelMetadata;
    readonly overrides: Partial<ModelMetadata>;
    readonly availability?: 'available' | 'unavailable';
}
export interface AgentModelBinding {
    readonly primary: ModelRef;
    readonly backup?: ModelRef;
}
export type AgentRuntimeConfig = AgentModelBinding;
export type ConfigErrorCode = ServiceErrorCode | 'CREDENTIAL_UNAVAILABLE' | 'SOURCE_CHANGED' | 'MIGRATION_CONFLICT' | 'APPLY_TARGET_MISMATCH';
export interface ConfigApplyError {
    readonly code: ConfigErrorCode;
    readonly message: string;
    readonly status?: number;
    readonly providerInstanceId?: string;
}
export type ModelCatalogState = 'ready' | 'empty' | 'stale' | 'error';
export interface ProviderModelCatalog {
    readonly state: ModelCatalogState;
    readonly entries: readonly ModelEntry[];
    readonly refreshedAt?: string;
    readonly error?: ConfigApplyError;
}
/** Accepted user-intent snapshot for one daemon; also the machine-agnostic view shape. */
export interface VersionedRuntimeConfig {
    /** Compatibility alias used by the runtime lifecycle; always equals acceptedRevision. */
    readonly revision: number;
    readonly acceptedRevision: number;
    readonly effectiveRevision?: number;
    readonly providers: Readonly<Record<string, ProviderInstance>>;
    readonly catalogs: Readonly<Record<string, ProviderModelCatalog>>;
    readonly agents: Readonly<Record<string, AgentModelBinding>>;
    readonly lastApplyError?: ConfigApplyError;
}
/** Exact identity of one configuration target at the moment an operation starts. */
export interface ConfigTargetIdentity {
    readonly agentId: string;
    readonly targetGeneration: number;
    readonly acceptedRevision: number;
    readonly acceptedSourceRevision: number;
    readonly acceptedSourceHash: string;
    readonly endpointFingerprint: string;
    readonly credentialRef?: string;
}
/** Merged machine-source + target-daemon accepted/effective/catalog observation. */
export interface DaemonRuntimeConfigView extends VersionedRuntimeConfig {
    readonly agentId: string;
    readonly sourceRevision: number;
    readonly sourceHash: string;
    readonly acceptedSourceRevision: number;
    readonly acceptedSourceHash: string;
    readonly applyState: 'clean' | 'uncertain';
    readonly targetGeneration: number;
}
/** Per-daemon discovered catalog observation; never contains manual entries. */
export interface ProviderCatalogObservation {
    readonly state: ModelCatalogState;
    readonly discoveredEntries: readonly ModelEntry[];
    readonly refreshedAt?: string;
    readonly error?: ConfigApplyError;
    readonly providerFingerprint: string;
    readonly observedAcceptedRevision: number;
    readonly observedAcceptedSourceRevision: number;
    readonly observedAcceptedSourceHash: string;
    readonly observedEndpoint: string;
    readonly observedCredentialRef?: string;
}
export interface ManagedOperationIdentity {
    readonly operationId: string;
    readonly kind: 'apply' | 'use-session';
    readonly target: ConfigTargetIdentity;
    readonly substrate: {
        readonly pid?: number;
        readonly effectiveRevision: number;
        readonly effectiveHandleFingerprint: string;
    };
}
export interface ManagedConfigUncertainty {
    readonly target: ConfigTargetIdentity;
    readonly operation: {
        readonly operationId: string;
        readonly kind: 'apply' | 'use-session';
    };
    readonly error: ConfigApplyError;
    readonly substrate: {
        readonly pid?: number;
        readonly effectiveRevision: number;
        readonly effectiveHandleFingerprint: string;
    };
}
export interface ManagedConfigUncertaintyFence {
    /** One record per ambiguous exchange/replacement; upsert by operationId, never a single overwrite. */
    readonly operations: readonly ManagedConfigUncertainty[];
}
export interface RuntimeConfigApplyRequest {
    readonly target: ConfigTargetIdentity;
    readonly config: DaemonRuntimeConfigView;
}
export type ConfigApplyResult = {
    readonly status: 'applied';
    readonly effectiveRevision: number;
} | {
    readonly status: 'unsupported' | 'failed';
    readonly error: ConfigApplyError;
} | {
    readonly status: 'uncertain';
    readonly error: ConfigApplyError;
    readonly fence: ManagedConfigUncertainty;
};
export interface RuntimeConfigApplier {
    apply(request: RuntimeConfigApplyRequest): Promise<ConfigApplyResult>;
}
export interface RefreshResult {
    readonly status: 'ready' | 'empty' | 'error';
    readonly config: DaemonRuntimeConfigView;
    readonly error?: ConfigApplyError;
}
/** Store-owned user-intent sections that map to `config.toml` providers/models/bindings. */
export interface RuntimeConfigStoreSections {
    readonly providers: Readonly<Record<string, ProviderInstance>>;
    readonly models: readonly ModelEntry[];
    readonly bindings: Readonly<Record<string, AgentModelBinding>>;
}
export interface RuntimeConfigTargetObservationPatch {
    readonly kind: 'target-observation';
    readonly catalogObservations?: Readonly<Record<string, ProviderCatalogObservation>>;
    readonly effectiveRevision?: number;
    readonly lastApplyError?: ConfigApplyError | null;
    readonly applyState?: 'clean' | 'uncertain';
    readonly uncertain?: ManagedConfigUncertainty;
    readonly expectedUncertain?: ManagedConfigUncertainty;
    readonly removeUncertainOperationId?: string;
    readonly target: ConfigTargetIdentity;
}
export interface RuntimeConfigOwnerFencePatch {
    readonly kind: 'owner-fence';
    readonly uncertain: ManagedConfigUncertainty;
    readonly expectedUncertain?: ManagedConfigUncertainty;
}
export type RuntimeConfigObservationPatch = RuntimeConfigTargetObservationPatch | RuntimeConfigOwnerFencePatch;
/**
 * Async persistence port. Every `*Unlocked` method assumes the caller already holds
 * `withLock`; it never re-enters the lock or performs external provider/OpenCode work.
 */
export interface RuntimeConfigPersistence {
    readonly agentId?: string;
    withLock<T>(task: () => Promise<T>): Promise<T>;
    loadDaemonUnlocked(agentId: string): Promise<DaemonRuntimeConfigView>;
    saveMachineSourceUnlocked(input: {
        readonly expectedSourceRevision: number;
        readonly expectedSourceHash: string;
        readonly sections: RuntimeConfigStoreSections;
    }): Promise<{
        readonly sourceRevision: number;
        readonly sourceHash: string;
    }>;
    acceptMachineSourceUnlocked(agentId: string, input: {
        readonly sourceRevision: number;
        readonly sourceHash: string;
        readonly expectedAcceptedRevision: number;
        readonly expectedAcceptedSourceHash: string | undefined;
    }): Promise<{
        readonly acceptedRevision: number;
        readonly acceptedSourceRevision: number;
        readonly acceptedSourceHash: string;
    }>;
    saveObservationUnlocked(agentId: string, patch: RuntimeConfigObservationPatch): Promise<void>;
}
export interface ResolvedCredential {
    readonly kind: 'bearer';
    readonly value: string;
}
export interface CredentialResolver {
    resolve(credentialRef: string): Promise<ResolvedCredential>;
}
export interface ProviderModelDescriptor {
    readonly modelId: string;
    readonly metadata: ModelMetadata;
}
export interface ProviderModelClient {
    listModels(input: {
        readonly provider: ProviderInstance;
        readonly credential?: ResolvedCredential;
    }): Promise<readonly ProviderModelDescriptor[]>;
}
export interface RuntimeConfigStore {
    read(): Promise<DaemonRuntimeConfigView>;
    readEffective(): Promise<{
        readonly acceptedRevision: number;
        readonly acceptedSourceRevision: number;
        readonly acceptedSourceHash: string;
        readonly effectiveRevision?: number;
        readonly applyState: 'clean' | 'uncertain';
        readonly lastApplyError?: ConfigApplyError;
    }>;
    listProviderInstances(): Promise<readonly ProviderInstance[]>;
    putProviderInstance(expectedRevision: number, provider: ProviderInstance): Promise<DaemonRuntimeConfigView>;
    removeProviderInstance(expectedRevision: number, providerInstanceId: string): Promise<DaemonRuntimeConfigView>;
    putModelEntry(expectedRevision: number, entry: ModelEntry): Promise<DaemonRuntimeConfigView>;
    bindAgentModel(expectedRevision: number, agentId: string, binding: AgentModelBinding): Promise<DaemonRuntimeConfigView>;
    selectAgentBackup(expectedRevision: number, agentId: string, backup?: ModelRef): Promise<DaemonRuntimeConfigView>;
    refreshProviderModels(expectedRevision: number, providerInstanceId: string, client: ProviderModelClient, credentials?: CredentialResolver): Promise<RefreshResult>;
    applyAcceptedConfig(applier: RuntimeConfigApplier): Promise<ConfigApplyResult>;
}
export interface RuntimeConfigStoreOptions {
    readonly agentId?: string;
}
export declare class RuntimeConfigError extends Error {
    readonly code: ConfigErrorCode;
    readonly status?: number;
    readonly providerInstanceId?: string;
    constructor(error: ConfigApplyError);
    toJSON(): ConfigApplyError;
}
export declare function createEmptyRuntimeConfig(): VersionedRuntimeConfig;
export declare function readConfigVersion(config: VersionedRuntimeConfig): number;
export declare function syncSharedRuntimeConfig(config: VersionedRuntimeConfig, admitted: boolean): VersionedRuntimeConfig;
/**
 * Canonical provider-instance validation. The v4 file intent parser reuses this
 * function so provider semantics have one implementation and one error owner.
 */
export declare function validateProvider(provider: ProviderInstance): void;
/** Canonical manual model-entry validation, reused by the v4 intent parser. */
export declare function validateModelEntry(entry: ModelEntry): void;
/** Canonical Agent model-binding validation, reused by the v4 intent parser. */
export declare function validateBinding(binding: AgentModelBinding, label?: string): void;
/**
 * Canonical binding-target closure check (provider/model existence, enabled and
 * availability). The v4 intent compiler reuses it after building the accepted
 * snapshot, so an unresolved file reference fails with the same rule.
 */
export declare function assertBindingTargets(config: VersionedRuntimeConfig, binding: AgentModelBinding): void;
export declare function providerIntentFingerprint(provider: ProviderInstance): string;
export declare function targetIdentityFor(view: DaemonRuntimeConfigView, provider?: ProviderInstance): ConfigTargetIdentity;
export declare function readUncertaintyFence(view: DaemonRuntimeConfigView): ManagedConfigUncertaintyFence;
/** Legacy JSON adapter retained only for migration fixtures and unit tests, never as a daemon entry. */
export declare function createJsonFileConfigPersistence(filePath: string): RuntimeConfigPersistence;
export declare function createRuntimeConfigStore(persistence: RuntimeConfigPersistence, options?: RuntimeConfigStoreOptions): RuntimeConfigStore;
export declare function readAgentRuntimeConfig(config: VersionedRuntimeConfig, agentId: string): AgentRuntimeConfig;
export declare function saveAgentRuntimeConfig(config: VersionedRuntimeConfig, agentId: string, next: AgentRuntimeConfig, expectedRevision: number): VersionedRuntimeConfig;
export declare function applyAgentRuntimeConfig(store: RuntimeConfigStore, applier: RuntimeConfigApplier): Promise<ConfigApplyResult>;
