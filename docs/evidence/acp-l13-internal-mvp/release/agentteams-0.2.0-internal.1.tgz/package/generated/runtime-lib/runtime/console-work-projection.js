function relationPermission(state) {
    if (state === 'rejected')
        return 'revoked';
    return 'granted';
}
/** Map durable Agent Work control fields only; request payloads never enter Console observation. */
export function projectConsoleWorkObservations(agentId, works) {
    if (!agentId)
        throw new Error('Console work observation requires the projecting Agent');
    return {
        works: works.map(work => ({
            agentId,
            workId: work.workId,
            consumerAgentId: work.consumerAgentId,
            providerAgentId: work.providerAgentId,
            capabilityId: work.capabilityId,
            capabilityVersion: work.capabilityVersion,
            policyRevision: work.policyRevision,
            state: work.state,
        })),
        relations: works.map(work => ({
            agentId,
            consumerAgentId: work.consumerAgentId,
            providerAgentId: work.providerAgentId,
            capabilityId: work.capabilityId,
            capabilityVersion: work.capabilityVersion,
            relationPermission: relationPermission(work.state),
            workId: work.workId,
        })),
    };
}
