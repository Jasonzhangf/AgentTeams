import type { AcpFault, HistoryRecord } from '../control-protocol/acp.ts';
import type { TeamsAgreement } from '../control-protocol/teams-connection.ts';
import type { HistoryPage, HistoryQuery, HistoryReadPort } from '../control-protocol/teams-state.ts';
import type { AcpHistoryPort } from '../agent-host/acp-history.ts';
/**
 * Teams connection history (owner: network).
 *
 * A thin typed wrapper over the injected durable store. It writes and reads only
 * `kind: 'connection'` records and keeps the frozen `HistoryRecord` shape, so
 * connection/role history never becomes a second request-history source and
 * never gains a second field vocabulary.
 *
 * The record shape carries no `role` or `targetGeneration` field: those facts
 * live in the typed `agreement` that a negotiation record stores. This module
 * does not invent fields to flatten them.
 */
export declare const TEAMS_CONNECTION_EVENTS: readonly ["connection.negotiated", "connection.rejected", "connection.closed", "connection.failed", "connection.half-open", "connection.registry-lost", "connection.registry-restored", "channel.opened", "channel.closed", "generation.replaced"];
export type TeamsConnectionEvent = (typeof TEAMS_CONNECTION_EVENTS)[number];
export type TeamsConnectionOutcome = 'completed' | 'failed' | 'denied' | 'unknown';
export interface TeamsConnectionHistoryEntry {
    readonly event: TeamsConnectionEvent;
    readonly agentId: string;
    readonly occurredAt: string;
    readonly connectionId?: string;
    readonly channelId?: string;
    readonly engineInstanceId?: string;
    readonly requestRecordId?: string;
    readonly sessionId?: string;
    readonly outcome?: TeamsConnectionOutcome;
    readonly error?: AcpFault;
    /** The negotiated agreement this connection event belongs to. */
    readonly agreement?: TeamsAgreement;
}
export interface TeamsConnectionHistory {
    record(entry: TeamsConnectionHistoryEntry): Promise<HistoryRecord>;
    /** Reads only `kind: 'connection'` records. A `request` query is refused, not silently rewritten. */
    query(query: HistoryQuery): Promise<HistoryPage>;
}
export declare function createTeamsConnectionHistory(store: AcpHistoryPort & HistoryReadPort): TeamsConnectionHistory;
