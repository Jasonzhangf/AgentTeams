import { RelayProtocolError } from "../control-protocol/relay-admission.js";
import { createRelayClient } from "./relay-client.js";
function describeFailure(error) {
    const code = error instanceof RelayProtocolError ? error.code : 'UNAVAILABLE';
    return { code, message: describeMessage(error) };
}
function describeMessage(error, depth = 0) {
    if (!(error instanceof Error))
        return String(error);
    const cause = error.cause;
    if (cause === undefined || depth >= 4)
        return error.message;
    return `${error.message}: ${describeMessage(cause, depth + 1)}`;
}
function positiveInteger(value, label, max = 2_147_483_647) {
    if (!Number.isSafeInteger(value) || value < 1 || value > max) {
        throw new RelayProtocolError('INVALID_INPUT', `registration: ${label} must be a positive safe integer`);
    }
    return value;
}
function validate(options) {
    if (typeof options.endpoint !== 'string' || !options.endpoint.startsWith('wss:')) {
        throw new RelayProtocolError('INVALID_INPUT', 'registration: endpoint must be a wss URL');
    }
    if (typeof options.credential !== 'string' || options.credential.length === 0 || /[\r\n]/.test(options.credential)) {
        throw new RelayProtocolError('INVALID_INPUT', 'registration: a valid credential is required');
    }
    positiveInteger(options.heartbeatIntervalMs, 'heartbeatIntervalMs');
    positiveInteger(options.admissionTimeoutMs, 'admissionTimeoutMs');
    positiveInteger(options.requestTimeoutMs, 'requestTimeoutMs');
    positiveInteger(options.maxPendingRequests, 'maxPendingRequests');
    positiveInteger(options.maxDataConnections, 'maxDataConnections');
    positiveInteger(options.connectTimeoutMs, 'connectTimeoutMs');
    positiveInteger(options.maxMessageBytes, 'maxMessageBytes');
    positiveInteger(options.maxBufferedBytes, 'maxBufferedBytes');
    positiveInteger(options.maxPendingFrames, 'maxPendingFrames');
    positiveInteger(options.reconnect.initialDelayMs, 'reconnect.initialDelayMs');
    positiveInteger(options.reconnect.maxDelayMs, 'reconnect.maxDelayMs');
    positiveInteger(options.reconnect.maxAttempts, 'reconnect.maxAttempts');
    if (options.reconnect.maxDelayMs < options.reconnect.initialDelayMs) {
        throw new RelayProtocolError('INVALID_INPUT', 'registration: reconnect.maxDelayMs must not be below reconnect.initialDelayMs');
    }
}
export function createRegistrationClient(options) {
    validate(options);
    const now = options.now ?? (() => new Date());
    const maxAttempts = options.reconnect.maxAttempts;
    let state = 'connecting';
    let relay;
    let generation;
    let attempts = 0;
    let reconnects = 0;
    let everConnected = false;
    let lastError;
    let lastSeenAt;
    let nextAttemptAt;
    let heartbeat;
    let retry;
    let heartbeatPending = false;
    let stopping = false;
    let closedResolved = false;
    let resolveClosed;
    const closed = new Promise(resolve => { resolveClosed = resolve; });
    const status = () => ({
        state,
        endpoint: options.endpoint,
        ...(generation === undefined ? {} : { generation }),
        attempts,
        reconnects,
        ...(lastError === undefined ? {} : { lastError }),
        ...(lastSeenAt === undefined ? {} : { lastSeenAt }),
        ...(nextAttemptAt === undefined ? {} : { nextAttemptAt }),
    });
    const publish = () => { options.onStatus?.(status()); };
    const clearHeartbeat = () => {
        if (heartbeat !== undefined) {
            clearInterval(heartbeat);
            heartbeat = undefined;
        }
    };
    const clearRetry = () => {
        if (retry !== undefined) {
            clearTimeout(retry);
            retry = undefined;
        }
    };
    const finish = (terminal) => {
        state = terminal;
        nextAttemptAt = undefined;
        clearHeartbeat();
        clearRetry();
        publish();
        if (!closedResolved) {
            closedResolved = true;
            resolveClosed(status());
        }
    };
    const relayOptions = () => ({
        declaration: options.declaration,
        transport: {
            endpoint: options.endpoint,
            credential: options.credential,
            ...(options.ca === undefined ? {} : { ca: options.ca }),
            connectTimeoutMs: options.connectTimeoutMs,
            maxMessageBytes: options.maxMessageBytes,
            maxBufferedBytes: options.maxBufferedBytes,
            maxPendingFrames: options.maxPendingFrames,
        },
        admissionTimeoutMs: options.admissionTimeoutMs,
        requestTimeoutMs: options.requestTimeoutMs,
        maxPendingRequests: options.maxPendingRequests,
        maxDataConnections: options.maxDataConnections,
    });
    const scheduleRetry = () => {
        const delayMs = Math.min(options.reconnect.initialDelayMs * 2 ** (attempts - 1), options.reconnect.maxDelayMs);
        nextAttemptAt = new Date(now().getTime() + delayMs).toISOString();
        state = 'reconnecting';
        publish();
        retry = setTimeout(() => { retry = undefined; void connect(); }, delayMs);
        retry.unref?.();
    };
    const recordFailure = (error) => {
        if (stopping)
            return;
        lastError = describeFailure(error);
        attempts += 1;
        if (attempts >= maxAttempts) {
            finish('failed');
            return;
        }
        scheduleRetry();
    };
    const onDisconnect = (reason) => {
        if (stopping)
            return;
        const client = relay;
        relay = undefined;
        clearHeartbeat();
        if (client !== undefined)
            void client.close().catch(() => undefined);
        recordFailure(reason);
    };
    const startHeartbeat = (client) => {
        clearHeartbeat();
        heartbeat = setInterval(() => {
            if (stopping || state !== 'online' || relay !== client || heartbeatPending)
                return;
            heartbeatPending = true;
            void client.presence()
                .then(() => { lastSeenAt = now().toISOString(); publish(); })
                .catch((cause) => onDisconnect(cause instanceof Error ? cause : new Error('registration: heartbeat failed')))
                .finally(() => { heartbeatPending = false; });
        }, options.heartbeatIntervalMs);
        heartbeat.unref?.();
    };
    const connect = async () => {
        if (stopping)
            return;
        if (attempts === 0) {
            state = 'connecting';
            publish();
        }
        let client;
        try {
            client = await createRelayClient(relayOptions());
        }
        catch (error) {
            recordFailure(error);
            return;
        }
        if (stopping) {
            await client.close().catch(() => undefined);
            return;
        }
        try {
            // The initial scoped directory query proves the directory path after admission.
            await client.directory(true);
        }
        catch (error) {
            await client.close().catch(() => undefined);
            recordFailure(error);
            return;
        }
        relay = client;
        generation = client.generation;
        if (everConnected)
            reconnects += 1;
        everConnected = true;
        attempts = 0;
        nextAttemptAt = undefined;
        lastSeenAt = now().toISOString();
        state = 'online';
        publish();
        startHeartbeat(client);
        void client.closed.then(reason => { if (relay === client)
            onDisconnect(reason); });
    };
    /** The one online-state guard: every directory/publish read needs the same live relay. */
    const onlineRelay = () => {
        const client = relay;
        if (state !== 'online' || client === undefined) {
            throw new RelayProtocolError(lastError?.code ?? 'UNAVAILABLE', lastError?.message ?? 'registration: client is not online');
        }
        return client;
    };
    return {
        closed,
        status,
        start: async () => { await connect(); return status(); },
        directory: async (subscribe) => await onlineRelay().directory(subscribe),
        directorySnapshot: async (subscribe) => await onlineRelay().directorySnapshot(subscribe),
        publish: async (declaration) => { await onlineRelay().publish(declaration); },
        stop: async () => {
            if (stopping) {
                await closed;
                return;
            }
            stopping = true;
            clearHeartbeat();
            clearRetry();
            const client = relay;
            relay = undefined;
            if (client !== undefined)
                await client.close().catch(() => undefined);
            if (state !== 'failed')
                state = 'stopped';
            publish();
            if (!closedResolved) {
                closedResolved = true;
                resolveClosed(status());
            }
        },
    };
}
