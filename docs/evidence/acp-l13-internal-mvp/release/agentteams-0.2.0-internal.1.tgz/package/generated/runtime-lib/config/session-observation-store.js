import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { RuntimeConfigError } from "./runtime-config.js";
import { sessionIntentScopeDirectory } from "./session-intent-store.js";
import { writeRecordAtomically } from "./durable-record.js";
/**
 * Durable Session observation: one record per agent, written by the agent daemon and read
 * by the control daemon.
 *
 * The agent daemon owns every Session and permission fact on this path — the sessions its
 * engine actually opened and the permission callbacks its engine is actually awaiting. This
 * record is how those facts reach the control daemon's Console projection, because the
 * control daemon declares no Teams listener and therefore has no channel to ask an agent
 * daemon for them. The direction is the mirror image of `config/session-intent-store.ts`:
 * there the control daemon writes the Session writes and the agent daemon reads them; here
 * the agent daemon publishes its own observation and the control daemon reads it. Neither
 * direction adds a control-to-agent channel, a second Session owner, or a Console data
 * path.
 *
 * The record carries projection rows only. It never carries Session business payloads, no
 * transcript, no permission option set and no credential, and the agent's own host stays
 * the only owner of the facts it publishes.
 */
export const SESSION_OBSERVATION_VERSION = 1;
/** Fixed file name inside the same account and scope record directory the intent record uses. */
export const SESSION_OBSERVATION_FILE_NAME = 'session-observation.json';
/**
 * The one record path both daemons derive independently.
 *
 * The directory is the one shared account-and-scope layout `config/session-intent-store.ts`
 * owns, so the two Session records for one agent live side by side under one directory and
 * this module does not restate the layout rule.
 */
export function sessionObservationScopePath(input) {
    return resolve(sessionIntentScopeDirectory(input), SESSION_OBSERVATION_FILE_NAME);
}
function fail(code, message) {
    throw new RuntimeConfigError({ code, message });
}
function invalid(message) {
    return { code: 'INVALID_INPUT', message };
}
function isTable(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function requireText(value, label) {
    if (typeof value !== 'string' || value.length === 0)
        return invalid(`${label} must be a non-empty string`);
    return undefined;
}
/**
 * Validate one snapshot on its own terms. A permission row that names a Session the same
 * snapshot does not report is refused: the reader would otherwise project a notification
 * whose Session row it cannot name, which is exactly the crossing this record must not
 * carry.
 */
function validateSnapshot(value) {
    if (!isTable(value))
        return invalid('session observation snapshot must be a table');
    const agentError = requireText(value.agentId, 'session observation snapshot agentId');
    if (agentError !== undefined)
        return agentError;
    if (!Array.isArray(value.sessions) || !Array.isArray(value.permissions)) {
        return invalid('session observation snapshot sessions and permissions must be arrays');
    }
    const sessionIds = new Set();
    for (const [index, session] of value.sessions.entries()) {
        if (!isTable(session))
            return invalid(`session observation snapshot sessions[${index}] must be a table`);
        const error = requireText(session.sessionId, `session observation snapshot sessions[${index}].sessionId`);
        if (error !== undefined)
            return error;
        if (sessionIds.has(session.sessionId))
            return invalid(`session observation snapshot repeats sessionId ${session.sessionId}`);
        sessionIds.add(session.sessionId);
    }
    const notificationIds = new Set();
    for (const [index, permission] of value.permissions.entries()) {
        if (!isTable(permission))
            return invalid(`session observation snapshot permissions[${index}] must be a table`);
        for (const field of ['notificationId', 'sessionId', 'permissionId']) {
            const error = requireText(permission[field], `session observation snapshot permissions[${index}].${field}`);
            if (error !== undefined)
                return error;
        }
        if (notificationIds.has(permission.notificationId)) {
            return invalid(`session observation snapshot repeats notificationId ${permission.notificationId}`);
        }
        notificationIds.add(permission.notificationId);
        if (!sessionIds.has(permission.sessionId)) {
            return invalid(`session observation snapshot permissions[${index}] names session ${permission.sessionId}, which it does not report`);
        }
    }
    return undefined;
}
function parseSnapshot(value) {
    return {
        agentId: value.agentId,
        sessions: value.sessions.map(session => ({ sessionId: session.sessionId })),
        permissions: value.permissions.map(permission => ({
            notificationId: permission.notificationId,
            sessionId: permission.sessionId,
            permissionId: permission.permissionId,
        })),
    };
}
function parseRecord(text, path) {
    let value;
    try {
        value = JSON.parse(text);
    }
    catch {
        fail('INVALID_INPUT', `session observation is not valid JSON: ${path}`);
    }
    if (!isTable(value))
        fail('INVALID_INPUT', `session observation must be a table: ${path}`);
    if (value.version !== SESSION_OBSERVATION_VERSION) {
        fail('UNSUPPORTED_VERSION', `session observation version must be ${SESSION_OBSERVATION_VERSION}: ${path}`);
    }
    const revision = value.revision;
    if (!Number.isSafeInteger(revision) || revision < 1) {
        fail('INVALID_INPUT', `session observation revision must be a positive integer: ${path}`);
    }
    const updatedError = requireText(value.updatedAt, 'session observation updatedAt');
    if (updatedError !== undefined)
        fail('INVALID_INPUT', `${updatedError.message}: ${path}`);
    const error = validateSnapshot(value);
    if (error !== undefined)
        fail('INVALID_INPUT', `${error.message}: ${path}`);
    return {
        version: SESSION_OBSERVATION_VERSION,
        revision: revision,
        updatedAt: value.updatedAt,
        ...parseSnapshot(value),
    };
}
/**
 * Read the observation record. A missing file means this agent has published nothing yet,
 * which is an honest absence rather than an empty observation. A broken stored record is a
 * typed throw: the reader never falls back to a default that would look like a real
 * observation.
 */
export async function readSessionObservationRecord(path) {
    let text;
    try {
        text = await readFile(path, 'utf8');
    }
    catch (cause) {
        if (cause.code === 'ENOENT')
            return undefined;
        fail('UNAVAILABLE', `session observation could not be read: ${path}`);
    }
    return parseRecord(text, path);
}
/**
 * Publish one observation with compare-and-swap on the durable revision. The agent daemon
 * is this record's single writer; the fence is what keeps a retry from reporting success
 * for an observation it did not store. `0` creates a record that does not exist yet.
 *
 * The snapshot is the whole observation, not a patch: a Session that closed and a permission
 * that resolved must disappear from the next revision, because a reader that keeps stale
 * rows would project a Session the engine no longer holds.
 */
export async function writeSessionObservationRecord(path, expectedRevision, snapshot) {
    if (!Number.isSafeInteger(expectedRevision) || expectedRevision < 0) {
        return { status: 'failed', error: invalid(`session observation expectedRevision must be a non-negative integer: ${path}`) };
    }
    const error = validateSnapshot(snapshot);
    if (error !== undefined)
        return { status: 'failed', error };
    // A malformed stored record fails here with its real code; the write then never runs, so
    // the existing bytes stay exactly as they were.
    const current = await readSessionObservationRecord(path);
    const acceptedRevision = current?.revision ?? 0;
    if (acceptedRevision !== expectedRevision) {
        return {
            status: 'failed',
            error: {
                code: 'REVISION_CONFLICT',
                message: `session observation revision is ${acceptedRevision}, expected ${expectedRevision}: ${path}`,
            },
        };
    }
    const revision = acceptedRevision + 1;
    return await writeRecordAtomically({
        path,
        label: 'session observation',
        record: { version: SESSION_OBSERVATION_VERSION, revision, updatedAt: new Date().toISOString(), ...snapshot },
        acceptedRevision,
        effectiveRevision: revision,
    });
}
