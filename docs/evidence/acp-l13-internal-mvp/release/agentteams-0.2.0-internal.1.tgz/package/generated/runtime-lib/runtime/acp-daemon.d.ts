import type { JsonValue } from '../control-protocol/agent-services.ts';
import type { AcpFault, AcpFrame, AcpRpcId } from '../control-protocol/acp.ts';
import type { EngineHandle, EngineLaunchSpec, EngineStopResult } from '../control-protocol/engine.ts';
import type { AcpPolicyIntent, AcpPolicySnapshot } from '../config/acp-policy.ts';
import type { AcpHistoryPort } from '../agent-host/acp-history.ts';
import { type AcpHost, type AcpPolicyAssert } from '../agent-host/acp-host.ts';
/**
 * Runtime child / stdio / Session owner for one ACP agent daemon.
 *
 * Owner: runtime. It launches the engine from the adapter's compiled
 * `EngineLaunchSpec`, owns the one stdio `AcpDuplex`, performs the single
 * bootstrap `initialize` as the sole reader before ownership transfer, and
 * composes the agent-host ACP host. It interprets no Session business.
 *
 * The legacy OpenCode SDK Session path (`runtime/agent-process.ts`
 * `createSessionHost` over the HTTP SDK client) stays untouched: it is the
 * D02 switch point, and this module does not add a second execution entry.
 *
 * Minimal call example (an adapter supplies `launch`; nothing else is
 * engine-specific):
 *
 * ```ts
 * const store = await createAcpHistoryStore({ directory: daemonDataDirectory })
 * const outcome = await startAcpAgentDaemon({
 *   launch: await adapter.compileLaunch(launchInput),
 *   engineInstanceId,
 *   targetGeneration,
 *   policy: { intent: acceptedConfig.acp, adapterMethods: adapter.declaredMethods },
 *   history: store,
 *   initialize: { params: { clientCapabilities: {} }, timeoutMs: 10_000 },
 *   stopTimeoutMs: 3_000,
 * })
 * if (outcome.kind === 'failed') throw new AcpError(outcome.fault.code, outcome.fault.message)
 * await outcome.daemon.host.open({ ref, principal, policy: outcome.daemon.policy })
 * ```
 */
export interface StartAcpEngineInput {
    readonly launch: EngineLaunchSpec;
    readonly engineInstanceId: string;
    readonly targetGeneration: number;
    readonly stopTimeoutMs: number;
    readonly resolveCredential?: (reference: string) => Promise<string>;
    readonly readTimeoutMs?: number;
    readonly maxFrameBytes?: number;
}
export type StartAcpEngineOutcome = {
    readonly kind: 'started';
    readonly handle: EngineHandle;
}
/**
 * `cleanup` is the real stop result of the spawned child. It is null only
 * when no OS process was created (pre-spawn validation, spawn error, or a
 * pid-less child), so a failed start can never hide a running engine.
 */
 | {
    readonly kind: 'failed';
    readonly fault: AcpFault;
    readonly cleanup: EngineStopResult | null;
};
export interface BootstrapAcpInitializeInput {
    readonly params?: JsonValue;
    readonly timeoutMs: number;
    readonly requestId?: AcpRpcId;
}
export type BootstrapAcpInitializeOutcome = {
    readonly kind: 'initialized';
    readonly result: AcpFrame;
} | {
    readonly kind: 'failed';
    readonly fault: AcpFault;
};
export interface AcpDaemonPolicyInput {
    readonly intent: AcpPolicyIntent;
    /** Adapter-verified extension methods merged into the capability set. */
    readonly adapterMethods?: readonly string[];
    /** Policy keys the adapter can actually enforce. Defaults to `supported`. */
    readonly enforceablePolicies?: readonly string[];
}
export interface StartAcpDaemonInput {
    readonly launch: EngineLaunchSpec;
    readonly engineInstanceId: string;
    readonly targetGeneration: number;
    /**
     * Resolved after the bootstrap initialize, because the supported capability
     * set is the real initialize declaration plus the adapter declaration. The
     * caller never re-initializes the child per client.
     */
    readonly policy: AcpDaemonPolicyInput;
    readonly history: AcpHistoryPort;
    readonly initialize: BootstrapAcpInitializeInput;
    readonly stopTimeoutMs: number;
    readonly resolveCredential?: (reference: string) => Promise<string>;
    readonly readTimeoutMs?: number;
    readonly maxFrameBytes?: number;
    readonly agentId?: string;
    readonly maxDeliveryBacklog?: number;
    readonly onHistoryFault?: (fault: AcpFault) => void;
    /** Defaults to the config-owned `assertAcpAllowed`. */
    readonly assertAllowed?: AcpPolicyAssert;
}
export interface AcpAgentDaemon {
    readonly handle: EngineHandle;
    readonly host: AcpHost;
    /** The genuine bootstrap initialize response the host serves to channels. */
    readonly initializeResult: AcpFrame;
    /** The resolved policy snapshot for this engine instance. */
    readonly policy: AcpPolicySnapshot;
    stop(): Promise<EngineStopResult>;
}
export type StartAcpDaemonOutcome = {
    readonly kind: 'started';
    readonly daemon: AcpAgentDaemon;
} | {
    readonly kind: 'failed';
    readonly fault: AcpFault;
    readonly cleanup: EngineStopResult | null;
};
/**
 * Write the adapter's compiled files and resolve its credential env refs, then
 * spawn exactly one child over the stdio ACP duplex.
 */
export declare function startAcpEngineHandle(input: StartAcpEngineInput): Promise<StartAcpEngineOutcome>;
/**
 * Perform the single real `initialize` exchange as the sole reader of the
 * duplex. The captured response is the only initialize result the agent-host
 * will ever serve; no per-client re-initialization exists.
 */
export declare function bootstrapAcpInitialize(handle: EngineHandle, input: BootstrapAcpInitializeInput): Promise<BootstrapAcpInitializeOutcome>;
/** Start one ACP agent daemon: child, stdio duplex, bootstrap initialize, host. */
export declare function startAcpAgentDaemon(input: StartAcpDaemonInput): Promise<StartAcpDaemonOutcome>;
