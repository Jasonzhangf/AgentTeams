import { type ControlDaemonIntent, type DaemonEffectiveConfig, type PeerIntent } from '../config/daemon-intent.ts';
import type { RelationRole } from '../control-protocol/teams-connection.ts';
import { type ConsoleCommandResultV1, type ConsoleCommandV1, type ConsoleClientV1, type ConsoleProjectionV1, type JsonValue } from '../control-protocol/console-api.ts';
import { type ConsoleProjectionSubscriber, type HistoryReadPort } from '../control-protocol/teams-state.ts';
import { type TeamsStatusPort } from '../network/teams-status.ts';
/**
 * Runtime single writer for the control-kind daemon. It composes the frozen v4 control
 * intent with the frozen Console wire surface and owns exactly one process: one PID, one
 * state file, one WebUI listener. It never starts an engine child, a registry, an implicit
 * master, or a second daemon.
 *
 * The Teams connection projection is a structural read of the real network status port
 * (`network/teams-status.ts`, D05). The child entry binds that owner from the daemon's own
 * real network facts; the port stays structurally optional so a daemon without the
 * dependency fails with a typed error instead of fabricating connection state. It never
 * infers online or execution state from history.
 *
 * The three frozen relation commands (A2.4) are written into the one durable
 * desired-relations record that the agent daemon observes later
 * (`config/relations-intent-store.ts`, one record per daemon data directory). This daemon
 * is that record's single writer: it writes desired intent and the accepted revision
 * only, and never reports a connection state, because the connection outcome belongs to
 * the reacting daemon.
 *
 * This file is both the parent lifecycle entry and the detached child entry, exactly like
 * `runtime/registry-process.ts`.
 */
declare const STATE_VERSION = 1;
/**
 * The network status port is the real D05 owner type. The control runtime consumes it
 * structurally and declares no synonymous port of its own.
 */
/** One bound Console owner: projection read plus the two mutation ingresses. */
export interface ControlOwnerBinding {
    readProjection(): Promise<ConsoleProjectionV1>;
    command(command: ConsoleCommandV1): Promise<ConsoleCommandResultV1>;
    sendSession(target: {
        readonly agentId: string;
        readonly sessionId: string;
    }, payload: JsonValue): Promise<ConsoleCommandResultV1>;
}
/** Owner projection feed. `watch` is absent when the owner cannot stream yet. */
export interface ControlProjectionSource {
    read(): Promise<ConsoleProjectionV1>;
    watch?: ConsoleProjectionSubscriber;
}
export type ControlDaemonLifecycleState = 'starting' | 'running' | 'failed' | 'stopped';
export interface ControlDaemonState {
    readonly version: typeof STATE_VERSION;
    readonly configPath: string;
    readonly entryPath: string;
    readonly daemonId: string;
    readonly startToken: string;
    readonly generation: number;
    readonly pid: number;
    readonly state: ControlDaemonLifecycleState;
    readonly url?: string;
    /** The typed failure the child published, so the parent re-throws the real code. */
    readonly errorCode?: ControlProcessErrorCode;
    readonly error?: string;
    readonly updatedAt: string;
}
export interface ControlDaemonStatus {
    readonly configPath: string;
    readonly statePath: string;
    readonly daemonId: string;
    readonly state: ControlDaemonLifecycleState;
    readonly generation: number;
    readonly pid?: number;
    readonly url?: string;
    readonly error?: string;
    /** Effective listener and owned paths; never a credential value. */
    readonly listener?: {
        readonly ip: string;
        readonly port: number;
    };
    readonly dataDirectory?: string;
}
export type ControlProcessErrorCode = 'INVALID_CONFIG' | 'UNSUPPORTED_CONFIGURATION' | 'ALREADY_RUNNING' | 'START_TIMEOUT' | 'STOP_TIMEOUT' | 'STALE_GENERATION' | 'STALE_OWNER' | 'INVALID_STATUS' | 'PORT_OCCUPIED' | 'CREDENTIAL_UNAVAILABLE' | 'HISTORY_UNAVAILABLE' | 'STREAM_UNAVAILABLE' | 'UNSUPPORTED_OPERATION';
export declare class ControlProcessError extends Error {
    readonly code: ControlProcessErrorCode;
    constructor(code: ControlProcessErrorCode, message: string, cause?: unknown);
}
export interface ControlDaemonStartOptions {
    readonly env?: NodeJS.ProcessEnv;
    readonly nodeExecutable?: string;
    readonly nodeArguments?: readonly string[];
    readonly startupTimeoutMs?: number;
}
export interface ControlProcessArgs {
    readonly configPath: string;
    readonly startToken?: string;
}
export declare function parseControlArgs(argv: readonly string[]): ControlProcessArgs;
/**
 * Loads one v4 control config through the frozen config owner. A non-control config is a
 * typed unsupported-configuration failure, never a silent reuse of another daemon kind.
 */
export declare function loadControlIntent(configPath: string): Promise<ControlDaemonIntent>;
/** The effective listener the control daemon binds; one readback for status and start. */
export declare function readControlEffectiveConfig(intent: ControlDaemonIntent): DaemonEffectiveConfig & {
    readonly listener: {
        readonly ip: string;
        readonly port: number;
    };
};
export declare function controlStatePath(intent: ControlDaemonIntent): string;
export declare function readControlState(statePath: string): Promise<ControlDaemonState | undefined>;
export declare function startControlDaemon(configPath: string, options?: ControlDaemonStartOptions): Promise<ControlDaemonStatus>;
export declare function statusControlDaemon(configPath: string): Promise<ControlDaemonStatus>;
export declare function stopControlDaemon(configPath: string, expectedGeneration?: number): Promise<ControlDaemonStatus>;
/** Structural history read: the frozen port or a typed absence, never a fabricated page. */
export declare function createControlHistoryReader(port: TeamsStatusPort | undefined): HistoryReadPort;
/**
 * The accepted control intent facts that own the durable desired-relations record: the
 * daemon's own accepted `peers` (the only legal connect targets), its accepted
 * `relations.allowed` (the one role derivation) and the data directory that owns the file.
 * They are threaded from the daemon's own `loadControlIntent` value; the owner never opens
 * the config file again and never reads the environment.
 */
export interface ControlRelationsIntentFacts {
    readonly peers: Readonly<Record<string, PeerIntent>>;
    readonly allowedRoles: readonly RelationRole[];
    /**
     * The account and scope of the target agent, and the home root the shared record path
     * resolves from. This daemon's own configured `daemon.dataDirectory` is deliberately
     * NOT used: an agent daemon must be able to derive the same path from its own facts,
     * and the frozen v4 `PeerIntent` (`config/daemon-intent.ts`: `agentId`, `hostId`,
     * `accountId`, `scopeId`, `endpoint?`, `admissionRef?`, `credentialRef`, `tlsTrustRef?`)
     * carries no peer `dataDirectory`. Adding a key is out of scope, so the one path both
     * sides derive independently is the shared account and scope layout that
     * `config/relations-intent-store.ts` exports:
     * `<home>/.agentteams/relations/<accountId>/<scopeId>/relations-intent.json`.
     *
     * Honest limitation: the record is one desired membership set per account and scope,
     * not one file per agent. A `disconnect` for an agentId this daemon no longer declares
     * is refused, because its account and scope — and therefore its record — cannot be resolved.
     */
    readonly home: string;
}
export interface CreateControlOwnerOptions {
    readonly network?: TeamsStatusPort;
    readonly owner?: ControlOwnerBinding;
    /**
     * The real projection owner. When bound it owns the complete read, including the
     * connection rows it already merged; `network` stays the read port for the connection
     * projection.
     */
    readonly source?: ControlProjectionSource;
    /**
     * The accepted control intent facts for the frozen relation commands (A2.4). Without
     * them those commands fail with the typed absence instead of writing a guessed record.
     */
    readonly relations?: ControlRelationsIntentFacts;
}
/**
 * The control owner client. Without a network status port the connection projection stays
 * absent, and without the daemon's accepted intent facts the relation commands fail with
 * the typed absence; nothing is faked. With those facts the relation commands write the
 * one durable desired-relations record through the delivered CAS store.
 */
export declare function createControlOwner(options: CreateControlOwnerOptions): ConsoleClientV1;
/** One bound real network read chain: the D05 status port, its projection owner and its stop path. */
export interface ControlNetworkStatusBinding {
    readonly port: TeamsStatusPort;
    /**
     * The real Console projection owner. `read` is the D04 directory readback projected into
     * the frozen Console rows plus the D05 connection rows; `watch` streams a frame whenever
     * that real read changes. `watch` is absent only when the owner cannot stream.
     */
    readonly projection: ControlProjectionSource;
    readonly stop: () => Promise<void>;
}
/**
 * The Sessions and pending permissions the Console projection reports, read from the
 * observation records the declared agent daemons publish.
 *
 * The agent daemon owns each record because it owns the Sessions and permission callbacks it
 * carries. This reader resolves one path per declared peer from the same account and scope
 * layout the writer used, and it adds no channel of its own. Three rules keep the projection
 * honest:
 *
 *  - A declared peer whose record does not exist or is empty contributes no rows, so the
 *    Console never invents a Session.
 *  - A peer the current directory readback reports as not online contributes nothing, so a
 *    directory that knows the daemon is down never keeps projecting its last observation.
 *    A peer the directory does not report at all is not treated as offline: a deployment
 *    with no registry has no liveness truth, and the agent daemon itself publishes the empty
 *    observation when it stops, which is the owner's own answer to the same question.
 *  - A record that names another agent is skipped rather than projected under this one, which
 *    keeps the `agentId` on every row the agent that really owns it.
 */
export declare function readObservedSessionProjection(input: {
    readonly home: string;
    readonly peers: readonly {
        readonly agentId: string;
        readonly accountId: string;
        readonly scopeId: string;
    }[];
    /** The presence the directory readback reports, by agent. A missing agent has no report. */
    readonly presence: ReadonlyMap<string, string>;
}): Promise<Pick<ConsoleProjectionV1, 'sessions' | 'notifications'>>;
export declare function createControlNetworkStatus(intent: ControlDaemonIntent, env: NodeJS.ProcessEnv): Promise<ControlNetworkStatusBinding>;
/** Polling owner feed. It emits a full snapshot only when the owner projection changes. */
export declare function createPollingProjectionSubscriber(read: () => Promise<ConsoleProjectionV1>, intervalMs?: number): ConsoleProjectionSubscriber;
interface ControlProjectionFixture {
    readonly snapshots: readonly {
        readonly delayMs: number;
        readonly seq: number;
        readonly projection: ConsoleProjectionV1;
    }[];
    readonly closeAfter?: {
        readonly delayMs: number;
        readonly reason: 'stream-ended' | 'retry-exhausted';
        readonly detail: string;
    };
}
/**
 * Deterministic projection feed for the black-box entry. It is reachable only through an
 * explicit environment variable and never participates in a normal daemon start.
 */
export declare function createFixtureProjectionSubscriber(fixture: ControlProjectionFixture): ConsoleProjectionSubscriber;
/**
 * Detached child entry. It publishes its own readiness into the one state file after the
 * WebUI listener is bound, so `control status` never reports a fabricated `running` state.
 */
export declare function runControlProcess(argv?: readonly string[], env?: NodeJS.ProcessEnv): Promise<void>;
export {};
