function containsEndpoint(candidate) {
    return candidate.endpoint !== undefined;
}
function isDirectWssEndpoint(endpoint) {
    try {
        const url = new URL(endpoint);
        return url.protocol === 'wss:' && url.username === '' && url.password === '' && url.hash === '';
    }
    catch {
        return false;
    }
}
export function buildDirectWssRoutePlan(input) {
    for (const candidate of input.candidates) {
        if (candidate.kind === 'relay-ws' || candidate.kind === 'relay-webrtc') {
            throw new Error('route-plan: direct WSS route cannot select a relay candidate');
        }
        if (typeof candidate.endpoint !== 'string' || !isDirectWssEndpoint(candidate.endpoint)) {
            throw new Error('route-plan: direct WSS route requires an explicit wss:// endpoint without credentials');
        }
    }
    return buildRoutePlan(input);
}
export function activeDirectWssCandidate(plan) {
    const candidateId = plan.candidateOrder[plan.cursor];
    const candidate = plan.candidates.find((item) => item.candidateId === candidateId);
    if (!candidate)
        throw new Error('route-plan: active route candidate is missing');
    if (candidate.kind === 'relay-ws' || candidate.kind === 'relay-webrtc') {
        throw new Error('route-plan: active route is not direct WSS');
    }
    if (!isDirectWssEndpoint(candidate.endpoint ?? '')) {
        throw new Error('route-plan: active route requires an explicit wss:// endpoint without credentials');
    }
    return candidate;
}
export function buildRoutePlan(input) {
    if (input.hostId.length === 0)
        throw new Error('route-plan: hostId is required');
    if (!Number.isInteger(input.directoryGeneration) || input.directoryGeneration < 1) {
        throw new Error('route-plan: directory generation must be a positive integer');
    }
    if (input.candidates.length === 0)
        throw new Error('route-plan: no route candidates');
    if (input.policy === 'manual') {
        const target = input.candidates.find((candidate) => candidate.candidateId === input.targetCandidateId);
        if (!target || !containsEndpoint(target)) {
            throw new Error('route-plan: manual route must select an existing candidate with endpoint');
        }
        return {
            hostId: input.hostId,
            directoryGeneration: input.directoryGeneration,
            policy: 'manual',
            candidates: [target],
            candidateOrder: [target.candidateId],
            cursor: 0,
            state: 'pending',
        };
    }
    const ordered = input.candidates.filter(containsEndpoint);
    if (ordered.length === 0)
        throw new Error('route-plan: auto route has no usable candidate with endpoint');
    return {
        hostId: input.hostId,
        directoryGeneration: input.directoryGeneration,
        policy: 'auto',
        candidates: ordered,
        candidateOrder: ordered.map((candidate) => candidate.candidateId),
        cursor: 0,
        state: 'pending',
    };
}
export function beginRouteCandidate(plan) {
    if (plan.state !== 'pending' && plan.state !== 'active')
        throw new Error('route-plan: plan is not active');
    return { ...plan, state: 'active' };
}
export function succeedRouteCandidate(plan, candidateId) {
    if (plan.state !== 'active')
        throw new Error('route-plan: only an active route can succeed');
    if (plan.candidateOrder[plan.cursor] !== candidateId)
        throw new Error('route-plan: candidate is not the active route');
    return { ...plan, state: 'succeeded' };
}
export function failRouteCandidate(plan, candidateId, reason) {
    if (plan.state === 'succeeded')
        throw new Error('route-plan: succeeded route cannot be rewritten as failed');
    if (plan.candidateOrder[plan.cursor] !== candidateId)
        throw new Error('route-plan: candidate is not the active route');
    const nextCursor = plan.cursor + 1;
    if (nextCursor >= plan.candidateOrder.length) {
        return { ...plan, state: 'failed', lastError: reason };
    }
    return { ...plan, cursor: nextCursor, state: 'pending', lastError: reason };
}
