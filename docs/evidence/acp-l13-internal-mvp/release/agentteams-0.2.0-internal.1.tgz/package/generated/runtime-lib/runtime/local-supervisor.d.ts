import { spawn as nodeSpawn } from 'node:child_process';
import { type LocalConfig, type LocalInternalConfig } from './local-config.ts';
import { type LocalConsolePublicStatus, type LocalWorkControlReply, type LocalWorkControlRequest } from './local-work-control.ts';
/** Launcher -> receiver child typed Work frame; business payload stays in `frame`. */
export interface LocalWorkChildRequest {
    readonly kind: 'work.control';
    readonly localCorrelation: string;
    readonly receiverAgentId: string;
    readonly expectedLauncherGeneration: number;
    readonly expectedAgentGeneration: number;
    readonly frame: LocalWorkControlRequest;
}
/** Receiver child -> launcher typed Work reply keyed by the local correlation. */
export interface LocalWorkChildReply {
    readonly kind: 'work.reply';
    readonly localCorrelation: string;
    readonly reply: LocalWorkControlReply;
}
export declare function localWorkControlSocketPath(internalPath: string): string;
export interface LocalDaemonIdentityProjection {
    readonly hostId: string;
    readonly machineId: string;
    readonly agentId: string;
    readonly accountId: string;
    readonly agentKind: 'opencode' | 'acp' | 'custom';
    readonly label: string;
}
export interface LocalDaemonResourceProjection {
    readonly resourceId: string;
    readonly capacity: number;
    readonly unit: 'slot' | 'context';
}
export interface LocalDaemonCapabilityProjection {
    readonly capabilityId: string;
    readonly version: string;
    readonly operations: readonly string[];
    readonly resources: readonly LocalDaemonResourceProjection[];
}
export interface LocalDaemonEndpointProjection {
    readonly agentId: string;
    readonly identity: LocalDaemonIdentityProjection;
    readonly role: 'provider' | 'receiver' | 'hybrid';
    readonly presence: 'online' | 'offline' | 'unknown';
    readonly state: 'online' | 'stopped' | 'failed';
    readonly generation: number;
    readonly capabilities: readonly LocalDaemonCapabilityProjection[];
}
export interface LocalDaemonStatusProjection {
    readonly version: 1;
    readonly generation: number;
    readonly startToken: string;
    readonly daemons: Readonly<Record<string, LocalDaemonEndpointProjection>>;
}
export interface LocalProcessSpec {
    readonly id: string;
    readonly kind: 'relay' | 'agent' | 'console';
    readonly entry: string;
    readonly args: readonly string[];
}
export interface LocalSupervisorOptions {
    readonly nodeExecutable?: string;
    /** Runtime flags are explicit so source and packaged entrypoints share the same child contract. */
    readonly nodeArguments?: readonly string[];
    readonly relayEntry?: string;
    readonly agentEntry?: string;
    readonly consoleEntry?: string;
    readonly env?: NodeJS.ProcessEnv;
    readonly startToken?: string;
    readonly launcherGeneration?: number;
    readonly startupTimeoutMs?: number;
    readonly stopTimeoutMs?: number;
    readonly spawn?: typeof nodeSpawn;
}
export type LocalSupervisorState = 'stopped' | 'starting' | 'running' | 'stopping' | 'failed';
export declare class LocalConsoleLifecycleError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** Validate the Agent-owned status snapshot before it becomes runtime projection truth. */
export declare function parseLocalDaemonEndpointProjection(value: unknown, label?: string): LocalDaemonEndpointProjection;
export declare function parseLocalDaemonStatusProjection(value: unknown, label?: string): LocalDaemonStatusProjection;
export declare function localDaemonStatusProjectionPath(internalPath: string): string;
export declare function writeLocalDaemonStatusProjection(internalPath: string, projection: LocalDaemonStatusProjection): Promise<string>;
export declare function readLocalDaemonStatusProjection(internalPath: string): Promise<LocalDaemonStatusProjection | undefined>;
export declare function planLocalProcesses(config: LocalConfig, options?: Pick<LocalSupervisorOptions, 'nodeExecutable' | 'relayEntry' | 'agentEntry' | 'consoleEntry'>): readonly LocalProcessSpec[];
/**
 * Read-only Console classification shared by the supervisor socket handler and
 * the public CLI status path. It never writes runtime facts and never invents
 * online availability from a stale durable record.
 */
export declare function classifyLocalConsoleStatus(config: LocalConfig, internal: LocalInternalConfig, env?: NodeJS.ProcessEnv, fallback?: {
    readonly state: LocalSupervisorState;
    readonly generation: number;
}): Promise<LocalConsolePublicStatus>;
export interface LocalSupervisor {
    readonly state: () => LocalSupervisorState;
    readonly failure: () => Error | undefined;
    readonly processes: () => readonly LocalProcessSpec[];
    /** Runtime-owned lifecycle generation; increments per successful start and persists through the launcher. */
    readonly generation: () => number;
    start(): Promise<void>;
    stop(): Promise<void>;
    consoleStatus(): Promise<LocalConsolePublicStatus>;
    consoleStart(expectedConsoleGeneration?: number): Promise<LocalConsolePublicStatus>;
    consoleStop(expectedConsoleGeneration?: number): Promise<LocalConsolePublicStatus>;
}
export declare function createLocalSupervisor(config: LocalConfig, options?: LocalSupervisorOptions): LocalSupervisor;
