import type { HistoryReadPort } from '../control-protocol/teams-state.ts';
import type { AcpHistoryPort } from '../agent-host/acp-history.ts';
export interface AcpHistoryStore extends AcpHistoryPort, HistoryReadPort {
    /** Absolute path of the durable history file. */
    readonly path: string;
}
export interface CreateAcpHistoryStoreInput {
    /** The daemon's own data directory. */
    readonly directory: string;
    readonly fileName?: string;
    /** Maximum retained records; the oldest records are pruned first. */
    readonly retention?: number;
}
export declare function createAcpHistoryStore(input: CreateAcpHistoryStoreInput): Promise<AcpHistoryStore>;
