import { type RelayClient, type RelayClientOptions } from '../network/relay-client.ts';
import { type DirectWssTarget, type DirectWssTargetOptions } from '../network/direct-route.ts';
import { type DirectPeerRouteInput } from '../network/peer-route.ts';
export type DirectPeerConnector = (options: DirectWssTargetOptions) => Promise<DirectWssTarget>;
export interface AgentDaemonOptions {
    readonly relay: RelayClientOptions;
    readonly presenceIntervalMs: number;
    readonly signal?: AbortSignal;
    readonly directPeerConnector?: DirectPeerConnector;
}
export interface AgentDaemonStatus {
    readonly state: 'online' | 'stopping' | 'stopped' | 'failed';
    readonly agentId: string;
    readonly generation: number;
    readonly error?: Error;
}
export interface AgentDaemon {
    /** Network control resource for Agent Host composition, never business payload. */
    readonly network: RelayClient;
    readonly closed: Promise<AgentDaemonStatus>;
    status(): AgentDaemonStatus;
    connectPeer(options: DirectWssTargetOptions): Promise<DirectWssTarget>;
    connectPeerRoute(input: DirectPeerRouteInput): Promise<DirectWssTarget>;
    stop(): Promise<void>;
}
/** Owns one Agent's live registration. Executor readiness is a separate concern. */
export declare function startAgentDaemon(options: AgentDaemonOptions): Promise<AgentDaemon>;
