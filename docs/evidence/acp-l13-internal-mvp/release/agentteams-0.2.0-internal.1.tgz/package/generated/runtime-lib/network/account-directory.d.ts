import type { RelayPeer } from '../control-protocol/agent-services.ts';
import type { HostDirectory, HostDirectoryEntry } from '../server/directory.ts';
export interface AccountDirectoryPeerState {
    readonly hostId: string;
    readonly agentId: string;
    readonly scopeId: string;
    readonly generation: number;
    readonly presence: RelayPeer['presence'];
}
export interface AccountDirectorySnapshot {
    readonly accountId: string;
    readonly scopeId?: string;
    readonly generation: number;
    readonly confirmedGeneration?: number;
    readonly hosts: readonly HostDirectoryEntry[];
    /** Relay connection metadata retained beside the route projection. */
    readonly peerStates?: readonly AccountDirectoryPeerState[];
}
/** Projects the admitted Relay directory into the route-oriented account view. */
export declare function projectRelayDirectory(accountId: string, revision: number, peers: readonly RelayPeer[], expectedScopeId?: string): AccountDirectorySnapshot;
export declare function refreshRelayDirectory(previous: AccountDirectorySnapshot, revision: number, peers: readonly RelayPeer[]): AccountDirectorySnapshot;
export declare function createAccountDirectorySnapshot(directory: HostDirectory, accountId: string): AccountDirectorySnapshot;
export declare function confirmDirectoryGeneration(snapshot: AccountDirectorySnapshot, confirmedGeneration: number): AccountDirectorySnapshot;
export declare function refreshAccountDirectory(previous: AccountDirectorySnapshot, directory: HostDirectory): AccountDirectorySnapshot;
export declare function resolveHostFromDirectory(snapshot: AccountDirectorySnapshot, hostId: string): HostDirectoryEntry;
