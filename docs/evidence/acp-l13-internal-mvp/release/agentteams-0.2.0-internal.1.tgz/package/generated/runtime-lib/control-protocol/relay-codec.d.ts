import type { AgentDeclaration, RelayServerControl, ServiceError, ServiceErrorCode } from './agent-services.ts';
export declare class RelayProtocolError extends Error {
    readonly code: ServiceErrorCode;
    constructor(code: ServiceErrorCode, message: string);
}
export declare function parseAgentDeclaration(value: unknown): AgentDeclaration;
export declare function parseServiceError(value: unknown, label: string): ServiceError;
export declare function parseRelayServerControl(text: string): RelayServerControl;
