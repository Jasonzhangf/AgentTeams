import type { IncomingMessage, ServerResponse } from 'node:http';
import { type ConsoleClientV1 } from '../../control-protocol/console-api.ts';
import { type ConsoleProjectionSubscriber, type HistoryReadPort } from '../../control-protocol/teams-state.ts';
export interface ConsoleApiOptions {
    /** Runtime authenticates this request and returns only its authorized daemon binding. */
    readonly authorize: (request: IncomingMessage) => Promise<ConsoleClientV1 | undefined>;
    /** Owner history reader. Absent means the control runtime has no bound history owner. */
    readonly history?: HistoryReadPort;
    /** Owner projection feed for the SSE stream. Absent means no stream can be offered. */
    readonly events?: ConsoleProjectionSubscriber;
    readonly maxBodyBytes?: number;
}
/** HTTP transport only: no Session, configuration, relationship or permission state is owned here. */
export declare function createConsoleApiHandler(options: ConsoleApiOptions): (request: IncomingMessage, response: ServerResponse) => Promise<void>;
