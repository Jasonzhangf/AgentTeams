import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { parseDaemonConfigText, readDaemonEffectiveConfig, resolveDaemonIntent, } from "../config/daemon-intent.js";
import { readRelationsIntentRecord, relationsIntentScopePath, writeRelationsIntentRecord, } from "../config/relations-intent-store.js";
import { readSessionIntentRecord, sessionIntentScopePath, writeSessionIntentRecord, } from "../config/session-intent-store.js";
import { readSessionObservationRecord, sessionObservationScopePath } from "../config/session-observation-store.js";
import { RuntimeConfigError } from "../config/runtime-config.js";
import { createConsoleAuthorization } from "../console-host/src/auth.js";
import { createConsoleServer } from "../console-host/src/server.js";
import { parseConsoleProjection, } from "../control-protocol/console-api.js";
import { parseConsoleProjectionSnapshot, parseHistoryQuery, } from "../control-protocol/teams-state.js";
import { refreshRelayDirectory } from "../network/account-directory.js";
import { createTeamsConnectionHistory } from "../network/teams-connection-history.js";
import { createTeamsConnectionLedger } from "../network/teams-ingress.js";
import { membershipHistoryEvents, projectTeamsMembership } from "../network/teams-membership.js";
import { createTeamsStatusPort } from "../network/teams-status.js";
import { createAcpHistoryStore } from "./acp-history-store.js";
import { directoryAgentObservation } from "./console-hub.js";
import { processAlive, processCommand, processOwnsConfigCommand } from "./local-ownership.js";
import { RegistrationProcessError, startDaemonRegistration } from "./registry-registration.js";
/**
 * Runtime single writer for the control-kind daemon. It composes the frozen v4 control
 * intent with the frozen Console wire surface and owns exactly one process: one PID, one
 * state file, one WebUI listener. It never starts an engine child, a registry, an implicit
 * master, or a second daemon.
 *
 * The Teams connection projection is a structural read of the real network status port
 * (`network/teams-status.ts`, D05). The child entry binds that owner from the daemon's own
 * real network facts; the port stays structurally optional so a daemon without the
 * dependency fails with a typed error instead of fabricating connection state. It never
 * infers online or execution state from history.
 *
 * The three frozen relation commands (A2.4) are written into the one durable
 * desired-relations record that the agent daemon observes later
 * (`config/relations-intent-store.ts`, one record per daemon data directory). This daemon
 * is that record's single writer: it writes desired intent and the accepted revision
 * only, and never reports a connection state, because the connection outcome belongs to
 * the reacting daemon.
 *
 * This file is both the parent lifecycle entry and the detached child entry, exactly like
 * `runtime/registry-process.ts`.
 */
const STATE_VERSION = 1;
const STATE_FILE_NAME = 'control-state.json';
const TOKEN_FLAG = '--start-token';
const AUTHENTICATION_CHALLENGE = 'Basic realm="AgentTeams", charset="UTF-8"';
const CONTROL_PROCESS_ERROR_CODES = [
    'INVALID_CONFIG', 'UNSUPPORTED_CONFIGURATION', 'ALREADY_RUNNING', 'START_TIMEOUT', 'STOP_TIMEOUT',
    'STALE_GENERATION', 'STALE_OWNER', 'INVALID_STATUS', 'PORT_OCCUPIED', 'CREDENTIAL_UNAVAILABLE',
    'HISTORY_UNAVAILABLE', 'STREAM_UNAVAILABLE', 'UNSUPPORTED_OPERATION',
];
export class ControlProcessError extends Error {
    code;
    constructor(code, message, cause) {
        super(message, { cause });
        this.code = code;
        this.name = 'ControlProcessError';
    }
}
export function parseControlArgs(argv) {
    let configPath;
    let startToken;
    for (let index = 0; index < argv.length; index += 1) {
        const argument = argv[index];
        if (argument === '--config') {
            configPath = argv[index + 1];
            index += 1;
        }
        else if (argument.startsWith('--config=')) {
            configPath = argument.slice('--config='.length);
        }
        else if (argument === TOKEN_FLAG) {
            startToken = argv[index + 1];
            index += 1;
        }
        else if (argument.startsWith(`${TOKEN_FLAG}=`)) {
            startToken = argument.slice(TOKEN_FLAG.length + 1);
        }
        else {
            throw new ControlProcessError('INVALID_CONFIG', `usage: control-process --config <file> [${TOKEN_FLAG} <token>]`);
        }
    }
    if (configPath === undefined || configPath.trim() === '') {
        throw new ControlProcessError('INVALID_CONFIG', `usage: control-process --config <file> [${TOKEN_FLAG} <token>]`);
    }
    if (startToken !== undefined && startToken.trim() === '') {
        throw new ControlProcessError('INVALID_CONFIG', `${TOKEN_FLAG} requires a non-empty token`);
    }
    return { configPath: resolve(configPath), ...(startToken === undefined ? {} : { startToken }) };
}
/**
 * Loads one v4 control config through the frozen config owner. A non-control config is a
 * typed unsupported-configuration failure, never a silent reuse of another daemon kind.
 */
export async function loadControlIntent(configPath) {
    const absolute = resolve(configPath);
    let text;
    try {
        text = await readFile(absolute, 'utf8');
    }
    catch (cause) {
        throw new ControlProcessError('INVALID_CONFIG', `control config could not be read: ${absolute}`, cause);
    }
    let intent;
    try {
        intent = parseDaemonConfigText(text);
    }
    catch (cause) {
        throw new ControlProcessError('INVALID_CONFIG', cause instanceof Error ? cause.message : String(cause), cause);
    }
    if (intent.daemon.kind !== 'control') {
        throw new ControlProcessError('UNSUPPORTED_CONFIGURATION', 'control daemon config is required; start agent, registry, or console daemons with their own entry');
    }
    return resolveDaemonIntent(intent, { configDirectory: dirname(absolute) });
}
/** The effective listener the control daemon binds; one readback for status and start. */
export function readControlEffectiveConfig(intent) {
    const effective = readDaemonEffectiveConfig(intent);
    if (effective.listener === undefined)
        throw new ControlProcessError('INVALID_CONFIG', 'control daemon requires a webui listener');
    return { ...effective, listener: effective.listener };
}
export function controlStatePath(intent) {
    return join(intent.daemon.dataDirectory, STATE_FILE_NAME);
}
export async function readControlState(statePath) {
    let text;
    try {
        text = await readFile(statePath, 'utf8');
    }
    catch (cause) {
        if (cause.code === 'ENOENT')
            return undefined;
        throw new ControlProcessError('INVALID_STATUS', `control state could not be read: ${statePath}`, cause);
    }
    let value;
    try {
        value = JSON.parse(text);
    }
    catch (cause) {
        throw new ControlProcessError('INVALID_STATUS', `control state is not valid JSON: ${statePath}`, cause);
    }
    const state = value;
    if (state === null || typeof state !== 'object' || state.version !== STATE_VERSION
        || typeof state.configPath !== 'string' || typeof state.entryPath !== 'string'
        || typeof state.startToken !== 'string' || !Number.isSafeInteger(state.generation)
        || !Number.isSafeInteger(state.pid) || !['starting', 'running', 'failed', 'stopped'].includes(state.state)
        || (state.errorCode !== undefined && !CONTROL_PROCESS_ERROR_CODES.includes(state.errorCode))) {
        throw new ControlProcessError('INVALID_STATUS', `control state is malformed: ${statePath}`);
    }
    return state;
}
async function writeControlState(statePath, state) {
    await mkdir(dirname(statePath), { recursive: true });
    const temporary = `${statePath}.${process.pid}.${randomUUID()}.tmp`;
    await writeFile(temporary, `${JSON.stringify(state)}\n`, 'utf8');
    await rename(temporary, statePath);
}
function sourceNodeArguments() {
    return fileURLToPath(import.meta.url).endsWith('.ts') ? ['--experimental-transform-types'] : [];
}
function statusFrom(intent, statePath, configPath, state) {
    const effective = readControlEffectiveConfig(intent);
    const base = {
        configPath,
        statePath,
        daemonId: intent.daemon.id,
        listener: effective.listener,
        dataDirectory: intent.daemon.dataDirectory,
    };
    if (state === undefined)
        return { ...base, state: 'stopped', generation: 0 };
    return {
        ...base,
        state: state.state,
        generation: state.generation,
        pid: state.pid,
        ...(state.url === undefined ? {} : { url: state.url }),
        ...(state.error === undefined ? {} : { error: state.error }),
    };
}
async function ownsPersistedProcess(state) {
    if (state.pid <= 0 || !processAlive(state.pid))
        return false;
    const command = await processCommand(state.pid);
    return command !== undefined && processOwnsConfigCommand(command, state.configPath, state.entryPath, state.startToken, TOKEN_FLAG);
}
async function waitForProcessExit(pid, deadlineMs) {
    const deadline = Date.now() + deadlineMs;
    while (Date.now() < deadline) {
        if (!processAlive(pid))
            return;
        await new Promise(resolveDelay => setTimeout(resolveDelay, 25));
    }
    throw new ControlProcessError('STOP_TIMEOUT', `control pid=${pid} did not exit after SIGTERM`);
}
async function waitForState(statePath, expected, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    let last;
    while (Date.now() < deadline) {
        last = await readControlState(statePath);
        if (last !== undefined && expected.includes(last.state))
            return last;
        await new Promise(resolveDelay => setTimeout(resolveDelay, 25));
    }
    if (last?.state === 'failed' && last.error !== undefined) {
        // The child published its typed code, so the parent re-throws the real failure.
        throw new ControlProcessError(last.errorCode ?? 'START_TIMEOUT', `control process failed to start: ${last.error}`);
    }
    throw new ControlProcessError('START_TIMEOUT', `control did not report ${expected.join('/')} within ${timeoutMs}ms`);
}
/**
 * Stop removes the daemon's runtime ownership record, not its data directory. The directory
 * is durable: the control daemon keeps its `kind: 'connection'` history there, so deleting
 * the whole directory would destroy history that must survive an owner restart. The agent
 * daemon likewise keeps its data directory across a stop. The recorded state is the only
 * runtime artifact the control daemon writes, so removing it is the whole cleanup.
 */
async function removeOwnedState(statePath) {
    try {
        await rm(statePath, { force: true });
    }
    catch { /* keep the recorded state */ }
}
export async function startControlDaemon(configPath, options = {}) {
    const intent = await loadControlIntent(configPath);
    // The parent validates the declared listener before spawning, like the registry plan.
    readControlEffectiveConfig(intent);
    const childEnv = { ...process.env, ...options.env };
    const declaredPasswordEnv = intent.webui.auth?.passwordEnv;
    if (declaredPasswordEnv !== undefined && (childEnv[declaredPasswordEnv] ?? '') === '') {
        // Resolve the declared credential reference before spawning, like the registry plan:
        // a listener that cannot authenticate never starts and never leaves a pid record.
        throw new ControlProcessError('CREDENTIAL_UNAVAILABLE', `webui.auth.passwordEnv ${declaredPasswordEnv} is not set in the operator environment`);
    }
    const statePath = controlStatePath(intent);
    const resolvedConfigPath = resolve(configPath);
    const entryPath = fileURLToPath(import.meta.url);
    const previous = await readControlState(statePath);
    if (previous !== undefined && previous.configPath !== resolvedConfigPath) {
        throw new ControlProcessError('STALE_OWNER', `control state belongs to another config: ${previous.configPath}`);
    }
    if (previous !== undefined && previous.state !== 'stopped' && previous.pid > 0 && processAlive(previous.pid)) {
        if (!(await ownsPersistedProcess(previous))) {
            throw new ControlProcessError('STALE_OWNER', `control pid=${previous.pid} does not match its persisted start token`);
        }
        throw new ControlProcessError('ALREADY_RUNNING', `control is already running pid=${previous.pid} generation=${previous.generation}`);
    }
    const generation = (previous?.generation ?? 0) + 1;
    const startToken = randomUUID();
    await writeControlState(statePath, {
        version: STATE_VERSION, configPath: resolvedConfigPath, entryPath, daemonId: intent.daemon.id,
        startToken, generation, pid: 0, state: 'starting', updatedAt: new Date().toISOString(),
    });
    let child;
    try {
        child = spawn(options.nodeExecutable ?? process.execPath, [...(options.nodeArguments ?? sourceNodeArguments()), entryPath, '--config', resolvedConfigPath, TOKEN_FLAG, startToken], {
            detached: true,
            env: childEnv,
            stdio: ['ignore', 'ignore', 'ignore'],
        });
        child.unref();
    }
    catch (cause) {
        const message = cause instanceof Error ? cause.message : String(cause);
        await writeControlState(statePath, {
            version: STATE_VERSION, configPath: resolvedConfigPath, entryPath, daemonId: intent.daemon.id,
            startToken, generation, pid: 0, state: 'failed', error: message, updatedAt: new Date().toISOString(),
        });
        throw new ControlProcessError('INVALID_CONFIG', `control process could not be spawned: ${message}`, cause);
    }
    if (child.pid === undefined) {
        const message = 'detached control process did not return a pid';
        await writeControlState(statePath, {
            version: STATE_VERSION, configPath: resolvedConfigPath, entryPath, daemonId: intent.daemon.id,
            startToken, generation, pid: 0, state: 'failed', error: message, updatedAt: new Date().toISOString(),
        });
        throw new ControlProcessError('INVALID_CONFIG', message);
    }
    const pid = child.pid;
    await writeControlState(statePath, {
        version: STATE_VERSION, configPath: resolvedConfigPath, entryPath, daemonId: intent.daemon.id,
        startToken, generation, pid, state: 'starting', updatedAt: new Date().toISOString(),
    });
    try {
        const running = await waitForState(statePath, ['running'], options.startupTimeoutMs ?? 10_000);
        return statusFrom(intent, statePath, resolvedConfigPath, running);
    }
    catch (error) {
        // A failed child leaves its own error in the state file; keep it and only reclaim the
        // process this parent started. A failed start removes its owned directory and pid record.
        const latest = await readControlState(statePath);
        const failure = latest?.error ?? (error instanceof Error ? error.message : String(error));
        const failureCode = latest?.errorCode ?? (error instanceof ControlProcessError ? error.code : undefined);
        if (latest === undefined || (latest.generation === generation && latest.startToken === startToken)) {
            await writeControlState(statePath, {
                version: STATE_VERSION, configPath: resolvedConfigPath, entryPath, daemonId: intent.daemon.id,
                startToken, generation, pid, state: 'failed',
                ...(failureCode === undefined ? {} : { errorCode: failureCode }), error: failure, updatedAt: new Date().toISOString(),
            });
        }
        if (processAlive(pid)) {
            try {
                process.kill(pid, 'SIGTERM');
            }
            catch { /* preserve the startup failure */ }
            try {
                await waitForProcessExit(pid, 2_000);
            }
            catch { /* preserve the startup failure */ }
        }
        await removeOwnedState(statePath);
        throw error;
    }
}
export async function statusControlDaemon(configPath) {
    const intent = await loadControlIntent(configPath);
    const statePath = controlStatePath(intent);
    const resolvedConfigPath = resolve(configPath);
    const state = await readControlState(statePath);
    if (state === undefined)
        return statusFrom(intent, statePath, resolvedConfigPath, undefined);
    if (state.state === 'running' || state.state === 'starting') {
        if (state.pid <= 0 || !processAlive(state.pid)) {
            return statusFrom(intent, statePath, resolvedConfigPath, { ...state, state: 'failed', error: 'control process pid is not alive' });
        }
        if (!(await ownsPersistedProcess(state))) {
            return statusFrom(intent, statePath, resolvedConfigPath, { ...state, state: 'failed', error: 'control process does not match persisted ownership' });
        }
    }
    return statusFrom(intent, statePath, resolvedConfigPath, state);
}
export async function stopControlDaemon(configPath, expectedGeneration) {
    const intent = await loadControlIntent(configPath);
    const statePath = controlStatePath(intent);
    const resolvedConfigPath = resolve(configPath);
    const state = await readControlState(statePath);
    if (state === undefined || state.state === 'stopped') {
        await removeOwnedState(statePath);
        return statusFrom(intent, statePath, resolvedConfigPath, undefined);
    }
    if (expectedGeneration !== undefined && expectedGeneration !== state.generation) {
        throw new ControlProcessError('STALE_GENERATION', `stale control generation expected=${expectedGeneration} current=${state.generation}`);
    }
    if (state.pid <= 0 || !processAlive(state.pid)) {
        await removeOwnedState(statePath);
        return statusFrom(intent, statePath, resolvedConfigPath, undefined);
    }
    if (!(await ownsPersistedProcess(state))) {
        throw new ControlProcessError('STALE_OWNER', `control pid=${state.pid} does not match its persisted start token`);
    }
    process.kill(state.pid, 'SIGTERM');
    await waitForProcessExit(state.pid, 5_000);
    await removeOwnedState(statePath);
    return statusFrom(intent, statePath, resolvedConfigPath, undefined);
}
/* ---------------------------------------------------------------------------------------
 * Owner projection, commands and the SSE source.
 * ------------------------------------------------------------------------------------- */
function unavailable(message, code) {
    throw new ControlProcessError(code, message);
}
/** Closed validation of an owner projection; a malformed owner view never reaches the wire. */
function validatedProjection(value) {
    return parseConsoleProjection(value);
}
/** Structural history read: the frozen port or a typed absence, never a fabricated page. */
export function createControlHistoryReader(port) {
    return {
        async query(query) {
            // Re-validate through the frozen parser so the runtime never forwards a widened query.
            const closed = parseHistoryQuery(query);
            if (port === undefined)
                unavailable('network status port is not bound to this control daemon; history is unavailable', 'HISTORY_UNAVAILABLE');
            return await port.history(closed);
        },
    };
}
function projectionWithConnections(projection, port) {
    if (port === undefined)
        return projection;
    // The additive connection rows reuse the frozen status verbatim. `halfOpen` is true while
    // the transport/negotiation lifecycle has not reached a terminal state.
    const connections = port.connections().map(status => ({
        status,
        halfOpen: !['ready', 'closed', 'failed', 'disconnected'].includes(status.state),
    }));
    return { ...projection, connections };
}
/**
 * One typed command result from one durable CAS write. The result reports the accepted
 * record revision only.
 *
 * It never reports a connection state: the record is the desired intent, and the agent
 * daemon observes it later and owns the real connection outcome. A `failed` or `uncertain`
 * store result keeps its real typed error, so an ambiguous rename is never reported as
 * applied.
 */
function relationsWriteResult(result) {
    if (result.status === 'applied')
        return { ok: true, result: { acceptedRevision: result.effectiveRevision } };
    return { ok: false, error: { code: result.error.code, message: result.error.message } };
}
/**
 * The control owner client. Without a network status port the connection projection stays
 * absent, and without the daemon's accepted intent facts the relation commands fail with
 * the typed absence; nothing is faked. With those facts the relation commands write the
 * one durable desired-relations record through the delivered CAS store.
 */
export function createControlOwner(options) {
    const { network, owner, source, relations } = options;
    const read = async () => {
        if (source !== undefined)
            return validatedProjection(await source.read());
        const base = owner === undefined
            ? { version: 1, agents: [], sessions: [], notifications: [], configs: [] }
            : validatedProjection(await owner.readProjection());
        return projectionWithConnections(base, network);
    };
    /**
     * The two frozen Session write commands plus the Session body ingress. They write the
     * durable pending-Session-write record and never touch an engine, a transcript, or a
     * Session state; the agent daemon that owns the Session reacts to the record later on its
     * own. The record path is resolved from the target agent's declared identity, account and
     * scope, never guessed and never this daemon's own data directory.
     */
    /**
     * The two frozen Session write commands. `permission.reply` carries the operator's `decision`
     * and, when the Console chose one, the engine `optionId` it clicked. This daemon carries both
     * into the record verbatim; it never invents an optionId. The agent daemon that owns the
     * Session answers the engine with exactly the named option, and it falls back to the projected
     * kind only for a command that named no option.
     */
    const sessionCommand = async (command) => {
        // This daemon is the record's single writer, and the store's CAS is read-then-rename. Two
        // Console commands that interleave there can both read the same revision and then both
        // rename, which loses one intent while reporting success for both. Serializing this
        // daemon's own writes removes that interleaving.
        return await serializeSessionWrite(async () => {
            if (command.kind === 'permission.reply') {
                return await sessionWrite(command.agentId, command.sessionId, target => ({
                    op: 'permission.reply',
                    agentId: target.agentId,
                    sessionId: target.sessionId,
                    permissionId: command.permissionId,
                    decision: command.decision,
                    // The frozen command may carry the engine option the Console chose. It is carried
                    // verbatim so the owning daemon answers with that option, not a same-kind guess.
                    ...(command.optionId === undefined ? {} : { optionId: command.optionId }),
                }));
            }
            return await sessionWrite(command.agentId, command.sessionId, target => ({ op: 'session.cancel', agentId: target.agentId, sessionId: target.sessionId }));
        });
    };
    /** Serialize this daemon's own writes to the Session write record it solely owns. */
    let sessionWriteChain = Promise.resolve();
    const serializeSessionWrite = (work) => {
        const next = sessionWriteChain.then(work, work);
        sessionWriteChain = next.then(() => undefined, () => undefined);
        return next;
    };
    const sessionWrite = async (agentId, sessionId, change) => {
        if (relations === undefined) {
            return { ok: false, error: { code: 'UNAVAILABLE', message: 'the accepted control intent is not bound to this control daemon; the pending Session write record is unavailable' } };
        }
        const target = Object.values(relations.peers).find(peer => peer.agentId === agentId);
        if (target === undefined) {
            // No guessed record path: an agentId this daemon does not declare has no resolvable
            // account and scope, and the Session it names is not this daemon's to write.
            return { ok: false, error: { code: 'FORBIDDEN', message: `agentId ${agentId} is not declared by this control daemon's accepted peers` } };
        }
        const path = sessionIntentScopePath({ home: relations.home, accountId: target.accountId, scopeId: target.scopeId, agentId: target.agentId });
        try {
            // These commands carry no expectedRevision, so the accepted revision of the one
            // durable record is the CAS base. This daemon is that record's single writer, and the
            // store still applies the CAS.
            const current = await readSessionIntentRecord(path);
            return relationsWriteResult(await writeSessionIntentRecord(path, current?.revision ?? 0, change({ agentId, sessionId })));
        }
        catch (error) {
            // A broken stored record is the store's own typed throw: refuse it here and leave the
            // durable bytes untouched instead of overwriting them.
            if (error instanceof RuntimeConfigError)
                return { ok: false, error: { code: error.code, message: error.message } };
            throw error;
        }
    };
    /**
     * The three frozen relation commands. They write the durable desired relations record
     * and never dial, negotiate, or report connection state; the agent daemon reacts to the
     * record later. The record path is resolved from the target agent's declared account and
     * scope, never guessed and never this daemon's own data directory.
     */
    const relationsCommand = async (command) => {
        if (relations === undefined) {
            return { ok: false, error: { code: 'UNAVAILABLE', message: 'the accepted control intent is not bound to this control daemon; the desired relations record is unavailable' } };
        }
        // One desired membership set per account and scope. The target's own account and scope
        // come from this daemon's accepted `peers`, which is the only place that carries them.
        const target = Object.values(relations.peers).find(peer => peer.agentId === command.agentId);
        if (target === undefined) {
            // No guessed relation and no guessed record path: an agentId this daemon does not
            // declare has no resolvable account and scope.
            return { ok: false, error: { code: 'FORBIDDEN', message: `agentId ${command.agentId} is not declared by this control daemon's accepted peers` } };
        }
        const path = relationsIntentScopePath({ home: relations.home, accountId: target.accountId, scopeId: target.scopeId });
        try {
            if (command.kind === 'network.membership.apply') {
                // One record means one CAS fence: every member must belong to the same account and
                // scope as the record, or the set could be written where its own agent never reads.
                const foreign = command.members.find(member => {
                    const peer = Object.values(relations.peers).find(candidate => candidate.agentId === member.agentId);
                    return peer === undefined || peer.accountId !== target.accountId || peer.scopeId !== target.scopeId;
                });
                if (foreign !== undefined) {
                    return { ok: false, error: { code: 'FORBIDDEN', message: `member ${foreign.agentId} is not a declared peer of the record's account and scope` } };
                }
                // The caller's own expectation is the CAS base, unchanged: a stale client must
                // conflict instead of overwriting a newer desired set.
                return relationsWriteResult(await writeRelationsIntentRecord(path, command.expectedRevision, { op: 'replace', peers: command.members }));
            }
            // `connect` and `disconnect` carry no expectedRevision, so the accepted revision of
            // the one durable record is the CAS base. The store still applies the CAS; this
            // daemon is that record's single writer. A disconnect of an absent relation stays
            // the store's accepted no-op revision bump.
            const current = await readRelationsIntentRecord(path);
            const change = command.kind === 'connection.connect'
                // The one role rule: the same derivation `runtime/serve-egress.ts` applies to its
                // `requestedPeerRole` from the daemon's own accepted `relations.allowed`.
                ? { op: 'connect', agentId: command.agentId, role: relations.allowedRoles.includes('master') ? 'master' : 'peer' }
                : { op: 'disconnect', agentId: command.agentId };
            return relationsWriteResult(await writeRelationsIntentRecord(path, current?.revision ?? 0, change));
        }
        catch (error) {
            // A broken stored record is the store's own typed throw: refuse it here and leave
            // the durable bytes untouched instead of overwriting them.
            if (error instanceof RuntimeConfigError)
                return { ok: false, error: { code: error.code, message: error.message } };
            throw error;
        }
    };
    return {
        readProjection: read,
        async command(command) {
            if (command.kind === 'connection.connect' || command.kind === 'connection.disconnect' || command.kind === 'network.membership.apply') {
                return await relationsCommand(command);
            }
            if (command.kind === 'permission.reply' || command.kind === 'session.cancel') {
                return await sessionCommand(command);
            }
            if (owner === undefined) {
                return { ok: false, error: { code: 'UNSUPPORTED_OPERATION', message: `no owner is bound for ${command.kind}` } };
            }
            return await owner.command(command);
        },
        async sendSession(target, payload) {
            if (owner !== undefined)
                return await owner.sendSession(target, payload);
            // The dedicated Session body ingress. The body is carried verbatim; this daemon never
            // parses, strips, or inspects it, and it never becomes a control frame. It writes the
            // same record as the Session commands, so it goes through the same serialization.
            return await serializeSessionWrite(async () => await sessionWrite(target.agentId, target.sessionId, resolved => ({
                op: 'session.message',
                agentId: resolved.agentId,
                sessionId: resolved.sessionId,
                payload,
            })));
        },
    };
}
/** The directory projection poll interval: one real D04 directory read per tick. */
const DIRECTORY_PROJECTION_INTERVAL_MS = 1_000;
/** Maps the D04 registration failure vocabulary onto the closed control error vocabulary. */
function controlCodeForRegistration(error) {
    switch (error.code) {
        case 'INVALID_CONFIG': return 'INVALID_CONFIG';
        case 'UNSUPPORTED_CONFIGURATION': return 'UNSUPPORTED_CONFIGURATION';
        case 'UNAUTHENTICATED': return 'CREDENTIAL_UNAVAILABLE';
        case 'NOT_FOUND': return 'INVALID_CONFIG';
    }
}
/**
 * The control daemon's real network read chain (A2.7).
 *
 * It composes only D05 owners: the live connection ledger, the durable connection history
 * over the runtime's own store, the D04 registration client and the membership projector.
 * The control daemon declares no Teams listener (A2.1), so the ledger stays empty and
 * `connections()` reports exactly the real membership of a daemon with no established
 * channel; nothing is fabricated. Real registration transitions are recorded through the
 * owner's own `membershipHistoryEvents`, so the durable `kind: 'connection'` history is a
 * record of observed transitions and never a source for online or execution state.
 *
 * The Console projection is the real D04 directory readback: every refresh reads the scoped
 * directory through the registration client and projects the admitted peers into frozen
 * Console agent rows. A config without `[discovery]` keeps the typed empty snapshot, so the
 * projection stays an honest absence instead of a fabricated row.
 */
/**
 * The Console row title for a pending engine permission callback.
 *
 * The agent daemon does not read the callback's own title out of the engine frame: the ACP
 * callback carries options, not a subject, and inventing one from the Session id would be a
 * guess. The Console shows this fixed label until a real subject is published.
 */
const PENDING_PERMISSION_TITLE = 'Permission request';
/**
 * The Sessions and pending permissions the Console projection reports, read from the
 * observation records the declared agent daemons publish.
 *
 * The agent daemon owns each record because it owns the Sessions and permission callbacks it
 * carries. This reader resolves one path per declared peer from the same account and scope
 * layout the writer used, and it adds no channel of its own. Three rules keep the projection
 * honest:
 *
 *  - A declared peer whose record does not exist or is empty contributes no rows, so the
 *    Console never invents a Session.
 *  - A peer the current directory readback reports as not online contributes nothing, so a
 *    directory that knows the daemon is down never keeps projecting its last observation.
 *    A peer the directory does not report at all is not treated as offline: a deployment
 *    with no registry has no liveness truth, and the agent daemon itself publishes the empty
 *    observation when it stops, which is the owner's own answer to the same question.
 *  - A record that names another agent is skipped rather than projected under this one, which
 *    keeps the `agentId` on every row the agent that really owns it.
 */
export async function readObservedSessionProjection(input) {
    const sessions = [];
    const notifications = [];
    for (const peer of input.peers) {
        const reported = input.presence.get(peer.agentId);
        if (reported !== undefined && reported !== 'online')
            continue;
        const path = sessionObservationScopePath({ home: input.home, accountId: peer.accountId, scopeId: peer.scopeId, agentId: peer.agentId });
        let record;
        try {
            record = await readSessionObservationRecord(path);
        }
        catch (error) {
            // The record's own owner reports its broken record; a projection read must still serve
            // the rest of the directory, so this peer's rows stay absent instead of guessed.
            console.error(`control Session observation read failed for ${peer.agentId}: ${error instanceof Error ? error.message : String(error)}`);
            continue;
        }
        if (record === undefined)
            continue;
        if (record.agentId !== peer.agentId) {
            console.error(`control Session observation at ${path} names agent ${record.agentId}, not ${peer.agentId}; its rows are not projected`);
            continue;
        }
        for (const row of record.sessions)
            sessions.push({ agentId: peer.agentId, sessionId: row.sessionId });
        for (const row of record.permissions) {
            notifications.push({
                agentId: peer.agentId,
                notificationId: row.notificationId,
                sessionId: row.sessionId,
                kind: 'permission',
                state: 'pending',
                title: PENDING_PERMISSION_TITLE,
                permissionId: row.permissionId,
            });
        }
    }
    return { sessions, notifications };
}
export async function createControlNetworkStatus(intent, env) {
    const localAgentId = intent.daemon.id;
    let history;
    try {
        history = createTeamsConnectionHistory(await createAcpHistoryStore({ directory: intent.daemon.dataDirectory }));
    }
    catch (cause) {
        throw new ControlProcessError('HISTORY_UNAVAILABLE', `control connection history store could not be opened: ${cause instanceof Error ? cause.message : String(cause)}`, cause);
    }
    const ledger = createTeamsConnectionLedger();
    // The honest unconfirmed local state until the first real directory readback replaces it.
    let directory = { accountId: intent.daemon.accountId, scopeId: intent.daemon.scopeId, generation: 0, hosts: [], peerStates: [] };
    let peers = [];
    let registration;
    let previous;
    const currentRegistration = () => registration === undefined
        ? { state: 'disabled', attempts: 0, reconnects: 0 }
        : registration.state === 'enabled' ? registration.client.status() : registration.status;
    const refreshDirectory = async () => {
        if (registration === undefined || registration.state !== 'enabled')
            return;
        if (registration.client.status().state !== 'online')
            return;
        let snapshot;
        try {
            snapshot = await registration.client.directorySnapshot(true);
        }
        catch (error) {
            // The registration status already carries the degraded registry; a failed read keeps the
            // last real readback instead of turning the projection read into a failure.
            console.error(`control directory read failed: ${error instanceof Error ? error.message : String(error)}`);
            return;
        }
        if (snapshot.revision < 1)
            return;
        // The local daemon's own registration is not a remote peer row, the same convention
        // `runtime/console-runtime.ts` applies to its discovered peers. Dropping it here keeps
        // the agent rows and the connection rows one consistent remote-only projection.
        const remotes = snapshot.peers.filter(peer => peer.declaration.identity.agentId !== localAgentId);
        try {
            directory = refreshRelayDirectory(directory, snapshot.revision, remotes);
            peers = remotes;
        }
        catch (error) {
            // A concurrent refresh can observe an older revision; the monotonic owner refuses it.
            console.error(`control directory projection failed: ${error instanceof Error ? error.message : String(error)}`);
        }
    };
    const observe = async (status) => {
        if (registration === undefined)
            return;
        const observed = status ?? currentRegistration();
        await refreshDirectory();
        const view = projectTeamsMembership({ localAgentId, directory, registration: observed, channels: ledger.list(), observedAt: new Date().toISOString() });
        for (const event of membershipHistoryEvents(previous, view))
            await history.record(event);
        previous = view;
    };
    try {
        registration = await startDaemonRegistration(intent, {
            env,
            // A registration transition is the one real membership event this daemon observes.
            // A failed history write is diagnostic only: it must never break registration.
            onStatus: status => {
                void observe(status).catch((error) => {
                    console.error(`control connection history write failed: ${error instanceof Error ? error.message : String(error)}`);
                });
            },
        });
    }
    catch (cause) {
        if (cause instanceof RegistrationProcessError)
            throw new ControlProcessError(controlCodeForRegistration(cause), cause.message, cause);
        throw cause;
    }
    // Seed the previous view so the next real registration transition is recorded once.
    await observe();
    // One live D05 port per read: the directory readback stays current without copying the
    // owner's membership projection into this runtime.
    const port = () => createTeamsStatusPort({ ledger, localAgentId, directory, registration: currentRegistration(), history });
    const readProjection = async () => {
        await refreshDirectory();
        const agents = peers.map(directoryAgentObservation);
        const observed = await readObservedSessionProjection({
            home: homedir(),
            peers: Object.values(intent.peers),
            presence: new Map(peers.map(peer => [peer.declaration.identity.agentId, peer.presence])),
        });
        return projectionWithConnections({ version: 1, agents, sessions: observed.sessions, notifications: observed.notifications, configs: [] }, port());
    };
    return {
        port: { connections: () => port().connections(), history: query => port().history(query) },
        projection: { read: readProjection, watch: createPollingProjectionSubscriber(readProjection, DIRECTORY_PROJECTION_INTERVAL_MS) },
        stop: async () => {
            if (registration !== undefined && registration.state === 'enabled')
                await registration.client.stop().catch(() => undefined);
        },
    };
}
/** Polling owner feed. It emits a full snapshot only when the owner projection changes. */
export function createPollingProjectionSubscriber(read, intervalMs = 250) {
    if (!Number.isSafeInteger(intervalMs) || intervalMs < 1)
        throw new ControlProcessError('INVALID_CONFIG', 'projection poll interval is invalid');
    return sink => {
        let seq = 0;
        let last;
        let stopped = false;
        let running = false;
        const tick = async () => {
            if (stopped || running)
                return;
            running = true;
            try {
                const projection = await read();
                const encoded = JSON.stringify(projection);
                if (encoded !== last) {
                    last = encoded;
                    seq += 1;
                    sink.onSnapshot({ seq, projection });
                }
            }
            catch (error) {
                if (!stopped) {
                    stopped = true;
                    sink.onHealth({ state: 'lost', reason: 'stream-ended', detail: error instanceof Error ? error.message : 'owner projection read failed' });
                }
            }
            finally {
                running = false;
            }
        };
        void tick();
        const timer = setInterval(() => { void tick(); }, intervalMs);
        timer.unref?.();
        return () => { stopped = true; clearInterval(timer); };
    };
}
/**
 * Deterministic projection feed for the black-box entry. It is reachable only through an
 * explicit environment variable and never participates in a normal daemon start.
 */
export function createFixtureProjectionSubscriber(fixture) {
    return sink => {
        const timers = [];
        let closed = false;
        for (const snapshot of fixture.snapshots) {
            timers.push(setTimeout(() => {
                if (closed)
                    return;
                const validated = parseConsoleProjectionSnapshot({ seq: snapshot.seq, projection: snapshot.projection });
                sink.onSnapshot(validated);
            }, snapshot.delayMs));
        }
        if (fixture.closeAfter !== undefined) {
            timers.push(setTimeout(() => {
                if (closed)
                    return;
                closed = true;
                sink.onHealth({ state: 'lost', reason: fixture.closeAfter.reason, detail: fixture.closeAfter.detail });
            }, fixture.closeAfter.delayMs));
        }
        for (const timer of timers)
            timer.unref?.();
        return () => { closed = true; for (const timer of timers)
            clearTimeout(timer); };
    };
}
async function readProjectionFixture(path) {
    let value;
    try {
        value = JSON.parse(await readFile(path, 'utf8'));
    }
    catch (cause) {
        throw new ControlProcessError('INVALID_CONFIG', `control projection fixture could not be read: ${path}`, cause);
    }
    const fixture = value;
    if (fixture === null || typeof fixture !== 'object' || !Array.isArray(fixture.snapshots)) {
        throw new ControlProcessError('INVALID_CONFIG', `control projection fixture is malformed: ${path}`);
    }
    for (const snapshot of fixture.snapshots) {
        if (!Number.isSafeInteger(snapshot.delayMs) || snapshot.delayMs < 0) {
            throw new ControlProcessError('INVALID_CONFIG', `control projection fixture delay is invalid: ${path}`);
        }
        parseConsoleProjectionSnapshot({ seq: snapshot.seq, projection: snapshot.projection });
    }
    return fixture;
}
/* ---------------------------------------------------------------------------------------
 * Child entry.
 * ------------------------------------------------------------------------------------- */
/**
 * Resolves the frozen presentation roots that ship beside the runtime entry. The entry
 * lives at `<root>/runtime/` from source and at `<root>/generated/runtime-lib/runtime/`
 * after `build:runtime`, so the owning package root is found by its real static entry.
 * The UI package serves `/ui/browser.js`, which is `ui/teams-console/lib/browser.js` from
 * source and `ui/teams-console/browser.js` in the staged package.
 */
function presentationRoots(entryPath) {
    let candidate = dirname(entryPath);
    for (let depth = 0; depth < 6; depth += 1) {
        const staticRoot = join(candidate, 'console-host', 'static');
        const uiBase = join(candidate, 'ui', 'teams-console');
        const uiRoot = existsSync(join(uiBase, 'browser.js')) ? uiBase
            : existsSync(join(uiBase, 'lib', 'browser.js')) ? join(uiBase, 'lib') : undefined;
        if (uiRoot !== undefined && existsSync(join(staticRoot, 'console.html')))
            return { staticRoot, uiRoot };
        const parent = dirname(candidate);
        if (parent === candidate)
            break;
        candidate = parent;
    }
    throw new ControlProcessError('INVALID_CONFIG', `console-host static assets and the compiled UI are missing beside the control entry: ${entryPath}; run pnpm build first`);
}
async function loadCredentials(intent, env) {
    const auth = intent.webui.auth;
    if (auth === undefined) {
        throw new ControlProcessError('CREDENTIAL_UNAVAILABLE', 'control webui requires webui.auth before it can bind a listener');
    }
    const password = env[auth.passwordEnv];
    if (password === undefined || password.length === 0) {
        throw new ControlProcessError('CREDENTIAL_UNAVAILABLE', `webui.auth.passwordEnv ${auth.passwordEnv} is not set in the operator environment`);
    }
    const host = intent.webui.ip.includes(':') ? `[${intent.webui.ip}]` : intent.webui.ip;
    const origin = intent.webui.allowedOrigin ?? `http://${host}:${intent.webui.port}`;
    return { username: auth.username, password, origin };
}
/**
 * Detached child entry. It publishes its own readiness into the one state file after the
 * WebUI listener is bound, so `control status` never reports a fabricated `running` state.
 */
export async function runControlProcess(argv = process.argv.slice(2), env = process.env) {
    const args = parseControlArgs(argv);
    const intent = await loadControlIntent(args.configPath);
    const effective = readControlEffectiveConfig(intent);
    const statePath = controlStatePath(intent);
    const previous = await readControlState(statePath);
    const base = {
        version: STATE_VERSION,
        configPath: resolve(args.configPath),
        entryPath: fileURLToPath(import.meta.url),
        daemonId: intent.daemon.id,
        startToken: args.startToken ?? previous?.startToken ?? randomUUID(),
        generation: previous?.generation ?? 1,
    };
    const { staticRoot, uiRoot } = presentationRoots(base.entryPath);
    let server;
    let network;
    try {
        const { username, password, origin } = await loadCredentials(intent, env);
        // The one injection point for the real network status port (D05 owner) and its real
        // projection owner (the D04 directory readback). The daemon binds both from its own real
        // network facts; `createControlOwner` and `createControlHistoryReader` keep the
        // structurally unbound path as a typed absence.
        network = await createControlNetworkStatus(intent, env);
        // The one desired-relations writer reads the same accepted intent this daemon loaded:
        // its declared peers and its accepted role set. The record path resolves from the home
        // root, through the shared convention the agent daemon uses for its own data directory,
        // because the frozen v4 `PeerIntent` carries no peer `dataDirectory` and no config key
        // may be added. No environment read and no second config source.
        const client = createControlOwner({
            network: network.port,
            source: network.projection,
            relations: {
                peers: intent.peers,
                allowedRoles: intent.relations.allowed,
                home: homedir(),
            },
        });
        const authorize = createConsoleAuthorization({ username, password, origin, client });
        const history = createControlHistoryReader(network.port);
        const projectionRead = async () => await client.readProjection();
        const fixturePath = env.AGENTTEAMS_CONTROL_PROJECTION_FIXTURE;
        // The real owner feed: the directory projection source streams a frame whenever the
        // readback changes. A source that cannot stream falls back to the same read on a poll.
        const events = fixturePath === undefined
            ? network.projection.watch ?? createPollingProjectionSubscriber(projectionRead)
            : createFixtureProjectionSubscriber(await readProjectionFixture(fixturePath));
        server = createConsoleServer({
            staticRoot,
            uiRoot,
            authorize,
            history,
            events,
            authenticationChallenge: AUTHENTICATION_CHALLENGE,
            ...(intent.webui.tlsCertRef === undefined || intent.webui.tlsKeyRef === undefined ? {} : {
                tls: { cert: await readFile(intent.webui.tlsCertRef), key: await readFile(intent.webui.tlsKeyRef) },
            }),
        });
        await new Promise((resolveListen, rejectListen) => {
            const onError = (error) => { server?.off('listening', onListening); rejectListen(error); };
            const onListening = () => { server?.off('error', onError); resolveListen(); };
            server.once('error', onError);
            server.once('listening', onListening);
            server.listen(effective.listener.port, effective.listener.ip);
        });
    }
    catch (error) {
        // The typed code travels in `errorCode`; `error` stays the plain message so a caller
        // that prefixes the code never prints it twice.
        const errorCode = error instanceof ControlProcessError ? error.code
            : error.code === 'EADDRINUSE' ? 'PORT_OCCUPIED' : undefined;
        const failure = error instanceof ControlProcessError
            ? error.message
            : errorCode === 'PORT_OCCUPIED'
                ? `control webui port ${effective.listener.port} is already in use`
                : error instanceof Error ? error.message : String(error);
        await writeControlState(statePath, { ...base, pid: process.pid, state: 'failed',
            ...(errorCode === undefined ? {} : { errorCode }), error: failure, updatedAt: new Date().toISOString() });
        // A failed start releases the registration client it opened; it never leaves a socket.
        await network?.stop().catch(() => undefined);
        throw error;
    }
    const scheme = intent.webui.tlsCertRef === undefined ? 'http' : 'https';
    const host = effective.listener.ip.includes(':') ? `[${effective.listener.ip}]` : effective.listener.ip;
    const url = `${scheme}://${host}:${effective.listener.port}`;
    await writeControlState(statePath, { ...base, pid: process.pid, state: 'running', url, updatedAt: new Date().toISOString() });
    console.log(`control listening ${url} config=${base.configPath} pid=${process.pid}`);
    let stopping;
    const stop = (signal) => {
        if (stopping)
            return;
        stopping = new Promise(resolveClose => {
            server.close(() => resolveClose());
            // `server.close()` only stops accepting new work and then waits for the sockets that
            // are already open. A WebUI keep-alive or event-stream client would hold the daemon
            // past the caller's bounded stop wait, so a correct shutdown reports STOP_TIMEOUT and
            // looks like a failure. Closing the listener's own connections is what the stop
            // actually means: the stream ends, the UI degrades to a lost owner, and the pid exits.
            server.closeIdleConnections();
            server.closeAllConnections();
        })
            .then(async () => {
            // Order: the WebUI listener first, then the owned registration client, then the
            // durable state record. The control daemon never stops a registry or an engine.
            await network?.stop();
            await writeControlState(statePath, { ...base, pid: process.pid, state: 'stopped', url, updatedAt: new Date().toISOString() });
        })
            .catch((error) => {
            process.exitCode = 1;
            console.error(`control shutdown failed after ${signal}: ${error instanceof Error ? error.message : String(error)}`);
        });
    };
    process.once('SIGINT', stop);
    process.once('SIGTERM', stop);
    try {
        await new Promise(resolveStopped => {
            const poll = () => { if (stopping)
                void stopping.finally(resolveStopped);
            else
                setTimeout(poll, 50); };
            poll();
        });
    }
    finally {
        process.removeListener('SIGINT', stop);
        process.removeListener('SIGTERM', stop);
    }
}
const invokedPath = process.argv[1] === undefined ? undefined : resolve(process.argv[1]);
if (invokedPath === fileURLToPath(import.meta.url)) {
    void runControlProcess().catch(error => {
        const code = error instanceof ControlProcessError ? error.code : 'UNAVAILABLE';
        console.error('control process failed:', code, error instanceof Error ? error.message : String(error));
        process.exitCode = 1;
    });
}
