import { parseConsoleWireRequest } from "../control-protocol/console-wire.js";
import { assertJsonValue } from "../control-protocol/json-value.js";
/** Relay authentication establishes the peer, not management authority. Policy sees only control. */
export function createConsoleIngress(options, authenticatedPeer) {
    const { agentId, generation, authorize, client } = options;
    const peer = Object.freeze({ ...authenticatedPeer });
    return async (input) => {
        assertJsonValue(input, 'Console ingress');
        const request = parseConsoleWireRequest(JSON.stringify(input));
        const denied = (code, message) => ({
            kind: 'console.result', correlationId: request.correlationId, result: { ok: false, error: { code, message } },
        });
        if (request.targetGeneration !== generation())
            return denied('STALE_GENERATION', 'Console request targets an old daemon generation');
        const targetId = request.kind === 'console.command' ? request.command.agentId : request.agentId;
        if (targetId !== agentId)
            return denied('FORBIDDEN', 'Console request targets another Agent');
        const access = request.kind === 'console.projection' ? { kind: 'observe', agentId }
            : request.kind === 'console.command' ? { kind: 'command', agentId, commandKind: request.command.kind }
                : { kind: 'session', agentId, sessionId: request.sessionId };
        if (!authorize(peer, access))
            return denied('FORBIDDEN', 'Agent management policy denied this request');
        if (request.kind === 'console.projection')
            return { kind: 'console.projection.result', correlationId: request.correlationId, projection: await client.readProjection() };
        const result = request.kind === 'console.command' ? await client.command(request.command)
            : await client.sendSession({ agentId, sessionId: request.sessionId }, request.payload);
        return { kind: 'console.result', correlationId: request.correlationId, result };
    };
}
