import { type BrowserCliAdapter } from './browser-cli.ts';
import { type AdapterResult, type CliRequest } from './contracts.ts';
import { type ReadOnlySearchCliAdapter } from './search-cli.ts';
export interface CliStartupOptions {
    readonly camoExecutable: string;
    readonly searchExecutable: string;
    readonly profile: string;
    readonly searchRoot: string;
    readonly headless: boolean;
}
export interface CliRuntime {
    readonly browser: BrowserCliAdapter;
    readonly search: ReadOnlySearchCliAdapter;
}
export declare function parseStartupOptions(argv: readonly string[]): CliStartupOptions;
export declare function parseCliRequest(value: unknown): CliRequest;
export declare function parseJsonRequestLine(line: string): CliRequest;
export declare function createCliRuntime(options: CliStartupOptions): CliRuntime;
export declare function dispatchCliRequest(runtime: CliRuntime, request: CliRequest): Promise<AdapterResult>;
export declare function runCli(argv: readonly string[], input: NodeJS.ReadableStream, output: NodeJS.WritableStream): Promise<void>;
