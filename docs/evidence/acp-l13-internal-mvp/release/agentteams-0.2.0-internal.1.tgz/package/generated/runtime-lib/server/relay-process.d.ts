import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import { type RelayServer } from './relay.ts';
export interface RelayProcessListenConfig {
    readonly host: string;
    readonly port: number;
}
export interface RelayProcessTlsConfig {
    readonly keyFile: string;
    readonly certFile: string;
}
export interface RelayProcessLimitsConfig {
    readonly maxPayload: number;
    readonly maxConnections: number;
    readonly maxGrants: number;
    readonly maxBufferedAmount: number;
    readonly maxPendingMessages: number;
    readonly maxPendingBytes: number;
    readonly grantTtlMs: number;
}
export interface RelayCredentialBinding {
    readonly credentialEnv: string;
    readonly identity: AuthenticatedAgent;
}
export interface RelayProcessConfig {
    readonly version: 1;
    readonly listen: RelayProcessListenConfig;
    readonly tls: RelayProcessTlsConfig;
    readonly limits: RelayProcessLimitsConfig;
    readonly credentials: readonly RelayCredentialBinding[];
}
export interface RelayProcessHandle {
    readonly configPath: string;
    readonly config: RelayProcessConfig;
    readonly server: RelayServer;
    close(): Promise<void>;
}
export declare class RelayProcessConfigError extends Error {
    constructor(message: string, cause?: unknown);
}
export declare function parseRelayProcessConfig(text: string, env?: NodeJS.ProcessEnv): RelayProcessConfig;
export declare function startRelayProcess(configPath: string, env?: NodeJS.ProcessEnv): Promise<RelayProcessHandle>;
export declare function parseRelayProcessArgs(argv: readonly string[]): string;
export declare function runRelayProcess(argv?: readonly string[], env?: NodeJS.ProcessEnv): Promise<void>;
