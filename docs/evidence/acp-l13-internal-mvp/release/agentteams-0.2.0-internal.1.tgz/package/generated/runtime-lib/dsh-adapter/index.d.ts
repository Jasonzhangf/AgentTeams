import type { JsonValue } from '../control-protocol/agent-services.ts';
import type { AcpFrame } from '../control-protocol/acp.ts';
import type { EngineAdapter, EngineHandle, EngineLaunchInput, EngineLaunchSpec } from '../control-protocol/engine.ts';
import type { ModelRef } from '../config/runtime-config.ts';
/**
 * DSH engine adapter.
 *
 * Owner: dsh-adapter. It compiles the real `EngineLaunchSpec` for the installed
 * DSH ACP server (`dsh --profile acp`) and maps DSH-specific features onto the
 * frozen ACP/engine ports. It declares no second Session path, no second stdio
 * transport and no engine registry: the D01 runtime owns the child, the single
 * stdio `AcpDuplex` and the Session/execution-policy boundary.
 *
 * Boundaries owned here:
 * - the derived DSH profile patch (provider routes + selected model),
 * - the engine environment (`DSH_HOME` isolation, permission mode, telemetry),
 * - the static policy check that must happen before any engine side effect,
 * - the effectiveness proof read from the real `initialize`/`session/new`
 *   results the runtime captured.
 *
 * Anything the installed DSH ACP surface does not carry is refused explicitly
 * with a typed fault. Nothing here falls back to a DSH shipped default route,
 * and no success is claimed without a real engine readback.
 */
/** Name of the derived patch file inside the daemon-owned directory. */
export declare const DSH_PATCH_FILE_NAME = "teams-dsh-acp.patch.json";
/** `agentInfo.name` the real DSH ACP server reports; the engine's own identity. */
export declare const DSH_AGENT_INFO_NAME = "deepseek-harness-acp";
/**
 * The engine's permission mode for a Teams-owned daemon. DSH derives its
 * sandbox mode and its approval policy from this variable, so pinning it makes
 * the permission behaviour deterministic instead of inheriting whatever the
 * launching shell happened to export. `workspace-write` keeps approval `ask`,
 * which is what routes real `session/request_permission` callbacks to the
 * controller. This is the DSH shipped CLI default, not a Teams-specified value.
 */
export declare const DSH_PERMISSION_MODE = "workspace-write";
/** DSH's documented telemetry opt-out; any non-empty value disables export. */
export declare const DSH_TELEMETRY_DISABLED = "1";
/** ACP methods the DSH adapter itself carries beyond the engine declaration. */
export declare const DSH_EXTENSION_METHODS: readonly ["session/set_config_option"];
/**
 * Engine-to-client callbacks the DSH ACP server raises to its controller.
 *
 * The real DSH engine asks for approval with a standard
 * `session/request_permission` callback; it uses no client filesystem or
 * terminal operation. The ACP initialize result cannot advertise client
 * methods, so this is the adapter's own declaration. Without it the frozen
 * policy vocabulary has no `callback:` key and the host refuses the engine's
 * approval request before any controller can see it.
 */
export declare const DSH_ENGINE_CALLBACKS: readonly ["session/request_permission"];
/** Session-management methods the real DSH initialize result declares. */
export declare const DSH_ENGINE_SESSION_METHODS: readonly ["session/list", "session/resume", "session/close"];
export declare function dshHasPolicyEnforcementOwner(key: string): boolean;
export interface DshCapability {
    /** A policy-vocabulary key, or a `feature:` label that is never a policy key. */
    readonly key: string;
    /**
     * `adapter` — carried by this adapter and declared to the host;
     * `engine` — declared by the real DSH initialize result at runtime;
     * `unsupported` — outside the DSH ACP surface and refused explicitly.
     */
    readonly support: 'adapter' | 'engine' | 'unsupported';
    readonly owner: 'dsh-adapter' | 'dsh-acp' | 'acp-host';
    readonly reason: string;
}
/**
 * The refused surface. Every entry is a contract-level limitation of the DSH
 * ACP server, not a build flag, so the adapter may reject it before spawning.
 */
export declare const DSH_UNSUPPORTED_FEATURES: readonly DshCapability[];
/** Capabilities whose support is declared by the real engine at initialize. */
export declare const DSH_ENGINE_DECLARED_CAPABILITIES: readonly DshCapability[];
/** Capabilities the adapter carries itself and must declare to the host. */
export declare const DSH_ADAPTER_CAPABILITIES: readonly DshCapability[];
/**
 * The exact adapter-declared policy keys, in the vocabulary the frozen policy
 * owner accepts: bare extension method names and prefixed callback keys. This
 * is what the runtime must pass as `adapterMethods`.
 */
export declare function dshDeclaredPolicyKeys(): string[];
/**
 * The exact adapter-declared enforceable policy keys. This is what the runtime
 * must pass as `enforceablePolicies`.
 *
 * The set is derived from the one enforcement-owner rule, applied to the whole
 * declared DSH ACP surface, so the adapter's pre-launch blacklist assertion and
 * the runtime's enforceable set can never drift. The D01 host enforces the base
 * capability, method, engine-capability, client-capability and engine-callback
 * classes before any engine write; a declared `feature:` label is not a policy
 * key and a key outside those classes has no enforcement owner here, so neither
 * becomes enforceable.
 */
export declare function dshEnforceablePolicyKeys(): string[];
export interface DshEffectivenessProof {
    readonly effectiveRevision: number;
    readonly modelTarget: ModelRef | null;
    readonly evidence: JsonValue;
}
export interface DshEngineAdapter extends EngineAdapter {
    readonly kind: 'dsh';
    /**
     * Adapter-declared policy keys for the frozen `adapterMethods` input: the
     * extension methods this adapter carries plus the engine callbacks it
     * declares. Bare method names and prefixed `callback:` keys are both part of
     * the frozen policy vocabulary.
     */
    readonly declaredMethods: readonly string[];
    /**
     * Adapter-declared policy keys for the frozen `enforceablePolicies` input: the
     * declared DSH ACP surface restricted to the classes
     * `dshHasPolicyEnforcementOwner` accepts. The adapter owns this answer; the
     * runtime must not substitute `declaredMethods` or any other set.
     */
    readonly enforceablePolicies: readonly string[];
    /** The typed support/refusal list for the DSH ACP surface. */
    readonly capabilities: readonly DshCapability[];
    compileLaunch(input: EngineLaunchInput): Promise<EngineLaunchSpec>;
    verifyEffective(input: {
        readonly handle: EngineHandle;
        readonly launch: EngineLaunchInput;
        readonly initializeResult: AcpFrame;
        readonly sessionConfigResult?: AcpFrame;
    }): Promise<DshEffectivenessProof>;
}
/**
 * Compile the real launch for the installed DSH ACP server. Every rejection is
 * explicit and happens before the runtime writes a file or spawns a process.
 */
export declare function createDshEngineAdapter(): DshEngineAdapter;
