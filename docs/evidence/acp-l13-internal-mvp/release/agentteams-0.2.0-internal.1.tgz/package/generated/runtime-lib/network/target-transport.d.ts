import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
export type TargetTransportStateName = 'connecting' | 'ready' | 'closed' | 'failed';
export interface TargetTransportTarget {
    readonly hostId: string;
    readonly agentId: string;
    readonly targetGeneration: number;
    readonly protocolVersion: number;
    readonly capabilitiesRevision: string;
}
export interface TargetTransportHello extends TargetTransportTarget {
    readonly source: AuthenticatedAgent;
    readonly admissionRef: string;
}
export interface TargetTransportState {
    readonly state: TargetTransportStateName;
    readonly targetGeneration: number;
    readonly hostId: string;
    readonly agentId: string;
    readonly protocolVersion: number;
    readonly capabilitiesRevision: string;
    readonly source: AuthenticatedAgent;
    readonly admissionRef: string;
    readonly error?: string;
}
export declare function beginTargetTransport(hello: TargetTransportHello): TargetTransportState;
export declare function receiveHelloAck(state: TargetTransportState): TargetTransportState;
export declare function confirmTargetHealth(state: TargetTransportState, generation: number): TargetTransportState;
export declare function assertTargetGeneration(state: TargetTransportState, generation: number): void;
export declare function closeTargetTransport(state: TargetTransportState, reason?: string): TargetTransportState;
export declare function failTargetTransport(state: TargetTransportState, reason: string): TargetTransportState;
