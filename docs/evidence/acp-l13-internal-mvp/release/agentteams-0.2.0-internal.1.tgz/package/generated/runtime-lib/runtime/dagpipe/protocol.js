// Typed stdio port between the Node host and the Rust DAGpipe runner.
//
// The runner emits `host.call` frames on stdout and consumes exactly one
// `host.result`/`host.error` frame per call on stdin. Control correlation and
// business values are separate fields at every boundary; nothing here schedules
// graph nodes or holds provider resource state.
export class HostProtocolError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}
const RUNNER_FINAL_FRAME_TYPES = new Set([
    'execution.result',
    'execution.failure',
    'compile.result',
    'compile.failure',
    'usage.failure',
    'run.failure',
]);
export function decodeRunnerFrame(line) {
    let decoded;
    try {
        decoded = JSON.parse(line);
    }
    catch (error) {
        const detail = error instanceof Error ? error.message : 'invalid JSON';
        throw new HostProtocolError('HOST_PROTOCOL', `runner frame is not JSON: ${detail}`);
    }
    if (decoded === null || typeof decoded !== 'object' || Array.isArray(decoded)) {
        throw new HostProtocolError('HOST_PROTOCOL', 'runner frame must be an object');
    }
    const type = decoded.type;
    if (type === 'host.call') {
        const control = decoded.control;
        if (control === null || typeof control !== 'object' || Array.isArray(control)) {
            throw new HostProtocolError('HOST_PROTOCOL', 'host.call lacks control object');
        }
        return decoded;
    }
    if (typeof type === 'string' && RUNNER_FINAL_FRAME_TYPES.has(type)) {
        if (type === 'execution.result') {
            return decodeExecutionResultFrame(decoded);
        }
        if (type === 'execution.failure') {
            return decodeExecutionFailureFrame(decoded);
        }
        if (type === 'compile.result') {
            return decodeCompileResultFrame(decoded);
        }
        if (type === 'compile.failure') {
            return decodeCompileFailureFrame(decoded);
        }
        return decodeRunnerFailureFrame(decoded, type);
    }
    throw new HostProtocolError('HOST_PROTOCOL', `runner frame has unsupported type ${JSON.stringify(type)}`);
}
function runnerObject(value, label) {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
        throw new HostProtocolError('HOST_PROTOCOL', `runner frame lacks ${label}`);
    }
    return value;
}
function stringField(value, label) {
    if (typeof value !== 'string' || value.length === 0) {
        throw new HostProtocolError('HOST_PROTOCOL', `${label} must be a non-empty string`);
    }
    return value;
}
function stringArrayField(value, label) {
    if (!Array.isArray(value) || value.some(item => typeof item !== 'string' || item.length === 0)) {
        throw new HostProtocolError('HOST_PROTOCOL', `${label} must be a non-empty string array`);
    }
    return value;
}
function journalField(value, label) {
    if (!Array.isArray(value) || value.some(item => item === null || typeof item !== 'object' || Array.isArray(item))) {
        throw new HostProtocolError('HOST_PROTOCOL', `${label} must be an object array`);
    }
    return value;
}
function identityField(value, label) {
    const identity = runnerObject(value, label);
    return {
        project_id: stringField(identity.project_id, `${label}.project_id`),
        graph_id: stringField(identity.graph_id, `${label}.graph_id`),
        graph_version: stringField(identity.graph_version, `${label}.graph_version`),
        execution_id: stringField(identity.execution_id, `${label}.execution_id`),
        attempt_id: stringField(identity.attempt_id, `${label}.attempt_id`),
    };
}
function decodeExecutionResultFrame(value) {
    const frame = runnerObject(value, 'execution.result');
    if (!Object.hasOwn(frame, 'identity'))
        throw new HostProtocolError('HOST_PROTOCOL', 'runner frame lacks execution.result.identity');
    if (!Object.hasOwn(frame, 'compiled'))
        throw new HostProtocolError('HOST_PROTOCOL', 'runner frame lacks execution.result.compiled');
    if (!Object.hasOwn(frame, 'outputs'))
        throw new HostProtocolError('HOST_PROTOCOL', 'runner frame lacks execution.result.outputs');
    if (!Object.hasOwn(frame, 'journal'))
        throw new HostProtocolError('HOST_PROTOCOL', 'runner frame lacks execution.result.journal');
    const identity = identityField(frame.identity, 'execution.result.identity');
    const compiledValue = runnerObject(frame.compiled, 'execution.result.compiled');
    const outputsValue = runnerObject(frame.outputs, 'execution.result.outputs');
    const journal = journalField(frame.journal, 'execution.result.journal');
    const compiled = {
        id: stringField(compiledValue.id, 'execution.result.compiled.id'),
        version: stringField(compiledValue.version, 'execution.result.compiled.version'),
        node_ids: stringArrayField(compiledValue.node_ids, 'execution.result.compiled.node_ids'),
        input_arcs: stringArrayField(compiledValue.input_arcs, 'execution.result.compiled.input_arcs'),
        output_arcs: stringArrayField(compiledValue.output_arcs, 'execution.result.compiled.output_arcs'),
    };
    if (compiled.id !== identity.graph_id || compiled.version !== identity.graph_version) {
        throw new HostProtocolError('HOST_PROTOCOL', 'execution.result compiled graph identity does not match identity');
    }
    if (compiled.output_arcs.length !== 1 || outputsValue[compiled.output_arcs[0]] === undefined) {
        throw new HostProtocolError('HOST_PROTOCOL', 'execution.result lacks its declared output ARC');
    }
    const outputs = {};
    for (const [arcId, arcValue] of Object.entries(outputsValue)) {
        const arc = runnerObject(arcValue, `execution.result.outputs.${arcId}`);
        const payload = runnerObject(arc.payload, `execution.result.outputs.${arcId}.payload`);
        outputs[arcId] = {
            id: stringField(arc.id, `execution.result.outputs.${arcId}.id`),
            version: requiredInteger(arc.version, `execution.result.outputs.${arcId}.version`),
            schema: stringField(arc.schema, `execution.result.outputs.${arcId}.schema`),
            payload: {
                control: runnerObject(payload.control, `execution.result.outputs.${arcId}.payload.control`),
                ...(Object.hasOwn(payload, 'business') ? { business: payload.business } : {}),
            },
        };
    }
    return { type: 'execution.result', identity, compiled, outputs, journal };
}
function decodeExecutionFailureFrame(value) {
    const frame = runnerObject(value, 'execution.failure');
    return {
        type: 'execution.failure',
        kind: stringField(frame.kind, 'execution.failure.kind'),
        message: stringField(frame.message, 'execution.failure.message'),
        journal: journalField(frame.journal, 'execution.failure.journal'),
    };
}
function decodeCompileResultFrame(value) {
    const frame = runnerObject(value, 'compile.result');
    return {
        type: 'compile.result',
        graph_id: stringField(frame.graph_id, 'compile.result.graph_id'),
        graph_version: stringField(frame.graph_version, 'compile.result.graph_version'),
        node_ids: stringArrayField(frame.node_ids, 'compile.result.node_ids'),
        capabilities: stringArrayField(frame.capabilities, 'compile.result.capabilities'),
    };
}
function decodeCompileFailureFrame(value) {
    const frame = runnerObject(value, 'compile.failure');
    return {
        type: 'compile.failure',
        stage: stringField(frame.stage, 'compile.failure.stage'),
        message: stringField(frame.message, 'compile.failure.message'),
        ...(frame.graph_id === undefined ? {} : { graph_id: stringField(frame.graph_id, 'compile.failure.graph_id') }),
        ...(frame.graph_version === undefined ? {} : { graph_version: stringField(frame.graph_version, 'compile.failure.graph_version') }),
    };
}
function decodeRunnerFailureFrame(value, type) {
    const frame = runnerObject(value, type);
    return { type, message: stringField(frame.message, `${type}.message`) };
}
export function requiredString(value, label) {
    if (typeof value !== 'string' || value.length === 0) {
        throw new HostProtocolError('INVALID_INPUT', `${label} must be a non-empty string`);
    }
    return value;
}
export function requiredInteger(value, label) {
    if (typeof value !== 'number' || !Number.isSafeInteger(value)) {
        throw new HostProtocolError('INVALID_INPUT', `${label} must be a safe integer`);
    }
    return value;
}
export function requiredBoolean(value, label) {
    if (typeof value !== 'boolean') {
        throw new HostProtocolError('INVALID_INPUT', `${label} must be a boolean`);
    }
    return value;
}
export function requiredObject(value, label) {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
        throw new HostProtocolError('INVALID_INPUT', `${label} must be an object`);
    }
    return value;
}
export function decodeResourceDemands(value, label) {
    if (!Array.isArray(value)) {
        throw new HostProtocolError('INVALID_INPUT', `${label} must be an array`);
    }
    return value.map((item, index) => {
        const demand = requiredObject(item, `${label}[${index}]`);
        const resourceId = requiredString(demand.resourceId, `${label}[${index}].resourceId`);
        const amount = requiredInteger(demand.amount, `${label}[${index}].amount`);
        if (amount < 1) {
            throw new HostProtocolError('INVALID_INPUT', `${label}[${index}].amount must be positive`);
        }
        return { resourceId, amount };
    });
}
export function decodeAgentWorkServiceSelection(value, label) {
    const selection = requiredObject(value, label);
    if (selection.mode === 'endpoint') {
        return { mode: 'endpoint' };
    }
    if (selection.mode !== 'capability') {
        throw new HostProtocolError('INVALID_INPUT', `${label}.mode must be endpoint or capability`);
    }
    const providerAgentId = requiredString(selection.providerAgentId, `${label}.providerAgentId`);
    const targetGeneration = requiredInteger(selection.targetGeneration, `${label}.targetGeneration`);
    const generationPolicy = selection.generationPolicy;
    if (generationPolicy !== 'exact' && generationPolicy !== 'current') {
        throw new HostProtocolError('INVALID_INPUT', `${label}.generationPolicy must be exact or current`);
    }
    const linkGeneration = selection.linkGeneration === undefined
        ? undefined
        : requiredInteger(selection.linkGeneration, `${label}.linkGeneration`);
    return {
        mode: 'capability',
        providerAgentId,
        targetGeneration,
        generationPolicy,
        ...(linkGeneration === undefined ? {} : { linkGeneration }),
    };
}
