import { type FixedProcessRunner } from './fixed-process.ts';
import { type ContextCreateRequest, type ContextCreateResult, type ContextDestroyRequest, type ContextDestroyResult, type NavigateRequest, type NavigateResult, type SnapshotRequest, type SnapshotResult } from './contracts.ts';
export interface BrowserCliAdapterOptions {
    readonly executable: string;
    readonly profile: string;
    readonly headless?: boolean;
    readonly timeoutMs?: number;
    readonly maxOutputBytes?: number;
    readonly runner?: FixedProcessRunner;
}
export interface BrowserCliAdapter {
    contextCreate(request: ContextCreateRequest): Promise<ContextCreateResult>;
    navigate(request: NavigateRequest): Promise<NavigateResult>;
    snapshot(request: SnapshotRequest): Promise<SnapshotResult>;
    contextDestroy(request: ContextDestroyRequest): Promise<ContextDestroyResult>;
}
export declare function createBrowserCliAdapter(options: BrowserCliAdapterOptions): BrowserCliAdapter;
