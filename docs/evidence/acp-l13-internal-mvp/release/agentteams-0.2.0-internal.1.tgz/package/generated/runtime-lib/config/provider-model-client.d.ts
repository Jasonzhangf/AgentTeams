import type { ProviderModelClient } from './runtime-config.ts';
export interface OpenAIModelCatalogClientOptions {
    readonly timeoutMs?: number;
    readonly maxResponseBytes?: number;
}
export declare function createOpenAIModelCatalogClient(options?: OpenAIModelCatalogClientOptions): ProviderModelClient;
