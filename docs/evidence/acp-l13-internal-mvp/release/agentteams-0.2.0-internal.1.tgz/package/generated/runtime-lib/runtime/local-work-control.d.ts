import type { Duplex } from 'node:stream';
import type { JsonValue, ResourceDemand } from '../control-protocol/agent-services.ts';
import type { ProjectExecutionControl, ProjectExecutionReceipt } from './dagpipe/host.ts';
import type { ConsoleRuntimeState } from './local-config.ts';
export type LocalWorkControlKind = 'work.submit' | 'work.query' | 'work.open' | 'work.request' | 'work.close';
interface LocalWorkControlBaseControl {
    readonly receiverAgentId: string;
    readonly expectedLauncherGeneration: number;
    readonly startToken: string;
    readonly executionId: string;
    readonly attemptId: string;
    readonly workId: string;
    readonly requestId: string;
}
export interface LocalWorkSubmitControl extends LocalWorkControlBaseControl {
}
export interface LocalWorkQueryEndpointControl extends LocalWorkControlBaseControl {
    readonly serviceSelection: 'endpoint';
}
export interface LocalWorkQueryCapabilityControl extends LocalWorkControlBaseControl {
    readonly serviceSelection: 'capability';
    readonly targetAgentId: string;
    readonly targetGeneration: number;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly linkGeneration?: number;
}
export interface LocalWorkOpenControl extends LocalWorkControlBaseControl {
    readonly targetAgentId: string;
    readonly targetGeneration: number;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly demands: readonly ResourceDemand[];
    readonly policyRevision?: number;
}
export interface LocalWorkRequestControl extends LocalWorkControlBaseControl {
    readonly targetAgentId: string;
    readonly targetGeneration: number;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly demands: readonly ResourceDemand[];
}
export interface LocalWorkCloseControl extends LocalWorkControlBaseControl {
    readonly targetAgentId: string;
    readonly targetGeneration: number;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
}
export type LocalWorkControlRequest = {
    readonly kind: 'work.submit';
    readonly requestId: string;
    readonly control: LocalWorkSubmitControl;
    readonly business: JsonValue;
} | {
    readonly kind: 'work.query';
    readonly requestId: string;
    readonly control: LocalWorkQueryEndpointControl;
} | {
    readonly kind: 'work.query';
    readonly requestId: string;
    readonly control: LocalWorkQueryCapabilityControl;
} | {
    readonly kind: 'work.open';
    readonly requestId: string;
    readonly control: LocalWorkOpenControl;
    readonly business: JsonValue;
} | {
    readonly kind: 'work.request';
    readonly requestId: string;
    readonly control: LocalWorkRequestControl;
    readonly business: JsonValue;
} | {
    readonly kind: 'work.close';
    readonly requestId: string;
    readonly control: LocalWorkCloseControl;
};
export type LocalWorkControlReply = {
    readonly kind: 'work.result';
    readonly requestId: string;
    readonly receipt: ProjectExecutionReceipt;
} | {
    readonly kind: 'work.error';
    readonly requestId: string;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
};
export type LocalConsoleControlKind = 'console.status' | 'console.start' | 'console.stop';
export interface LocalConsoleControlRequest {
    readonly kind: LocalConsoleControlKind;
    readonly correlationId: string;
    readonly expectedLauncherGeneration: number;
    readonly expectedConsoleGeneration?: number;
}
/** Credential is a resolution state, never the secret value. */
export interface LocalConsolePublicStatus {
    readonly enabled: boolean;
    readonly state: ConsoleRuntimeState | 'disabled';
    readonly generation: number;
    readonly launcherState: 'stopped' | 'starting' | 'running' | 'stopping' | 'failed';
    readonly launcherGeneration: number;
    readonly credential: 'configured' | 'missing';
    readonly url?: string;
    readonly origin?: string;
    readonly pid?: number;
    readonly identityRef?: string;
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
}
export type LocalConsoleControlReply = {
    readonly kind: 'console.result';
    readonly correlationId: string;
    readonly ok: true;
    readonly status: LocalConsolePublicStatus;
} | {
    readonly kind: 'console.result';
    readonly correlationId: string;
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
};
export type LocalControlRequest = LocalWorkControlRequest | LocalConsoleControlRequest;
export type LocalControlReply = LocalWorkControlReply | LocalConsoleControlReply;
export type LocalWorkControlDelivery = 'written' | 'unconfirmed';
export type LocalWorkControlErrorCode = 'LOCAL_CONTROL_UNAVAILABLE' | 'HOST_PROTOCOL' | 'NOT_AUTHORIZED' | 'STALE_GENERATION' | 'RECEIVER_NOT_FOUND';
export declare class LocalWorkControlError extends Error {
    readonly code: LocalWorkControlErrorCode | string;
    constructor(code: LocalWorkControlErrorCode | string, message: string, options?: ErrorOptions);
}
/**
 * The binding a persistent Work frame already fixed. A failed or unconfirmed
 * receipt must carry it, so the caller can query or close the Work with the
 * original identity instead of rebuilding it from config or logs.
 */
export declare function localWorkFrameBinding(frame: LocalWorkControlRequest): Partial<ProjectExecutionControl>;
/**
 * The single owner of the failed or unconfirmed Work receipt shape. The CLI
 * pre-dispatch refusal path and the receiver post-dispatch path both build it
 * from the frame they already hold, so the projectId literal, the generated
 * identity and the fixed binding projection cannot diverge between them.
 */
export declare function failedLocalWorkReceipt(frame: LocalWorkControlRequest, error: {
    readonly code: string;
    readonly message: string;
}, deliveryState?: 'unconfirmed'): ProjectExecutionReceipt;
export interface LocalWorkControlHandlerInput {
    readonly frame: LocalWorkControlRequest;
    readonly peer: Duplex;
    readonly disconnected: Promise<void>;
    respond(reply: ProjectExecutionReceipt | {
        readonly code: string;
        readonly message: string;
    }): Promise<LocalWorkControlDelivery>;
}
export interface LocalConsoleControlHandlerInput {
    readonly frame: LocalConsoleControlRequest;
    respond(reply: LocalConsoleControlReply): Promise<LocalWorkControlDelivery>;
}
export interface LocalWorkControlListenerOptions {
    readonly socketPath: string;
    readonly launcherGeneration: number;
    readonly startToken: string;
    readonly receivers: Readonly<Record<string, boolean>>;
    readonly handler: (input: LocalWorkControlHandlerInput) => Promise<ProjectExecutionReceipt | {
        readonly code: string;
        readonly message: string;
    }>;
    readonly consoleHandler?: (input: LocalConsoleControlHandlerInput) => Promise<void>;
}
export interface LocalWorkControlSendOptions {
    readonly socketPath: string;
    readonly frame: LocalWorkControlRequest;
    readonly timeoutMs?: number;
}
export interface LocalConsoleControlSendOptions {
    readonly socketPath: string;
    readonly frame: LocalConsoleControlRequest;
    readonly timeoutMs?: number;
}
export interface LocalWorkControlServer {
    readonly socketPath: string;
    close(): Promise<void>;
}
export declare function encodeLocalWorkControlFrame(frame: LocalControlRequest | LocalControlReply): string;
export declare function decodeLocalWorkControlRequest(value: unknown): LocalWorkControlRequest;
export declare function decodeLocalConsoleControlRequest(value: unknown): LocalConsoleControlRequest;
export declare function decodeLocalControlRequest(value: unknown): LocalControlRequest;
export declare function decodeLocalWorkControlReply(value: unknown, expectedRequestId: string): LocalWorkControlReply;
export declare function decodeLocalConsoleControlReply(value: unknown, expectedCorrelationId: string): LocalConsoleControlReply;
export declare function startLocalWorkControlListener(options: LocalWorkControlListenerOptions): Promise<LocalWorkControlServer>;
export declare function sendLocalWorkControlRequest(options: LocalWorkControlSendOptions): Promise<LocalWorkControlReply>;
export declare function sendLocalConsoleControlRequest(options: LocalConsoleControlSendOptions): Promise<LocalConsoleControlReply>;
export {};
