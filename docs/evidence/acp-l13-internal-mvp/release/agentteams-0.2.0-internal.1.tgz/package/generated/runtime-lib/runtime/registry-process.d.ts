import { type RegistryDaemonIntent } from '../config/daemon-intent.ts';
/**
 * Runtime single writer for the local registry companion. It composes the
 * server-owned Relay directory (`server/Relay`) from one v4 registry config and
 * owns that daemon's lifecycle: one process, one PID, one state file, explicit
 * stop. It never starts a second daemon, never rewrites the config, and never
 * reuses the control daemon's lifecycle.
 *
 * This file is both the parent lifecycle entry and the detached child entry,
 * exactly like `runtime/local-process.ts`.
 */
declare const STATE_VERSION = 1;
export type RegistryDaemonLifecycleState = 'starting' | 'running' | 'failed' | 'stopped';
export interface RegistryDaemonState {
    readonly version: typeof STATE_VERSION;
    readonly configPath: string;
    readonly entryPath: string;
    readonly daemonId: string;
    readonly startToken: string;
    readonly generation: number;
    readonly pid: number;
    readonly state: RegistryDaemonLifecycleState;
    readonly url?: string;
    readonly error?: string;
    readonly updatedAt: string;
}
export interface RegistryDaemonStatus {
    readonly configPath: string;
    readonly statePath: string;
    readonly daemonId: string;
    readonly state: RegistryDaemonLifecycleState;
    readonly generation: number;
    readonly pid?: number;
    readonly url?: string;
    readonly error?: string;
}
export type RegistryProcessErrorCode = 'INVALID_CONFIG' | 'ALREADY_RUNNING' | 'START_TIMEOUT' | 'STOP_TIMEOUT' | 'STALE_GENERATION' | 'STALE_OWNER' | 'INVALID_STATUS';
export declare class RegistryProcessError extends Error {
    readonly code: RegistryProcessErrorCode;
    constructor(code: RegistryProcessErrorCode, message: string, cause?: unknown);
}
export interface RegistryDaemonStartOptions {
    readonly env?: NodeJS.ProcessEnv;
    readonly nodeExecutable?: string;
    readonly nodeArguments?: readonly string[];
    readonly startupTimeoutMs?: number;
}
export interface RegistryProcessArgs {
    readonly configPath: string;
    readonly startToken?: string;
}
export declare function parseRegistryArgs(argv: readonly string[]): RegistryProcessArgs;
/** Loads one v4 registry config through the frozen config owner. */
export declare function loadRegistryIntent(configPath: string): Promise<RegistryDaemonIntent>;
export declare function registryStatePath(intent: RegistryDaemonIntent): string;
export declare function readRegistryState(statePath: string): Promise<RegistryDaemonState | undefined>;
export declare function startRegistryDaemon(configPath: string, options?: RegistryDaemonStartOptions): Promise<RegistryDaemonStatus>;
export declare function statusRegistryDaemon(configPath: string): Promise<RegistryDaemonStatus>;
export declare function stopRegistryDaemon(configPath: string, expectedGeneration?: number): Promise<RegistryDaemonStatus>;
/**
 * Detached child entry. It publishes its own readiness into the one state file
 * after the Relay listener is bound, so `registry status` never reports a
 * fabricated `running` state.
 */
export declare function runRegistryProcess(argv?: readonly string[], env?: NodeJS.ProcessEnv): Promise<void>;
export {};
