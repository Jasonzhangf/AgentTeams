import type { AgentDeclaration } from '../control-protocol/agent-services.ts';
import type { RelayClientOptions } from '../network/relay-client.ts';
export declare function object(value: unknown, keys: readonly string[], label: string): Record<string, unknown>;
export declare function text(value: unknown, label: string): string;
export declare function number(value: unknown, label: string, max?: number): number;
export declare function credential(value: unknown, env: NodeJS.ProcessEnv): string;
export interface DirectListenerConfig {
    readonly host?: string;
    readonly port: number;
    readonly keyFile: string;
    readonly certFile: string;
    readonly credential: string;
    readonly admissions: readonly {
        readonly admissionRef: string;
        readonly agentId: string;
        readonly credential: string;
    }[];
    readonly target: {
        readonly hostId: string;
        readonly agentId: string;
        readonly protocolVersion: number;
        readonly capabilitiesRevision: string;
    };
    readonly maxPayload: number;
    readonly maxConnections: number;
    readonly maxMessageBytes: number;
    readonly maxBufferedBytes: number;
    readonly maxPendingFrames: number;
    readonly helloTimeoutMs: number;
}
/** Shared runtime bootstrap config owner; credentials never enter declarations. */
export declare function loadRelayConfig(input: unknown, declaration: AgentDeclaration, configPath: string, env: NodeJS.ProcessEnv): Promise<RelayClientOptions>;
export declare function loadDirectListenerConfig(input: unknown, declaration: AgentDeclaration, configPath: string, env: NodeJS.ProcessEnv): DirectListenerConfig;
