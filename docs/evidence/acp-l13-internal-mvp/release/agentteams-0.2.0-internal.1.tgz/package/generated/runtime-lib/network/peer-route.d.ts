import type { ServiceErrorCode } from '../control-protocol/agent-services.ts';
import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import { type AccountDirectorySnapshot } from './account-directory.ts';
import { type DirectWssTarget, type DirectWssTargetOptions } from './direct-route.ts';
import type { WssConnectionOptions } from './wss-connection.ts';
type RelayCandidateKind = 'relay-ws' | 'relay-webrtc';
export type PeerRouteErrorCode = Extract<ServiceErrorCode, 'INVALID_INPUT' | 'CONFLICT' | 'NOT_FOUND' | 'STALE_GENERATION' | 'RESULT_UNKNOWN' | 'UNAVAILABLE'>;
export declare class PeerRouteError extends Error {
    readonly code: PeerRouteErrorCode;
    constructor(code: PeerRouteErrorCode, message: string, cause?: unknown);
}
export interface PeerRouteBinding {
    readonly kind: 'direct-wss' | RelayCandidateKind;
    readonly connectionId: string;
    readonly connectionGeneration: number;
    readonly directoryGeneration: number;
    readonly targetGeneration: number;
    readonly candidateId: string;
}
export interface PeerRouteConnectionBinding {
    readonly connectionId: string;
    readonly connectionGeneration: number;
}
export interface PeerRouteExpectedBinding extends PeerRouteConnectionBinding {
    readonly directoryGeneration: number;
    readonly targetGeneration: number;
}
export interface DirectPeerRouteInput {
    readonly directory: AccountDirectorySnapshot;
    readonly hostId: string;
    readonly targetCandidateId: string;
    readonly targetGeneration: number;
    readonly protocolVersion: number;
    readonly binding: PeerRouteConnectionBinding;
    readonly transport: Omit<WssConnectionOptions, 'endpoint'>;
    readonly helloTimeoutMs: number;
    readonly source: AuthenticatedAgent;
    readonly admissionRef: string;
}
export interface RelayPeerRouteInput {
    readonly directory: AccountDirectorySnapshot;
    readonly hostId: string;
    readonly targetCandidateId: string;
    readonly targetGeneration: number;
    readonly binding: PeerRouteConnectionBinding;
}
export interface DirectPeerRouteOptions extends DirectWssTargetOptions {
    readonly kind: 'direct-wss';
    readonly peerRoute: PeerRouteBinding & {
        readonly kind: 'direct-wss';
    };
}
export interface RelayPeerRouteOptions {
    readonly kind: 'relay';
    readonly peerRoute: PeerRouteBinding & {
        readonly kind: RelayCandidateKind;
    };
    readonly target: {
        readonly hostId: string;
        readonly agentId: string;
        readonly capabilitiesRevision: string;
        readonly targetGeneration: number;
    };
}
export type PeerRouteOptions = DirectPeerRouteOptions | RelayPeerRouteOptions;
export declare function assembleDirectWssTargetOptions(input: DirectPeerRouteInput): DirectPeerRouteOptions;
export declare function assembleRelayPeerRoute(input: RelayPeerRouteInput): RelayPeerRouteOptions;
export declare function assemblePeerRoute(input: DirectPeerRouteInput | RelayPeerRouteInput): PeerRouteOptions;
export declare function connectDirectPeerRoute(input: DirectPeerRouteInput): Promise<DirectWssTarget>;
export declare function assertPeerRouteBinding(route: PeerRouteBinding, expected: PeerRouteExpectedBinding): void;
export {};
