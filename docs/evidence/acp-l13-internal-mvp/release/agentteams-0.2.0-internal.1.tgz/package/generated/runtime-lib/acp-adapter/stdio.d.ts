import type { Readable, Writable } from 'node:stream';
import type { AcpDuplex } from '../control-protocol/engine.ts';
/**
 * Newline-delimited JSON ACP transport over one engine's stdio.
 *
 * Owner: acp-adapter. This is the only stdio ACP frame encoder/decoder. It
 * implements the frozen `AcpDuplex` port from control-protocol/engine.ts and
 * reuses the frozen `parseAcpFrame` validator, so it declares no second frame
 * shape, fault carrier, or duplex type.
 *
 * The transport preserves the complete JSON-RPC object and its id type. It
 * never rewrites a frame, drops a notification, or kills a process: `close()`
 * releases the owned streams only.
 */
export declare const DEFAULT_ACP_MAX_FRAME_BYTES = 8388608;
export interface StdioAcpDuplexOptions {
    readonly readable: Readable;
    readonly writable: Writable;
    /** Hard bound for one encoded frame, in bytes. Defaults to 8 MiB. */
    readonly maxFrameBytes?: number;
    /**
     * Deadline for one `read()` call. A stalled engine is a transport failure,
     * so the duplex settles `failed` with ENGINE_UNAVAILABLE. Omitted means the
     * caller keeps no read deadline.
     */
    readonly readTimeoutMs?: number;
}
export declare function createStdioAcpDuplex(options: StdioAcpDuplexOptions): AcpDuplex;
