import type { AgentWork, AuthenticatedAgent, ResourceAllocation, ServiceErrorCode, WorkProposal, WorkRequest } from '../control-protocol/agent-services.ts';
import { type ProviderWorkPolicy, type RequestCompletion, type WorkLedger, type WorkRequestRecord } from '../agent/work-resource.ts';
/** Local adapter port. Terminal outcomes require actual execution completion. */
export interface WorkExecutor {
    execute(work: AgentWork, request: WorkRequest, allocations: readonly ResourceAllocation[]): Promise<RequestCompletion>;
    /** Resolve only after this Work's resources have actually been destroyed; allocations are a read-only ledger projection. */
    destroy(work: AgentWork, allocations: readonly ResourceAllocation[]): Promise<{
        readonly destroyed: true;
    }>;
}
export interface WorkHostOptions {
    readonly ledger: WorkLedger;
    readonly policy: () => ProviderWorkPolicy;
    readonly executor: WorkExecutor;
}
export interface WorkHost {
    propose(consumer: AuthenticatedAgent, proposal: WorkProposal): AgentWork;
    request(consumer: AuthenticatedAgent, input: WorkRequest): Promise<WorkRequestRecord>;
    get(consumer: AuthenticatedAgent, workId: string, requestId: string): WorkRequestRecord;
    close(consumer: AuthenticatedAgent, workId: string): Promise<AgentWork>;
}
export declare class WorkHostError extends Error {
    readonly code: ServiceErrorCode;
    constructor(code: ServiceErrorCode, message: string);
}
/** Composes execution with the Agent-owned ledger; no second allocation owner. */
export declare function createWorkHost({ ledger, policy, executor }: WorkHostOptions): WorkHost;
