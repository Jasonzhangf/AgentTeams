import type { RelayServerControl } from './agent-services.ts';
export { RelayProtocolError } from './relay-codec.ts';
type Admission = Extract<RelayServerControl, {
    kind: 'relay.admitted' | 'relay.error';
}>;
/** First server frame only. A directory or arbitrary object cannot imply admission. */
export declare function parseRelayAdmission(text: string): Admission;
