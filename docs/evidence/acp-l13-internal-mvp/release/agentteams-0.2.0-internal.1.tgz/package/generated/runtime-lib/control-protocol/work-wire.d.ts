import type { AgentWork, ServiceError, WorkProposal, WorkReply, WorkRequest } from './agent-services.ts';
export type WorkWireRequest = {
    readonly kind: 'work.propose';
    readonly correlationId: string;
    readonly proposal: WorkProposal;
} | ({
    readonly kind: 'work.request';
    readonly correlationId: string;
} & WorkRequest) | {
    readonly kind: 'work.get';
    readonly correlationId: string;
    readonly workId: string;
    readonly requestId: string;
} | {
    readonly kind: 'work.close';
    readonly correlationId: string;
    readonly workId: string;
};
export type WorkWireReply = {
    readonly kind: 'work.state';
    readonly correlationId: string;
    readonly work: AgentWork;
} | ({
    readonly kind: 'work.result';
    readonly correlationId: string;
} & WorkReply) | {
    readonly kind: 'work.error';
    readonly correlationId: string;
    readonly error: ServiceError;
};
export type WorkWireFrame = WorkWireRequest | WorkWireReply;
export declare function parseWorkWireFrame(text: string): WorkWireFrame;
