import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { AcpChannelRef, AcpDelivery, AcpFault, AcpFrame, AcpIngress, AcpRpcId } from '../control-protocol/acp.ts';
import type { ConsolePermissionOption } from '../control-protocol/console-api.ts';
import type { EngineHandle } from '../control-protocol/engine.ts';
import type { AcpPolicySnapshot } from '../config/acp-policy.ts';
import type { AcpHistoryPort } from './acp-history.ts';
/**
 * Agent-host ACP owner: logical channels, RPC/callback correlation, Session
 * ownership, execution admission and execution-history semantics.
 *
 * Owner: agent-host. It consumes the frozen D00 contracts (`AcpFrame`,
 * `AcpFault`, `AcpError`, `parseAcpFrame`, `AcpDuplex`/`EngineHandle`,
 * `AcpPolicySnapshot`) and declares no second frame, fault, duplex, policy or
 * history-read type. `AcpIngress` is flat: a ref plus `frame`, never `{ ref }`.
 */
export type AcpDirection = 'to-engine' | 'from-engine';
/**
 * Injected D00 policy assertion (`config/acp-policy.ts#assertAcpAllowed`). The
 * host never compiles policy and never imports the config store at runtime.
 */
export type AcpPolicyAssert = (input: {
    readonly policy: AcpPolicySnapshot;
    readonly direction: AcpDirection;
    readonly frame: AcpFrame;
}) => void;
/**
 * One engine callback that awaits a controller reply, with the identity and the real option
 * set the controller needs (A2.6).
 *
 * `permissionId` is the id the controller received with the request, which is also the
 * address a reply must use. It is the Console-facing identity because it is the one the
 * controller can really see; the host keeps its own history record id separately as the
 * durable audit identity.
 */
export interface AcpPendingPermission {
    readonly ref: AcpChannelRef;
    readonly sessionId: string;
    readonly permissionId: string;
    /** The engine's real choice set; empty when the engine offered no options. */
    readonly options: readonly ConsolePermissionOption[];
}
export interface AcpHost {
    open(input: {
        readonly ref: AcpChannelRef;
        readonly principal: AuthenticatedAgent;
        readonly policy: AcpPolicySnapshot;
    }): Promise<void>;
    receive(ingress: AcpIngress): Promise<void>;
    /** Read and consume the channel's live deliveries after `afterSequence`. */
    read(ref: AcpChannelRef, afterSequence: number, limit: number): Promise<{
        readonly frames: readonly AcpDelivery[];
        readonly nextSequence: number;
    }>;
    close(ref: AcpChannelRef): Promise<void>;
    /**
     * The engine permission callbacks awaiting a controller reply. The host is the A2.6
     * permission owner, so this is the only place that knows which callbacks are still open
     * and which options the engine really offered.
     */
    pendingPermissions(): readonly AcpPendingPermission[];
    /**
     * The host-facing ref of the channel that owns `sessionId`, or `undefined` when no open
     * channel owns it. A caller never invents a ref for a Session it does not own.
     */
    channelForSession(sessionId: string): AcpChannelRef | undefined;
    /**
     * The Session ids an open channel really owns, in the order this host learned them.
     *
     * The host is the Session owner, so it is the only place that knows which engine Sessions
     * are still held by a live channel. This is a read of the host's own record, never a
     * second session source: a Session whose channel closed is not reported, and no title or
     * transcript is invented here.
     */
    openedSessions(): readonly string[];
}
export interface CreateAcpHostInput {
    readonly handle: EngineHandle;
    /**
     * The genuine successful `initialize` response captured once by the runtime
     * bootstrap as the sole reader before ownership transfer. The host serves it
     * to every channel under that channel's policy and never initializes the
     * child again.
     */
    readonly initializeResult: AcpFrame;
    readonly policy: AcpPolicySnapshot;
    readonly history: AcpHistoryPort;
    readonly assertAllowed: AcpPolicyAssert;
    /** Local Agent identity used for request history. Defaults to the engine instance. */
    readonly agentId?: string;
    readonly maxDeliveryBacklog?: number;
    /** Observable history-write failure; never carried inside an ACP payload. */
    readonly onHistoryFault?: (fault: AcpFault) => void;
}
/** Canonical correlation key for a JSON-RPC id, preserving `string` vs `number`. */
export declare function rpcIdKey(id: AcpRpcId): string;
/**
 * The one ACP JSON-RPC error envelope. Exported so the runtime serve transport
 * answers a frame the host rejects with the same envelope instead of declaring
 * a second one.
 */
export declare function rpcErrorFrame(id: AcpRpcId, fault: AcpFault): AcpFrame;
/**
 * Engine-side projection of the real engine-supplied permission choice set (A2.6).
 *
 * The option set is read verbatim from the engine's own `session/request_permission`
 * params: this function never mints an option the engine did not offer, and it returns
 * `undefined` when the engine offered none (the field is additive and stays absent). A
 * malformed option fails explicitly at this owning boundary instead of reaching a
 * controller as an unactionable or ambiguous choice.
 */
export declare function projectPermissionOptions(frame: AcpFrame): readonly ConsolePermissionOption[] | undefined;
/**
 * Adjudicates one controller reply against the engine's real option set (A2.6).
 *
 * The engine is answered with a selection it really offered. A selection the engine never
 * offered, a selection when the engine offered no options, or an unknown outcome fails
 * typed; a missing or stale callback never becomes an approval and the host never supplies
 * an `optionId` of its own.
 */
export declare function adjudicatePermissionReply(result: unknown, options: readonly ConsolePermissionOption[] | undefined): {
    readonly outcome: {
        readonly outcome: 'selected';
        readonly optionId: string;
    } | {
        readonly outcome: 'cancelled';
    };
};
export declare function createAcpHost(input: CreateAcpHostInput): AcpHost;
