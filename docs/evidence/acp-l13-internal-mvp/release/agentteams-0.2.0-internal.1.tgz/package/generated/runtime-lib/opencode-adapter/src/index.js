import { randomBytes } from 'node:crypto';
import { createOpencodeClient } from '@opencode-ai/sdk';
import { assertEnvelopeKeys, assertJsonValue } from "../../control-protocol/json-value.js";
export class OpenCodeAdapterError extends Error {
    code;
    operation;
    status;
    constructor(operation, code, message, status) {
        super(message);
        this.name = 'OpenCodeAdapterError';
        this.code = code;
        this.operation = operation;
        this.status = status;
    }
}
function isRecord(value) {
    return typeof value === 'object' && value !== null;
}
function responseStatus(response) {
    const nested = response.response;
    if (isRecord(nested) && typeof nested.status === 'number')
        return nested.status;
    return typeof response.status === 'number' ? response.status : undefined;
}
function responseMessage(value, operation) {
    if (value instanceof Error && value.message.length > 0)
        return value.message;
    if (isRecord(value) && typeof value.message === 'string' && value.message.length > 0)
        return value.message;
    return `OpenCode ${operation} failed`;
}
function errorCodeForStatus(status) {
    if (status === 401)
        return 'UNAUTHENTICATED';
    if (status === 403)
        return 'FORBIDDEN';
    if (status === 404)
        return 'NOT_FOUND';
    if (status !== undefined && status >= 500)
        return 'UPSTREAM_ERROR';
    return 'INVALID_RESPONSE';
}
function unwrapOpenCodeResponse(response, operation, allowUndefined = false) {
    if (!isRecord(response)) {
        if (response === undefined && !allowUndefined)
            throw new OpenCodeAdapterError(operation, 'INVALID_RESPONSE', `OpenCode ${operation} returned no data`);
        return response;
    }
    const status = responseStatus(response);
    if (status !== undefined && (status < 200 || status >= 300)) {
        throw new OpenCodeAdapterError(operation, errorCodeForStatus(status), responseMessage(response.error, operation), status);
    }
    const hasEnvelope = 'data' in response || 'error' in response || 'response' in response;
    if (!hasEnvelope) {
        if (status !== undefined) {
            if (allowUndefined)
                return undefined;
            throw new OpenCodeAdapterError(operation, 'INVALID_RESPONSE', `OpenCode ${operation} returned no data`, status);
        }
        return response;
    }
    if (response.error !== undefined) {
        throw new OpenCodeAdapterError(operation, errorCodeForStatus(status), responseMessage(response.error, operation), status);
    }
    if (response.data === undefined) {
        if (allowUndefined)
            return undefined;
        throw new OpenCodeAdapterError(operation, errorCodeForStatus(status), `OpenCode ${operation} returned no data`, status);
    }
    return response.data;
}
export async function listOpenCodeSessions(client, directory) {
    const result = await client.session.list(directory === undefined ? {} : { query: { directory } });
    const sessions = unwrapOpenCodeResponse(result, 'session.list');
    if (sessions === undefined)
        throw new OpenCodeAdapterError('session.list', 'INVALID_RESPONSE', 'OpenCode session.list returned no data');
    return sessions.map(session => ({ id: session.id, title: session.title, directory: session.directory, time: session.time }));
}
export async function getOpenCodeSession(client, sessionId) {
    const result = await client.session.get({ path: { id: sessionId } });
    const session = unwrapOpenCodeResponse(result, 'session.get');
    if (session === undefined)
        throw new OpenCodeAdapterError('session.get', 'NOT_FOUND', `OpenCode session not found: ${sessionId}`, 404);
    return { id: session.id, title: session.title, directory: session.directory, time: session.time };
}
/**
 * Reads one Session's real message/tool history through the SDK pull path. The
 * adapter preserves the raw `{info, parts}` entries; the owner-side projector
 * applies the same closed event classification used for SSE events.
 */
export async function readOpenCodeSessionMessages(client, sessionId, query) {
    const result = await client.session.messages({ path: { id: sessionId }, ...(query === undefined ? {} : { query }) });
    const messages = unwrapOpenCodeResponse(result, 'session.messages');
    if (messages === undefined)
        throw new OpenCodeAdapterError('session.messages', 'INVALID_RESPONSE', 'OpenCode session.messages returned no data');
    return messages;
}
/**
 * Reads the substrate's real session-level status map. Status is auxiliary
 * observation only: `idle` never confirms a cancel, and the runtime must not
 * derive cancel causality from it.
 */
export async function readOpenCodeSessionStatus(client, query) {
    const result = await client.session.status(query === undefined ? {} : { query });
    const statuses = unwrapOpenCodeResponse(result, 'session.status');
    if (statuses === undefined)
        throw new OpenCodeAdapterError('session.status', 'INVALID_RESPONSE', 'OpenCode session.status returned no data');
    return statuses;
}
function invalidOpenCodeModelTarget(message) {
    throw new OpenCodeAdapterError('session.prompt', 'INVALID_INPUT', message);
}
function validateOpenCodeModelTarget(target) {
    if (target === undefined)
        return undefined;
    if (typeof target !== 'object' || target === null || Array.isArray(target)) {
        return invalidOpenCodeModelTarget('OpenCode model target must be a plain object');
    }
    try {
        assertJsonValue(target, 'OpenCode model target');
        assertEnvelopeKeys(target, ['providerID', 'modelID'], 'OpenCode model target');
    }
    catch (error) {
        return invalidOpenCodeModelTarget(error instanceof Error ? error.message : 'OpenCode model target is invalid');
    }
    const input = target;
    const providerID = input.providerID;
    const modelID = input.modelID;
    if (typeof providerID !== 'string' || providerID.trim() === '' || typeof modelID !== 'string' || modelID.trim() === '') {
        return invalidOpenCodeModelTarget('OpenCode model target requires non-empty providerID and modelID');
    }
    return { providerID, modelID };
}
export async function sendOpenCodeMessage(client, sessionId, text, target) {
    if (text.trim() === '')
        throw new Error('OpenCode message must not be empty');
    const selectedTarget = validateOpenCodeModelTarget(target);
    const body = {
        parts: [{ type: 'text', text }],
        ...(selectedTarget === undefined ? {} : { model: selectedTarget }),
    };
    const result = await client.session.prompt({ path: { id: sessionId }, body });
    unwrapOpenCodeResponse(result, 'session.prompt', true);
}
/**
 * OpenCode's `Session.Message.ID` is a `msg_`-prefixed identifier, and its prompt
 * route rejects any other shape before the message exists. The Session dispatch
 * path must allocate the prompt id before dispatch, because an event that arrives
 * before the synchronous response is correlated by that id. The substrate's
 * identifier format therefore stays owned here and is never re-derived by callers.
 */
export function createOpenCodePromptMessageId() {
    const alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let body = '';
    for (const byte of randomBytes(26))
        body += alphabet[byte % alphabet.length];
    return `msg_${body}`;
}
function validatePromptMessageId(messageId) {
    if (messageId === undefined)
        return undefined;
    if (typeof messageId !== 'string' || !messageId.startsWith('msg_') || messageId.length === 4) {
        throw new OpenCodeAdapterError('session.prompt', 'INVALID_INPUT', 'OpenCode prompt messageID must be a msg_-prefixed Session.Message.ID');
    }
    return messageId;
}
/**
 * Dispatches one SDK prompt with an explicit, owner-resolved model target and an
 * owner-allocated user messageID. Both are required in the Session dispatch
 * path; the messageID is the SDK body field, never a Teams business part.
 *
 * The synchronous `{ info, parts }` response is one of the two allowed binding
 * sources, so it is decoded rather than discarded: a response only binds when it
 * names an assistant message whose session and parent are this request's.
 */
export async function promptOpenCodeSession(client, sessionId, text, target, messageId, onDispatch) {
    if (text.trim() === '')
        throw new OpenCodeAdapterError('session.prompt', 'INVALID_INPUT', 'OpenCode message must not be empty');
    const selectedTarget = validateOpenCodeModelTarget(target);
    if (selectedTarget === undefined)
        throw new OpenCodeAdapterError('session.prompt', 'INVALID_INPUT', 'OpenCode prompt requires an effective model target');
    const validatedMessageId = validatePromptMessageId(messageId);
    const body = {
        messageID: validatedMessageId,
        parts: [{ type: 'text', text }],
        model: selectedTarget,
    };
    onDispatch?.();
    const result = await client.session.prompt({ path: { id: sessionId }, body });
    const response = unwrapOpenCodeResponse(result, 'session.prompt', true);
    const info = asRecord(asRecord(response)?.info);
    const assistantId = info === undefined ? undefined : stringField(info.id);
    const boundSession = info === undefined ? undefined : stringField(info.sessionID);
    const parentId = info === undefined ? undefined : stringField(info.parentID);
    if (assistantId === undefined || boundSession === undefined || parentId === undefined)
        return undefined;
    if (boundSession !== sessionId || parentId !== validatedMessageId)
        return undefined;
    return { messageId: assistantId, sessionId: boundSession, parentId };
}
/**
 * Maps the real 1.18.23 `Session` envelope; never synthesizes a default title or id.
 * `agentId` comes from the validated Teams target, never from the SDK.
 */
export async function createOpenCodeSession(client, agentId, title) {
    if (typeof agentId !== 'string' || agentId.trim() === '') {
        throw new OpenCodeAdapterError('session.create', 'INVALID_INPUT', 'OpenCode session create requires a target agent id');
    }
    if (title !== undefined && (typeof title !== 'string' || title.trim() === '')) {
        throw new OpenCodeAdapterError('session.create', 'INVALID_INPUT', 'OpenCode session title must be a non-empty string when provided');
    }
    const result = await client.session.create(title === undefined ? {} : { body: { title } });
    const session = unwrapOpenCodeResponse(result, 'session.create');
    if (session === undefined || typeof session.id !== 'string' || session.id.length === 0) {
        throw new OpenCodeAdapterError('session.create', 'INVALID_RESPONSE', 'OpenCode session.create returned no session id');
    }
    return {
        kind: 'session.create',
        agentId,
        sessionId: session.id,
        ...(session.title === undefined ? {} : { title: session.title }),
        ...(session.directory === undefined ? {} : { directory: session.directory }),
        ...(session.time === undefined ? {} : { time: session.time }),
    };
}
/** 1.18.23 `session.abort` base acceptance; absent stays absent and is never proof the cancel completed. */
export async function cancelOpenCodeSession(client, sessionId) {
    const result = await client.session.abort({ path: { id: sessionId } });
    return unwrapOpenCodeResponse(result, 'session.abort', true);
}
/**
 * Binds the real `@opencode-ai/sdk` client to one owner-scoped managed handle.
 * The runtime consumes only the adapter; nothing else imports the SDK transport.
 */
export function createOpenCodeSessionClient(handle) {
    if (typeof handle.url !== 'string' || handle.url.length === 0 || typeof handle.authorization !== 'string') {
        throw new OpenCodeAdapterError('client.create', 'INVALID_INPUT', 'OpenCode client requires a managed url and authorization');
    }
    return createOpencodeClient({ baseUrl: handle.url, headers: { authorization: handle.authorization } });
}
/**
 * Sole Session message decoder: converts a supported business payload into the
 * SDK prompt input shape. It rejects lossy/extra shapes before any side effect.
 */
export function decodeOpenCodeSessionMessage(payload) {
    if (typeof payload !== 'object' || payload === null || Array.isArray(payload)) {
        throw new OpenCodeAdapterError('session.prompt', 'INVALID_INPUT', 'OpenCode session message payload must be a { text } object');
    }
    // A shape this adapter cannot map fails here as the typed refusal the Session contract
    // promises. A bare envelope error would escape the adapter error contract instead.
    try {
        assertEnvelopeKeys(payload, ['text'], 'OpenCode session message payload');
    }
    catch (error) {
        throw new OpenCodeAdapterError('session.prompt', 'UNSUPPORTED_OPERATION', error instanceof Error ? error.message : 'OpenCode session message payload has an unsupported shape');
    }
    const text = payload.text;
    if (typeof text !== 'string' || text.length === 0) {
        throw new OpenCodeAdapterError('session.prompt', 'INVALID_INPUT', 'OpenCode session message requires a non-empty text string');
    }
    return { text };
}
/**
 * Thin wrapper over the real `client.event.subscribe`. It establishes no second
 * connection, performs no retry, buffers nothing, and holds no lifecycle state;
 * it only forwards the SDK stream to the caller and honors the abort signal.
 */
export async function* subscribeOpenCodeEvents(client, signal) {
    // The SDK owns the SSE retry loop and only observes an abort signal it is given, so the
    // caller's signal is forwarded. Without it the loop retries forever and never closes.
    const subscription = unwrapOpenCodeResponse(await client.event.subscribe({ signal }), 'event.subscribe');
    if (subscription === undefined)
        throw new OpenCodeAdapterError('event.subscribe', 'INVALID_RESPONSE', 'OpenCode event.subscribe returned no stream');
    if (typeof subscription.stream?.[Symbol.asyncIterator] !== 'function') {
        throw new OpenCodeAdapterError('event.subscribe', 'INVALID_RESPONSE', 'OpenCode event.subscribe returned no event stream');
    }
    const iterator = subscription.stream[Symbol.asyncIterator]();
    const aborted = new Promise(resolve => {
        if (signal.aborted)
            resolve({ kind: 'abort' });
        else
            signal.addEventListener('abort', () => resolve({ kind: 'abort' }), { once: true });
    });
    try {
        while (true) {
            if (signal.aborted)
                return;
            const outcome = await Promise.race([
                iterator.next().then(value => ({ kind: 'next', value })),
                aborted,
            ]);
            if (outcome.kind === 'abort')
                return;
            if (outcome.value.done === true)
                return;
            yield outcome.value.value;
        }
    }
    finally {
        // Closing the SDK generator resumes only after its pending retry sleep settles, so an
        // aborted caller must not wait for it: the SDK loop already stops on the same signal.
        const returned = iterator.return?.(undefined);
        if (returned !== undefined)
            await Promise.race([returned.then(() => undefined, () => undefined), aborted]);
    }
}
function asRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value) ? value : undefined;
}
function stringField(value) {
    return typeof value === 'string' && value.length > 0 ? value : undefined;
}
function structuredError(value) {
    const error = asRecord(value);
    if (error === undefined)
        return undefined;
    const name = error.name;
    if (name !== 'ProviderAuthError' && name !== 'UnknownError' && name !== 'MessageOutputLengthError' && name !== 'MessageAbortedError' && name !== 'APIError')
        return undefined;
    if (error.data === undefined)
        return undefined;
    try {
        assertJsonValue(error.data, 'OpenCode structured error data');
    }
    catch {
        return undefined;
    }
    return { name, data: error.data };
}
const OBSERVED_PART_TAGS = {
    file: 'file', 'step-start': 'step-start', 'step-finish': 'step-finish', snapshot: 'snapshot',
    patch: 'patch', agent: 'agent', retry: 'retry', compaction: 'compaction', subtask: 'subtask',
};
/**
 * Members of the installed SDK `Event` union that carry no Session projection
 * outcome. They are recognized and deliberately ignored: a healthy child emits
 * these routinely, so they are not loss and must not degrade observation.
 */
const IGNORED_EVENT_TAGS = [
    'server.connected', 'server.instance.disposed',
    'installation.updated', 'installation.update-available',
    'lsp.client.diagnostics', 'lsp.updated',
    'message.removed', 'message.part.removed',
    'session.status', 'session.idle', 'session.compacted',
    'session.created', 'session.updated', 'session.deleted', 'session.diff',
    'file.edited', 'file.watcher.updated', 'todo.updated', 'command.executed',
    'vcs.branch.updated', 'tui.prompt.append', 'tui.command.execute', 'tui.toast.show',
    'pty.created', 'pty.updated', 'pty.exited', 'pty.deleted',
];
function eventBase(type, sessionId, messageId) {
    return { eventId: `${type}:${sessionId}:${messageId ?? ''}`, sessionId };
}
/**
 * The sole SDK-shape classifier. Pure: it holds no state, decides nothing about
 * stream lifetime or observation status, and returns exactly one typed event,
 * `unsupported`, or `invalid` for one raw SDK event/part.
 */
export function projectOpenCodeSessionEvent(raw) {
    const event = asRecord(raw);
    const rawJson = (asRecord(raw) ?? {});
    if (event === undefined || typeof event.type !== 'string')
        return { kind: 'invalid', reason: 'event is not a typed OpenCode event', raw: rawJson };
    const properties = asRecord(event.properties);
    const type = event.type;
    if (type === 'message.part.updated') {
        if (properties === undefined)
            return { kind: 'invalid', reason: 'part event is missing properties', raw: rawJson };
        return classifyPart(type, properties, rawJson);
    }
    if (type === 'message.updated') {
        if (properties === undefined)
            return { kind: 'invalid', reason: 'message event is missing properties', raw: rawJson };
        return classifyMessage(type, properties, rawJson);
    }
    if (type === 'session.error') {
        const sessionId = stringField(properties?.sessionID);
        const error = structuredError(properties?.error);
        if (sessionId === undefined || error === undefined)
            return { kind: 'invalid', reason: 'session.error is missing session identity or structured error', raw: rawJson };
        const messageId = stringField(properties?.messageID);
        return { kind: 'event', event: { eventId: `${type}:${sessionId}`, agentId: '', sessionId, kind: 'error', state: 'failed', error,
                correlation: messageId === undefined ? { kind: 'session', sessionId } : { kind: 'message', messageId } } };
    }
    if (type === 'permission.asked') {
        // Substrate shape: { id, sessionID, permission, patterns, always, metadata, tool?: { messageID, callID } }.
        // The message identity lives under `tool` and the permission name is the only title the substrate owns.
        const sessionId = stringField(properties?.sessionID);
        const permissionId = stringField(properties?.id);
        const tool = asRecord(properties?.tool);
        const messageId = stringField(tool?.messageID);
        const title = stringField(properties?.permission);
        const metadata = properties?.metadata;
        if (sessionId === undefined || permissionId === undefined || messageId === undefined || title === undefined || metadata === undefined) {
            return { kind: 'invalid', reason: 'permission.asked is missing id, sessionID, tool.messageID, permission, or metadata', raw: rawJson };
        }
        try {
            assertJsonValue(metadata, 'permission metadata');
        }
        catch {
            return { kind: 'invalid', reason: 'permission metadata is not JSON', raw: rawJson };
        }
        const callId = stringField(tool?.callID);
        return { kind: 'event', event: { ...eventBase(type, sessionId), agentId: '', kind: 'permission', state: 'pending', permissionId, messageId,
                ...(callId === undefined ? {} : { callId }), title, metadata: metadata } };
    }
    if (type === 'permission.replied') {
        // Substrate shape: { sessionID, requestID, reply }.
        const sessionId = stringField(properties?.sessionID);
        const permissionId = stringField(properties?.requestID);
        const reply = properties?.reply;
        if (sessionId === undefined || permissionId === undefined || typeof reply !== 'string') {
            return { kind: 'invalid', reason: 'permission.replied is missing sessionID, requestID, or string reply', raw: rawJson };
        }
        const decision = reply === 'once' || reply === 'always' || reply === 'reject' ? reply : 'unknown';
        return { kind: 'event', event: { ...eventBase(type, sessionId), agentId: '', kind: 'permission', state: 'resolved', permissionId, decision, ...(decision === 'unknown' ? { rawResponse: reply } : {}) } };
    }
    // A recognized SDK event with no Session projection outcome is intentionally ignored,
    // never counted as projection loss. Only genuinely unknown tags fail below.
    if (IGNORED_EVENT_TAGS.includes(type))
        return { kind: 'ignored', reason: `recognized non-outcome OpenCode event ${type}`, raw: rawJson };
    return { kind: 'unsupported', reason: `unsupported OpenCode event ${type}`, raw: rawJson };
}
function classifyMessage(type, properties, raw) {
    const info = asRecord(properties.info);
    const messageId = stringField(info?.id);
    const role = info?.role;
    const sessionId = stringField(info?.sessionID) ?? stringField(properties.sessionID);
    if (messageId === undefined || sessionId === undefined || (role !== 'user' && role !== 'assistant'))
        return { kind: 'invalid', reason: 'message.updated is missing a user/assistant message id', raw };
    const messageRole = role === 'assistant' ? 'assistant' : 'user';
    const base = eventBase(type, sessionId, messageId);
    const parentMessageId = stringField(info?.parentID);
    if (info?.error !== undefined) {
        const error = structuredError(info.error);
        if (error === undefined)
            return { kind: 'invalid', reason: 'message.updated error is not a structured OpenCode error', raw };
        const event = messageRole === 'assistant'
            ? { ...base, agentId: '', kind: 'final', state: 'failed', messageId, error }
            : { ...base, agentId: '', kind: 'message', state: 'failed', messageId, role: messageRole, error };
        return { kind: 'event', event, ...(parentMessageId === undefined ? {} : { parentMessageId }) };
    }
    const completed = asRecord(info?.time)?.completed;
    if (messageRole === 'assistant' && completed !== undefined) {
        const finish = stringField(info?.finish);
        const event = { ...base, agentId: '', kind: 'final', state: 'completed', messageId, ...(finish === undefined ? {} : { finish }) };
        return { kind: 'event', event, ...(parentMessageId === undefined ? {} : { parentMessageId }) };
    }
    const event = { ...base, agentId: '', kind: 'message', state: completed === undefined ? 'pending' : 'completed', messageId, role: messageRole };
    return { kind: 'event', event, ...(parentMessageId === undefined ? {} : { parentMessageId }) };
}
function classifyPart(type, properties, raw) {
    const part = asRecord(properties.part) ?? asRecord(properties);
    if (part === undefined)
        return { kind: 'invalid', reason: 'part event has no part object', raw };
    const partType = stringField(part.type);
    const messageId = stringField(part.messageID);
    const partId = stringField(part.id);
    const sessionId = stringField(part.sessionID);
    if (partType === undefined || messageId === undefined || partId === undefined || sessionId === undefined)
        return { kind: 'invalid', reason: 'part event is missing type, id, messageID, or sessionID', raw };
    const base = eventBase(type, sessionId, messageId);
    const rawPart = part;
    if (partType === 'text' || partType === 'reasoning') {
        if (typeof part.text !== 'string')
            return { kind: 'invalid', reason: `${partType} part is missing text`, raw };
        // The installed SDK types `time` as `{ start, end? }`, so a streaming part that only
        // carries `start` is still pending; only a present `end` proves completion.
        const time = asRecord(part.time);
        const completed = time !== undefined && time.end !== undefined;
        return { kind: 'event', event: { ...base, agentId: '', kind: 'part', state: completed ? 'completed' : 'pending', messageId, partId, partType, text: part.text } };
    }
    if (partType === 'tool') {
        const state = asRecord(part.state);
        const tool = stringField(part.tool);
        const callId = stringField(part.callID);
        if (state === undefined || tool === undefined || callId === undefined)
            return { kind: 'invalid', reason: 'tool part is missing state, tool, or callID', raw };
        // A malformed tool part must fail here, at the adapter boundary, not later in the Console wire parser.
        let input;
        let metadata;
        let attachments;
        try {
            input = state.input;
            assertJsonValue(input, 'tool part input');
            if (state.metadata !== undefined) {
                metadata = state.metadata;
                assertJsonValue(metadata, 'tool part metadata');
            }
            if (state.attachments !== undefined) {
                if (!Array.isArray(state.attachments))
                    throw new Error('tool part attachments must be a JSON array');
                attachments = state.attachments;
                assertJsonValue(attachments, 'tool part attachments');
            }
        }
        catch (cause) {
            return { kind: 'invalid', reason: cause instanceof Error ? cause.message : 'tool part carries a non-JSON value', raw };
        }
        const common = { ...base, agentId: '', kind: 'tool', messageId, partId, callId, tool };
        // The Console wire contract requires a non-empty `title` whenever a tool event carries one,
        // and a completed tool always carries one (`text(event.title)`). Coercing an absent or empty
        // substrate title to `''` here would emit a shape the closed Console parser rejects, and one
        // rejected event fails the whole projection reply instead of degrading this single event.
        // The installed SDK types the remaining per-state fields as required too (`raw` for pending,
        // `metadata` for completed, `error` for error), so a missing one is a malformed shape that must
        // be classified invalid here rather than normalized into a wire-valid event with an empty value.
        switch (state.status) {
            case 'pending': {
                if (typeof state.raw !== 'string')
                    return { kind: 'invalid', reason: 'pending tool part is missing a string raw', raw };
                return { kind: 'event', event: { ...common, state: 'pending', input, raw: state.raw } };
            }
            case 'running': {
                if (state.title !== undefined && (typeof state.title !== 'string' || state.title === '')) {
                    return { kind: 'invalid', reason: 'running tool part carries an empty or non-string title', raw };
                }
                return { kind: 'event', event: { ...common, state: 'running', input, ...(state.title === undefined ? {} : { title: state.title }), ...(metadata === undefined ? {} : { metadata }) } };
            }
            case 'completed': {
                if (typeof state.title !== 'string' || state.title === '')
                    return { kind: 'invalid', reason: 'completed tool part is missing a non-empty title', raw };
                if (typeof state.output !== 'string')
                    return { kind: 'invalid', reason: 'completed tool part is missing a string output', raw };
                if (metadata === undefined)
                    return { kind: 'invalid', reason: 'completed tool part is missing metadata', raw };
                return { kind: 'event', event: { ...common, state: 'completed', input, output: state.output, title: state.title, metadata, ...(attachments === undefined ? {} : { attachments }) } };
            }
            case 'error': {
                if (typeof state.error !== 'string')
                    return { kind: 'invalid', reason: 'error tool part is missing a string error', raw };
                return { kind: 'event', event: { ...common, state: 'error', input, error: state.error, ...(metadata === undefined ? {} : { metadata }) } };
            }
            default: return { kind: 'invalid', reason: `tool part has an unknown state ${String(state.status)}`, raw };
        }
    }
    const observed = OBSERVED_PART_TAGS[partType];
    if (observed === undefined)
        return { kind: 'unsupported', reason: `unsupported part type ${partType}`, raw };
    return { kind: 'event', event: { ...base, agentId: '', kind: 'part', state: 'observed', messageId, partId, partType: observed, sourcePart: rawPart } };
}
/**
 * Converts the real `session.messages` response into the same closed event
 * projection used by the SSE ingress. The SDK shape classification stays in
 * this adapter, and a malformed entry is reported as `invalid` rather than
 * being silently dropped.
 */
export function projectOpenCodeSessionMessages(raw) {
    if (!Array.isArray(raw))
        return [{ kind: 'invalid', reason: 'session.messages response is not an array', raw: raw }];
    return raw.flatMap(entry => {
        const record = asRecord(entry);
        if (record === undefined)
            return [{ kind: 'invalid', reason: 'session.messages entry is not an object', raw: entry }];
        const projections = [];
        const info = record.info;
        if (asRecord(info) === undefined)
            projections.push({ kind: 'invalid', reason: 'session.messages entry is missing message info', raw: entry });
        else
            projections.push(classifyMessage('message.updated', { info }, info));
        const parts = record.parts;
        if (!Array.isArray(parts)) {
            projections.push({ kind: 'invalid', reason: 'session.messages entry is missing parts', raw: entry });
            return projections;
        }
        for (const part of parts) {
            if (asRecord(part) === undefined)
                projections.push({ kind: 'invalid', reason: 'session.messages part is not an object', raw: part });
            else
                projections.push(classifyPart('message.part.updated', { part }, part));
        }
        return projections;
    });
}
/**
 * OpenCode brands its permission route parameter as a `per_`-prefixed
 * `PermissionID` and rejects any other shape as a schema violation before it
 * reaches a permission. The Console supplies this value, so the substrate format
 * is enforced here instead of leaking out as an opaque transport failure.
 */
function validatePermissionId(permissionId) {
    if (typeof permissionId !== 'string' || !permissionId.startsWith('per_') || permissionId.length === 4) {
        throw new OpenCodeAdapterError('permission.reply', 'INVALID_INPUT', 'OpenCode permissionID must be a per_-prefixed PermissionID');
    }
    return permissionId;
}
export async function replyOpenCodePermission(client, permissionId, sessionId, response) {
    const result = await client.postSessionIdPermissionsPermissionId({ path: { id: sessionId, permissionID: validatePermissionId(permissionId) }, body: { response } });
    unwrapOpenCodeResponse(result, 'permission.reply', true);
}
function modelEntryFor(config, providerInstanceId, modelId) {
    return config.catalogs[providerInstanceId]?.entries.find(entry => entry.ref.providerInstanceId === providerInstanceId && entry.ref.modelId === modelId);
}
function compileTarget(config, providerInstanceId, modelId) {
    const provider = config.providers[providerInstanceId];
    if (provider === undefined) {
        throw new OpenCodeAdapterError('config.compile', 'NOT_FOUND', `OpenCode provider not found: ${providerInstanceId}`);
    }
    if (!provider.enabled) {
        throw new OpenCodeAdapterError('config.compile', 'UNAVAILABLE', `OpenCode provider is disabled: ${providerInstanceId}`);
    }
    const entry = modelEntryFor(config, providerInstanceId, modelId);
    if (entry === undefined) {
        throw new OpenCodeAdapterError('config.compile', 'NOT_FOUND', `OpenCode model not found: ${providerInstanceId}/${modelId}`);
    }
    if (entry.availability === 'unavailable') {
        throw new OpenCodeAdapterError('config.compile', 'UNAVAILABLE', `OpenCode model is unavailable: ${providerInstanceId}/${modelId}`);
    }
    return {
        provider: provider.id,
        model: entry.ref.modelId,
        protocol: provider.protocol,
        baseUrl: provider.apiBaseUrl,
        ...(provider.auth.kind === 'bearer' ? { credentialRef: provider.auth.credentialRef } : {}),
    };
}
export function compileOpenCodeConfig(config, agentId) {
    if (agentId.trim() === '')
        throw new OpenCodeAdapterError('config.compile', 'INVALID_INPUT', 'OpenCode agent id is required');
    const binding = config.agents[agentId];
    if (binding === undefined)
        throw new OpenCodeAdapterError('config.compile', 'NOT_FOUND', `OpenCode Agent binding not found: ${agentId}`);
    return {
        agentId,
        acceptedRevision: config.acceptedRevision,
        primary: compileTarget(config, binding.primary.providerInstanceId, binding.primary.modelId),
        ...(binding.backup === undefined ? {} : { backup: compileTarget(config, binding.backup.providerInstanceId, binding.backup.modelId) }),
    };
}
export function createOpenCodeConfigApplier() {
    return {
        apply: async (_config) => ({
            status: 'unsupported',
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: 'OpenCode config apply API is unsupported',
            },
        }),
    };
}
export function createOpenCodeHostFacade(client, binding = createOpenCodeNotificationStoreBinding()) {
    let sessions = [];
    const listeners = new Set();
    const notify = () => { for (const listener of listeners)
        listener({ sessions, notifications: binding.get() }); };
    return {
        projection: () => ({ sessions, notifications: binding.get() }),
        teamsProjection: identities => projectOpenCodeTeamsProjection(sessions, binding.get(), identities),
        subscribe: listener => { listeners.add(listener); return () => { listeners.delete(listener); }; },
        refreshSessions: async (directory) => {
            sessions = await listOpenCodeSessions(client, directory);
            notify();
            return sessions;
        },
        actions: {
            openSession: async (sessionId) => { await getOpenCodeSession(client, sessionId); },
            sendMessage: async (sessionId, payload) => { await sendOpenCodeMessage(client, sessionId, decodeOpenCodeSessionMessage(payload).text); },
            replyPermission: async (sessionId, permissionId, response) => { await replyOpenCodePermission(client, permissionId, sessionId, response); },
            acknowledgeNotification: notificationId => {
                binding.acknowledge(notificationId);
                notify();
            },
        },
    };
}
export function projectOpenCodeTeamsProjection(sessions, notifications, identities) {
    const sessionOwner = new Map(identities.flatMap(identity => identity.sessionIds.map(sessionId => [sessionId, identity.agentId])));
    const projectedSessions = sessions.flatMap(session => {
        const agentId = sessionOwner.get(session.id);
        return agentId === undefined ? [] : [{ ...session, agentId, running: true }];
    });
    return { agents: identities, sessions: projectedSessions, notifications };
}
export function projectOpenCodeNotifications(notifications) {
    return sortOpenCodeNotifications([...notifications.pending, ...notifications.processed]).map(notification => ({
        id: notificationIdFor(notification),
        sessionId: notification.sessionId,
        ...(notification.requestId === undefined ? {} : { requestId: notification.requestId }),
        interactive: notification.interactive,
        processed: notification.status === 'processed',
        priority: notification.priority === 'high' ? 'high' : 'medium',
        createdAt: notification.occurredAt,
    }));
}
export async function createOpenCodePluginRuntime(input, binding = createOpenCodeNotificationStoreBinding()) {
    const facade = createOpenCodeHostFacade(input.client, binding);
    await facade.refreshSessions(input.directory);
    const hooks = registerOpenCodeHooks(notification => {
        binding.sink(notification);
        void facade.refreshSessions(input.directory);
    });
    return { facade, hooks };
}
const notificationSinks = new Set();
export function acknowledgeOpenCodeNotification(store, notificationId) {
    const all = [...store.pending, ...store.processed];
    const target = all.find(item => notificationIdFor(item) === notificationId);
    if (target === undefined)
        throw new Error(`OpenCode notification not found: ${notificationId}`);
    return {
        pending: store.pending.filter(item => notificationIdFor(item) !== notificationId),
        processed: [...store.processed, { ...target, status: 'processed' }],
    };
}
export function createOpenCodeNotificationStoreBinding(initial = { pending: [], processed: [] }) {
    let store = initial;
    return {
        get: () => store,
        sink: notification => {
            if (notification.status === 'processed') {
                const id = notificationIdFor(notification);
                store = {
                    pending: store.pending.filter(item => notificationIdFor(item) !== id),
                    processed: [...store.processed, notification],
                };
                return;
            }
            store = { pending: sortOpenCodeNotifications([...store.pending, notification]), processed: store.processed };
        },
        acknowledge: notificationId => { store = acknowledgeOpenCodeNotification(store, notificationId); },
    };
}
export function sortOpenCodeNotifications(notifications) {
    return [...notifications].sort((left, right) => {
        const priority = Number(right.priority === 'high') - Number(left.priority === 'high');
        return priority || right.occurredAt.localeCompare(left.occurredAt);
    });
}
function notificationIdFor(notification) {
    return `${notification.kind}:${notification.sessionId}:${notification.requestId ?? notification.occurredAt}`;
}
export function subscribeOpenCodeNotifications(sink) {
    notificationSinks.add(sink);
    return () => { notificationSinks.delete(sink); };
}
function sessionIdFromEvent(event) {
    const properties = event.properties;
    if (typeof properties?.sessionID === 'string')
        return properties.sessionID;
    if (typeof properties?.info !== 'object' || properties.info === null)
        return undefined;
    const info = properties.info;
    if (typeof info.sessionID === 'string')
        return info.sessionID;
    return typeof info.id === 'string' ? info.id : undefined;
}
function permissionIdFromEvent(event) {
    const properties = event.properties;
    if (typeof properties?.permissionID === 'string')
        return properties.permissionID;
    if (typeof properties?.id === 'string')
        return properties.id;
    return undefined;
}
export function projectOpenCodeEvent(event) {
    const properties = event.properties;
    const sessionId = sessionIdFromEvent(event);
    if (sessionId === undefined)
        return undefined;
    switch (event.type) {
        case 'session.created':
            return notification('session-created', sessionId, false);
        case 'session.updated':
            return notification('session-updated', sessionId, false);
        case 'session.deleted':
            return notification('session-deleted', sessionId, false);
        case 'session.status':
            return notification('session-status', sessionId, false);
        case 'message.updated':
            return notification('message-updated', sessionId, false);
        case 'permission.updated': {
            const requestId = permissionIdFromEvent(event);
            if (requestId === undefined)
                return undefined;
            return { ...notification('permission-request', sessionId, true), requestId };
        }
        case 'permission.replied': {
            const requestId = permissionIdFromEvent(event);
            if (requestId === undefined)
                return undefined;
            return { ...notification('permission-processed', sessionId, true, 'processed'), requestId };
        }
        default:
            return undefined;
    }
}
function notification(kind, sessionId, interactive, status = 'pending') {
    return { source: 'opencode', kind, sessionId, interactive, status, priority: interactive ? 'high' : 'normal', occurredAt: new Date().toISOString() };
}
export function projectOpenCodePermission(permission) {
    return {
        source: 'opencode',
        kind: 'permission-request',
        sessionId: permission.sessionID,
        requestId: permission.id,
        interactive: true,
        status: 'pending',
        priority: 'high',
        occurredAt: new Date().toISOString(),
    };
}
export function registerOpenCodeHooks(sink) {
    return {
        event: async ({ event }) => {
            const notification = projectOpenCodeEvent(event);
            if (notification !== undefined)
                sink(notification);
        },
        'permission.ask': async (permission) => {
            sink(projectOpenCodePermission(permission));
        },
    };
}
export function createTeamsOpenCodePlugin(sink) {
    return async () => registerOpenCodeHooks(sink);
}
export const TeamsOpenCodePluginWithNotifications = async (input) => {
    const binding = createOpenCodeNotificationStoreBinding();
    const hooks = registerOpenCodeHooks(notification => {
        binding.sink(notification);
        for (const sink of notificationSinks)
            sink(notification);
    });
    void input;
    return {
        ...hooks,
        event: async (eventInput) => {
            await hooks.event?.(eventInput);
        },
        'permission.ask': async (permission, output) => {
            await hooks['permission.ask']?.(permission, output);
        },
    };
};
export const TeamsOpenCodePlugin = TeamsOpenCodePluginWithNotifications;
/**
 * ACP engine adapter for the installed OpenCode ACP server. Declared here as
 * the package entry point; the implementation owns no second Session path and
 * reuses `compileOpenCodeConfig`/`createOpenCodeLaunchConfig` from this module.
 */
export { openCodeAcpAdapter, assertOpenCodeNativePolicy } from "./acp-engine.js";
export default {
    id: 'teams-opencode-adapter',
    server: TeamsOpenCodePlugin,
};
