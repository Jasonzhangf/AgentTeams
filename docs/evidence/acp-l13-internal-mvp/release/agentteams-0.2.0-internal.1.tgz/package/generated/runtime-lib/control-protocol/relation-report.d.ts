export type RelationReportRole = 'consumer' | 'provider';
export type RelationState = 'discovered' | 'requested' | 'allowed' | 'denied' | 'using' | 'stopped' | 'revoked' | 'expired';
export interface RelationReport {
    readonly relationId: string;
    readonly reporterAgentId: string;
    readonly subjectAgentId: string;
    readonly capabilityId: string;
    readonly role: RelationReportRole;
    readonly state: RelationState;
    readonly reportRevision: number;
    readonly reportedAt: string;
}
export declare function validateRelationReport(value: unknown): RelationReport;
