import type { ServiceErrorCode } from '../control-protocol/agent-services.ts';
import { RelayProtocolError } from '../control-protocol/relay-codec.ts';
import { type RoutePlan } from './route-plan.ts';
import { type TargetTransportHello, type TargetTransportState } from './target-transport.ts';
import { type WssConnection, type WssConnectionOptions } from './wss-connection.ts';
export declare class DirectWssRouteError extends RelayProtocolError {
    readonly plan: RoutePlan;
    constructor(code: ServiceErrorCode, message: string, plan: RoutePlan);
}
export interface DirectWssTargetOptions {
    readonly transport: WssConnectionOptions;
    readonly hello: TargetTransportHello;
    readonly plan: RoutePlan;
    readonly helloTimeoutMs: number;
}
export interface DirectWssTarget {
    readonly connection: WssConnection;
    readonly plan: RoutePlan;
    readonly state: TargetTransportState;
    readonly closed: Promise<Error>;
    assertGeneration(generation: number): void;
    close(reason?: string): Promise<void>;
    reconnect(): Promise<DirectWssTarget>;
}
export declare function connectDirectWssTarget(input: DirectWssTargetOptions): Promise<DirectWssTarget>;
