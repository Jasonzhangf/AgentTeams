import { type ConsoleWireReply, type ConsoleWireRequest } from '../control-protocol/console-wire.ts';
import type { WssConnection } from './wss-connection.ts';
/** One management request per granted connection; no retry queue or Work execution ownership. */
export declare function requestConsole(socket: WssConnection, input: ConsoleWireRequest, timeoutMs: number): Promise<ConsoleWireReply>;
/** Socket loss/deadline ends transport only; the owning handler continues its execution. */
export declare function serveConsole(socket: WssConnection, handler: (request: ConsoleWireRequest) => Promise<ConsoleWireReply>, timeoutMs: number): Promise<void>;
