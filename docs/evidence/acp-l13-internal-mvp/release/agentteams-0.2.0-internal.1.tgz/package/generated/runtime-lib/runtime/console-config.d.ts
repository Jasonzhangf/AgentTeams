import { type CredentialResolver, type ProviderModelClient, type RuntimeConfigApplier, type RuntimeConfigStore } from '../config/runtime-config.ts';
import { type ConsoleCommandV1, type ConsoleCommandResultV1, type ConsoleProjectionV1 } from '../control-protocol/console-api.ts';
type ConfigCommand = Extract<ConsoleCommandV1, {
    kind: `config.${string}`;
}>;
/** Daemon assembly port. Caller authenticates the principal; config remains the durable owner. */
export declare function createConsoleConfigBinding(options: {
    readonly agentId: string;
    readonly store: RuntimeConfigStore;
    readonly models: ProviderModelClient;
    readonly credentials?: CredentialResolver;
    readonly applier: RuntimeConfigApplier;
}): {
    readProjection: () => Promise<ConsoleProjectionV1["configs"][number]>;
    command: (input: ConfigCommand) => Promise<ConsoleCommandResultV1>;
};
export {};
