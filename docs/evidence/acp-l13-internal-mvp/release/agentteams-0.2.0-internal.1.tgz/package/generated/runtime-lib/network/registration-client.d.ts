import type { AgentDeclaration, RelayPeer, ServiceError } from '../control-protocol/agent-services.ts';
import { type RelayDirectorySnapshot } from './relay-client.ts';
/**
 * Network owns the registration client transport and its health. It consumes an
 * explicit WSS endpoint plus credential; the config-selected endpoint is chosen
 * by `runtime/registry-registration.ts`.
 *
 * Vocabulary: the relay boundary keeps `RelayPeer.presence` as `online|offline`.
 * This client reports its own health as `RegistrationClientState`; it never
 * renames peer presence and never adds a third presence value. The single
 * presence -> `HostHealthState` bridge stays in `network/account-directory.ts`.
 *
 * Policy: a disconnect or a failed heartbeat is a typed state plus an explicit
 * bounded reconnect with backoff on the same configured endpoint. The client
 * never switches servers and never throws out of a timer, so a registry outage
 * cannot terminate the engine that hosts it.
 */
/**
 * Client health vocabulary. `disabled` is produced only by the runtime config
 * selector (`runtime/registry-registration.ts`) when a config declares no
 * `[discovery]` server; this client itself never enters it.
 */
export type RegistrationClientState = 'disabled' | 'connecting' | 'online' | 'reconnecting' | 'failed' | 'stopped';
export interface RegistrationStatus {
    readonly state: RegistrationClientState;
    /** The configured endpoint; absent only for the `disabled` plan. Never silently changed. */
    readonly endpoint?: string;
    readonly generation?: number;
    /** Consecutive failed attempts since the last successful connection. */
    readonly attempts: number;
    /** Successful connections after the first one. */
    readonly reconnects: number;
    /** Most recent failure, retained after recovery so the original error stays visible. */
    readonly lastError?: ServiceError;
    readonly lastSeenAt?: string;
    readonly nextAttemptAt?: string;
}
export interface RegistrationReconnectPolicy {
    readonly initialDelayMs: number;
    readonly maxDelayMs: number;
    /** Connect attempts allowed per outage, including the first one. */
    readonly maxAttempts: number;
}
export interface RegistrationClientOptions {
    readonly declaration: AgentDeclaration;
    readonly endpoint: string;
    readonly credential: string;
    readonly ca?: string | Buffer;
    readonly heartbeatIntervalMs: number;
    readonly admissionTimeoutMs: number;
    readonly requestTimeoutMs: number;
    readonly maxPendingRequests: number;
    readonly maxDataConnections: number;
    readonly connectTimeoutMs: number;
    readonly maxMessageBytes: number;
    readonly maxBufferedBytes: number;
    readonly maxPendingFrames: number;
    readonly reconnect: RegistrationReconnectPolicy;
    readonly onStatus?: (status: RegistrationStatus) => void;
    readonly now?: () => Date;
}
export interface RegistrationClient {
    /** Resolves on a terminal state (`failed` or `stopped`); never rejects. */
    readonly closed: Promise<RegistrationStatus>;
    status(): RegistrationStatus;
    /** Runs the first attempt and returns the resulting status; retries continue in the background. */
    start(): Promise<RegistrationStatus>;
    directory(subscribe: boolean): Promise<readonly RelayPeer[]>;
    /**
     * The same real scoped directory read, carrying the server's directory revision.
     * The account-directory projection needs the revision to confirm a route
     * generation, so this is the one seam the D06 control daemon consumes.
     */
    directorySnapshot(subscribe: boolean): Promise<RelayDirectorySnapshot>;
    /**
     * R4: publishes an advanced declaration (the daemon's real listener route plus
     * its accepted ACP capability) over the same registration connection. It
     * requires the online state, never switches servers, and refuses a declaration
     * that does not preserve identity/scope or advance the revision.
     */
    publish(declaration: AgentDeclaration): Promise<void>;
    stop(): Promise<void>;
}
export declare function createRegistrationClient(options: RegistrationClientOptions): RegistrationClient;
