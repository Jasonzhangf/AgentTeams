export const ENDPOINT_KINDS = ['browser', 'shell', 'filesystem', 'llm', 'device', 'service'];
export const ENDPOINT_LIFECYCLES = ['active', 'draining', 'disabled'];
