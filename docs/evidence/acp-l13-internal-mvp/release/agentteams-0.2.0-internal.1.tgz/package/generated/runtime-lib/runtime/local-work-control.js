import { once as onceEvent } from 'node:events';
import { chmod, lstat, mkdir, stat } from 'node:fs/promises';
import { createServer, createConnection } from 'node:net';
import { dirname } from 'node:path';
import { assertEnvelopeKeys, assertJsonValue } from "../control-protocol/json-value.js";
export class LocalWorkControlError extends Error {
    code;
    constructor(code, message, options) {
        super(message, options);
        this.code = code;
        this.name = 'LocalWorkControlError';
    }
}
/**
 * The binding a persistent Work frame already fixed. A failed or unconfirmed
 * receipt must carry it, so the caller can query or close the Work with the
 * original identity instead of rebuilding it from config or logs.
 */
export function localWorkFrameBinding(frame) {
    if (frame.kind === 'work.submit')
        return {};
    if (frame.kind === 'work.query') {
        if (frame.control.serviceSelection !== 'capability')
            return { serviceSelection: 'endpoint' };
        const control = frame.control;
        return {
            providerAgentId: control.targetAgentId,
            targetGeneration: control.targetGeneration,
            ...(control.linkGeneration === undefined ? {} : { linkGeneration: control.linkGeneration }),
            serviceSelection: 'capability',
            capabilityId: control.capabilityId,
            capabilityVersion: control.capabilityVersion,
            operation: control.operation,
        };
    }
    const control = frame.control;
    return {
        providerAgentId: control.targetAgentId,
        targetGeneration: control.targetGeneration,
        capabilityId: control.capabilityId,
        capabilityVersion: control.capabilityVersion,
        operation: control.operation,
    };
}
/**
 * The single owner of the failed or unconfirmed Work receipt shape. The CLI
 * pre-dispatch refusal path and the receiver post-dispatch path both build it
 * from the frame they already hold, so the projectId literal, the generated
 * identity and the fixed binding projection cannot diverge between them.
 */
export function failedLocalWorkReceipt(frame, error, deliveryState) {
    return {
        status: 'failed',
        control: {
            projectId: 'agentteams-local-work',
            graphId: '',
            graphVersion: '',
            executionId: frame.control.executionId,
            attemptId: frame.control.attemptId,
            workId: frame.control.workId,
            requestId: frame.control.requestId,
            ...localWorkFrameBinding(frame),
            ...(deliveryState === undefined ? {} : { deliveryState }),
            error,
        },
        cleanup: { channelsOpened: 0, channelsDisposed: 0 },
        evidence: { execution: 'failed', graphId: '', graphVersion: '', nodeSchedule: [], nodeCompletion: [], hostOperations: [] },
    };
}
const REQUEST_KEYS = {
    'work.submit': ['kind', 'requestId', 'control', 'business'],
    'work.query': ['kind', 'requestId', 'control'],
    'work.open': ['kind', 'requestId', 'control', 'business'],
    'work.request': ['kind', 'requestId', 'control', 'business'],
    'work.close': ['kind', 'requestId', 'control'],
};
const CONTROL_KEYS = {
    'work.submit': ['receiverAgentId', 'expectedLauncherGeneration', 'startToken', 'executionId', 'attemptId', 'workId', 'requestId'],
    'work.query': ['serviceSelection', 'receiverAgentId', 'expectedLauncherGeneration', 'startToken', 'executionId', 'attemptId', 'workId', 'requestId', 'targetAgentId', 'targetGeneration', 'capabilityId', 'capabilityVersion', 'operation', 'linkGeneration'],
    'work.open': ['receiverAgentId', 'expectedLauncherGeneration', 'startToken', 'executionId', 'attemptId', 'workId', 'requestId', 'targetAgentId', 'targetGeneration', 'capabilityId', 'capabilityVersion', 'operation', 'demands', 'policyRevision'],
    'work.request': ['receiverAgentId', 'expectedLauncherGeneration', 'startToken', 'executionId', 'attemptId', 'workId', 'requestId', 'targetAgentId', 'targetGeneration', 'capabilityId', 'capabilityVersion', 'operation', 'demands'],
    'work.close': ['receiverAgentId', 'expectedLauncherGeneration', 'startToken', 'executionId', 'attemptId', 'workId', 'requestId', 'targetAgentId', 'targetGeneration', 'capabilityId', 'capabilityVersion', 'operation'],
};
const QUERY_ENDPOINT_CONTROL_KEYS = ['serviceSelection', 'receiverAgentId', 'expectedLauncherGeneration', 'startToken', 'executionId', 'attemptId', 'workId', 'requestId'];
const QUERY_CAPABILITY_CONTROL_KEYS = [...QUERY_ENDPOINT_CONTROL_KEYS, 'targetAgentId', 'targetGeneration', 'capabilityId', 'capabilityVersion', 'operation', 'linkGeneration'];
export function encodeLocalWorkControlFrame(frame) {
    return `${JSON.stringify(frame)}\n`;
}
function protocol(message) {
    return new LocalWorkControlError('HOST_PROTOCOL', message);
}
function assertControlEnvelopeKeys(value, allowed, path) {
    try {
        assertEnvelopeKeys(value, allowed, path);
    }
    catch (cause) {
        throw protocol(cause instanceof Error ? cause.message : `${path} has invalid fields`);
    }
}
function plainObject(value, label) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        throw protocol(`${label} must be an object`);
    return value;
}
function requiredRecord(value, label) {
    if (value === undefined)
        throw protocol(`${label} is required`);
    return plainObject(value, label);
}
function requiredString(value, label) {
    if (typeof value !== 'string' || value.length === 0)
        throw protocol(`${label} must be a non-empty string`);
    return value;
}
function requiredInteger(value, label) {
    if (typeof value !== 'number' || !Number.isSafeInteger(value))
        throw protocol(`${label} must be a safe integer`);
    return value;
}
function optionalInteger(value, label) {
    return value === undefined ? undefined : requiredInteger(value, label);
}
function baseControl(value, kind) {
    const control = requiredRecord(value, 'control');
    assertEnvelopeKeys(control, CONTROL_KEYS[kind], 'control');
    return {
        receiverAgentId: requiredString(control.receiverAgentId, 'control.receiverAgentId'),
        expectedLauncherGeneration: requiredInteger(control.expectedLauncherGeneration, 'control.expectedLauncherGeneration'),
        startToken: requiredString(control.startToken, 'control.startToken'),
        executionId: requiredString(control.executionId, 'control.executionId'),
        attemptId: requiredString(control.attemptId, 'control.attemptId'),
        workId: requiredString(control.workId, 'control.workId'),
        requestId: requiredString(control.requestId, 'control.requestId'),
    };
}
function durableBinding(control, kind) {
    return {
        targetAgentId: requiredString(control.targetAgentId, 'control.targetAgentId'),
        targetGeneration: requiredInteger(control.targetGeneration, 'control.targetGeneration'),
        capabilityId: requiredString(control.capabilityId, 'control.capabilityId'),
        capabilityVersion: requiredString(control.capabilityVersion, 'control.capabilityVersion'),
        operation: requiredString(control.operation, 'control.operation'),
    };
}
function demands(value, label) {
    if (!Array.isArray(value))
        throw protocol(`${label} must be an array`);
    return value.map((item, index) => {
        const demand = requiredRecord(item, `${label}[${index}]`);
        assertEnvelopeKeys(demand, ['resourceId', 'amount'], `${label}[${index}]`);
        const amount = requiredInteger(demand.amount, `${label}[${index}].amount`);
        if (amount < 1)
            throw protocol(`${label}[${index}].amount must be positive`);
        return {
            resourceId: requiredString(demand.resourceId, `${label}[${index}].resourceId`),
            amount,
        };
    });
}
export function decodeLocalWorkControlRequest(value) {
    const frame = plainObject(value, 'request');
    const kind = frame.kind;
    if (typeof kind !== 'string' || !Object.hasOwn(REQUEST_KEYS, kind))
        throw protocol(`request.kind must be one of ${Object.keys(REQUEST_KEYS).join(', ')}`);
    const typedKind = kind;
    assertEnvelopeKeys(frame, REQUEST_KEYS[typedKind], 'request');
    const correlation = requiredString(frame.requestId, 'requestId');
    const frameControl = requiredRecord(frame.control, 'control');
    const base = baseControl(frameControl, typedKind);
    const withBusiness = typedKind === 'work.submit' || typedKind === 'work.open' || typedKind === 'work.request';
    if (typedKind === 'work.query') {
        const selection = frameControl.serviceSelection;
        if (selection === 'endpoint') {
            assertEnvelopeKeys(frameControl, QUERY_ENDPOINT_CONTROL_KEYS, 'control');
            return { kind: typedKind, requestId: correlation, control: { ...base, serviceSelection: 'endpoint' } };
        }
        if (selection === 'capability') {
            assertEnvelopeKeys(frameControl, QUERY_CAPABILITY_CONTROL_KEYS, 'control');
            const linkGeneration = optionalInteger(frameControl.linkGeneration, 'control.linkGeneration');
            return {
                kind: typedKind,
                requestId: correlation,
                control: {
                    ...base,
                    serviceSelection: 'capability',
                    ...durableBinding(frameControl, 'work.query'),
                    ...(linkGeneration === undefined ? {} : { linkGeneration }),
                },
            };
        }
        throw protocol('control.serviceSelection must be endpoint or capability');
    }
    if (typedKind === 'work.open' || typedKind === 'work.request' || typedKind === 'work.close') {
        const result = {
            kind: typedKind,
            requestId: correlation,
            control: { ...base, ...durableBinding(frameControl, typedKind) },
        };
        if (typedKind === 'work.close')
            return result;
        const execution = {
            ...result,
            kind: typedKind,
            control: { ...result.control, demands: demands(frameControl.demands, 'control.demands') },
        };
        if (typedKind === 'work.open') {
            const policyRevision = optionalInteger(frameControl.policyRevision, 'control.policyRevision');
            if (policyRevision !== undefined)
                Object.assign(execution.control, { policyRevision });
        }
        assertJsonValue(frame.business, 'business');
        return { ...execution, business: frame.business };
    }
    if (withBusiness)
        assertJsonValue(frame.business, 'business');
    if (frame.business === undefined)
        throw protocol('business is required');
    assertJsonValue(frame.business, 'business');
    return { kind: 'work.submit', requestId: correlation, control: base, business: frame.business };
}
const CONSOLE_CONTROL_KEYS = ['kind', 'correlationId', 'expectedLauncherGeneration', 'expectedConsoleGeneration'];
const CONSOLE_KINDS = ['console.status', 'console.start', 'console.stop'];
export function decodeLocalConsoleControlRequest(value) {
    const frame = plainObject(value, 'request');
    if (typeof frame.kind !== 'string' || !CONSOLE_KINDS.includes(frame.kind)) {
        throw protocol(`request.kind must be one of ${CONSOLE_KINDS.join(', ')}`);
    }
    assertControlEnvelopeKeys(frame, CONSOLE_CONTROL_KEYS, 'request');
    const expectedConsoleGeneration = optionalInteger(frame.expectedConsoleGeneration, 'expectedConsoleGeneration');
    return {
        kind: frame.kind,
        correlationId: requiredString(frame.correlationId, 'correlationId'),
        expectedLauncherGeneration: requiredInteger(frame.expectedLauncherGeneration, 'expectedLauncherGeneration'),
        ...(expectedConsoleGeneration === undefined ? {} : { expectedConsoleGeneration }),
    };
}
export function decodeLocalControlRequest(value) {
    const frame = plainObject(value, 'request');
    if (typeof frame.kind === 'string' && CONSOLE_KINDS.includes(frame.kind)) {
        return decodeLocalConsoleControlRequest(value);
    }
    return decodeLocalWorkControlRequest(value);
}
function isConsoleControlRequest(frame) {
    return frame.kind === 'console.status' || frame.kind === 'console.start' || frame.kind === 'console.stop';
}
export function decodeLocalWorkControlReply(value, expectedRequestId) {
    const frame = plainObject(value, 'reply');
    const requestId = requiredString(frame.requestId, 'requestId');
    if (requestId !== expectedRequestId)
        throw protocol('reply requestId must match the request correlation');
    const kind = frame.kind;
    if (kind === 'work.result') {
        assertEnvelopeKeys(frame, ['kind', 'requestId', 'receipt'], 'reply');
        assertJsonValue(frame.receipt, 'receipt');
        return { kind, requestId, receipt: frame.receipt };
    }
    if (kind === 'work.error') {
        assertEnvelopeKeys(frame, ['kind', 'requestId', 'error'], 'reply');
        const error = plainObject(frame.error, 'error');
        assertEnvelopeKeys(error, ['code', 'message'], 'error');
        return { kind, requestId, error: { code: requiredString(error.code, 'error.code'), message: requiredString(error.message, 'error.message') } };
    }
    throw protocol('reply.kind must be work.result or work.error');
}
export function decodeLocalConsoleControlReply(value, expectedCorrelationId) {
    const frame = plainObject(value, 'reply');
    if (frame.kind !== 'console.result')
        throw protocol('reply.kind must be console.result');
    const correlationId = requiredString(frame.correlationId, 'correlationId');
    if (correlationId !== expectedCorrelationId)
        throw protocol('reply correlationId must match the request correlation');
    if (frame.ok === true) {
        assertControlEnvelopeKeys(frame, ['kind', 'correlationId', 'ok', 'status'], 'reply');
        const status = plainObject(frame.status, 'status');
        const state = status.state;
        if (state !== 'disabled' && state !== 'stopped' && state !== 'starting' && state !== 'online'
            && state !== 'stopping' && state !== 'failed' && state !== 'retained') {
            throw protocol('status.state is invalid');
        }
        const launcherState = status.launcherState;
        if (launcherState !== 'stopped' && launcherState !== 'starting' && launcherState !== 'running' && launcherState !== 'stopping' && launcherState !== 'failed') {
            throw protocol('status.launcherState is invalid');
        }
        const credential = status.credential;
        if (credential !== 'configured' && credential !== 'missing')
            throw protocol('status.credential is invalid');
        if (typeof status.enabled !== 'boolean')
            throw protocol('status.enabled must be a boolean');
        return {
            kind: 'console.result',
            correlationId,
            ok: true,
            status: {
                enabled: status.enabled,
                state,
                generation: requiredInteger(status.generation, 'status.generation'),
                launcherState,
                launcherGeneration: requiredInteger(status.launcherGeneration, 'status.launcherGeneration'),
                credential,
                ...(status.url === undefined ? {} : { url: requiredString(status.url, 'status.url') }),
                ...(status.origin === undefined ? {} : { origin: requiredString(status.origin, 'status.origin') }),
                ...(status.pid === undefined ? {} : { pid: requiredInteger(status.pid, 'status.pid') }),
                ...(status.identityRef === undefined ? {} : { identityRef: requiredString(status.identityRef, 'status.identityRef') }),
                ...(status.error === undefined ? {} : (() => {
                    const error = plainObject(status.error, 'status.error');
                    assertControlEnvelopeKeys(error, ['code', 'message'], 'status.error');
                    return { error: { code: requiredString(error.code, 'status.error.code'), message: requiredString(error.message, 'status.error.message') } };
                })()),
            },
        };
    }
    if (frame.ok === false) {
        assertControlEnvelopeKeys(frame, ['kind', 'correlationId', 'ok', 'error'], 'reply');
        const error = plainObject(frame.error, 'error');
        assertControlEnvelopeKeys(error, ['code', 'message'], 'error');
        return { kind: 'console.result', correlationId, ok: false, error: { code: requiredString(error.code, 'error.code'), message: requiredString(error.message, 'error.message') } };
    }
    throw protocol('reply.ok must be true or false');
}
async function prepareSocketDirectory(path) {
    const directory = dirname(path);
    try {
        await mkdir(directory, { recursive: true, mode: 0o700 });
        const existing = await stat(directory);
        if (!existing.isDirectory())
            throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'socket parent path is not a directory');
        await chmod(directory, 0o700);
        return;
    }
    catch (cause) {
        if (cause instanceof LocalWorkControlError)
            throw cause;
        throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', `cannot prepare local Work socket directory: ${cause instanceof Error ? cause.message : String(cause)}`, { cause });
    }
}
function disconnected(peer) {
    if (peer.destroyed)
        return Promise.resolve();
    return onceEvent(peer, 'close').then(() => undefined);
}
export async function startLocalWorkControlListener(options) {
    if (!Number.isSafeInteger(options.launcherGeneration) || options.launcherGeneration < 0) {
        throw protocol('launcherGeneration must be a non-negative safe integer');
    }
    if (typeof options.startToken !== 'string' || options.startToken.length === 0) {
        throw protocol('startToken must be a non-empty string');
    }
    await prepareSocketDirectory(options.socketPath);
    try {
        const existing = await lstat(options.socketPath);
        throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', `local Work socket already exists: ${options.socketPath}`, { cause: undefined });
    }
    catch (cause) {
        if (cause instanceof LocalWorkControlError)
            throw cause;
        if (cause.code !== 'ENOENT')
            throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', `local Work socket path cannot be inspected: ${cause instanceof Error ? cause.message : String(cause)}`, { cause });
    }
    const accepted = new Set();
    const idle = new Set();
    let closing = false;
    let dispatchFailure;
    const server = createServer((peer) => {
        if (closing) {
            peer.destroy();
            return;
        }
        idle.add(peer);
        const handling = handleConnection(peer, options, () => {
            if (closing)
                throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'local Work listener is closing');
            idle.delete(peer);
        });
        accepted.add(handling);
        void handling.then(() => { accepted.delete(handling); idle.delete(peer); }, cause => {
            accepted.delete(handling);
            idle.delete(peer);
            dispatchFailure ??= cause;
        });
    });
    server.unref();
    const opened = new Promise((resolveOpen, rejectOpen) => {
        const onListening = () => {
            server.removeListener('error', onError);
            resolveOpen();
        };
        const onError = (cause) => {
            server.removeListener('listening', onListening);
            rejectOpen(cause);
        };
        server.once('listening', onListening);
        server.once('error', onError);
        server.listen(options.socketPath);
    });
    try {
        await opened;
        const existing = await lstat(options.socketPath);
        if (!existing.isSocket())
            throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'local Work socket path is not a socket');
        await chmod(options.socketPath, 0o600);
    }
    catch (cause) {
        try {
            await new Promise((resolveClosed, rejectClosed) => {
                if (!server.listening) {
                    resolveClosed();
                    return;
                }
                server.close(closeError => closeError === undefined ? resolveClosed() : rejectClosed(closeError));
            });
        }
        catch (cleanupCause) {
            throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'local Work socket startup and cleanup failed', {
                cause: new AggregateError([cause, cleanupCause], 'startup and cleanup causes'),
            });
        }
        throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', `cannot listen local Work socket: ${cause instanceof Error ? cause.message : String(cause)}`, { cause });
    }
    return {
        socketPath: options.socketPath,
        async close() {
            closing = true;
            const closed = closeServer(server, accepted);
            for (const peer of idle)
                peer.destroy();
            await closed;
            if (dispatchFailure !== undefined)
                throw dispatchFailure;
        },
    };
}
async function closeServer(server, accepted) {
    const closed = new Promise((resolveClosed, rejectClosed) => {
        server.close(closeError => closeError === undefined ? resolveClosed() : rejectClosed(closeError));
    });
    const settled = await Promise.allSettled([
        closed,
        ...(accepted === undefined ? [] : [...accepted]),
    ]);
    if (settled[0]?.status === 'rejected')
        throw settled[0].reason;
    const failedDispatch = settled.slice(1).find((result) => result.status === 'rejected');
    if (failedDispatch !== undefined)
        throw failedDispatch.reason;
}
function receiveLine(peer) {
    return new Promise((resolveLine, rejectLine) => {
        let buffered = '';
        const cleanup = () => {
            peer.removeListener('data', onData);
            peer.removeListener('end', onEnd);
            peer.removeListener('close', onEnd);
            peer.removeListener('error', onError);
        };
        const onData = (data) => {
            buffered += data.toString('utf8');
            const index = buffered.indexOf('\n');
            if (index < 0)
                return;
            cleanup();
            resolveLine(buffered.slice(0, index));
        };
        const onEnd = () => { cleanup(); resolveLine(undefined); };
        const onError = (cause) => { cleanup(); rejectLine(cause); };
        peer.on('data', onData);
        peer.once('end', onEnd);
        peer.once('close', onEnd);
        peer.once('error', onError);
    });
}
async function handleConnection(peer, options, admit) {
    peer.setEncoding('utf8');
    let correlation = 'unknown';
    try {
        const line = await receiveLine(peer);
        if (line === undefined)
            return;
        let decoded;
        try {
            decoded = decodeLocalControlRequest(JSON.parse(line));
        }
        catch (cause) {
            const message = cause instanceof Error ? cause.message : 'invalid Work request';
            let requestedKind;
            try {
                requestedKind = JSON.parse(line).kind;
            }
            catch { /* the decode error already describes the frame */ }
            if (typeof requestedKind === 'string' && requestedKind.startsWith('console.')) {
                await sendReply(peer, consoleError('HOST_PROTOCOL', message));
            }
            else {
                await sendReply(peer, { kind: 'work.error', requestId: 'unknown', error: { code: 'HOST_PROTOCOL', message } });
            }
            return;
        }
        if (isConsoleControlRequest(decoded)) {
            correlation = decoded.correlationId;
            if (decoded.expectedLauncherGeneration !== options.launcherGeneration) {
                await sendReply(peer, consoleError('STALE_GENERATION', 'Console request targets a stale launcher generation', decoded.correlationId));
                return;
            }
            if (options.consoleHandler === undefined) {
                await sendReply(peer, consoleError('LOCAL_CONTROL_UNAVAILABLE', 'Console lifecycle handler is not available on this launcher', decoded.correlationId));
                return;
            }
            admit();
            await options.consoleHandler({
                frame: decoded,
                respond: async (reply) => sendReply(peer, reply),
            });
            return;
        }
        const workFrame = decoded;
        correlation = workFrame.requestId;
        if (workFrame.control.startToken !== options.startToken) {
            await sendReply(peer, error('NOT_AUTHORIZED', 'Work start token does not match the current launcher', workFrame.requestId));
            return;
        }
        if (workFrame.control.expectedLauncherGeneration !== options.launcherGeneration) {
            await sendReply(peer, error('STALE_GENERATION', 'Work request targets a stale launcher generation', workFrame.requestId));
            return;
        }
        if (options.receivers[workFrame.control.receiverAgentId] !== true) {
            await sendReply(peer, error('RECEIVER_NOT_FOUND', `Work receiver ${workFrame.control.receiverAgentId} is not available`, workFrame.requestId));
            return;
        }
        admit();
        await options.handler({
            frame: workFrame,
            peer,
            disconnected: disconnected(peer),
            respond: async (result) => {
                const reply = 'status' in result
                    ? { kind: 'work.result', requestId: workFrame.requestId, receipt: result }
                    : error(result.code, result.message, workFrame.requestId);
                return sendReply(peer, reply);
            },
        });
    }
    catch (cause) {
        const message = cause instanceof Error ? cause.message : 'local Work control handler failed';
        try {
            await sendReply(peer, error('HOST_PROTOCOL', message, correlation));
        }
        catch (sendCause) {
            throw new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', `local Work control reply failed: ${sendCause instanceof Error ? sendCause.message : String(sendCause)}`, { cause });
        }
        throw new LocalWorkControlError('HOST_PROTOCOL', message, { cause });
    }
    finally {
        peer.destroy();
    }
}
function error(code, message, requestId = 'unknown') {
    return { kind: 'work.error', requestId, error: { code, message } };
}
function consoleError(code, message, correlationId = 'unknown') {
    return { kind: 'console.result', correlationId, ok: false, error: { code, message } };
}
async function sendReply(peer, reply) {
    if (!peer.writable || peer.destroyed)
        return 'unconfirmed';
    await new Promise((resolveWrite, rejectWrite) => {
        peer.write(encodeLocalWorkControlFrame(reply), (writeError) => writeError ? rejectWrite(writeError) : resolveWrite());
    });
    return 'written';
}
export async function sendLocalWorkControlRequest(options) {
    const timeoutMs = options.timeoutMs ?? 30_000;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0)
        throw protocol('timeoutMs must be a positive integer');
    const frame = decodeLocalWorkControlRequest(options.frame);
    const socket = createConnection({ path: options.socketPath });
    socket.setEncoding('utf8');
    const result = new Promise((resolve, reject) => {
        let buffered = '';
        let settled = false;
        const fail = (cause) => {
            if (settled)
                return;
            settled = true;
            reject(cause instanceof LocalWorkControlError ? cause : new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', `local Work control socket is unavailable: ${cause instanceof Error ? cause.message : String(cause)}`, { cause }));
        };
        socket.once('error', fail);
        socket.once('timeout', () => fail(new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'local Work control request timed out')));
        socket.once('close', () => {
            if (buffered.trim()) {
                const text = buffered.trim();
                const index = text.indexOf('\n');
                try {
                    resolve(decodeLocalWorkControlReply(JSON.parse(index >= 0 ? text.slice(0, index) : text), frame.requestId));
                    return;
                }
                catch (cause) {
                    fail(cause);
                    return;
                }
            }
            if (!settled)
                fail(new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'local Work control socket closed before reply'));
        });
        socket.on('data', chunk => {
            buffered += chunk.toString('utf8');
            const index = buffered.indexOf('\n');
            if (index < 0)
                return;
            const text = buffered.slice(0, index);
            try {
                resolve(decodeLocalWorkControlReply(JSON.parse(text), frame.requestId));
                settled = true;
            }
            catch (cause) {
                fail(cause);
            }
        });
        socket.once('connect', () => {
            socket.write(encodeLocalWorkControlFrame(frame), writeError => {
                if (writeError)
                    fail(writeError);
            });
        });
    }).finally(() => {
        socket.setTimeout(0);
        socket.destroy();
    });
    socket.setTimeout(timeoutMs);
    return result;
}
export async function sendLocalConsoleControlRequest(options) {
    const timeoutMs = options.timeoutMs ?? 30_000;
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0)
        throw protocol('timeoutMs must be a positive integer');
    const frame = decodeLocalConsoleControlRequest(options.frame);
    const socket = createConnection({ path: options.socketPath });
    socket.setEncoding('utf8');
    const result = new Promise((resolve, reject) => {
        let buffered = '';
        let settled = false;
        const fail = (cause) => {
            if (settled)
                return;
            settled = true;
            reject(cause instanceof LocalWorkControlError ? cause : new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', `local Console control socket is unavailable: ${cause instanceof Error ? cause.message : String(cause)}`, { cause }));
        };
        socket.once('error', fail);
        socket.once('timeout', () => fail(new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'local Console control request timed out')));
        socket.once('close', () => {
            if (buffered.trim()) {
                const text = buffered.trim();
                const index = text.indexOf('\n');
                try {
                    resolve(decodeLocalConsoleControlReply(JSON.parse(index >= 0 ? text.slice(0, index) : text), frame.correlationId));
                    return;
                }
                catch (cause) {
                    fail(cause);
                    return;
                }
            }
            if (!settled)
                fail(new LocalWorkControlError('LOCAL_CONTROL_UNAVAILABLE', 'local Console control socket closed before reply'));
        });
        socket.on('data', chunk => {
            buffered += chunk.toString('utf8');
            const index = buffered.indexOf('\n');
            if (index < 0)
                return;
            const text = buffered.slice(0, index);
            try {
                resolve(decodeLocalConsoleControlReply(JSON.parse(text), frame.correlationId));
                settled = true;
            }
            catch (cause) {
                fail(cause);
            }
        });
        socket.once('connect', () => {
            socket.write(encodeLocalWorkControlFrame(frame), writeError => {
                if (writeError)
                    fail(writeError);
            });
        });
    }).finally(() => {
        socket.setTimeout(0);
        socket.destroy();
    });
    socket.setTimeout(timeoutMs);
    return result;
}
