import type { OpenCodeCompiledConfig } from './index.ts';
interface LaunchProvider {
    npm: '@ai-sdk/openai' | '@ai-sdk/openai-compatible';
    name: string;
    env: string[];
    options: {
        baseURL: string;
        apiKey?: string;
    };
    models: Record<string, {
        name: string;
    }>;
}
/** Derived substrate configuration; runtime resolves references into its private child environment. */
export declare function createOpenCodeLaunchConfig(compiled: OpenCodeCompiledConfig): {
    config: {
        model: string;
        enabled_providers: string[];
        provider: Record<string, LaunchProvider>;
    };
    credentialReferences: Record<string, string>;
};
export {};
