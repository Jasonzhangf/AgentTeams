import type { AgentDeclaration, RelayGrant, RelayPeer, RelayServerControl } from '../control-protocol/agent-services.ts';
import { type RelayLoginOptions } from './relay-login.ts';
import { type WssConnection } from './wss-connection.ts';
type Event = Extract<RelayServerControl, {
    kind: 'relay.changed' | 'relay.offer' | 'relay.closed';
}>;
export interface RelayClientOptions extends RelayLoginOptions {
    readonly requestTimeoutMs: number;
    readonly maxPendingRequests: number;
    readonly maxDataConnections: number;
    /** Receiver owns execution admission/capacity; failures close this control connection. */
    readonly onEvent?: (event: Event) => void | Promise<void>;
}
export interface RelayDirectorySnapshot {
    readonly revision: number;
    readonly peers: readonly RelayPeer[];
}
export interface RelayClient {
    readonly generation: number;
    readonly closed: Promise<Error>;
    directory(subscribe: boolean): Promise<readonly RelayPeer[]>;
    directorySnapshot(subscribe: boolean): Promise<RelayDirectorySnapshot>;
    connect(targetAgentId: string, targetGeneration: number): Promise<RelayGrant>;
    openData(grant: RelayGrant): Promise<WssConnection>;
    presence(): Promise<void>;
    publish(declaration: AgentDeclaration): Promise<void>;
    close(): Promise<void>;
}
export declare function createRelayClient(input: RelayClientOptions): Promise<RelayClient>;
export {};
