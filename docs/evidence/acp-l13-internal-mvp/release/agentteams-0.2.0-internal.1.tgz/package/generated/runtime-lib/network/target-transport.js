function positiveInteger(value, label) {
    if (!Number.isInteger(value) || value < 1)
        throw new Error(`INVALID_${label.toUpperCase()}`);
}
function assertState(state, expected) {
    if (state.state !== expected)
        throw new Error(`INVALID_TRANSITION: expected ${expected}, got ${state.state}`);
}
export function beginTargetTransport(hello) {
    positiveInteger(hello.targetGeneration, 'generation');
    positiveInteger(hello.protocolVersion, 'protocol_version');
    if (hello.hostId.length === 0 || hello.agentId.length === 0 || hello.capabilitiesRevision.length === 0 ||
        hello.admissionRef.length === 0 || hello.source.accountId.length === 0 || hello.source.scopeId.length === 0 || hello.source.agentId.length === 0) {
        throw new Error('transport: hello identity fields are required');
    }
    return { state: 'connecting', ...hello };
}
export function receiveHelloAck(state) {
    assertState(state, 'connecting');
    return { ...state, state: 'ready' };
}
export function confirmTargetHealth(state, generation) {
    assertState(state, 'ready');
    if (state.targetGeneration !== generation)
        throw new Error('STALE_GENERATION');
    return state;
}
export function assertTargetGeneration(state, generation) {
    if (state.targetGeneration !== generation)
        throw new Error('STALE_GENERATION');
}
export function closeTargetTransport(state, reason) {
    if (state.state !== 'ready' && state.state !== 'connecting') {
        throw new Error(`INVALID_TRANSITION: cannot close ${state.state}`);
    }
    return { ...state, state: 'closed', error: reason };
}
export function failTargetTransport(state, reason) {
    if (state.state === 'closed' || state.state === 'failed') {
        throw new Error(`INVALID_TRANSITION: cannot fail ${state.state}`);
    }
    return { ...state, state: 'failed', error: reason };
}
