import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { AcpFault } from '../control-protocol/acp.ts';
import type { RelationRole } from '../control-protocol/teams-connection.ts';
import type { AcpPolicySnapshot } from '../config/acp-policy.ts';
import type { AcpHost } from '../agent-host/acp-host.ts';
import type { MembershipChannelObservation } from './teams-membership.ts';
import type { TeamsConnectionHistory } from './teams-connection-history.ts';
import { type TeamsNegotiationState } from './teams-negotiation.ts';
import { type TeamsSession, type TeamsSessionTransport } from './teams-session.ts';
import type { WssFrame } from './wss-connection.ts';
/** The byte-level socket the direct listener already authenticated. */
export interface TeamsFrameSocket {
    /** Resolves when the socket is gone, from either side. */
    readonly closed: Promise<unknown>;
    read(): Promise<WssFrame>;
    send(frame: WssFrame): Promise<void>;
    close(): Promise<void>;
}
export interface TeamsIngressConnection {
    /** The listener's authenticated transport connection id. */
    readonly connectionId: string;
    /** The authenticated peer identity; never read from a payload. */
    readonly peer: AuthenticatedAgent;
    readonly connection: TeamsFrameSocket;
}
/**
 * The Teams session transport over the existing wss frame shape. It owns the
 * bytes/JSON codec boundary and the socket lifecycle: a Teams frame is a JSON
 * text frame, and a binary or non-JSON frame is refused explicitly.
 */
export declare function createTeamsFrameTransport(connection: TeamsFrameSocket, peer: AuthenticatedAgent): TeamsSessionTransport;
/**
 * Live per-connection truth over the existing `MembershipChannelObservation`
 * shape. `list()` is the only source `projectTeamsMembership` reads for live
 * channels; a closed or failed connection keeps its record and is never rebuilt
 * from history or logs.
 */
export interface TeamsConnectionLedger {
    /** Register a new live connection. A duplicate connection id is a conflict. */
    open(observation: MembershipChannelObservation): void;
    /** Replace the live record of an existing connection. An unknown id is a conflict. */
    update(observation: MembershipChannelObservation): void;
    /** Move an existing connection to `closed`; its record is retained. */
    close(connectionId: string, observedAt: string): void;
    list(): readonly MembershipChannelObservation[];
}
export declare function createTeamsConnectionLedger(): TeamsConnectionLedger;
export interface OpenTeamsIngressInput {
    readonly connection: TeamsIngressConnection;
    /** This daemon's own authenticated identity. */
    readonly self: AuthenticatedAgent;
    readonly selfGeneration: number;
    readonly selfCapabilitiesRevision: string;
    /** The accepted config revision; never a policy snapshot hash. */
    readonly selfPolicyRevision: number;
    readonly allowedRoles: readonly RelationRole[];
    readonly admittedCapabilities: readonly string[];
    readonly host: AcpHost;
    readonly policy: AcpPolicySnapshot;
    readonly engineInstanceId: string;
    readonly history: TeamsConnectionHistory;
    readonly ledger: TeamsConnectionLedger;
    readonly timeoutMs?: number;
    readonly pollIntervalMs?: number;
    /** Live clock; defaults to the system clock. */
    readonly now?: () => string;
    /** Observable history-write failure; never carried inside a Teams frame. */
    readonly onHistoryFault?: (fault: AcpFault) => void;
}
export interface TeamsIngressHandle {
    readonly connectionId: string;
    readonly peer: AuthenticatedAgent;
    readonly negotiation: TeamsNegotiationState;
    readonly session: TeamsSession;
    /** Settles when the session read loop ends; a read-loop failure is recorded, never thrown here. */
    readonly done: Promise<void>;
}
/**
 * Open the responder side of one authenticated connection.
 *
 * A rejected or timed-out negotiation records `connection.failed`, marks the
 * ledger entry failed and throws the typed fault, so the listener can terminate
 * the transport. An agreed negotiation records `connection.negotiated`, creates
 * the ACP session and starts its read loop; the caller never awaits the loop.
 */
export declare function openTeamsIngress(input: OpenTeamsIngressInput): Promise<TeamsIngressHandle>;
