import { type DirectListenerConfig } from './process-config.ts';
import type { AgentDeclaration } from '../control-protocol/agent-services.ts';
import type { ConsoleAgentObservationV1, ConsoleCapabilityDetail, ConsoleCommandResultV1, ConsoleProjectionV1, ConsoleSessionEventView, JsonValue, SessionObservationState } from '../control-protocol/console-api.ts';
import type { RelayClientOptions } from '../network/relay-client.ts';
import { type AgentDaemon } from './agent-daemon.ts';
import { type ManagedEffectiveHandle, type ManagedRuntimeReadiness } from './managed-config-owner.ts';
import { type OpenCodeSessionClient, type OpenCodeEventClient } from '../opencode-adapter/src/index.ts';
import { type AgentWorkClient } from './agent-work-client.ts';
import type { ResourceDemand } from '../control-protocol/agent-services.ts';
import { type LocalServiceIntent } from './local-config.ts';
import type { LocalDaemonEndpointProjection, LocalWorkChildRequest } from './local-supervisor.ts';
import { type LocalWorkControlReply, type LocalWorkControlRequest } from './local-work-control.ts';
import { type ProjectExecutionReceipt } from './dagpipe/host.ts';
export interface AgentConnectionIntent {
    readonly targetAgentId: string;
    readonly capabilityId: string;
    readonly capabilityVersion: string;
    readonly operation: string;
    readonly demands: readonly ResourceDemand[];
}
export interface AgentEndpointConfig {
    readonly role: 'provider' | 'receiver' | 'hybrid';
    readonly connect?: AgentConnectionIntent;
    readonly services: readonly LocalServiceIntent[];
}
export interface AgentProcessConfig {
    readonly declaration: AgentDeclaration;
    readonly dataDirectory: string;
    readonly leasePort: number;
    readonly relay: RelayClientOptions;
    readonly presenceIntervalMs: number;
    readonly policyRevision: number;
    readonly allowedConsumers: readonly string[];
    readonly allowedManagers: readonly string[];
    readonly cli: {
        readonly camoExecutable: string;
        readonly searchExecutable: string;
        readonly searchRoot: string;
        readonly profilePrefix: string;
    };
    readonly openCode?: {
        readonly executable: string;
        readonly directory: string;
        readonly configFile: string;
        readonly port: number;
        readonly startupTimeoutMs: number;
        readonly stopTimeoutMs: number;
    };
    readonly directListener?: DirectListenerConfig;
    readonly endpoint?: AgentEndpointConfig;
}
/** Owner-scoped ports the Session host consumes; never a second config or lifecycle owner. */
export interface SessionHostOwnerPort {
    readiness(): ManagedRuntimeReadiness;
    currentHandle(): ManagedEffectiveHandle | undefined;
    use<T>(operation: (handle: ManagedEffectiveHandle) => Promise<T>): Promise<T>;
}
export interface SessionHostDeps {
    readonly agentId: string;
    readonly generation: () => number;
    readonly owner: SessionHostOwnerPort;
    readonly createClient?: (handle: {
        readonly url: string;
        readonly authorization: string;
    }) => OpenCodeSessionClient & OpenCodeEventClient;
    readonly bufferLimit?: number;
}
/** The single per-Agent Session owner: one event stream, per-session buffer, and prompt admission. */
export interface SessionHost {
    readonly openSession: (sessionId: string) => Promise<ConsoleCommandResultV1>;
    readonly createSession: (title?: string) => Promise<ConsoleCommandResultV1>;
    readonly sendSession: (sessionId: string, payload: JsonValue) => Promise<ConsoleCommandResultV1>;
    readonly cancelSession: (sessionId: string) => Promise<ConsoleCommandResultV1>;
    readonly replyPermission: (sessionId: string, permissionId: string, decision: 'once' | 'always' | 'reject') => Promise<ConsoleCommandResultV1>;
    readonly sessionEvents: () => readonly ConsoleSessionEventView[];
    /** Owner-backed Session list; the single read path that feeds ConsoleProjectionV1.sessions. */
    readonly projectionSessions: () => Promise<ConsoleProjectionV1['sessions']>;
    readonly currentSessionId: () => string | undefined;
    readonly observation: () => SessionObservationState;
    readonly ensureStream: () => void | Promise<void>;
    readonly dispose: () => Promise<void>;
}
/**
 * The single runtime management-row projection. `sessionCapable` is the U2
 * binding fact; the owner supplies only readiness, never a second config truth.
 */
export declare function projectRuntimeAgentRow(input: {
    readonly agentId: string;
    readonly machineId: string;
    readonly label: string;
    readonly presence: 'online' | 'offline' | 'unknown';
    readonly capabilities: readonly string[];
    readonly capabilityDetails?: readonly ConsoleCapabilityDetail[];
    readonly generation?: number;
    readonly sessionCapable: boolean;
    readonly readiness?: ManagedRuntimeReadiness;
    readonly observation?: SessionObservationState;
    readonly currentSessionId?: string;
}): ConsoleAgentObservationV1;
/**
 * Owns the single per-child OpenCode event stream, the bounded per-session projection buffer, the
 * observation state, and the per-session prompt operation record. It is not a persistent store.
 */
export declare function createSessionHost(deps: SessionHostDeps): SessionHost;
export declare function loadAgentProcessConfig(path: string, env?: NodeJS.ProcessEnv): Promise<AgentProcessConfig>;
export interface AgentProcess {
    readonly daemon: AgentDaemon;
    readonly consumerWork: AgentWorkClient;
    readonly executeWork: (frame: LocalWorkControlRequest) => Promise<ProjectExecutionReceipt>;
    readonly closed: Promise<void>;
    readonly statusProjection: () => LocalDaemonEndpointProjection;
    stop(): Promise<void>;
}
export declare function startAgentProcess(configPath: string, env?: NodeJS.ProcessEnv): Promise<AgentProcess>;
/**
 * Build the typed reply for one launcher Work frame. Exported so the failure
 * contract — identity, fixed binding and unconfirmed delivery — is verifiable
 * without spawning a daemon.
 */
export declare function resolveWorkChildReply(handle: Pick<AgentProcess, 'daemon' | 'executeWork'>, request: LocalWorkChildRequest): Promise<LocalWorkControlReply>;
export declare function runAgentProcess(argv?: string[]): Promise<void>;
