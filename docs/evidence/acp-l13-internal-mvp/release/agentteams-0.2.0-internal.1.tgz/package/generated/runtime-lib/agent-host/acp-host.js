import { AcpError, parseAcpFrame } from "../control-protocol/acp.js";
const DEFAULT_MAX_DELIVERY_BACKLOG = 1024;
const MAX_READ_LIMIT = 1000;
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function requireText(value, label) {
    if (typeof value !== 'string' || value.length === 0) {
        throw new AcpError('INVALID_ACP_FRAME', `${label} must be a non-empty string`);
    }
    return value;
}
/** Canonical correlation key for a JSON-RPC id, preserving `string` vs `number`. */
export function rpcIdKey(id) {
    return `${typeof id}:${String(id)}`;
}
function methodOf(frame) {
    return typeof frame.method === 'string' && frame.method.length > 0 ? frame.method : undefined;
}
function isRequestFrame(frame) {
    return methodOf(frame) !== undefined && Object.hasOwn(frame, 'id');
}
function isNotificationFrame(frame) {
    return methodOf(frame) !== undefined && !Object.hasOwn(frame, 'id');
}
function isResponseFrame(frame) {
    return methodOf(frame) === undefined && Object.hasOwn(frame, 'id');
}
function sessionIdOf(frame) {
    const params = frame.params;
    if (!isRecord(params))
        return undefined;
    const sessionId = params.sessionId;
    return typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : undefined;
}
function resultSessionId(frame) {
    const result = frame.result;
    if (!isRecord(result))
        return undefined;
    const sessionId = result.sessionId;
    return typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : undefined;
}
function cloneJson(value) {
    if (Array.isArray(value))
        return value.map(cloneJson);
    if (isRecord(value)) {
        const output = {};
        for (const key of Object.keys(value))
            output[key] = cloneJson(value[key]);
        return output;
    }
    return value;
}
/**
 * Project the engine's declared capabilities under the channel policy. A
 * denied capability becomes `false` in the served result; the declaration is
 * the policy's projection, never a second editable source.
 */
function projectCapabilityNode(node, pointer, policy) {
    for (const key of Object.keys(node)) {
        const value = node[key];
        const escaped = key.replaceAll('~', '~0').replaceAll('/', '~1');
        const childPointer = `${pointer}/${escaped}`;
        if (value === true) {
            if (!policy.effective.includes(`capability:${childPointer}`))
                node[key] = false;
        }
        else if (isRecord(value)) {
            projectCapabilityNode(value, childPointer, policy);
        }
    }
}
function projectInitializeResult(frame, policy) {
    const result = frame.result;
    if (!isRecord(result))
        return frame;
    const cloned = cloneJson(result);
    if (!isRecord(cloned))
        return frame;
    const agentCapabilities = cloned.agentCapabilities;
    if (isRecord(agentCapabilities))
        projectCapabilityNode(agentCapabilities, '', policy);
    return { ...frame, result: cloned };
}
function faultFrom(error, fallback) {
    if (error instanceof AcpError)
        return error.toFault();
    return { code: fallback, message: error instanceof Error ? error.message : 'ACP operation failed' };
}
function toAcpError(error, fallback) {
    if (error instanceof AcpError)
        return error;
    return new AcpError(fallback, error instanceof Error ? error.message : 'ACP operation failed');
}
function faultData(fault) {
    const output = { code: fault.code, message: fault.message };
    if (fault.detail !== undefined)
        output.detail = fault.detail;
    return output;
}
/**
 * The one ACP JSON-RPC error envelope. Exported so the runtime serve transport
 * answers a frame the host rejects with the same envelope instead of declaring
 * a second one.
 */
export function rpcErrorFrame(id, fault) {
    return { jsonrpc: '2.0', id, error: { code: -32000, message: fault.message, data: faultData(fault) } };
}
/**
 * The ACP `session/request_permission` option kinds, in the exact vocabulary the engine
 * sends. Each maps onto the frozen Console decision vocabulary without inventing a value.
 */
const ACP_PERMISSION_OPTION_KINDS = {
    allow_once: 'once',
    allow_always: 'always',
    reject_once: 'reject',
    reject_always: 'reject',
};
function permissionParams(frame) {
    const params = frame.params;
    if (!isRecord(params))
        throw new AcpError('INVALID_ACP_FRAME', 'session/request_permission requires object params');
    return params;
}
/**
 * Engine-side projection of the real engine-supplied permission choice set (A2.6).
 *
 * The option set is read verbatim from the engine's own `session/request_permission`
 * params: this function never mints an option the engine did not offer, and it returns
 * `undefined` when the engine offered none (the field is additive and stays absent). A
 * malformed option fails explicitly at this owning boundary instead of reaching a
 * controller as an unactionable or ambiguous choice.
 */
export function projectPermissionOptions(frame) {
    const raw = permissionParams(frame).options;
    if (raw === undefined)
        return undefined;
    if (!Array.isArray(raw))
        throw new AcpError('INVALID_ACP_FRAME', 'session/request_permission options must be an array');
    if (raw.length === 0)
        return undefined;
    const seen = new Set();
    return raw.map(entry => {
        if (!isRecord(entry))
            throw new AcpError('INVALID_ACP_FRAME', 'session/request_permission option must be an object');
        const optionId = requireText(entry.optionId, 'permission option.optionId');
        const name = requireText(entry.name, 'permission option.name');
        const kind = typeof entry.kind === 'string' ? ACP_PERMISSION_OPTION_KINDS[entry.kind] : undefined;
        if (kind === undefined) {
            throw new AcpError('INVALID_ACP_FRAME', `permission option.kind ${String(entry.kind)} is not an ACP permission option kind`);
        }
        if (seen.has(optionId))
            throw new AcpError('INVALID_ACP_FRAME', `permission optionId ${optionId} is offered twice`);
        seen.add(optionId);
        return { optionId, name, kind };
    });
}
/**
 * Adjudicates one controller reply against the engine's real option set (A2.6).
 *
 * The engine is answered with a selection it really offered. A selection the engine never
 * offered, a selection when the engine offered no options, or an unknown outcome fails
 * typed; a missing or stale callback never becomes an approval and the host never supplies
 * an `optionId` of its own.
 */
export function adjudicatePermissionReply(result, options) {
    if (!isRecord(result))
        throw new AcpError('INVALID_ACP_FRAME', 'permission reply result must be an object');
    const outcome = result.outcome;
    if (!isRecord(outcome))
        throw new AcpError('INVALID_ACP_FRAME', 'permission reply result requires an outcome object');
    if (outcome.outcome === 'cancelled')
        return { outcome: { outcome: 'cancelled' } };
    if (outcome.outcome !== 'selected') {
        throw new AcpError('INVALID_ACP_FRAME', `permission reply outcome ${String(outcome.outcome)} is not selected or cancelled`);
    }
    const optionId = requireText(outcome.optionId, 'permission reply outcome.optionId');
    if (options === undefined || !options.some(option => option.optionId === optionId)) {
        throw new AcpError('INVALID_ACP_FRAME', `permission reply optionId ${optionId} is not an option the engine offered for this callback`);
    }
    return { outcome: { outcome: 'selected', optionId } };
}
function assertRefShape(ref) {
    if (!isRecord(ref))
        throw new AcpError('INVALID_ACP_FRAME', 'ACP channel ref must be an object');
    requireText(ref.connectionId, 'ref.connectionId');
    requireText(ref.channelId, 'ref.channelId');
    requireText(ref.engineInstanceId, 'ref.engineInstanceId');
    if (!Number.isSafeInteger(ref.targetGeneration) || ref.targetGeneration < 1) {
        throw new AcpError('INVALID_ACP_FRAME', 'ref.targetGeneration must be a positive safe integer');
    }
}
function assertPrincipal(principal) {
    if (!isRecord(principal))
        throw new AcpError('AUTHENTICATION_REQUIRED', 'ACP channel principal is required');
    requireText(principal.accountId, 'principal.accountId');
    requireText(principal.scopeId, 'principal.scopeId');
    requireText(principal.agentId, 'principal.agentId');
}
function assertPolicyShape(policy) {
    if (!isRecord(policy))
        throw new AcpError('UNSUPPORTED_POLICY', 'ACP policy snapshot is required');
    requireText(policy.revision, 'policy.revision');
    requireText(policy.engineInstanceId, 'policy.engineInstanceId');
    for (const [label, value] of [
        ['policy.supported', policy.supported],
        ['policy.effective', policy.effective],
        ['policy.denied', policy.denied],
    ]) {
        if (!Array.isArray(value) || value.some(item => typeof item !== 'string' || item.length === 0)) {
            throw new AcpError('UNSUPPORTED_POLICY', `${label} must be an array of non-empty strings`);
        }
    }
}
function channelKeyOf(ref) {
    return `${ref.engineInstanceId}\u0000${ref.targetGeneration}\u0000${ref.connectionId}\u0000${ref.channelId}`;
}
export function createAcpHost(input) {
    if (input === null || typeof input !== 'object') {
        throw new AcpError('UNSUPPORTED_CONFIGURATION', 'createAcpHost input is required');
    }
    const engineInstanceId = requireText(input.handle?.engineInstanceId, 'handle.engineInstanceId');
    if (!Number.isSafeInteger(input.handle?.targetGeneration) || input.handle.targetGeneration < 1) {
        throw new AcpError('UNSUPPORTED_CONFIGURATION', 'handle.targetGeneration must be a positive safe integer');
    }
    if (typeof input.handle?.acp?.read !== 'function' || typeof input.handle.acp.send !== 'function') {
        throw new AcpError('UNSUPPORTED_CONFIGURATION', 'handle.acp must be an AcpDuplex');
    }
    const initializeResult = parseAcpFrame(input.initializeResult);
    if (Object.hasOwn(initializeResult, 'error') || !Object.hasOwn(initializeResult, 'result')) {
        throw new AcpError('ENGINE_UNAVAILABLE', 'a genuine successful initialize result is required before host handoff');
    }
    assertPolicyShape(input.policy);
    if (input.policy.engineInstanceId !== engineInstanceId) {
        throw new AcpError('STALE_GENERATION', 'host policy does not belong to the initialized engine instance');
    }
    if (typeof input.assertAllowed !== 'function') {
        throw new AcpError('UNSUPPORTED_POLICY', 'an injected ACP policy assertion is required');
    }
    if (typeof input.history?.append !== 'function') {
        throw new AcpError('HISTORY_UNAVAILABLE', 'an injected ACP history write port is required');
    }
    const maxDeliveryBacklog = input.maxDeliveryBacklog ?? DEFAULT_MAX_DELIVERY_BACKLOG;
    if (!Number.isSafeInteger(maxDeliveryBacklog) || maxDeliveryBacklog < 1) {
        throw new AcpError('UNSUPPORTED_CONFIGURATION', 'maxDeliveryBacklog must be a positive safe integer');
    }
    const localAgentId = input.agentId ?? engineInstanceId;
    const channels = new Map();
    const sessionOwners = new Map();
    const childRequests = new Map();
    const outwardCallbacks = new Map();
    let childCounter = 0;
    let callbackCounter = 0;
    let engineEnded = false;
    const historyEntry = (event, extras = {}) => ({
        agentId: localAgentId,
        occurredAt: new Date().toISOString(),
        kind: 'request',
        event,
        ...extras,
    });
    /** Append that fails the operation: used before any engine effect. */
    const appendRecord = async (record) => {
        try {
            return await input.history.append(record);
        }
        catch (cause) {
            throw new AcpError('HISTORY_UNAVAILABLE', cause instanceof Error ? cause.message : 'ACP history append failed');
        }
    };
    /** Append after an effect already happened: report the fault, never block live behavior. */
    const safeAppend = async (record) => {
        try {
            await input.history.append(record);
        }
        catch (cause) {
            input.onHistoryFault?.(faultFrom(cause, 'HISTORY_UNAVAILABLE'));
        }
    };
    const channelBySession = (sessionId) => {
        const key = sessionOwners.get(sessionId);
        return key === undefined ? undefined : channels.get(key);
    };
    /** Bounded live delivery. Returns false when the frame could not be delivered. */
    const enqueue = (channel, frame) => {
        if (channel.deliveries.length >= maxDeliveryBacklog) {
            void safeAppend(historyEntry('delivery.overflow', {
                connectionId: channel.ref.connectionId,
                channelId: channel.ref.channelId,
                engineInstanceId,
                frame,
                outcome: 'unknown',
                error: { code: 'CONFLICT', message: 'ACP live delivery backlog is full' },
            }));
            return false;
        }
        channel.deliveries.push({ ...channel.ref, frame, sequence: channel.nextSequence });
        channel.nextSequence += 1;
        return true;
    };
    const assertSessionOwner = (channel, sessionId) => {
        if (sessionOwners.get(sessionId) !== channel.key) {
            throw new AcpError('SESSION_OWNERSHIP_CONFLICT', `session ${sessionId} is not owned by this channel`);
        }
    };
    const requireSessionId = (frame) => {
        const sessionId = sessionIdOf(frame);
        if (sessionId === undefined)
            throw new AcpError('INVALID_ACP_FRAME', 'ACP session method requires params.sessionId');
        return sessionId;
    };
    const nextChildId = () => {
        childCounter += 1;
        return `acp-child-${engineInstanceId}-${childCounter}`;
    };
    const nextCallbackId = () => {
        callbackCounter += 1;
        return `acp-callback-${engineInstanceId}-${callbackCounter}`;
    };
    const removePendingRequest = (pending) => {
        channels.get(pending.channelKey)?.pendingRequests.delete(pending.originalIdKey);
        childRequests.delete(rpcIdKey(pending.childId));
    };
    const respondCallbackError = async (engineId, fault) => {
        if (engineEnded)
            return;
        try {
            await input.handle.acp.send({
                jsonrpc: '2.0',
                id: engineId,
                error: { code: -32601, message: fault.message, data: faultData(fault) },
            });
        }
        catch {
            // The child is gone; the callback obligation stays an explicit unknown.
        }
    };
    /**
     * A permission callback with no controller is answered with the ACP
     * cancellation outcome. The host never converts "nobody replied" into an
     * approval.
     */
    const sendPermissionCancellation = async (engineId) => {
        if (engineEnded)
            return;
        try {
            await input.handle.acp.send({ jsonrpc: '2.0', id: engineId, result: { outcome: { outcome: 'cancelled' } } });
        }
        catch {
            // No controller and no child: the callback remains an explicit unknown.
        }
    };
    const settlePendingCallbacks = async (channel, reason) => {
        const pending = [...channel.pendingCallbacks.values()];
        channel.pendingCallbacks.clear();
        for (const item of pending) {
            outwardCallbacks.delete(rpcIdKey(item.outwardId));
            await safeAppend(historyEntry('callback.unknown', {
                connectionId: channel.ref.connectionId,
                channelId: channel.ref.channelId,
                engineInstanceId,
                sessionId: item.sessionId,
                requestRecordId: item.recordId,
                outcome: 'unknown',
                error: { code: 'CALLBACK_UNAVAILABLE', message: `${reason} before a callback reply` },
            }));
            if (!engineEnded) {
                if (item.method === 'session/request_permission')
                    await sendPermissionCancellation(item.engineId);
                else
                    await respondCallbackError(item.engineId, {
                        code: 'CALLBACK_UNAVAILABLE',
                        message: `${reason} before a callback reply`,
                    });
            }
        }
    };
    const settlePendingRequests = async (channel, reason) => {
        const pending = [...channel.pendingRequests.values()];
        for (const item of pending) {
            removePendingRequest(item);
            await safeAppend(historyEntry('result.unknown', {
                connectionId: channel.ref.connectionId,
                channelId: channel.ref.channelId,
                engineInstanceId,
                sessionId: item.sessionId,
                requestRecordId: item.recordId,
                frame: item.frame,
                outcome: 'unknown',
                error: { code: 'RESULT_UNKNOWN', message: `${reason} before a result` },
            }));
            enqueue(channel, rpcErrorFrame(item.originalId, { code: 'RESULT_UNKNOWN', message: `${reason} before a result` }));
        }
    };
    const releaseSessions = (channel) => {
        for (const sessionId of channel.sessions)
            sessionOwners.delete(sessionId);
        channel.sessions.clear();
        channel.activePrompt = undefined;
    };
    const onEngineEnd = (reason) => {
        if (engineEnded)
            return;
        engineEnded = true;
        childRequests.clear();
        outwardCallbacks.clear();
        for (const channel of channels.values()) {
            if (channel.closed)
                continue;
            channel.closed = true;
            void settlePendingRequests(channel, `engine ${reason}`);
            for (const item of [...channel.pendingCallbacks.values()]) {
                void safeAppend(historyEntry('callback.unknown', {
                    connectionId: channel.ref.connectionId,
                    channelId: channel.ref.channelId,
                    engineInstanceId,
                    sessionId: item.sessionId,
                    requestRecordId: item.recordId,
                    outcome: 'unknown',
                    error: { code: 'CALLBACK_UNAVAILABLE', message: `engine ${reason} before a callback reply` },
                }));
            }
            channel.pendingCallbacks.clear();
            releaseSessions(channel);
        }
    };
    const handleInitialize = async (channel, frame) => {
        if (channel.initialized)
            throw new AcpError('CONFLICT', 'ACP initialize has already completed for this channel');
        input.assertAllowed({ policy: channel.policy, direction: 'to-engine', frame });
        await appendRecord(historyEntry('initialize', {
            connectionId: channel.ref.connectionId,
            channelId: channel.ref.channelId,
            engineInstanceId,
            frame,
        }));
        channel.initialized = true;
        enqueue(channel, { ...projectInitializeResult(initializeResult, channel.policy), id: frame.id });
    };
    const dispatchToEngine = async (channel, frame) => {
        const method = methodOf(frame);
        if (method === undefined)
            throw new AcpError('INVALID_ACP_FRAME', 'ACP dispatch requires a method');
        const originalId = frame.id;
        const originalIdKey = rpcIdKey(originalId);
        if (channel.pendingRequests.has(originalIdKey)) {
            throw new AcpError('CONFLICT', `pending ACP request id ${String(originalId)} cannot be reused`);
        }
        if (engineEnded)
            throw new AcpError('ENGINE_UNAVAILABLE', 'ACP engine is not available');
        const childId = nextChildId();
        const sessionId = sessionIdOf(frame);
        const entry = await appendRecord(historyEntry('request.dispatched', {
            connectionId: channel.ref.connectionId,
            channelId: channel.ref.channelId,
            engineInstanceId,
            sessionId,
            frame,
        }));
        const pending = {
            originalId,
            originalIdKey,
            channelKey: channel.key,
            childId,
            method,
            sessionId,
            recordId: entry.recordId,
            frame,
        };
        channel.pendingRequests.set(originalIdKey, pending);
        childRequests.set(rpcIdKey(childId), pending);
        try {
            await input.handle.acp.send({ ...frame, id: childId });
        }
        catch (cause) {
            removePendingRequest(pending);
            await safeAppend(historyEntry('request.send.failed', {
                connectionId: channel.ref.connectionId,
                channelId: channel.ref.channelId,
                engineInstanceId,
                sessionId,
                frame,
                outcome: 'unknown',
                error: faultFrom(cause, 'ENGINE_UNAVAILABLE'),
            }));
            throw toAcpError(cause, 'ENGINE_UNAVAILABLE');
        }
    };
    const handlePrompt = async (channel, frame) => {
        const sessionId = requireSessionId(frame);
        assertSessionOwner(channel, sessionId);
        if (channel.activePrompt !== undefined) {
            throw new AcpError('CONFLICT', `session ${sessionId} already has a prompt in flight`);
        }
        channel.activePrompt = { sessionId };
        try {
            await dispatchToEngine(channel, frame);
        }
        catch (cause) {
            channel.activePrompt = undefined;
            throw cause;
        }
    };
    const handleSessionAdoption = async (channel, frame) => {
        assertSessionOwner(channel, requireSessionId(frame));
        await dispatchToEngine(channel, frame);
    };
    const receiveClientRequest = async (channel, frame) => {
        const method = methodOf(frame);
        if (method === undefined)
            throw new AcpError('INVALID_ACP_FRAME', 'ACP request requires a method');
        if (method === 'initialize') {
            await handleInitialize(channel, frame);
            return;
        }
        if (!channel.initialized)
            throw new AcpError('CONFLICT', 'ACP initialize must precede other channel traffic');
        input.assertAllowed({ policy: channel.policy, direction: 'to-engine', frame });
        if (method === 'session/load' || method === 'session/resume') {
            await handleSessionAdoption(channel, frame);
            return;
        }
        if (method === 'session/prompt') {
            await handlePrompt(channel, frame);
            return;
        }
        const sessionId = sessionIdOf(frame);
        if (sessionId !== undefined && method !== 'session/new') {
            assertSessionOwner(channel, sessionId);
        }
        await dispatchToEngine(channel, frame);
    };
    const receiveClientNotification = async (channel, frame) => {
        if (!channel.initialized)
            throw new AcpError('CONFLICT', 'ACP initialize must precede other channel traffic');
        input.assertAllowed({ policy: channel.policy, direction: 'to-engine', frame });
        const method = methodOf(frame);
        if (method === 'initialize') {
            // `initialize` is a request whose only legitimate answer is the captured
            // bootstrap result. A notification form cannot be answered, so it must
            // never reach the engine as a second initialize.
            throw new AcpError('UNSUPPORTED_METHOD', 'ACP initialize must be a request and cannot be sent as a notification');
        }
        const sessionId = sessionIdOf(frame);
        if (sessionId !== undefined)
            assertSessionOwner(channel, sessionId);
        if (engineEnded)
            throw new AcpError('ENGINE_UNAVAILABLE', 'ACP engine is not available');
        if (method === 'session/cancel') {
            // A cancel request is recorded separately from the prompt's terminal
            // result; only the engine result confirms the prompt ended.
            await appendRecord(historyEntry('cancel.requested', {
                connectionId: channel.ref.connectionId,
                channelId: channel.ref.channelId,
                engineInstanceId,
                sessionId,
                frame,
            }));
            try {
                await input.handle.acp.send(frame);
            }
            catch (cause) {
                throw toAcpError(cause, 'ENGINE_UNAVAILABLE');
            }
            return;
        }
        await appendRecord(historyEntry('notification.dispatched', {
            connectionId: channel.ref.connectionId,
            channelId: channel.ref.channelId,
            engineInstanceId,
            sessionId,
            frame,
        }));
        try {
            await input.handle.acp.send(frame);
        }
        catch (cause) {
            throw toAcpError(cause, 'ENGINE_UNAVAILABLE');
        }
    };
    const receiveClientResponse = async (channel, frame) => {
        const id = frame.id;
        const idKey = rpcIdKey(id);
        const pending = outwardCallbacks.get(idKey);
        if (pending === undefined) {
            throw new AcpError('CALLBACK_UNAVAILABLE', 'no pending engine callback matches this response id');
        }
        if (pending.channelKey !== channel.key) {
            throw new AcpError('SESSION_OWNERSHIP_CONFLICT', 'callback response belongs to another channel');
        }
        // The engine's real option set adjudicates the controller's selection (A2.6). A reply
        // that selects an option the engine never offered, or that selects anything while the
        // engine offered no options, fails typed before the pending callback is consumed, so a
        // rejected reply never becomes an approval and the callback stays answerable. The
        // refusal is recorded as one durable callback.denied fact instead of being dropped.
        let delivered = frame;
        if (pending.method === 'session/request_permission' && Object.hasOwn(frame, 'result')) {
            try {
                delivered = { ...frame, result: adjudicatePermissionReply(frame.result, pending.permissionOptions) };
            }
            catch (cause) {
                await safeAppend(historyEntry('callback.denied', {
                    connectionId: channel.ref.connectionId,
                    channelId: channel.ref.channelId,
                    engineInstanceId,
                    sessionId: pending.sessionId,
                    requestRecordId: pending.recordId,
                    frame,
                    outcome: 'denied',
                    error: faultFrom(cause, 'CALLBACK_UNAVAILABLE'),
                }));
                throw cause;
            }
        }
        outwardCallbacks.delete(idKey);
        channel.pendingCallbacks.delete(idKey);
        await safeAppend(historyEntry('callback.reply', {
            connectionId: channel.ref.connectionId,
            channelId: channel.ref.channelId,
            engineInstanceId,
            sessionId: pending.sessionId,
            requestRecordId: pending.recordId,
            frame: delivered,
        }));
        if (engineEnded)
            throw new AcpError('ENGINE_UNAVAILABLE', 'ACP engine is not available');
        try {
            await input.handle.acp.send({ ...delivered, id: pending.engineId });
        }
        catch (cause) {
            await safeAppend(historyEntry('callback.send.failed', {
                connectionId: channel.ref.connectionId,
                channelId: channel.ref.channelId,
                engineInstanceId,
                sessionId: pending.sessionId,
                requestRecordId: pending.recordId,
                frame: delivered,
                outcome: 'unknown',
                error: faultFrom(cause, 'ENGINE_UNAVAILABLE'),
            }));
            throw toAcpError(cause, 'ENGINE_UNAVAILABLE');
        }
    };
    const handleEngineResponse = async (frame) => {
        const id = frame.id;
        const pending = childRequests.get(rpcIdKey(id));
        if (pending === undefined) {
            await safeAppend(historyEntry('result.unmatched', { engineInstanceId, frame, outcome: 'unknown' }));
            return;
        }
        removePendingRequest(pending);
        const channel = channels.get(pending.channelKey);
        if (channel === undefined) {
            await safeAppend(historyEntry('result.channel-missing', {
                engineInstanceId,
                sessionId: pending.sessionId,
                requestRecordId: pending.recordId,
                frame,
                outcome: 'unknown',
            }));
            return;
        }
        // The execution result is real even when its durable record is not. The
        // result is delivered; a failed append is reported through onHistoryFault.
        await safeAppend(historyEntry('result.received', {
            connectionId: channel.ref.connectionId,
            channelId: channel.ref.channelId,
            engineInstanceId,
            sessionId: pending.sessionId,
            requestRecordId: pending.recordId,
            frame,
            outcome: Object.hasOwn(frame, 'error') ? 'failed' : 'completed',
        }));
        let delivery = { ...frame, id: pending.originalId };
        if (pending.method === 'session/new') {
            const sessionId = resultSessionId(frame);
            if (sessionId !== undefined) {
                const owner = sessionOwners.get(sessionId);
                if (owner !== undefined && owner !== channel.key) {
                    delivery = rpcErrorFrame(pending.originalId, {
                        code: 'SESSION_OWNERSHIP_CONFLICT',
                        message: `engine returned session ${sessionId} already owned by another channel`,
                    });
                }
                else {
                    channel.sessions.add(sessionId);
                    sessionOwners.set(sessionId, channel.key);
                }
            }
        }
        if (pending.method === 'session/prompt'
            && channel.activePrompt !== undefined
            && channel.activePrompt.sessionId === pending.sessionId) {
            channel.activePrompt = undefined;
        }
        enqueue(channel, delivery);
    };
    const handleEngineCallback = async (frame) => {
        const method = methodOf(frame);
        if (method === undefined)
            throw new AcpError('INVALID_ACP_FRAME', 'engine callback requires a method');
        const engineId = frame.id;
        // The engine's real permission choice set is projected once, at the owning boundary,
        // before the callback reaches a controller (A2.6). A malformed set is refused here and
        // never forwarded as an unactionable permission request.
        let permissionOptions;
        if (method === 'session/request_permission') {
            try {
                permissionOptions = projectPermissionOptions(frame);
            }
            catch (cause) {
                const fault = faultFrom(cause, 'CALLBACK_UNAVAILABLE');
                await safeAppend(historyEntry('callback.denied', { engineInstanceId, frame, outcome: 'denied', error: fault }));
                await respondCallbackError(engineId, fault);
                return;
            }
        }
        try {
            input.assertAllowed({ policy: input.policy, direction: 'from-engine', frame });
        }
        catch (cause) {
            const fault = faultFrom(cause, 'CALLBACK_UNAVAILABLE');
            await safeAppend(historyEntry('callback.denied', { engineInstanceId, frame, outcome: 'denied', error: fault }));
            await respondCallbackError(engineId, fault);
            return;
        }
        const sessionId = sessionIdOf(frame);
        let target;
        if (sessionId !== undefined) {
            target = channelBySession(sessionId);
        }
        else {
            const open = [...channels.values()].filter(channel => !channel.closed);
            if (open.length === 1)
                target = open[0];
        }
        if (target === undefined || target.closed) {
            const fault = { code: 'CALLBACK_UNAVAILABLE', message: 'no controller channel owns this callback' };
            await safeAppend(historyEntry('callback.unavailable', { engineInstanceId, sessionId, frame, outcome: 'unknown', error: fault }));
            if (method === 'session/request_permission')
                await sendPermissionCancellation(engineId);
            else
                await respondCallbackError(engineId, fault);
            return;
        }
        const outwardId = nextCallbackId();
        const idKey = rpcIdKey(outwardId);
        let entry;
        try {
            entry = await appendRecord(historyEntry('callback.dispatched', {
                connectionId: target.ref.connectionId,
                channelId: target.ref.channelId,
                engineInstanceId,
                sessionId,
                frame,
            }));
        }
        catch (cause) {
            // The callback must not reach an executor without a record; refuse it.
            await respondCallbackError(engineId, faultFrom(cause, 'HISTORY_UNAVAILABLE'));
            return;
        }
        const pending = { engineId, outwardId, channelKey: target.key, sessionId, method, recordId: entry.recordId,
            ...(permissionOptions === undefined ? {} : { permissionOptions }) };
        outwardCallbacks.set(idKey, pending);
        target.pendingCallbacks.set(idKey, pending);
        if (!enqueue(target, { ...frame, id: outwardId })) {
            // A callback the controller cannot receive is answered now, so the
            // engine never waits on an undelivered permission request.
            outwardCallbacks.delete(idKey);
            target.pendingCallbacks.delete(idKey);
            if (method === 'session/request_permission')
                await sendPermissionCancellation(engineId);
            else
                await respondCallbackError(engineId, { code: 'CALLBACK_UNAVAILABLE', message: 'controller delivery backlog is full' });
        }
    };
    const handleEngineNotification = async (frame) => {
        const sessionId = sessionIdOf(frame);
        const target = sessionId === undefined ? undefined : channelBySession(sessionId);
        if (target === undefined || target.closed) {
            // A necessary notification is recorded, never silently dropped.
            await safeAppend(historyEntry('notification.unrouted', { engineInstanceId, sessionId, frame, outcome: 'unknown' }));
            return;
        }
        await safeAppend(historyEntry('notification.received', {
            connectionId: target.ref.connectionId,
            channelId: target.ref.channelId,
            engineInstanceId,
            sessionId,
            frame,
        }));
        enqueue(target, frame);
    };
    const handleEngineFrame = async (frame) => {
        if (isResponseFrame(frame)) {
            await handleEngineResponse(frame);
            return;
        }
        if (isRequestFrame(frame)) {
            await handleEngineCallback(frame);
            return;
        }
        if (isNotificationFrame(frame)) {
            await handleEngineNotification(frame);
            return;
        }
        throw new AcpError('INVALID_ACP_FRAME', 'engine produced an unrecognized ACP frame');
    };
    const pump = async () => {
        while (!engineEnded) {
            let frame;
            try {
                frame = await input.handle.acp.read();
            }
            catch {
                onEngineEnd('stream ended');
                return;
            }
            try {
                await handleEngineFrame(parseAcpFrame(frame));
            }
            catch (cause) {
                await safeAppend(historyEntry('engine.protocol-fault', {
                    engineInstanceId,
                    frame,
                    outcome: 'failed',
                    error: faultFrom(cause, 'INVALID_ACP_FRAME'),
                }));
                onEngineEnd('protocol fault');
                return;
            }
        }
    };
    void pump();
    void input.handle.exited.then(() => onEngineEnd('exited'), () => onEngineEnd('exited'));
    void input.handle.acp.closed.then(() => onEngineEnd('closed'), () => onEngineEnd('closed'));
    const open = async (openInput) => {
        if (engineEnded)
            throw new AcpError('ENGINE_UNAVAILABLE', 'ACP engine is not available');
        if (openInput === null || typeof openInput !== 'object') {
            throw new AcpError('INVALID_ACP_FRAME', 'ACP open input is required');
        }
        assertRefShape(openInput.ref);
        assertPrincipal(openInput.principal);
        assertPolicyShape(openInput.policy);
        if (openInput.ref.engineInstanceId !== engineInstanceId
            || openInput.ref.targetGeneration !== input.handle.targetGeneration) {
            throw new AcpError('STALE_GENERATION', 'ACP channel ref does not match the initialized engine instance');
        }
        if (openInput.policy.engineInstanceId !== engineInstanceId || openInput.policy.revision !== input.policy.revision) {
            throw new AcpError('UNSUPPORTED_POLICY', 'ACP channel policy is not the active host policy');
        }
        const key = channelKeyOf(openInput.ref);
        if (channels.has(key))
            throw new AcpError('CONFLICT', 'ACP channel is already open');
        await appendRecord(historyEntry('channel.open', {
            connectionId: openInput.ref.connectionId,
            channelId: openInput.ref.channelId,
            engineInstanceId,
        }));
        channels.set(key, {
            key,
            ref: { ...openInput.ref },
            principal: { ...openInput.principal },
            policy: openInput.policy,
            sessions: new Set(),
            pendingRequests: new Map(),
            pendingCallbacks: new Map(),
            deliveries: [],
            nextSequence: 1,
            initialized: false,
            closed: false,
        });
    };
    const receive = async (ingress) => {
        if (ingress === null || typeof ingress !== 'object')
            throw new AcpError('INVALID_ACP_FRAME', 'ACP ingress must be an object');
        assertRefShape(ingress);
        if (ingress.engineInstanceId !== engineInstanceId || ingress.targetGeneration !== input.handle.targetGeneration) {
            throw new AcpError('STALE_GENERATION', 'ACP ingress ref does not match the initialized engine instance');
        }
        const channel = channels.get(channelKeyOf(ingress));
        if (channel === undefined)
            throw new AcpError('STALE_GENERATION', 'ACP channel is not open');
        if (engineEnded)
            throw new AcpError('ENGINE_UNAVAILABLE', 'ACP engine is not available');
        if (channel.closed)
            throw new AcpError('CONFLICT', 'ACP channel is closed');
        const frame = parseAcpFrame(ingress.frame);
        if (isResponseFrame(frame)) {
            await receiveClientResponse(channel, frame);
            return;
        }
        if (isRequestFrame(frame)) {
            await receiveClientRequest(channel, frame);
            return;
        }
        if (isNotificationFrame(frame)) {
            await receiveClientNotification(channel, frame);
            return;
        }
        throw new AcpError('INVALID_ACP_FRAME', 'ACP ingress must be a request, notification, or response');
    };
    const read = async (ref, afterSequence, limit) => {
        assertRefShape(ref);
        if (!Number.isSafeInteger(afterSequence) || afterSequence < 0) {
            throw new AcpError('INVALID_ACP_FRAME', 'afterSequence must be a non-negative safe integer');
        }
        if (!Number.isSafeInteger(limit) || limit < 1 || limit > MAX_READ_LIMIT) {
            throw new AcpError('INVALID_ACP_FRAME', `limit must be an integer from 1 to ${MAX_READ_LIMIT}`);
        }
        if (ref.engineInstanceId !== engineInstanceId || ref.targetGeneration !== input.handle.targetGeneration) {
            throw new AcpError('STALE_GENERATION', 'ACP read ref does not match the initialized engine instance');
        }
        const channel = channels.get(channelKeyOf(ref));
        if (channel === undefined)
            throw new AcpError('STALE_GENERATION', 'ACP channel is not open');
        const frames = channel.deliveries.filter(delivery => delivery.sequence > afterSequence).slice(0, limit);
        const nextSequence = frames.length > 0 ? frames[frames.length - 1].sequence : afterSequence;
        channel.deliveries = channel.deliveries.filter(delivery => delivery.sequence > nextSequence);
        return { frames, nextSequence };
    };
    const close = async (ref) => {
        assertRefShape(ref);
        const channel = channels.get(channelKeyOf(ref));
        if (channel === undefined)
            throw new AcpError('STALE_GENERATION', 'ACP channel is not open');
        if (channel.closed)
            return;
        channel.closed = true;
        await settlePendingRequests(channel, 'channel closed');
        await settlePendingCallbacks(channel, 'controller channel closed');
        releaseSessions(channel);
        await safeAppend(historyEntry('channel.close', {
            connectionId: channel.ref.connectionId,
            channelId: channel.ref.channelId,
            engineInstanceId,
        }));
    };
    const pendingPermissions = () => {
        const rows = [];
        for (const channel of channels.values()) {
            if (channel.closed)
                continue;
            for (const pending of channel.pendingCallbacks.values()) {
                // Only a permission callback carries an option set, and only a callback with a
                // Session can be matched to a Session write.
                if (pending.method !== 'session/request_permission' || pending.sessionId === undefined)
                    continue;
                rows.push({
                    ref: channel.ref,
                    sessionId: pending.sessionId,
                    permissionId: pending.outwardId,
                    options: pending.permissionOptions ?? [],
                });
            }
        }
        return rows;
    };
    const channelForSession = (sessionId) => {
        const channel = channelBySession(sessionId);
        // A closed channel cannot accept a write, so it must not be reported as the owner.
        return channel === undefined || channel.closed ? undefined : channel.ref;
    };
    const openedSessions = () => {
        const rows = [];
        for (const channel of channels.values()) {
            // A closed channel holds no Session any more, so it must not be reported as one — the same
            // rule `channelForSession` and `pendingPermissions` already apply. `releaseSessions` clears
            // the ids, but `close()` marks the channel closed and only then awaits its durable settling,
            // so a reader that samples this host inside that window would otherwise see the Sessions of
            // a channel that already stopped accepting writes.
            if (channel.closed)
                continue;
            for (const sessionId of channel.sessions)
                rows.push(sessionId);
        }
        return rows;
    };
    return { open, receive, read, close, pendingPermissions, channelForSession, openedSessions };
}
