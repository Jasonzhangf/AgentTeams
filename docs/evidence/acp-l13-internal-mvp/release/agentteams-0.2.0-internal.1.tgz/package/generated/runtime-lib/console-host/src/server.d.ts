import { type ConsoleApiOptions } from './http-api.ts';
export interface ConsoleServerOptions extends ConsoleApiOptions {
    readonly staticRoot: string;
    readonly uiRoot: string;
    readonly authenticationChallenge?: string;
    readonly tls?: {
        readonly cert: Buffer;
        readonly key: Buffer;
    };
}
/** Presentation/API transport only. Runtime supplies the authenticated remote client binding. */
export declare function createConsoleServer(options: ConsoleServerOptions): import("https").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse> | import("http").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse>;
