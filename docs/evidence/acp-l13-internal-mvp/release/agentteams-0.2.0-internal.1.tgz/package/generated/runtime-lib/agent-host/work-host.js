import { closeWork, completeRequest, confirmWorkDestroyed, createTrustedWorkAuthority, getRequest, proposeWork, requestWork, } from "../agent/work-resource.js";
export class WorkHostError extends Error {
    code;
    constructor(code, message) {
        super(`${code}: ${message}`);
        this.code = code;
    }
}
/** Composes execution with the Agent-owned ledger; no second allocation owner. */
export function createWorkHost({ ledger, policy, executor }) {
    const authority = createTrustedWorkAuthority();
    const executions = new Map();
    const closings = new Map();
    const authorizedWork = (consumer, workId) => {
        const work = ledger.snapshot.works.find(work => work.workId === workId);
        if (!work || consumer.accountId !== ledger.provider.accountId || consumer.scopeId !== ledger.provider.scopeId ||
            consumer.agentId !== work.consumerAgentId)
            throw new WorkHostError('FORBIDDEN', 'Work is not owned by this authenticated consumer');
        return work;
    };
    return {
        propose: (consumer, proposal) => structuredClone(proposeWork(ledger, consumer, proposal, policy())),
        get: (consumer, workId, requestId) => {
            authorizedWork(consumer, workId);
            return structuredClone(getRequest(ledger, workId, requestId));
        },
        request: async (consumer, input) => {
            const allocations = structuredClone(ledger.snapshot.allocations.filter(allocation => allocation.workId === input.control.workId));
            const admitted = requestWork(ledger, { authenticatedConsumer: consumer, request: input, policy: policy() });
            if (!admitted.executionAllowed)
                return structuredClone(admitted.request);
            const workId = admitted.request.control.workId;
            const requestId = admitted.request.control.requestId;
            const work = structuredClone(authorizedWork(consumer, workId));
            const request = structuredClone({ control: admitted.request.control, payload: admitted.request.payload });
            const key = JSON.stringify([workId, requestId]);
            const result = (async () => {
                let completion;
                try {
                    completion = await executor.execute(work, request, allocations);
                }
                catch (cause) {
                    // An exception is not proof that an external side effect stopped.
                    completion = { outcome: 'unknown', error: { code: 'RESULT_UNKNOWN',
                            message: cause instanceof Error ? cause.message : 'local executor completion is unconfirmed' } };
                }
                return structuredClone(completeRequest(ledger, authority, workId, requestId, completion));
            })().finally(() => { executions.delete(key); });
            executions.set(key, { workId, result });
            return result;
        },
        close: async (consumer, workId) => {
            authorizedWork(consumer, workId);
            const work = closeWork(ledger, consumer, workId);
            if (work.state === 'closed' || work.state === 'rejected')
                return structuredClone(work);
            const existing = closings.get(workId);
            if (existing)
                return structuredClone(await existing);
            const closing = (async () => {
                await Promise.all([...executions.values()].filter(item => item.workId === workId).map(item => item.result));
                const requests = ledger.snapshot.requests.filter(request => request.control.workId === workId);
                if (requests.some(request => request.state === 'unknown'))
                    throw new WorkHostError('RESULT_UNKNOWN', 'Work execution must be reconciled before destruction');
                if (requests.some(request => request.state === 'running' || request.state === 'cancel_requested')) {
                    throw new WorkHostError('RESULT_UNKNOWN', 'persisted execution has no local completion proof');
                }
                const allocations = structuredClone(ledger.snapshot.allocations.filter(allocation => allocation.workId === workId));
                const confirmation = await executor.destroy(structuredClone(work), allocations);
                if (confirmation?.destroyed !== true)
                    throw new WorkHostError('RESULT_UNKNOWN', 'resource destruction is unconfirmed');
                return structuredClone(confirmWorkDestroyed(ledger, authority, workId));
            })().finally(() => { closings.delete(workId); });
            closings.set(workId, closing);
            return structuredClone(await closing);
        },
    };
}
