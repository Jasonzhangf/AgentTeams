export class CliAdapterError extends Error {
    error;
    constructor(error) {
        super(`${error.code}: ${error.message}`);
        this.name = 'CliAdapterError';
        this.error = error;
    }
}
export function asAdapterError(error) {
    if (error instanceof CliAdapterError)
        return error.error;
    return {
        code: 'UNAVAILABLE',
        message: error instanceof Error ? error.message : String(error),
    };
}
