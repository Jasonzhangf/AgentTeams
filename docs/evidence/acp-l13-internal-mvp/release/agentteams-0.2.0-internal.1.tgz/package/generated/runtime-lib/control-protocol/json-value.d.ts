import type { JsonValue } from './agent-services.ts';
/** Validate without serializing: JSON.stringify would silently strip or coerce values. */
export declare function assertJsonValue(value: unknown, path: string, ancestors?: Set<object>): asserts value is JsonValue;
export declare function assertEnvelopeKeys(value: Record<string, unknown>, allowed: readonly string[], path: string): void;
