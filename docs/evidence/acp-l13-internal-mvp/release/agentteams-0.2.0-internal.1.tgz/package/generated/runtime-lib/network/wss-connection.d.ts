import type { ServiceErrorCode } from '../control-protocol/agent-services.ts';
/** Network owns bytes and socket lifecycle; callers own the wire protocol. */
export interface WssFrame {
    readonly bytes: Buffer;
    readonly binary: boolean;
}
export interface WssConnectionOptions {
    readonly endpoint: string;
    readonly credential: string;
    readonly ca?: string | Buffer;
    readonly connectTimeoutMs: number;
    readonly maxMessageBytes: number;
    readonly maxBufferedBytes: number;
    readonly maxPendingFrames: number;
}
export declare class WssConnectionError extends Error {
    readonly code: ServiceErrorCode;
    constructor(code: ServiceErrorCode, message: string, cause?: unknown);
}
export interface WssConnection {
    /** Resolves on actual socket closure. Never interpreted as request completion. */
    readonly closed: Promise<WssConnectionError>;
    read(): Promise<WssFrame>;
    /** Completion means local transport write only, never peer execution. */
    send(frame: WssFrame): Promise<void>;
    close(): Promise<void>;
}
export declare function connectWss(options: WssConnectionOptions, signal?: AbortSignal): Promise<WssConnection>;
