export declare const ENDPOINT_ERROR_CODES: readonly ["INVALID_IDENTITY", "INVALID_REVISION", "INVALID_LIFECYCLE", "DUPLICATE_ENDPOINT_ID", "CROSS_AGENT_OWNERSHIP", "CAPABILITY_OUTSIDE_ENDPOINT", "RESOURCE_OUTSIDE_ENDPOINT", "ENDPOINT_DISABLED", "STALE_REVISION", "NOT_FOUND", "CONFLICT", "INVALID_INPUT"];
export type EndpointErrorCode = (typeof ENDPOINT_ERROR_CODES)[number];
export interface EndpointError extends Error {
    readonly name: 'EndpointError';
    readonly code: EndpointErrorCode;
}
export declare function isEndpointError(error: unknown): error is EndpointError;
export declare function fail(code: EndpointErrorCode, message: string): never;
