import type { AuthenticatedAgent } from '../control-protocol/agent-services.ts';
import type { AcpChannelRef } from '../control-protocol/acp.ts';
import type { TeamsConnectionFrame } from '../control-protocol/teams-connection.ts';
import type { AcpPolicySnapshot } from '../config/acp-policy.ts';
import type { AcpHost } from '../agent-host/acp-host.ts';
import type { TeamsNegotiationState } from './teams-negotiation.ts';
export interface TeamsSessionTransport {
    /** The authenticated peer identity of this connection; never read from a payload. */
    readonly peer: AuthenticatedAgent;
    read(): Promise<unknown>;
    send(frame: TeamsConnectionFrame): Promise<void>;
    /** Resolves when the transport is gone, from either side. */
    readonly closed: Promise<unknown>;
    close(): Promise<void>;
}
export interface TeamsSessionChannelView {
    readonly peerConnectionId: string;
    readonly peerChannelId: string;
    readonly localRef: AcpChannelRef;
    readonly open: boolean;
}
export interface CreateTeamsSessionInput {
    /** The agreed negotiation for this connection; anything else refuses to open ACP. */
    readonly negotiation: TeamsNegotiationState;
    /** This side's transport-scoped connection id. */
    readonly connectionId: string;
    readonly transport: TeamsSessionTransport;
    readonly host: AcpHost;
    readonly policy: AcpPolicySnapshot;
    /** This daemon's engine instance; never taken from the wire. */
    readonly engineInstanceId: string;
    readonly pollIntervalMs?: number;
    readonly deliveryPageLimit?: number;
}
export interface TeamsSessionOpenInput {
    /** How long the initiator waits for `acp.open_ack`; defaults to 10s. */
    readonly timeoutMs?: number;
}
export interface TeamsSession {
    readonly connectionId: string;
    readonly peer: AuthenticatedAgent;
    readonly channels: readonly TeamsSessionChannelView[];
    /**
     * Initiator only (D00 amendment A3). Open one outbound ACP channel: name the
     * responder's own engine instance on `acp.open`, then adopt the `acp.open_ack`
     * ref as this side's peer ref. Call it before `run()`, because the handshake
     * drives its own reads. A responder session refuses it: the responder waits for
     * `acp.open` and never initiates a channel.
     */
    open(input?: TeamsSessionOpenInput): Promise<TeamsSessionChannelView>;
    /** Handle exactly one inbound Teams frame. */
    receive(frame: unknown): Promise<void>;
    /** Relay one page of host deliveries for every open channel. */
    flush(): Promise<void>;
    /** Read loop plus delivery pump; settles when the transport closes or `close` is called. */
    run(): Promise<void>;
    close(reason?: string): Promise<void>;
}
export declare function createTeamsSession(input: CreateTeamsSessionInput): TeamsSession;
