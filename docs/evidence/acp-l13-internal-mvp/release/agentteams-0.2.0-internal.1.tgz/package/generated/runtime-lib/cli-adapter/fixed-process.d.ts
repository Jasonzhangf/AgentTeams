export interface FixedProcessSpec {
    readonly executable: string;
    readonly argv: readonly string[];
    readonly cwd?: string;
    readonly env?: NodeJS.ProcessEnv;
    readonly stdin?: string;
    readonly timeoutMs?: number;
    readonly maxOutputBytes?: number;
    readonly readyToken?: string;
    readonly shell: false;
}
export interface FixedProcessResult {
    readonly exitCode: number | null;
    readonly signal: NodeJS.Signals | null;
    readonly timedOut: boolean;
    readonly outputLimitExceeded?: boolean;
    readonly stdout: string;
    readonly stderr: string;
}
export type FixedProcessRunner = (spec: FixedProcessSpec) => Promise<FixedProcessResult>;
export declare function runFixedProcess(spec: FixedProcessSpec): Promise<FixedProcessResult>;
export declare function assertProcessSucceeded(spec: FixedProcessSpec, result: FixedProcessResult): void;
