import { RuntimeConfigError, } from "../config/runtime-config.js";
import { compileOpenCodeConfig } from "../opencode-adapter/src/index.js";
import { startManagedOpenCode } from "./managed-opencode.js";
function sameUncertaintyIdentity(left, right) {
    return left.operation.operationId === right.operation.operationId &&
        left.operation.kind === right.operation.kind &&
        left.target.agentId === right.target.agentId &&
        left.target.targetGeneration === right.target.targetGeneration &&
        left.target.acceptedRevision === right.target.acceptedRevision &&
        left.target.acceptedSourceRevision === right.target.acceptedSourceRevision &&
        left.target.acceptedSourceHash === right.target.acceptedSourceHash &&
        left.target.endpointFingerprint === right.target.endpointFingerprint &&
        left.target.credentialRef === right.target.credentialRef &&
        left.substrate.pid === right.substrate.pid &&
        left.substrate.effectiveRevision === right.substrate.effectiveRevision &&
        left.substrate.effectiveHandleFingerprint === right.substrate.effectiveHandleFingerprint;
}
/** Owner-owned persistence adapter over the single RuntimeConfigPersistence/store lock. */
export function createManagedConfigOwnerPersistence(options) {
    const { agentId, persistence } = options;
    return {
        readRecovery: async (ownerAgentId) => {
            if (ownerAgentId !== agentId)
                throw new RuntimeConfigError({ code: 'FORBIDDEN', message: 'config: recovery owner does not match this daemon' });
            const view = await persistence.withLock(() => persistence.loadDaemonUnlocked(agentId));
            const fence = view.uncertain ?? [];
            if (view.applyState === 'uncertain' || fence.length > 0)
                return { state: 'uncertain', fence: { operations: fence } };
            return { state: 'clean' };
        },
        persistUncertainty: async (input) => {
            await persistence.withLock(() => persistence.saveObservationUnlocked(agentId, { kind: 'owner-fence', uncertain: input.fence }));
            return { persistence: 'committed' };
        },
        clearUncertainty: async (input) => {
            await persistence.withLock(async () => {
                const view = await persistence.loadDaemonUnlocked(agentId);
                const operations = view.uncertain ?? [];
                const remaining = operations.filter(record => !sameUncertaintyIdentity(record, input.expectedFence));
                await persistence.saveObservationUnlocked(agentId, {
                    kind: 'target-observation',
                    target: input.currentTarget,
                    removeUncertainOperationId: input.expectedFence.operation.operationId,
                    expectedUncertain: input.expectedFence,
                    effectiveRevision: input.effectiveRevision,
                    ...(remaining.length === 0 ? { lastApplyError: null } : {}),
                });
            });
            return { persistence: 'committed' };
        },
    };
}
function handleFingerprint(handle, pid) {
    return `${handle.url}\u0000${handle.effectiveRevision}\u0000${pid ?? ''}`;
}
function effectiveModelTarget(handle) {
    return { providerID: handle.compiled.primary.provider, modelID: handle.compiled.primary.model };
}
function uncertaintyError(error) {
    return { code: 'RESULT_UNKNOWN', message: error instanceof Error ? error.message : 'managed runtime outcome is unknown' };
}
function assertPriorSubstratesTerminated(fence) {
    for (const record of fence.operations) {
        const pid = record.substrate.pid;
        if (pid === undefined || !Number.isSafeInteger(pid) || pid <= 0) {
            throw new RuntimeConfigError({ code: 'RESULT_UNKNOWN', message: 'config: prior managed substrate identity is incomplete' });
        }
        let alive = false;
        try {
            process.kill(pid, 0);
            alive = true;
        }
        catch (error) {
            if (error.code === 'EPERM')
                alive = true;
        }
        if (alive)
            throw new RuntimeConfigError({ code: 'CONFLICT', message: `config: prior managed substrate pid=${pid} is still live or cannot be proven exited` });
    }
}
/** Serializes configuration replacement with operations using the owned substrate. */
export function createManagedConfigOwner(options, launch = startManagedOpenCode) {
    let current;
    let changing = false;
    let stopped = false;
    let active = 0;
    let uncertain = false;
    let lastTarget;
    const conflict = () => new RuntimeConfigError({ code: 'CONFLICT', message: 'Managed runtime has active or unconfirmed operations' });
    const fenceFor = (kind, target, handle, error) => ({
        target,
        operation: { operationId: `${kind}:${target.agentId}:${Date.now()}:${Math.random().toString(16).slice(2)}`, kind },
        error: uncertaintyError(error),
        substrate: {
            ...(handle.pid === undefined ? {} : { pid: handle.pid }),
            effectiveRevision: handle.effectiveRevision,
            effectiveHandleFingerprint: handleFingerprint(handle, handle.pid),
        },
    });
    const persistFence = async (fence) => {
        uncertain = true;
        try {
            await options.persistence.persistUncertainty({ fence, expectedAcceptedRevision: fence.target.acceptedRevision });
        }
        catch (error) {
            // The volatile fence stays set; the caller must surface an explicit typed failure.
            throw new RuntimeConfigError({ code: 'UNAVAILABLE', message: `config: durable uncertainty fence was not persisted: ${error instanceof Error ? error.message : String(error)}` });
        }
    };
    const owner = {
        async apply(request) {
            if (stopped)
                throw new RuntimeConfigError({ code: 'UNAVAILABLE', message: 'Managed runtime is stopped' });
            if (changing || active || uncertain)
                throw conflict();
            const compiled = compileOpenCodeConfig(request.config, options.agentId);
            changing = true;
            try {
                if (current) {
                    await current.stop();
                    current = undefined;
                }
                const handle = await launch({ ...options, compiled });
                current = handle;
                lastTarget = request.target;
                void handle.closed.then(() => { if (current === handle)
                    current = undefined; }, () => { if (current === handle)
                    current = undefined; });
                return { status: 'applied', effectiveRevision: handle.effectiveRevision };
            }
            catch (error) {
                // An ambiguous launch failure is a durable responsibility, not a silent retry.
                const handle = current ?? { url: '', effectiveRevision: request.target.acceptedRevision, pid: undefined };
                const fence = fenceFor('apply', request.target, handle, error);
                await persistFence(fence);
                return { status: 'uncertain', error: fence.error, fence };
            }
            finally {
                changing = false;
            }
        },
        async recover(readRequest) {
            const recovery = await options.persistence.readRecovery(options.agentId);
            if (recovery.state === 'clean') {
                uncertain = false;
                return 'clean';
            }
            uncertain = true;
            if (readRequest === undefined)
                return 'uncertain';
            const request = await readRequest();
            if (request === undefined)
                return 'uncertain';
            try {
                return await this.reconcile(request);
            }
            catch {
                uncertain = true;
                return 'uncertain';
            }
        },
        async reconcile(request) {
            const recovery = await options.persistence.readRecovery(options.agentId);
            if (recovery.state === 'clean') {
                uncertain = false;
                return 'clean';
            }
            if (changing || active || stopped)
                throw conflict();
            changing = true;
            let replacement;
            try {
                assertPriorSubstratesTerminated(recovery.fence);
                const compiled = compileOpenCodeConfig(request.config, options.agentId);
                if (current) {
                    await current.stop();
                    current = undefined;
                }
                const handle = await launch({ ...options, compiled });
                replacement = handle;
                if (handle.effectiveRevision !== request.target.acceptedRevision) {
                    throw new RuntimeConfigError({ code: 'APPLY_TARGET_MISMATCH', message: 'config: recovery apply returned a mismatched effective revision' });
                }
                current = handle;
                lastTarget = request.target;
                void handle.closed.then(() => { if (current === handle)
                    current = undefined; }, () => { if (current === handle)
                    current = undefined; });
                for (const record of recovery.fence.operations) {
                    await options.persistence.clearUncertainty({ expectedFence: record, effectiveRevision: handle.effectiveRevision, currentTarget: request.target });
                }
                const after = await options.persistence.readRecovery(options.agentId);
                if (after.state === 'clean') {
                    uncertain = false;
                    return 'clean';
                }
                uncertain = true;
                return 'uncertain';
            }
            catch (error) {
                if (replacement !== undefined && current === replacement) {
                    try {
                        await replacement.stop();
                    }
                    catch { /* preserve the first recovery failure */ }
                    current = undefined;
                }
                uncertain = true;
                throw error instanceof RuntimeConfigError ? error : new RuntimeConfigError({ code: 'RESULT_UNKNOWN', message: error instanceof Error ? error.message : 'managed runtime reconcile is unknown' });
            }
            finally {
                changing = false;
            }
        },
        async use(operation) {
            if (changing || stopped || !current || uncertain)
                throw new RuntimeConfigError({ code: 'UNAVAILABLE', message: 'Managed runtime is not available' });
            const handle = current;
            const target = lastTarget;
            active++;
            try {
                return await operation({ url: handle.url, authorization: handle.authorization, effectiveRevision: handle.effectiveRevision,
                    ...(handle.pid === undefined ? {} : { pid: handle.pid }), modelTarget: effectiveModelTarget(handle) });
            }
            catch (error) {
                // A failed exchange is not proof that the substrate's operation ended.
                if (target !== undefined) {
                    const fence = fenceFor('use-session', target, handle, error);
                    await persistFence(fence);
                }
                else {
                    uncertain = true;
                }
                throw error;
            }
            finally {
                active--;
            }
        },
        readiness() {
            if (changing)
                return { state: 'changing' };
            if (stopped)
                return { state: 'stopped' };
            if (uncertain)
                return { state: 'uncertain', ...(current === undefined ? {} : { effectiveRevision: current.effectiveRevision }) };
            if (!current)
                return { state: 'no-current' };
            return { state: 'current', effectiveRevision: current.effectiveRevision, modelTarget: effectiveModelTarget(current), activeOperations: active };
        },
        currentHandle() {
            if (!current)
                return undefined;
            return { url: current.url, authorization: current.authorization, effectiveRevision: current.effectiveRevision,
                ...(current.pid === undefined ? {} : { pid: current.pid }), modelTarget: effectiveModelTarget(current) };
        },
        async stop() {
            if (changing || active || uncertain)
                throw conflict();
            stopped = true;
            if (current) {
                await current.stop();
                current = undefined;
            }
        },
        uncertainty: () => uncertain,
    };
    return owner;
}
