import { IncomingMessage, ServerResponse } from "node:http";
//#region ../control-protocol/endpoint-ref.d.ts
interface EndpointCapabilitySummary {
  readonly capabilityId: string;
  readonly version: string;
  readonly operations: readonly string[];
}
interface EndpointResourceSummary {
  readonly resourceId: string;
  readonly capacity: number;
  readonly unit: 'slot' | 'context';
}
//#endregion
//#region ../control-protocol/agent-services.d.ts
/** Shared service contracts, revision 1. Declarations do not implement transport or authorization. */
type JsonValue = null | boolean | number | string | readonly JsonValue[] | {
  readonly [key: string]: JsonValue;
};
type ServiceErrorCode = 'INVALID_INPUT' | 'UNAUTHENTICATED' | 'FORBIDDEN' | 'NOT_FOUND' | 'UNSUPPORTED_VERSION' | 'UNSUPPORTED_OPERATION' | 'STALE_GENERATION' | 'REVISION_CONFLICT' | 'RESOURCE_EXHAUSTED' | 'CONFLICT' | 'RESULT_UNKNOWN' | 'UNAVAILABLE' | 'UPSTREAM_ERROR';
interface CliExecutionFailure {
  readonly kind: 'cli';
  readonly code: string;
  readonly message: string;
  readonly contextId?: string;
  readonly exitCode?: number | null;
  readonly signal?: string | null;
  readonly stdout?: string;
  readonly stderr?: string;
}
interface ServiceError {
  readonly code: ServiceErrorCode;
  readonly message: string;
  readonly execution?: CliExecutionFailure;
}
interface AuthenticatedAgent {
  readonly accountId: string;
  readonly scopeId: string;
  readonly agentId: string;
}
type WorkState = 'accepted' | 'closing' | 'closed' | 'rejected';
//#endregion
//#region ../control-protocol/acp.d.ts
/** A complete JSON-RPC object. Teams control never flattens or rewrites it. */
type AcpFrame = Readonly<Record<string, JsonValue>>;
type AcpFaultCode = 'INVALID_ACP_FRAME' | 'UNSUPPORTED_METHOD' | 'UNSUPPORTED_CAPABILITY' | 'UNSUPPORTED_POLICY' | 'UNSUPPORTED_CONFIGURATION' | 'CAPABILITY_DENIED' | 'AUTHENTICATION_REQUIRED' | 'STALE_GENERATION' | 'SESSION_OWNERSHIP_CONFLICT' | 'CALLBACK_UNAVAILABLE' | 'ENGINE_UNAVAILABLE' | 'RESULT_UNKNOWN' | 'HISTORY_UNAVAILABLE' | 'CONFLICT' | 'FORBIDDEN';
interface AcpFault {
  readonly code: AcpFaultCode;
  readonly message: string;
  readonly detail?: JsonValue;
}
interface HistoryRecord {
  readonly recordId: string;
  readonly sequence: number;
  readonly occurredAt: string;
  readonly agentId: string;
  readonly kind: 'request' | 'connection';
  readonly event: string;
  readonly connectionId?: string;
  readonly channelId?: string;
  readonly engineInstanceId?: string;
  readonly requestRecordId?: string;
  readonly sessionId?: string;
  readonly frame?: AcpFrame;
  readonly agreement?: TeamsAgreement;
  readonly outcome?: 'completed' | 'failed' | 'denied' | 'unknown';
  readonly error?: AcpFault;
}
//#endregion
//#region ../control-protocol/teams-connection.d.ts
/**
 * D00 amendment A1 (effective 2026-10-11): the two negotiation frames that carry
 * this side's own facts also carry the integer accepted config policy revision
 * (`TeamsConnectionContext.policyRevision` and
 * `TeamsConnectionPropose.sourcePolicyRevision`), so the responder no longer
 * needs an unauthenticated caller-supplied `peerPolicyRevision`.
 *
 * The frame `version` stays 1. The key set is wire-visible, so a pre-A1 peer
 * that omits the key is refused `INVALID_ACP_FRAME` by the positive-integer
 * check below. A version bump would be required only if a v1 peer had shipped,
 * and none has: D05 was unclosed and no LAN peer was deployed.
 */
/** A relation is bilateral: master/peer or peer/peer. No subordinate alias exists. */
type RelationRole = 'master' | 'peer';
interface TeamsAgreement {
  readonly connectionId: string;
  /** A new connection starts this value at 1. */
  readonly relationRevision: number;
  readonly source: AuthenticatedAgent;
  readonly target: AuthenticatedAgent;
  readonly sourceRole: RelationRole;
  readonly targetRole: RelationRole;
  readonly sourceGeneration: number;
  readonly targetGeneration: number;
  readonly sourceCapabilitiesRevision: string;
  readonly targetCapabilitiesRevision: string;
  readonly sourcePolicyRevision: number;
  readonly targetPolicyRevision: number;
  /** Capabilities explicitly admitted for this connection. */
  readonly capabilities: readonly string[];
}
//#endregion
//#region ../control-protocol/teams-state.d.ts
/**
 * Public Teams lifecycle and history read surface. Owner: control-protocol.
 * Version: 1 for the connection-status and history-query shapes below.
 *
 * Request/execution lifecycle is intentionally NOT redefined here. The canonical
 * vocabulary stays `RequestState` in `agent-services.ts`; registration presence
 * stays the server directory health vocabulary. This module only adds the two
 * facts no existing owner declares: the transport/negotiation lifecycle of one
 * Teams connection, and the history read request/response shape.
 */
declare const TEAMS_CONNECTION_STATUS_VERSION = 1;
declare const TEAMS_HISTORY_QUERY_VERSION = 1;
/** Transport and negotiation lifecycle for one Teams connection. */
type TeamsConnectionState = 'disconnected' | 'connecting' | 'authenticating' | 'negotiating' | 'ready' | 'closed' | 'failed';
interface TeamsConnectionStatus {
  readonly version: typeof TEAMS_CONNECTION_STATUS_VERSION;
  readonly remoteAgentId: string;
  readonly state: TeamsConnectionState;
  /** The target daemon generation this observation belongs to. */
  readonly targetGeneration: number;
  /** Owner event time; never derived from UI animation. */
  readonly observedAt: string;
  readonly connectionId?: string;
  readonly role?: RelationRole;
  /** Present only for `failed`; `closed` carries no error. */
  readonly error?: AcpFault;
}
/** One page of owner-recorded history. Records keep their owning sequence. */
interface HistoryQuery {
  readonly version: typeof TEAMS_HISTORY_QUERY_VERSION;
  readonly kind?: 'request' | 'connection';
  readonly agentId?: string;
  readonly sessionId?: string;
  readonly limit: number;
  /** Return records with a strictly smaller sequence; enables paging. */
  readonly beforeSequence?: number;
}
interface HistoryPage {
  readonly records: readonly HistoryRecord[];
  /** Set only when more matching records exist before this page. */
  readonly nextBeforeSequence?: number;
}
/** Read-only history port. agent-host owns request history, network owns connection history. */
interface HistoryReadPort {
  query(query: HistoryQuery): Promise<HistoryPage>;
}
/**
 * One owner projection snapshot carried by the SSE stream. `seq` is the owner's own
 * monotonic projection sequence; a consumer that sees a gap treats the projection as
 * degraded instead of inventing the missing rows. The full projection is always carried,
 * so the UI never keeps a delta store as a second source of truth.
 */
interface ConsoleProjectionSnapshot {
  readonly seq: number;
  readonly projection: ConsoleProjectionV1;
}
/**
 * Owner projection feed. The owner decides when a snapshot exists and when the owner is
 * lost; a subscriber must never fabricate liveness after `onHealth` reports loss.
 */
interface ConsoleProjectionSink {
  onSnapshot(snapshot: ConsoleProjectionSnapshot): void;
  onHealth(state: SessionObservationState): void;
}
type ConsoleProjectionUnsubscribe = () => void;
/** SSE source. Returns the unsubscribe handle that the server calls when the stream ends. */
type ConsoleProjectionSubscriber = (sink: ConsoleProjectionSink) => ConsoleProjectionUnsubscribe;
//#endregion
//#region ../control-protocol/console-api.d.ts
/** Console config errors retain their owning service's code and provider/status context. */
interface ConsoleServiceError extends Omit<ServiceError, 'code'> {
  readonly code: ServiceErrorCode | 'CREDENTIAL_UNAVAILABLE' | 'SOURCE_CHANGED' | 'MIGRATION_CONFLICT' | 'APPLY_TARGET_MISMATCH';
  readonly message: string;
  readonly status?: number;
  readonly providerInstanceId?: string;
  /** Typed cancel unknown detail; never a business payload or log mirror. */
  readonly detail?: SessionCancelUnknownDetail;
}
/** Console transport DTOs. Daemons own the source state and command authorization. */
interface ConsoleProviderView {
  readonly id: string;
  readonly label: string;
  readonly protocol: 'openai-chat' | 'openai-responses';
  readonly apiBaseUrl: string;
  readonly enabled: boolean;
  readonly authKind: 'none' | 'bearer';
  readonly catalogState: 'ready' | 'empty' | 'stale' | 'error';
  readonly models: readonly {
    readonly id: string;
    readonly label?: string;
  }[];
  readonly error?: ConsoleServiceError;
}
interface ConsoleBindingRef {
  readonly providerInstanceId: string;
  readonly modelId: string;
}
interface ConsoleAcceptedBinding {
  readonly primary: ConsoleBindingRef;
  readonly backup?: ConsoleBindingRef;
}
interface ConsoleModelMetadata {
  readonly label?: string;
  readonly contextWindow?: number;
  readonly maxOutputTokens?: number;
  readonly tools?: boolean;
  readonly streaming?: boolean;
  readonly reasoning?: boolean;
  readonly inputModalities?: readonly string[];
  readonly outputModalities?: readonly string[];
}
interface ConsoleManualModelEntry {
  readonly ref: {
    readonly providerInstanceId: string;
    readonly modelId: string;
  };
  readonly origin: 'manual';
  readonly base: ConsoleModelMetadata;
  readonly overrides: ConsoleModelMetadata;
  readonly availability?: 'available' | 'unavailable';
}
/** Independent event-observation health; never a ManagedRuntimeReadiness branch. */
type SessionObservationState = {
  readonly state: 'live';
} | {
  readonly state: 'degraded';
  readonly reason: 'projection-loss' | 'stream-retry';
  readonly detail: string;
  readonly droppedEvents: number;
} | {
  readonly state: 'lost';
  readonly reason: 'stream-ended' | 'retry-exhausted';
  readonly detail: string;
};
/**
 * One engine-provided permission choice. `kind` reuses the decision vocabulary the
 * permission reply already carries; a daemon projects the option set verbatim from the
 * engine callback and never mints an option the engine did not offer.
 */
type ConsolePermissionOptionKind = 'once' | 'always' | 'reject';
interface ConsolePermissionOption {
  readonly optionId: string;
  readonly name: string;
  readonly kind: ConsolePermissionOptionKind;
}
/** The exact OpenCode structured error union retained on failed message/final/error events. */
interface OpenCodeStructuredError {
  readonly name: 'ProviderAuthError' | 'UnknownError' | 'MessageOutputLengthError' | 'MessageAbortedError' | 'APIError';
  readonly data: JsonValue;
}
interface ConsoleSessionEventBase {
  readonly eventId: string;
  readonly agentId: string;
  readonly sessionId: string;
  readonly occurredAt?: string;
}
/** Closed owner-projected Session event union. Every required identity comes from a real SDK event/part. */
type ConsoleSessionEventView = ConsoleSessionEventBase & {
  readonly kind: 'message';
  readonly state: 'pending' | 'completed';
  readonly messageId: string;
  readonly role: 'user' | 'assistant';
} | ConsoleSessionEventBase & {
  readonly kind: 'message';
  readonly state: 'failed';
  readonly messageId: string;
  readonly role: 'user' | 'assistant';
  readonly error: OpenCodeStructuredError;
} | ConsoleSessionEventBase & {
  readonly kind: 'part';
  readonly state: 'pending' | 'completed';
  readonly messageId: string;
  readonly partId: string;
  readonly partType: 'text' | 'reasoning';
  readonly text: string;
} | ConsoleSessionEventBase & {
  readonly kind: 'part';
  readonly state: 'observed';
  readonly messageId: string;
  readonly partId: string;
  readonly partType: 'file' | 'step-start' | 'step-finish' | 'snapshot' | 'patch' | 'agent' | 'retry' | 'compaction' | 'subtask';
  readonly sourcePart: JsonValue;
} | ConsoleSessionEventBase & {
  readonly kind: 'tool';
  readonly state: 'pending';
  readonly messageId: string;
  readonly partId: string;
  readonly callId: string;
  readonly tool: string;
  readonly input: JsonValue;
  readonly raw: string;
} | ConsoleSessionEventBase & {
  readonly kind: 'tool';
  readonly state: 'running';
  readonly messageId: string;
  readonly partId: string;
  readonly callId: string;
  readonly tool: string;
  readonly input: JsonValue;
  readonly title?: string;
  readonly metadata?: JsonValue;
} | ConsoleSessionEventBase & {
  readonly kind: 'tool';
  readonly state: 'completed';
  readonly messageId: string;
  readonly partId: string;
  readonly callId: string;
  readonly tool: string;
  readonly input: JsonValue;
  readonly output: string;
  readonly title: string;
  readonly metadata: JsonValue;
  readonly attachments?: readonly JsonValue[];
} | ConsoleSessionEventBase & {
  readonly kind: 'tool';
  readonly state: 'error';
  readonly messageId: string;
  readonly partId: string;
  readonly callId: string;
  readonly tool: string;
  readonly input: JsonValue;
  readonly error: string;
  readonly metadata?: JsonValue;
} | ConsoleSessionEventBase & {
  readonly kind: 'permission';
  readonly state: 'pending';
  readonly permissionId: string;
  readonly messageId: string;
  readonly callId?: string;
  readonly title: string;
  readonly metadata: JsonValue;
  /** Engine-provided choice set; absent when the engine callback offered none. */
  readonly options?: readonly ConsolePermissionOption[];
} | ConsoleSessionEventBase & {
  readonly kind: 'permission';
  readonly state: 'resolved';
  readonly permissionId: string;
  readonly decision: 'once' | 'always' | 'reject' | 'unknown';
  readonly rawResponse?: string;
} | ConsoleSessionEventBase & {
  readonly kind: 'final';
  readonly state: 'completed';
  readonly messageId: string;
  readonly finish?: string;
} | ConsoleSessionEventBase & {
  readonly kind: 'final';
  readonly state: 'failed';
  readonly messageId: string;
  readonly error: OpenCodeStructuredError;
} | ConsoleSessionEventBase & {
  readonly kind: 'error';
  readonly state: 'failed';
  readonly error: OpenCodeStructuredError;
  readonly correlation: {
    readonly kind: 'session';
    readonly sessionId: string;
  } | {
    readonly kind: 'message';
    readonly messageId: string;
  };
} | ConsoleSessionEventBase & {
  readonly kind: 'cancel';
  readonly state: 'accepted';
  readonly abortOperationId: string;
  readonly operationId: string;
  readonly sessionId: string;
  readonly runtimeGeneration: number;
  readonly effectiveRevision: number;
  readonly promptMessageId: string;
  readonly baseAccepted: true;
} | ConsoleSessionEventBase & {
  readonly kind: 'cancel';
  readonly state: 'rejected';
  readonly abortOperationId: string;
  readonly operationId: string;
  readonly sessionId: string;
  readonly runtimeGeneration: number;
  readonly effectiveRevision: number;
  readonly promptMessageId: string;
  readonly baseAccepted: false;
} | ConsoleSessionEventBase & {
  readonly kind: 'cancel';
  readonly state: 'reconciled';
  readonly abortOperationId: string;
  readonly operationId: string;
  readonly sessionId: string;
  readonly runtimeGeneration: number;
  readonly effectiveRevision: number;
  readonly promptMessageId: string;
  readonly baseAccepted: true;
  readonly finalState: 'cancelled';
  readonly messageId: string;
  readonly errorName: 'MessageAbortedError';
  readonly causalEvidence: 'unique-owned-message';
} | ConsoleSessionEventBase & {
  readonly kind: 'cancel';
  readonly state: 'unknown';
  readonly abortOperationId?: string;
  readonly operationId?: string;
  readonly sessionId: string;
  readonly runtimeGeneration?: number;
  readonly effectiveRevision?: number;
  readonly promptMessageId?: string;
  readonly baseAccepted?: boolean;
  readonly reason: 'abort-rejected' | 'no-final' | 'link-lost' | 'uncorrelated-idle' | 'ambiguous-owner' | 'stale-generation' | 'superseded';
};
/** Typed cancel unknown detail retained by the owning Session runtime. */
interface SessionCancelUnknownDetail {
  readonly kind: 'session.cancel';
  readonly sessionId: string;
  readonly operationId?: string;
  readonly promptMessageId?: string;
  readonly runtimeGeneration?: number;
  readonly effectiveRevision?: number;
  readonly baseAccepted?: boolean;
  readonly reconciliation: 'unknown';
  readonly finalState: 'unknown';
  readonly reason: 'abort-rejected' | 'no-final' | 'link-lost' | 'uncorrelated-idle' | 'ambiguous-owner' | 'stale-generation' | 'superseded';
  readonly abortOperationId?: string;
}
/**
 * Canonical Console summary of one published capability declaration. It reuses the
 * Endpoint summary field types and carries declared capacity only: never remaining
 * capacity, live usage, or an allocation ledger.
 */
interface ConsoleCapabilityDetail extends EndpointCapabilitySummary {
  readonly resources: readonly EndpointResourceSummary[];
}
/**
 * Agent management row. The runtime/directory discriminated union is not a Work capability and
 * is not a second source of config or runtime truth.
 *
 * `engine` and `lastSeenAt` are additive optional projections of existing owner sources: the
 * engine kind the agent daemon published and the directory observation time. A row that has no
 * owner value omits the field; a daemon never derives either from history or from UI state.
 */
interface ConsoleAgentObservationBaseV1 {
  readonly kind: 'runtime' | 'directory';
  readonly agentId: string;
  readonly label: string;
  readonly machineId: string;
  readonly generation?: number;
  readonly presence: 'online' | 'offline' | 'unknown';
  readonly capabilities: readonly string[];
  readonly capabilityDetails?: readonly ConsoleCapabilityDetail[];
  /** Engine kind declared by the owning agent daemon; mirrors the frozen config EngineKind. */
  readonly engine?: 'opencode' | 'dsh';
  /** Directory observation time of the owning peer; never a UI-side heartbeat. */
  readonly lastSeenAt?: string;
}
type ConsoleAgentObservationV1 = (ConsoleAgentObservationBaseV1 & {
  readonly kind: 'runtime';
  readonly sessionCapable: true;
  readonly sessionAvailability: 'changing' | 'stopped' | 'no-current' | 'uncertain' | 'current';
  readonly sessionObservation?: SessionObservationState;
  readonly sessionEffectiveRevision?: number;
  readonly currentSessionId?: string;
  readonly providerId?: string;
  readonly modelId?: string;
}) | (ConsoleAgentObservationBaseV1 & {
  readonly kind: 'runtime';
  readonly sessionCapable: false;
  readonly sessionAvailability: 'not-applicable';
}) | (ConsoleAgentObservationBaseV1 & {
  readonly kind: 'directory';
});
/**
 * One Teams connection row. It reuses the frozen `TeamsConnectionStatus` verbatim and only adds
 * the two facts that status cannot carry: whether the handshake is still half-open, and this
 * daemon's own relation role for the link. No synonym of the connection lifecycle is minted here.
 */
interface ConsoleConnectionView {
  readonly status: TeamsConnectionStatus;
  readonly halfOpen: boolean;
  readonly localRole?: RelationRole;
}
interface ConsoleProjectionV1 {
  readonly version: 1;
  readonly agents: readonly ConsoleAgentObservationV1[];
  readonly sessions: readonly {
    readonly agentId: string;
    readonly sessionId: string;
    readonly title?: string;
  }[];
  readonly notifications: readonly {
    readonly agentId: string;
    readonly notificationId: string;
    readonly sessionId?: string;
    readonly kind: 'notice' | 'permission';
    readonly state: 'pending' | 'resolved';
    readonly title: string;
    readonly permissionId?: string;
    readonly priority?: 'low' | 'normal' | 'high' | 'critical';
    readonly occurredAt?: string;
    readonly detail?: string;
  }[];
  readonly configs: readonly {
    readonly agentId: string;
    readonly acceptedRevision: number;
    readonly effectiveRevision?: number;
    /** Durable config-owner fence projection; always emitted by the U2 config binding. */
    readonly applyState?: 'clean' | 'uncertain';
    /** Accepted binding from the same config view; null before the first explicit accept. */
    readonly acceptedBinding?: ConsoleAcceptedBinding | null;
    readonly providers: readonly ConsoleProviderView[];
    readonly error?: ConsoleServiceError;
  }[];
  readonly sessionEvents?: readonly ConsoleSessionEventView[];
  readonly works?: readonly ConsoleWorkView[];
  readonly relations?: readonly ConsoleRelationView[];
  /** Additive Teams connection rows projected from the network status port; absent when unbound. */
  readonly connections?: readonly ConsoleConnectionView[];
}
interface ConsoleWorkView {
  readonly agentId: string;
  readonly workId: string;
  readonly consumerAgentId: string;
  readonly providerAgentId: string;
  readonly capabilityId: string;
  readonly capabilityVersion: string;
  readonly policyRevision: number;
  readonly state: WorkState;
}
interface ConsoleRelationView {
  readonly agentId: string;
  readonly consumerAgentId: string;
  readonly providerAgentId: string;
  readonly capabilityId: string;
  readonly capabilityVersion: string;
  readonly relationPermission: 'requested' | 'granted' | 'revoked';
  readonly workId?: string;
}
type ConsoleCommandV1 = {
  readonly kind: 'session.open';
  readonly agentId: string;
  readonly sessionId: string;
} | {
  readonly kind: 'session.create';
  readonly agentId: string;
  readonly title?: string;
} | {
  readonly kind: 'session.cancel';
  readonly agentId: string;
  readonly sessionId: string;
} | {
  readonly kind: 'permission.reply';
  readonly agentId: string;
  readonly sessionId: string;
  readonly permissionId: string;
  readonly decision: 'once' | 'always' | 'reject';
  /** Engine option chosen from the pending event's option set; omitted when the engine offered none. */
  readonly optionId?: string;
} | {
  readonly kind: 'notification.ack';
  readonly agentId: string;
  readonly notificationId: string;
} | {
  readonly kind: 'config.refreshModels';
  readonly agentId: string;
  readonly expectedRevision: number;
  readonly providerId: string;
} | {
  readonly kind: 'config.bindModel';
  readonly agentId: string;
  readonly expectedRevision: number;
  readonly providerId: string;
  readonly modelId: string;
} | {
  readonly kind: 'config.model.put';
  readonly agentId: string;
  readonly expectedRevision: number;
  readonly entry: ConsoleManualModelEntry;
} | {
  readonly kind: 'config.apply';
  readonly agentId: string;
} | {
  readonly kind: 'config.agent.select-backup';
  readonly agentId: string;
  readonly expectedRevision: number;
  readonly backup: {
    readonly providerInstanceId: string;
    readonly modelId: string;
  };
} | {
  readonly kind: 'config.putProvider';
  readonly agentId: string;
  readonly expectedRevision: number;
  readonly provider: {
    readonly id: string;
    readonly label: string;
    readonly protocol: ConsoleProviderView['protocol'];
    readonly apiBaseUrl: string;
    readonly enabled: boolean;
    readonly auth: {
      readonly kind: 'none';
    } | {
      readonly kind: 'bearer';
      readonly credentialRef: string;
    };
  };
} | {
  readonly kind: 'connection.connect';
  readonly agentId: string;
} | {
  readonly kind: 'connection.disconnect';
  readonly agentId: string;
} | {
  readonly kind: 'network.membership.apply';
  readonly agentId: string;
  readonly expectedRevision: number;
  readonly members: readonly {
    readonly agentId: string;
    readonly role: RelationRole;
  }[];
};
type ConsoleCommandResultV1 = {
  readonly ok: true;
  readonly result?: JsonValue;
} | {
  readonly ok: false;
  readonly error: ConsoleServiceError;
};
/** Host binding; no success is inferred when the transport or daemon reports failure. */
interface ConsoleClientV1 {
  readProjection(): Promise<ConsoleProjectionV1>;
  command(command: ConsoleCommandV1): Promise<ConsoleCommandResultV1>;
  /** Dedicated Session data ingress; business content never enters a host command. */
  sendSession(target: {
    readonly agentId: string;
    readonly sessionId: string;
  }, payload: JsonValue): Promise<ConsoleCommandResultV1>;
}
//#endregion
//#region src/http-api.d.ts
interface ConsoleApiOptions {
  /** Runtime authenticates this request and returns only its authorized daemon binding. */
  readonly authorize: (request: IncomingMessage) => Promise<ConsoleClientV1 | undefined>;
  /** Owner history reader. Absent means the control runtime has no bound history owner. */
  readonly history?: HistoryReadPort;
  /** Owner projection feed for the SSE stream. Absent means no stream can be offered. */
  readonly events?: ConsoleProjectionSubscriber;
  readonly maxBodyBytes?: number;
}
/** HTTP transport only: no Session, configuration, relationship or permission state is owned here. */
declare function createConsoleApiHandler(options: ConsoleApiOptions): (request: IncomingMessage, response: ServerResponse) => Promise<void>;
//#endregion
//#region src/server.d.ts
interface ConsoleServerOptions extends ConsoleApiOptions {
  readonly staticRoot: string;
  readonly uiRoot: string;
  readonly authenticationChallenge?: string;
  readonly tls?: {
    readonly cert: Buffer;
    readonly key: Buffer;
  };
}
/** Presentation/API transport only. Runtime supplies the authenticated remote client binding. */
declare function createConsoleServer(options: ConsoleServerOptions): import("https").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse> | import("http").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse>;
//#endregion
//#region src/auth.d.ts
/** Credentials are supplied by runtime; daemon management policy remains independent. */
declare function createConsoleAuthorization(options: {
  readonly username: string;
  readonly password: string;
  readonly origin: string;
  readonly client: ConsoleClientV1;
}): (request: IncomingMessage) => Promise<ConsoleClientV1 | undefined>;
//#endregion
export { type ConsoleApiOptions, type ConsoleServerOptions, createConsoleApiHandler, createConsoleAuthorization, createConsoleServer };